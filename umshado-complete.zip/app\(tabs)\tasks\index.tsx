import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  Alert,
  SafeAreaView,
  Modal,
  TextInput,
  ScrollView,
  ActivityIndicator,
  Switch,
} from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { useWeddingStore } from '@/stores/wedding';
import { formatDate, isOverdue } from '@/lib/date-utils';
import { DatePicker } from '@/components/ui/DatePicker';
import { 
  listTasks, 
  deleteTask, 
  createTask, 
  updateTask, 
  Task, 
  TaskStatus, 
  TaskPriority,
  TaskCategory,
  CreateTaskData,
} from '@/lib/task-service';
import { Logo } from '@/src/components/ui/Logo';

const colors = {
  primary: '#00a86b',
  primaryLight: '#E8F5F0',
  surface: '#FFFFFF',
  background: '#F5F5F5',
  text: '#1F2937',
  textLight: '#6B7280',
  textMuted: '#9CA3AF',
  border: '#E5E7EB',
  lightGray: '#F3F4F6',
  success: '#22C55E',
  warning: '#F59E0B',
  error: '#EF4444',
  white: '#FFFFFF',
  shadow: '#000000',
  blue: '#3B82F6',
};

export default function TasksScreen() {
  const { currentWedding } = useWeddingStore();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'pending' | 'in_progress' | 'completed'>('all');
  const [selectedPriority, setSelectedPriority] = useState<'all' | TaskPriority>('all');

  // Define categories and priorities arrays
  const categories: TaskCategory[] = [
    'venue', 'catering', 'photography', 'music', 'flowers', 'decor',
    'transport', 'attire', 'invitations', 'general'
  ];

  const priorities: TaskPriority[] = ['low', 'medium', 'high'];

  const statusOrder = { pending: 0, in_progress: 1, completed: 2 };

  const loadTasks = useCallback(async () => {
    if (!currentWedding?.id) {
      console.log('No current wedding found');
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const data = await listTasks(currentWedding.id);
      setTasks(data || []);
    } catch (error) {
      console.error('Error loading tasks:', error);
      Alert.alert('Error', 'Failed to load tasks. Please try again.');
      setTasks([]);
    } finally {
      setLoading(false);
    }
  }, [currentWedding?.id]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadTasks();
    setRefreshing(false);
  }, [loadTasks]);

  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  const filterTasks = (taskList: Task[]) => {
    return taskList.filter(task => {
      const statusMatch = selectedFilter === 'all' || task.status === selectedFilter;
      const priorityMatch = selectedPriority === 'all' || task.priority === selectedPriority;
      return statusMatch && priorityMatch;
    });
  };

  const sortTasks = (taskList: Task[]) => {
    return [...taskList].sort((a, b) => {
      // First sort by status
      const statusA = statusOrder[a.status];
      const statusB = statusOrder[b.status];
      
      if (statusA !== statusB) {
        return statusA - statusB;
      }
      
      // Then by priority (high to low)
      const priorityOrder = { high: 0, medium: 1, low: 2 };
      const priorityA = priorityOrder[a.priority];
      const priorityB = priorityOrder[b.priority];
      
      if (priorityA !== priorityB) {
        return priorityA - priorityB;
      }
      
      // Finally by due date
      if (a.due_date && b.due_date) {
        return new Date(a.due_date).getTime() - new Date(b.due_date).getTime();
      }
      
      return 0;
    });
  };

  const handleAddTask = async (taskData: Omit<CreateTaskData, 'wedding_id'>) => {
    if (!currentWedding?.id) {
      Alert.alert('Error', 'No active wedding found');
      return;
    }

    try {
      await createTask({
        ...taskData,
        wedding_id: currentWedding.id,
        assigned_to: undefined,
        estimated_hours: undefined,
        notes: undefined,
      });
      await loadTasks();
      setShowAddModal(false);
    } catch (error) {
      console.error('Error creating task:', error);
      Alert.alert('Error', 'Failed to create task. Please try again.');
    }
  };

  const handleEditTask = async (taskData: Partial<CreateTaskData> & { id: string }) => {
    try {
      await updateTask(taskData);
      await loadTasks();
      setEditingTask(null);
    } catch (error) {
      console.error('Error updating task:', error);
      Alert.alert('Error', 'Failed to update task. Please try again.');
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    Alert.alert(
      'Delete Task',
      'Are you sure you want to delete this task?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteTask(taskId);
              await loadTasks();
            } catch (error) {
              console.error('Error deleting task:', error);
              Alert.alert('Error', 'Failed to delete task. Please try again.');
            }
          },
        },
      ]
    );
  };

  const isTaskOverdue = (task: Task) => {
    return task.due_date && task.status !== 'completed' && isOverdue(task.due_date);
  };

  const filteredAndSortedTasks = sortTasks(filterTasks(tasks));

  const renderTask = ({ item }: { item: Task }) => {
    const overdue = isTaskOverdue(item);

    return (
      <View style={[styles.taskCard, overdue && styles.overdueTask]}>
        <View style={styles.taskHeader}>
          <View style={styles.taskInfo}>
            <Text style={styles.taskTitle}>{item.title}</Text>
            {item.description && (
              <Text style={styles.taskDescription}>{item.description}</Text>
            )}
          </View>
          <View style={styles.taskActions}>
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => setEditingTask(item)}
            >
              <Feather name="edit-2" size={16} color={colors.primary} />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => handleDeleteTask(item.id)}
            >
              <Feather name="trash-2" size={16} color={colors.error} />
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.taskMeta}>
          <View style={styles.metaItem}>
            <Text style={styles.metaLabel}>Category:</Text>
            <Text style={styles.metaValue}>{item.category}</Text>
          </View>
          <View style={styles.metaItem}>
            <Text style={styles.metaLabel}>Priority:</Text>
            <Text style={[styles.metaValue, { color: getPriorityColor(item.priority) }]}>
              {item.priority}
            </Text>
          </View>
          <View style={styles.metaItem}>
            <Text style={styles.metaLabel}>Status:</Text>
            <Text style={[styles.metaValue, { color: getStatusColor(item.status) }]}>
              {item.status.replace('_', ' ')}
            </Text>
          </View>
        </View>

        {item.due_date && (
          <View style={styles.taskFooter}>
            <Feather name="calendar" size={14} color={overdue ? colors.error : colors.textMuted} />
            <Text style={[styles.dueDate, overdue && styles.overdueDueDate]}>
              Due: {formatDate(item.due_date)}
            </Text>
            {overdue && (
              <Text style={styles.overdueLabel}>OVERDUE</Text>
            )}
          </View>
        )}
      </View>
    );
  };

  const getPriorityColor = (priority: TaskPriority) => {
    switch (priority) {
      case 'high': return colors.error;
      case 'medium': return colors.warning;
      case 'low': return colors.success;
      default: return colors.textMuted;
    }
  };

  const getStatusColor = (status: TaskStatus) => {
    switch (status) {
      case 'completed': return colors.success;
      case 'in_progress': return colors.blue;
      case 'pending': return colors.warning;
      default: return colors.textMuted;
    }
  };

  const getCategoryIcon = (category: TaskCategory) => {
    const iconMap: Record<TaskCategory, string> = {
      venue: 'map-pin',
      catering: 'coffee',
      photography: 'camera',
      music: 'music',
      flowers: 'heart',
      decor: 'star',
      transport: 'truck',
      attire: 'user',
      invitations: 'mail',
      general: 'clipboard',
    };
    return iconMap[category] || 'clipboard';
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <Stack.Screen
          options={{
            headerShown: false,
          }}
        />
        
        {/* Custom Header */}
        <View style={styles.headerSection}>
          <View style={styles.headerTop}>
            <Logo size="small" showText={false} />
            <Text style={styles.headerTitle}>Tasks</Text>
            <View style={styles.headerButtons} />
          </View>
        </View>
        
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>Loading tasks...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!currentWedding) {
    return (
      <SafeAreaView style={styles.container}>
        <Stack.Screen
          options={{
            headerShown: false,
          }}
        />
        
        {/* Custom Header */}
        <View style={styles.headerSection}>
          <View style={styles.headerTop}>
            <Logo size="small" showText={false} />
            <Text style={styles.headerTitle}>Tasks</Text>
            <View style={styles.headerButtons} />
          </View>
        </View>
        
        <View style={styles.emptyState}>
          <Feather name="calendar" size={64} color={colors.textMuted} />
          <Text style={styles.emptyStateTitle}>No Active Wedding</Text>
          <Text style={styles.emptyStateText}>
            Please create or select a wedding to manage tasks.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen
        options={{
          headerShown: false,
        }}
      />
      
      {/* Custom Header */}
      <View style={styles.headerSection}>
        <View style={styles.headerTop}>
          <Logo size="small" showText={false} />
          <Text style={styles.headerTitle}>Tasks</Text>
          <View style={styles.headerButtons}>
            <TouchableOpacity
              style={styles.addButton}
              onPress={() => setShowAddModal(true)}
            >
              <Feather name="plus" size={20} color={colors.white} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Filters */}
        <View style={styles.filtersSection}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filtersScrollView}>
            <TouchableOpacity
              style={[styles.filterChip, selectedFilter === 'all' && styles.filterChipActive]}
              onPress={() => setSelectedFilter('all')}
            >
              <Text style={[styles.filterChipText, selectedFilter === 'all' && styles.filterChipTextActive]}>
                All ({tasks.length})
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.filterChip, selectedFilter === 'pending' && styles.filterChipActive]}
              onPress={() => setSelectedFilter('pending')}
            >
              <Text style={[styles.filterChipText, selectedFilter === 'pending' && styles.filterChipTextActive]}>
                Pending ({tasks.filter(t => t.status === 'pending').length})
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.filterChip, selectedFilter === 'in_progress' && styles.filterChipActive]}
              onPress={() => setSelectedFilter('in_progress')}
            >
              <Text style={[styles.filterChipText, selectedFilter === 'in_progress' && styles.filterChipTextActive]}>
                In Progress ({tasks.filter(t => t.status === 'in_progress').length})
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.filterChip, selectedFilter === 'completed' && styles.filterChipActive]}
              onPress={() => setSelectedFilter('completed')}
            >
              <Text style={[styles.filterChipText, selectedFilter === 'completed' && styles.filterChipTextActive]}>
                Completed ({tasks.filter(t => t.status === 'completed').length})
              </Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>

      {/* Task List */}
      {filteredAndSortedTasks.length === 0 ? (
        <View style={styles.emptyState}>
          <Feather name="check-circle" size={64} color={colors.textMuted} />
          <Text style={styles.emptyStateTitle}>No Tasks Found</Text>
          <Text style={styles.emptyStateText}>
            {selectedFilter === 'all'
              ? 'Start planning by adding your first task!'
              : `No ${selectedFilter.replace('_', ' ')} tasks found.`}
          </Text>
        </View>
      ) : (
        <FlatList
          data={filteredAndSortedTasks}
          renderItem={renderTask}
          keyExtractor={(item) => item.id}
          style={styles.taskList}
          contentContainerStyle={styles.taskListContent}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={[colors.primary]}
              tintColor={colors.primary}
            />
          }
        />
      )}

      {/* Add/Edit Task Modal */}
      <TaskModal
        visible={showAddModal || !!editingTask}
        task={editingTask}
        categories={categories}
        priorities={priorities}
        onSave={(taskData) => {
          if (editingTask) {
            handleEditTask({ ...taskData, id: editingTask.id });
          } else {
            handleAddTask(taskData);
          }
        }}
        onCancel={() => {
          setShowAddModal(false);
          setEditingTask(null);
        }}
      />
    </SafeAreaView>
  );
}

interface TaskModalProps {
  visible: boolean;
  task?: Task | null;
  categories: TaskCategory[];
  priorities: TaskPriority[];
  onSave: (taskData: Omit<CreateTaskData, 'wedding_id'>) => void;
  onCancel: () => void;
}

function TaskModal({ visible, task, categories, priorities, onSave, onCancel }: TaskModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<TaskCategory>('general');
  const [priority, setPriority] = useState<TaskPriority>('medium');
  const [status, setStatus] = useState<TaskStatus>('pending');
  const [dueDate, setDueDate] = useState<Date | null>(null);
  const [showDatePicker, setShowDatePicker] = useState(false);

  useEffect(() => {
    if (task) {
      setTitle(task.title);
      setDescription(task.description || '');
      setCategory(task.category);
      setPriority(task.priority);
      setStatus(task.status);
      setDueDate(task.due_date ? new Date(task.due_date) : null);
    } else {
      setTitle('');
      setDescription('');
      setCategory('general');
      setPriority('medium');
      setStatus('pending');
      setDueDate(null);
    }
  }, [task, visible]);

  const handleSave = () => {
    if (!title.trim()) {
      Alert.alert('Error', 'Please enter a task title');
      return;
    }

    const taskData: Omit<CreateTaskData, 'wedding_id'> = {
      title: title.trim(),
      description: description.trim() || undefined,
      category,
      priority,
      status,
      due_date: dueDate?.toISOString(),
    };

    onSave(taskData);
  };

  const getCategoryIcon = (cat: TaskCategory) => {
    const iconMap: Record<TaskCategory, string> = {
      venue: 'map-pin',
      catering: 'coffee',
      photography: 'camera',
      music: 'music',
      flowers: 'heart',
      decor: 'star',
      transport: 'truck',
      attire: 'user',
      invitations: 'mail',
      general: 'clipboard',
    };
    return iconMap[cat] || 'clipboard';
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <SafeAreaView style={styles.modalContainer}>
        <View style={styles.modalHeader}>
          <TouchableOpacity onPress={onCancel}>
            <Text style={styles.modalCancelButton}>Cancel</Text>
          </TouchableOpacity>
          <Text style={styles.modalTitle}>{task ? 'Edit Task' : 'Add Task'}</Text>
          <TouchableOpacity onPress={handleSave}>
            <Text style={styles.modalSaveButton}>Save</Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.modalContent} showsVerticalScrollIndicator={false}>
          {/* Title */}
          <View style={styles.formGroup}>
            <Text style={styles.formLabel}>Title *</Text>
            <TextInput
              style={styles.formInput}
              value={title}
              onChangeText={setTitle}
              placeholder="Enter task title"
              placeholderTextColor={colors.textMuted}
            />
          </View>

          {/* Description */}
          <View style={styles.formGroup}>
            <Text style={styles.formLabel}>Description</Text>
            <TextInput
              style={[styles.formInput, styles.formTextArea]}
              value={description}
              onChangeText={setDescription}
              placeholder="Enter task description (optional)"
              placeholderTextColor={colors.textMuted}
              multiline
              numberOfLines={3}
            />
          </View>

          {/* Category */}
          <View style={styles.formGroup}>
            <Text style={styles.formLabel}>Category</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryScroll}>
              {categories.map((cat) => (
                <TouchableOpacity
                  key={cat}
                  style={[styles.categoryChip, category === cat && styles.categoryChipActive]}
                  onPress={() => setCategory(cat)}
                >
                  <Feather
                    name={getCategoryIcon(cat) as any}
                    size={16}
                    color={category === cat ? colors.white : colors.primary}
                  />
                  <Text style={[
                    styles.categoryChipText,
                    category === cat && styles.categoryChipTextActive
                  ]}>
                    {cat}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          {/* Priority */}
          <View style={styles.formGroup}>
            <Text style={styles.formLabel}>Priority</Text>
            <View style={styles.priorityContainer}>
              {priorities.map((p) => (
                <TouchableOpacity
                  key={p}
                  style={[styles.priorityChip, priority === p && styles.priorityChipActive]}
                  onPress={() => setPriority(p)}
                >
                  <Text style={[
                    styles.priorityChipText,
                    priority === p && styles.priorityChipTextActive
                  ]}>
                    {p}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Status (only show for editing) */}
          {task && (
            <View style={styles.formGroup}>
              <Text style={styles.formLabel}>Status</Text>
              <View style={styles.statusContainer}>
                {(['pending', 'in_progress', 'completed'] as TaskStatus[]).map((s) => (
                  <TouchableOpacity
                    key={s}
                    style={[styles.statusChip, status === s && styles.statusChipActive]}
                    onPress={() => setStatus(s)}
                  >
                    <Text style={[
                      styles.statusChipText,
                      status === s && styles.statusChipTextActive
                    ]}>
                      {s.replace('_', ' ')}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          )}

          {/* Due Date */}
          <View style={styles.formGroup}>
            <Text style={styles.formLabel}>Due Date</Text>
            <TouchableOpacity
              style={styles.dateButton}
              onPress={() => setShowDatePicker(true)}
            >
              <Feather name="calendar" size={20} color={colors.primary} />
              <Text style={styles.dateButtonText}>
                {dueDate ? formatDate(dueDate.toISOString()) : 'Select due date (optional)'}
              </Text>
              {dueDate && (
                <TouchableOpacity
                  onPress={() => setDueDate(null)}
                  style={styles.clearDateButton}
                >
                  <Feather name="x" size={16} color={colors.textMuted} />
                </TouchableOpacity>
              )}
            </TouchableOpacity>
          </View>
        </ScrollView>

        {/* Date Picker */}
        <DatePicker
          visible={showDatePicker}
          date={dueDate || new Date()}
          mode="date"
          onConfirm={(selectedDate) => {
            setDueDate(selectedDate);
            setShowDatePicker(false);
          }}
          onCancel={() => setShowDatePicker(false)}
        />
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  headerSection: {
    backgroundColor: colors.white,
    paddingTop: 20,
    paddingHorizontal: 20,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    shadowColor: colors.shadow,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  headerTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.text,
    flex: 1,
    textAlign: 'center',
  },
  headerButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  addButton: {
    backgroundColor: colors.primary,
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: colors.shadow,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  filtersSection: {
    marginBottom: 8,
  },
  filtersScrollView: {
    marginHorizontal: -20,
    paddingHorizontal: 20,
  },
  filterChip: {
    backgroundColor: colors.lightGray,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  filterChipActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  filterChipText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.textLight,
  },
  filterChipTextActive: {
    color: colors.white,
  },
  taskList: {
    flex: 1,
  },
  taskListContent: {
    padding: 20,
    paddingBottom: 100,
  },
  taskCard: {
    backgroundColor: colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
    shadowColor: colors.shadow,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  overdueTask: {
    borderColor: colors.error,
    borderWidth: 2,
  },
  taskHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  taskInfo: {
    flex: 1,
    marginRight: 12,
  },
  taskTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  taskDescription: {
    fontSize: 14,
    color: colors.textLight,
    lineHeight: 20,
  },
  taskActions: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    padding: 6,
  },
  taskMeta: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
    marginBottom: 12,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  metaLabel: {
    fontSize: 12,
    color: colors.textMuted,
    marginRight: 4,
  },
  metaValue: {
    fontSize: 12,
    fontWeight: '500',
    color: colors.text,
    textTransform: 'capitalize',
  },
  taskFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  dueDate: {
    fontSize: 12,
    color: colors.textMuted,
    marginLeft: 6,
    flex: 1,
  },
  overdueDueDate: {
    color: colors.error,
    fontWeight: '600',
  },
  overdueLabel: {
    fontSize: 10,
    fontWeight: '700',
    color: colors.error,
    backgroundColor: colors.error + '20',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  emptyStateTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.text,
    marginTop: 16,
    marginBottom: 8,
  },
  emptyStateText: {
    fontSize: 16,
    color: colors.textLight,
    textAlign: 'center',
    lineHeight: 24,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: colors.textLight,
  },

  // Modal styles
  modalContainer: {
    flex: 1,
    backgroundColor: colors.background,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: colors.white,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  modalCancelButton: {
    fontSize: 16,
    color: colors.textLight,
  },
  modalSaveButton: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.primary,
  },
  modalContent: {
    flex: 1,
    padding: 20,
  },
  formGroup: {
    marginBottom: 24,
  },
  formLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 8,
  },
  formInput: {
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: colors.text,
  },
  formTextArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  categoryScroll: {
    marginHorizontal: -20,
    paddingHorizontal: 20,
  },
  categoryChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.primary,
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginRight: 8,
    gap: 6,
  },
  categoryChipActive: {
    backgroundColor: colors.primary,
  },
  categoryChipText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.primary,
    textTransform: 'capitalize',
  },
  categoryChipTextActive: {
    color: colors.white,
  },
  priorityContainer: {
    flexDirection: 'row',
    gap: 8,
  },
  priorityChip: {
    flex: 1,
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
  },
  priorityChipActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  priorityChipText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.textLight,
    textTransform: 'capitalize',
  },
  priorityChipTextActive: {
    color: colors.white,
  },
  statusContainer: {
    flexDirection: 'row',
    gap: 8,
  },
  statusChip: {
    flex: 1,
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
  },
  statusChipActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  statusChipText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.textLight,
    textTransform: 'capitalize',
  },
  statusChipTextActive: {
    color: colors.white,
  },
  dateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  dateButtonText: {
    flex: 1,
    fontSize: 16,
    color: colors.text,
  },
  clearDateButton: {
    padding: 4,
  },
});