import { supabase } from '@/lib/supabase';
import type { Guest, RSVPStatus } from '@/types/guest';

export async function fetchGuestsByStatus(weddingId: string, status?: RSVPStatus) {
  let q = supabase.from('guest').select('*').eq('wedding_id', weddingId).order('created_at', { ascending: false });
  if (status) q = q.eq('rsvp_status', status);
  const { data, error } = await q.returns<Guest[]>();
  if (error) throw error;
  return data ?? [];
}

export async function updateGuestStatus(guestId: string, status: RSVPStatus) {
  const { data, error } = await supabase.from('guest').update({ rsvp_status: status }).eq('id', guestId).select().single();
  if (error) throw error;
  return data as Guest;
}

export async function rsvpCounts(weddingId: string) {
  const statuses: RSVPStatus[] = ['going', 'maybe', 'declined', 'no_reply'];
  const counts: Record<RSVPStatus, number> = { going: 0, maybe: 0, declined: 0, no_reply: 0 };
  await Promise.all(
    statuses.map(async (s) => {
      const { count, error } = await supabase
        .from('guest')
        .select('id', { count: 'exact', head: true })
        .eq('wedding_id', weddingId)
        .eq('rsvp_status', s);
      if (error) throw error;
      counts[s] = count ?? 0;
    })
  );
  return counts;
}




