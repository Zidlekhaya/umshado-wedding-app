// lib/wedding-service.ts
import { supabase } from './supabase';

export interface CreateWeddingPayload {
  name: string;
  date?: string;
  city?: string;
  culture?: string;
}


export interface Wedding {
  id: string;
  owner_id: string;
  name: string;
  date: string | null;
  location: string | null;
  culture: string | null;
  profile_picture?: string | null;
  ceremony_location?: string | null;
  reception_location?: string | null;
  city?: string | null;
  slug?: string | null;
  created_at?: string;
  updated_at?: string;
}

export async function createWedding(payload: CreateWeddingPayload): Promise<Wedding> {
  console.log('WeddingService: Creating wedding with payload:', payload);
  
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('No authenticated user');
  
  // Ensure date is 'YYYY-MM-DD'
  const dateStr =
    typeof payload.date === 'string'
      ? payload.date
      : payload.date ? new Date(payload.date).toISOString().slice(0, 10) : null;

  // Use city as location
  const location = payload.city ?? null;

  const { data, error } = await supabase
    .from('weddings')
    .insert([{
      owner_id: user.id,
      name: payload.name,
      date: dateStr,
      location: location,
      culture: payload.culture ?? null,
    }])
    .select('*')
    .single();

  if (error) {
    console.log('WeddingService: Error creating wedding:', error);
    throw error;
  }
  
  console.log('WeddingService: Wedding created successfully:', data);
  return data as Wedding;
}

export async function getWeddings(): Promise<Wedding[]> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('No authenticated user');

  const { data, error } = await supabase
    .from('weddings')
    .select('*')
    .eq('owner_id', user.id)
    .order('created_at', { ascending: false });

  if (error) {
    console.log('WeddingService: Error fetching weddings:', error);
    throw error;
  }

  return data || [];
}

export async function getCurrentWedding(): Promise<Wedding | null> {
  const weddings = await getWeddings();
  return weddings.length > 0 ? weddings[0] : null;
}


export async function invitePartner(weddingId: string, email: string) {
  const { data, error } = await supabase.rpc('invite_partner_secure', {
    p_wedding_id: weddingId,
    p_email: email.trim(),
  });
  if (error) throw error;
  // data is invite id or null if user already existed and was auto-added
  return data ?? null;
}

export async function acceptMyInvites() {
  const { data, error } = await supabase.rpc('accept_my_invites');
  if (error) {
    console.log('acceptMyInvites error:', error);
    // Don't throw - this is optional
  }
  return data;
}
