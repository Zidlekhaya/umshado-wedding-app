-- Check constraints on guests table
SELECT 
  conname as constraint_name,
  contype as constraint_type,
  pg_get_constraintdef(oid) as constraint_definition
FROM pg_constraint 
WHERE conrelid = 'guests'::regclass;

-- Check the actual rsvp_status column definition
SELECT 
  column_name,
  data_type,
  column_default,
  is_nullable
FROM information_schema.columns 
WHERE table_name = 'guests' 
AND column_name = 'rsvp_status';































