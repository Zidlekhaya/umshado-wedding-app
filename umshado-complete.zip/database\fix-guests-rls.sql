-- Fix RLS policy for guests table
-- Run this in your Supabase SQL editor

-- Enable RLS on guests table
ALTER TABLE guests ENABLE ROW LEVEL SECURITY;

-- Create RLS policy for guests table
CREATE POLICY "Users can manage guests of their weddings" ON guests FOR ALL USING (
  wedding_id IN (
    SELECT id FROM weddings WHERE owner_id = auth.uid()
    UNION
    SELECT wedding_id FROM wedding_members WHERE user_id = auth.uid()
  )
);

-- If wedding_members table doesn't exist, use this simpler policy:
-- CREATE POLICY "Users can manage guests of their weddings" ON guests FOR ALL USING (
--   wedding_id IN (
--     SELECT id FROM weddings WHERE owner_id = auth.uid()
--   )
-- );































