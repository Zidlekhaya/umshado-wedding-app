#!/usr/bin/env node

/**
 * Reset Session Script
 * This script clears all cached data and forces a fresh start
 */

const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing Supabase environment variables');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function resetSession() {
  console.log('🔄 Resetting session...\n');

  try {
    // Sign out to clear all cached data
    const { error } = await supabase.auth.signOut();
    
    if (error) {
      console.error('❌ Error signing out:', error.message);
      return;
    }

    console.log('✅ Session cleared successfully!');
    console.log('📱 Please refresh your app and sign in again');
    console.log('🎯 Use the vendor sign-in page to sign in as a vendor');

  } catch (error) {
    console.error('❌ Script failed:', error.message);
  }
}

// Run the reset
resetSession().then(() => {
  console.log('\n✨ Session reset completed');
  process.exit(0);
}).catch((error) => {
  console.error('❌ Script failed:', error);
  process.exit(1);
});
