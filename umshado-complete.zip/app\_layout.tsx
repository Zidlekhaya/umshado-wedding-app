// app/_layout.tsx
import '../polyfills';
import { Stack, Slot, Redirect, useSegments } from 'expo-router';
import { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator } from 'react-native';
import { supabase } from '@/lib/supabase';
import type { Session } from '@supabase/supabase-js';
import '@/src/lib/notifications'; // Register notification handler
import { initializePushNotifications, setupForegroundNotificationHandler, setupNotificationTapHandler } from '@/lib/notification-service';
import { useRouter } from 'expo-router';

export default function RootLayout() {
  const [session, setSession] = useState<Session | null>(null);
  const [initialized, setInitialized] = useState(false);
  const [userType, setUserType] = useState<'couple' | 'vendor' | null>(null);
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    console.log('ROUTE SEGMENTS:', segments);
  }, [segments]);

  // Initialize push notifications when user is authenticated
  useEffect(() => {
    if (session?.user && initialized) {
      console.log('🔔 Initializing push notifications for user:', session.user.id);
      initializePushNotifications().catch(console.error);
      
      // Setup notification handlers
      const foregroundSubscription = setupForegroundNotificationHandler();
      const tapSubscription = setupNotificationTapHandler((data) => {
        if (data.conversationId) {
          router.push(`/(chat)/${data.conversationId}`);
        }
      });
      
      return () => {
        foregroundSubscription.remove();
        tapSubscription.remove();
      };
    }
  }, [session, initialized, router]);

  useEffect(() => {
    console.log('Auth: initializing listener...');
    
    // 1) Load existing session once
    supabase.auth.getSession().then(({ data: { session } }) => {
      console.log('Auth: initial session =', !!session);
      setSession(session);
      
      // Set user type from initial session
      if (session?.user) {
        const userType = session.user.user_metadata?.user_type || 'couple';
        setUserType(userType);
        console.log('Initial user type:', userType);
        console.log('Initial user metadata:', session.user.user_metadata);
        
        // Check if user has vendor profile but wrong user_type
        if (userType === 'couple') {
          console.log('User type is couple, checking for vendor profile...');
          supabase
            .from('vendor_profiles')
            .select('*')
            .eq('user_id', session.user.id)
            .single()
            .then(({ data: vendorProfile, error }) => {
              if (!error && vendorProfile) {
                console.log('Found vendor profile, updating user metadata...');
                supabase.auth.updateUser({
                  data: {
                    user_type: 'vendor',
                    business_name: vendorProfile.business_name,
                    category: vendorProfile.category,
                    location: vendorProfile.location || vendorProfile.city
                  }
                }).then(() => {
                  console.log('User metadata updated to vendor');
                  setUserType('vendor');
                });
              }
            });
        }
      }
      
      setInitialized(true);
    });

    // 2) Listen for changes
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      console.log('Auth event:', event, 'hasSession=', !!session);
      setSession(session);
      
      // Update user type when session changes
      if (session?.user) {
        const userType = session.user.user_metadata?.user_type || 'couple';
        setUserType(userType);
        console.log('User type updated:', userType);
        console.log('User metadata:', session.user.user_metadata);
      } else {
        setUserType(null);
      }
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  console.log('Layout: Session state:', { session: session ? 'Found' : 'None', initialized });

  // ⚠️ Don't redirect until `initialized` is true
  if (!initialized) {
    console.log('Layout: Not initialized yet, showing loading...');
    return (
      <View style={{ 
        flex: 1, 
        justifyContent: 'center', 
        alignItems: 'center', 
        backgroundColor: '#F5F5F5' 
      }}>
        <ActivityIndicator size="large" color="#D4A373" />
        <Text style={{ 
          marginTop: 16, 
          fontSize: 16, 
          color: '#666',
          fontFamily: 'System'
        }}>
          Loading...
        </Text>
      </View>
    );
  }

  // Now guard routes
  if (!session) {
    console.log('Layout: No session, redirecting to user type selection...');
    // Not signed in: show user type selection first
    return (
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="user-type-selection" />
        <Stack.Screen name="(auth)/index" />
        <Stack.Screen name="(auth)/sign-in" />
        <Stack.Screen name="(auth)/sign-up" />
        <Stack.Screen name="(auth)/vendor-sign-in" />
        <Stack.Screen name="(auth)/vendor-sign-up" />
        <Redirect href="/user-type-selection" />
      </Stack>
    );
  }

  console.log('Layout: Session found, user type:', userType);
  console.log('Layout: Session user metadata:', session?.user?.user_metadata);
  
  // Route based on user type
  if (userType === 'vendor') {
    console.log('Layout: Routing vendor to vendor dashboard');
    return (
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(vendor)" />
        <Stack.Screen name="(chat)/[conversationId]" />
        <Stack.Screen name="(marketplace)" />
        <Redirect href="/(vendor)" />
      </Stack>
    );
  } else {
    console.log('Layout: Routing couple to HomeGate');
    // Default to couple app - include HomeGate for wedding checking
    return (
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="(tabs)" />
        <Redirect href="/" />
      </Stack>
    );
  }
}
