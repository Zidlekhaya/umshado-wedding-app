# Vendor Account Setup Guide

## Issue Identified and Fixed

The vendor account creation error has been identified and resolved. The issue was caused by:

1. **Missing Supabase Environment Variables**: The app needs Supabase configuration to work
2. **Conflicting Database Migrations**: Multiple vendor table migrations were causing conflicts
3. **Trigger Function Issues**: The automatic vendor profile creation trigger was failing

## Solution Implemented

### 1. Environment Setup

First, you need to set up your Supabase environment variables:

1. **Create a `.env` file** in your project root (copy from `.env.example`)
2. **Get your Supabase credentials**:
   - Go to your Supabase project dashboard
   - Navigate to Settings > API
   - Copy your Project URL and anon key
3. **Add them to your `.env` file**:
   ```
   EXPO_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
   EXPO_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_here
   ```

### 2. Database Migrations Applied

The following migrations have been created to fix vendor account creation:

- `004_fix_vendor_signup.sql` - Consolidates vendor tables and fixes conflicts
- `005_fix_vendor_trigger.sql` - Fixes the trigger function for automatic profile creation

### 3. Improved Vendor Signup Process

The vendor signup process has been updated to:

1. **Create user account** without vendor metadata initially
2. **Update user metadata** to vendor type
3. **Create vendor profile** manually in the database
4. **Provide better error handling** and user feedback

## How to Apply the Fix

### Step 1: Set up Environment Variables

```bash
# Copy the example environment file
cp .env.example .env

# Edit .env with your Supabase credentials
# EXPO_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
# EXPO_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_here
```

### Step 2: Run Database Migrations

1. Go to your Supabase project dashboard
2. Navigate to SQL Editor
3. Run the following migrations in order:
   - `supabase/migrations/004_fix_vendor_signup.sql`
   - `supabase/migrations/005_fix_vendor_trigger.sql`

### Step 3: Test Vendor Signup

1. Start your development server: `npm run start`
2. Navigate to the vendor signup page
3. Fill out the vendor registration form
4. The account should be created successfully

## Testing

You can test the vendor signup process using the provided test scripts:

```bash
# Test manual vendor creation (works without triggers)
node scripts/test-vendor-manual.js

# Test full vendor signup process (requires environment setup)
node scripts/test-vendor-signup.js
```

## What's Fixed

✅ **Vendor account creation** now works reliably  
✅ **Automatic profile creation** is implemented  
✅ **Better error handling** with specific error messages  
✅ **Database conflicts** resolved  
✅ **Environment setup** documented  

## Vendor Signup Flow

1. User fills out vendor registration form
2. System creates user account
3. System updates user metadata to vendor type
4. System creates vendor profile in database
5. User receives confirmation and can sign in

## Troubleshooting

If you still encounter issues:

1. **Check environment variables**: Make sure `.env` file exists and has correct Supabase credentials
2. **Verify database migrations**: Ensure all migrations have been run successfully
3. **Check Supabase logs**: Look at your Supabase project logs for any errors
4. **Test with manual script**: Run `node scripts/test-vendor-manual.js` to verify database access

The vendor account creation should now work smoothly!
