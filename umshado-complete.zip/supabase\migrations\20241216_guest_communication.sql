-- Create guest_rsvp table for tracking RSVP responses
CREATE TABLE IF NOT EXISTS public.guest_rsvp (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL,
  guest_id UUID NOT NULL,
  response TEXT NOT NULL CHECK (response IN ('going', 'maybe', 'declined', 'no_reply')),
  plus_ones INTEGER DEFAULT 0,
  dietary_requirements TEXT,
  song_requests TEXT,
  special_requests TEXT,
  responded_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create guest_communication table for tracking all communications
CREATE TABLE IF NOT EXISTS public.guest_communication (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL,
  guest_id UUID NOT NULL,
  communication_type TEXT NOT NULL CHECK (communication_type IN ('invite_sent', 'reminder_sent', 'rsvp_received', 'message_sent', 'call_made', 'email_sent')),
  message_content TEXT,
  template_id UUID,
  sent_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  status TEXT DEFAULT 'sent' CHECK (status IN ('sent', 'delivered', 'read', 'failed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create seating_chart table for table arrangements
CREATE TABLE IF NOT EXISTS public.seating_chart (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL,
  table_name TEXT NOT NULL,
  table_number INTEGER NOT NULL,
  capacity INTEGER NOT NULL DEFAULT 8,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create seating_assignments table for guest table assignments
CREATE TABLE IF NOT EXISTS public.seating_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL,
  guest_id UUID NOT NULL,
  table_id UUID NOT NULL REFERENCES public.seating_chart(id) ON DELETE CASCADE,
  seat_number INTEGER,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS guest_rsvp_wedding_idx ON public.guest_rsvp(wedding_id);
CREATE INDEX IF NOT EXISTS guest_rsvp_guest_idx ON public.guest_rsvp(guest_id);
CREATE INDEX IF NOT EXISTS guest_rsvp_response_idx ON public.guest_rsvp(response);

CREATE INDEX IF NOT EXISTS guest_communication_wedding_idx ON public.guest_communication(wedding_id);
CREATE INDEX IF NOT EXISTS guest_communication_guest_idx ON public.guest_communication(guest_id);
CREATE INDEX IF NOT EXISTS guest_communication_type_idx ON public.guest_communication(communication_type);
CREATE INDEX IF NOT EXISTS guest_communication_sent_at_idx ON public.guest_communication(sent_at);

CREATE INDEX IF NOT EXISTS seating_chart_wedding_idx ON public.seating_chart(wedding_id);
CREATE INDEX IF NOT EXISTS seating_assignments_wedding_idx ON public.seating_assignments(wedding_id);
CREATE INDEX IF NOT EXISTS seating_assignments_guest_idx ON public.seating_assignments(guest_id);
CREATE INDEX IF NOT EXISTS seating_assignments_table_idx ON public.seating_assignments(table_id);

-- Enable RLS
ALTER TABLE public.guest_rsvp ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.guest_communication ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.seating_chart ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.seating_assignments ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "select_own_guest_rsvp" ON public.guest_rsvp
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "insert_own_guest_rsvp" ON public.guest_rsvp
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "update_own_guest_rsvp" ON public.guest_rsvp
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "delete_own_guest_rsvp" ON public.guest_rsvp
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

-- Similar policies for other tables
CREATE POLICY "select_own_guest_communication" ON public.guest_communication
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "insert_own_guest_communication" ON public.guest_communication
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "select_own_seating_chart" ON public.seating_chart
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "insert_own_seating_chart" ON public.seating_chart
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "update_own_seating_chart" ON public.seating_chart
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "delete_own_seating_chart" ON public.seating_chart
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "select_own_seating_assignments" ON public.seating_assignments
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "insert_own_seating_assignments" ON public.seating_assignments
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "update_own_seating_assignments" ON public.seating_assignments
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "delete_own_seating_assignments" ON public.seating_assignments
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

-- Create updated_at triggers
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_guest_rsvp_updated
  BEFORE UPDATE ON public.guest_rsvp
  FOR EACH ROW
  EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_seating_chart_updated
  BEFORE UPDATE ON public.seating_chart
  FOR EACH ROW
  EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_seating_assignments_updated
  BEFORE UPDATE ON public.seating_assignments
  FOR EACH ROW
  EXECUTE FUNCTION set_updated_at();
















