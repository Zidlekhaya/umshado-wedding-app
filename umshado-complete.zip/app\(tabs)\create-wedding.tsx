import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { router } from 'expo-router';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Card } from '@/components/ui/Card';
import { Loading } from '@/components/ui/Loading';
import { Logo } from '@/src/components/ui/Logo';
import { colors, typography, spacing } from '@/src/theme/design-system';
import { createWedding } from '@/lib/wedding-service';
import { useWeddingStore } from '@/stores/wedding';
import { DatePicker } from '@/components/ui/DatePicker';

export default function CreateWedding() {
  const [weddingName, setWeddingName] = useState('');
  const [weddingDate, setWeddingDate] = useState('');
  const [weddingCity, setWeddingCity] = useState('');
  const [loading, setLoading] = useState(false);
  const { setCurrentWedding, setHasWedding } = useWeddingStore();

  const handleCreateWedding = async () => {
    if (!weddingName.trim()) {
      Alert.alert('Error', 'Please enter a wedding name');
      return;
    }

    // Validate date format if provided
    if (weddingDate && !/^\d{4}-\d{2}-\d{2}$/.test(weddingDate)) {
      Alert.alert('Error', 'Please enter date in YYYY-MM-DD format');
      return;
    }

    try {
      setLoading(true);
      
      console.log('Creating wedding with data:', {
        name: weddingName.trim(),
        date: weddingDate || undefined,
        city: weddingCity.trim() || undefined,
      });
      
      const wedding = await createWedding({
        name: weddingName.trim(),
        date: weddingDate || undefined,
        city: weddingCity.trim() || undefined,
      });

      console.log('Wedding created successfully:', wedding);
      
      // Update the store
      setCurrentWedding(wedding);
      setHasWedding(true);
      
      // Show success message
      Alert.alert(
        'Success!', 
        'Your wedding has been created successfully!',
        [
          {
            text: 'OK',
            onPress: () => router.replace('/(tabs)')
          }
        ]
      );
      
    } catch (error: any) {
      console.error('Error creating wedding:', error);
      
      // More specific error messages
      let errorMessage = 'Failed to create wedding';
      if (error.message?.includes('duplicate')) {
        errorMessage = 'A wedding with this name already exists';
      } else if (error.message?.includes('permission')) {
        errorMessage = 'You do not have permission to create a wedding';
      } else if (error.message?.includes('network')) {
        errorMessage = 'Network error. Please check your connection';
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      Alert.alert('Error', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <Loading size="large" color={colors.primary[500]} text="Creating your wedding..." />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Logo size="medium" showText={true} />
        <Text style={styles.title}>Create Your Wedding</Text>
        <Text style={styles.subtitle}>Let&apos;s get started with the basics</Text>
      </View>

      <Card variant="elevated" padding="lg" style={styles.formCard}>
        <Input
          label="Wedding Name *"
          placeholder="e.g., Thandi & Sipho's Wedding"
          value={weddingName}
          onChangeText={setWeddingName}
          variant="filled"
        />

        <DatePicker
          label="Wedding Date"
          placeholder="Select wedding date (optional)"
          value={weddingDate}
          onChange={(date) => setWeddingDate(date || '')}
          minimumDate={new Date()}
        />

        <Input
          label="City"
          placeholder="e.g., Johannesburg (optional)"
          value={weddingCity}
          onChangeText={setWeddingCity}
          variant="filled"
        />

        <View style={styles.buttonContainer}>
          <Button
            title="Create Wedding"
            onPress={handleCreateWedding}
            variant="primary"
            size="lg"
            style={styles.createButton}
            disabled={loading}
          />
          
          <Button
            title="Cancel"
            onPress={() => router.back()}
            variant="outline"
            size="lg"
            style={styles.cancelButton}
          />

        </View>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0fbe9',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0fbe9',
  },
  header: {
    paddingHorizontal: spacing[6],
    paddingTop: spacing[8],
    paddingBottom: spacing[4],
    alignItems: 'center',
  },
  title: {
    fontSize: typography.fontSize['3xl'],
    fontWeight: '700' as any,
    color: colors.text.primary,
    marginBottom: spacing[2],
  },
  subtitle: {
    fontSize: typography.fontSize.lg,
    color: colors.text.secondary,
    textAlign: 'center',
  },
  formCard: {
    marginHorizontal: spacing[6],
    marginBottom: spacing[6],
  },
  buttonContainer: {
    marginTop: spacing[6],
    gap: spacing[4],
  },
  createButton: {
    backgroundColor: colors.primary[500],
  },
  cancelButton: {
    borderColor: colors.border.primary,
  },
});
