import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { Vendor, createVendor, updateVendor } from '@/lib/vendor-service';
import { formatCurrency, parseCurrency, isValidCurrency } from '@/lib/money';

interface VendorFormProps {
  visible: boolean;
  onClose: () => void;
  onSuccess: () => void;
  vendor?: Vendor | null;
  weddingId: string;
}

const categories = [
  'venue',
  'catering',
  'photography',
  'music',
  'florist',
  'decor',
  'transportation',
  'makeup',
  'hair',
  'dress',
  'suit',
  'cake',
  'invitations',
  'officiant',
  'other'
];

const statusOptions = [
  { value: 'contacted', label: 'Contacted' },
  { value: 'quoted', label: 'Quoted' },
  { value: 'booked', label: 'Booked' },
  { value: 'confirmed', label: 'Confirmed' },
  { value: 'completed', label: 'Completed' },
  { value: 'cancelled', label: 'Cancelled' },
];

export default function VendorForm({ visible, onClose, onSuccess, vendor, weddingId }: VendorFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    contact_person: '',
    phone: '',
    email: '',
    website: '',
    address: '',
    city: '',
    province: '',
    estimated_cost: '',
    status: 'contacted' as 'contacted' | 'pending' | 'confirmed',
    notes: '',
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (vendor) {
      setFormData({
        name: vendor.name || '',
        category: vendor.category || '',
        contact_person: vendor.contact_person || '',
        phone: vendor.phone || '',
        email: vendor.email || '',
        website: vendor.website || '',
        address: vendor.address || '',
        city: vendor.city || '',
        province: vendor.province || '',
        estimated_cost: vendor.estimated_cost ? vendor.estimated_cost.toString() : '',
        status: vendor.status || 'contacted',
        notes: vendor.notes || '',
      });
    } else {
      setFormData({
        name: '',
        category: '',
        contact_person: '',
        phone: '',
        email: '',
        website: '',
        address: '',
        city: '',
        province: '',
        estimated_cost: '',
        status: 'contacted',
        notes: '',
      });
    }
    setErrors({});
  }, [vendor, visible]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Vendor name is required';
    }

    if (!formData.category.trim()) {
      newErrors.category = 'Category is required';
    }

    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (formData.phone && !/^[\+]?[0-9\s\-\(\)]{10,}$/.test(formData.phone)) {
      newErrors.phone = 'Please enter a valid phone number';
    }

    if (formData.website && !/^https?:\/\/.+/.test(formData.website)) {
      newErrors.website = 'Please enter a valid website URL (starting with http:// or https://)';
    }

    if (formData.estimated_cost && !isValidCurrency(formData.estimated_cost)) {
      newErrors.estimated_cost = 'Please enter a valid amount';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      return;
    }

    try {
      setLoading(true);
      
      const vendorData = {
        name: formData.name,
        category: formData.category as any,
        contact_person: formData.contact_person || undefined,
        phone: formData.phone || undefined,
        email: formData.email || undefined,
        website: formData.website || undefined,
        address: formData.address || undefined,
        city: formData.city || undefined,
        province: formData.province || undefined,
        estimated_cost: formData.estimated_cost ? parseCurrency(formData.estimated_cost) : undefined,
        status: formData.status,
        notes: formData.notes || undefined,
      };

      if (vendor) {
        await updateVendor({ id: vendor.id, ...vendorData });
      } else {
        await createVendor(weddingId, vendorData);
      }
      
      Alert.alert(
        'Success',
        vendor ? 'Vendor updated successfully' : 'Vendor added successfully'
      );
      
      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error saving vendor:', error);
      Alert.alert('Error', 'Failed to save vendor. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const renderCategorySelector = () => (
    <View style={styles.selectorContainer}>
      <Text style={styles.label}>Category *</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryScroll}>
        {categories.map((category) => (
          <TouchableOpacity
            key={category}
            style={[
              styles.categoryChip,
              formData.category === category && styles.categoryChipActive
            ]}
            onPress={() => handleInputChange('category', category)}
          >
            <Text style={[
              styles.categoryChipText,
              formData.category === category && styles.categoryChipTextActive
            ]}>
              {category}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      {errors.category && <Text style={styles.errorText}>{errors.category}</Text>}
    </View>
  );

  const renderStatusSelector = () => (
    <View style={styles.selectorContainer}>
      <Text style={styles.label}>Status</Text>
      <View style={styles.statusContainer}>
        {statusOptions.map((option) => (
          <TouchableOpacity
            key={option.value}
            style={[
              styles.statusChip,
              formData.status === option.value && styles.statusChipActive
            ]}
            onPress={() => handleInputChange('status', option.value)}
          >
            <Text style={[
              styles.statusChipText,
              formData.status === option.value && styles.statusChipTextActive
            ]}>
              {option.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  if (!visible) return null;

  return (
    <KeyboardAvoidingView
      style={styles.overlay}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>
            {vendor ? 'Edit Vendor' : 'Add New Vendor'}
          </Text>
          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <Feather name="x" size={24} color="#D4A373" />
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {/* Basic Information */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Basic Information</Text>
            
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Vendor Name *</Text>
              <TextInput
                style={[styles.input, errors.name && styles.inputError]}
                value={formData.name}
                onChangeText={(value) => handleInputChange('name', value)}
                placeholder="Enter vendor name"
                placeholderTextColor="#D3D3D3"
              />
              {errors.name && <Text style={styles.errorText}>{errors.name}</Text>}
            </View>

            {renderCategorySelector()}
            {renderStatusSelector()}
          </View>

          {/* Contact Information */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Contact Information</Text>
            
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Contact Person</Text>
              <TextInput
                style={styles.input}
                value={formData.contact_person}
                onChangeText={(value) => handleInputChange('contact_person', value)}
                placeholder="Enter contact person name"
                placeholderTextColor="#D3D3D3"
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Phone</Text>
              <TextInput
                style={[styles.input, errors.phone && styles.inputError]}
                value={formData.phone}
                onChangeText={(value) => handleInputChange('phone', value)}
                placeholder="Enter phone number"
                placeholderTextColor="#D3D3D3"
                keyboardType="phone-pad"
              />
              {errors.phone && <Text style={styles.errorText}>{errors.phone}</Text>}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Email</Text>
              <TextInput
                style={[styles.input, errors.email && styles.inputError]}
                value={formData.email}
                onChangeText={(value) => handleInputChange('email', value)}
                placeholder="Enter email address"
                placeholderTextColor="#D3D3D3"
                keyboardType="email-address"
                autoCapitalize="none"
              />
              {errors.email && <Text style={styles.errorText}>{errors.email}</Text>}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Website</Text>
              <TextInput
                style={[styles.input, errors.website && styles.inputError]}
                value={formData.website}
                onChangeText={(value) => handleInputChange('website', value)}
                placeholder="https://example.com"
                placeholderTextColor="#D3D3D3"
                keyboardType="url"
                autoCapitalize="none"
              />
              {errors.website && <Text style={styles.errorText}>{errors.website}</Text>}
            </View>
          </View>

          {/* Additional Information */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Additional Information</Text>
            
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Address</Text>
              <TextInput
                style={styles.input}
                value={formData.address}
                onChangeText={(value) => handleInputChange('address', value)}
                placeholder="Enter street address"
                placeholderTextColor="#D3D3D3"
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>City</Text>
              <TextInput
                style={styles.input}
                value={formData.city}
                onChangeText={(value) => handleInputChange('city', value)}
                placeholder="Enter city"
                placeholderTextColor="#D3D3D3"
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Province</Text>
              <TextInput
                style={styles.input}
                value={formData.province}
                onChangeText={(value) => handleInputChange('province', value)}
                placeholder="Enter province/state"
                placeholderTextColor="#D3D3D3"
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Estimated Cost</Text>
              <TextInput
                style={[styles.input, errors.estimated_cost && styles.inputError]}
                value={formData.estimated_cost}
                onChangeText={(value) => handleInputChange('estimated_cost', value)}
                placeholder="R 0.00"
                placeholderTextColor="#D3D3D3"
                keyboardType="numeric"
              />
              {errors.estimated_cost && <Text style={styles.errorText}>{errors.estimated_cost}</Text>}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Notes</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={formData.notes}
                onChangeText={(value) => handleInputChange('notes', value)}
                placeholder="Add any additional notes..."
                placeholderTextColor="#D3D3D3"
                multiline
                numberOfLines={4}
                textAlignVertical="top"
              />
            </View>
          </View>
        </ScrollView>

        {/* Actions */}
        <View style={styles.actions}>
          <TouchableOpacity
            style={styles.cancelButton}
            onPress={onClose}
            disabled={loading}
          >
            <Text style={styles.cancelButtonText}>Cancel</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.saveButton, loading && styles.saveButtonDisabled]}
            onPress={handleSubmit}
            disabled={loading}
          >
            {loading ? (
              <Text style={styles.saveButtonText}>Saving...</Text>
            ) : (
              <Text style={styles.saveButtonText}>
                {vendor ? 'Update Vendor' : 'Add Vendor'}
              </Text>
            )}
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  container: {
    backgroundColor: '#F5E8C7',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: '90%',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#D3D3D3',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#D4A373',
  },
  closeButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#FFFFFF',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  inputContainer: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: '#333',
    borderWidth: 1,
    borderColor: '#D3D3D3',
  },
  inputError: {
    borderColor: '#FF6B6B',
  },
  textArea: {
    height: 100,
  },
  errorText: {
    color: '#FF6B6B',
    fontSize: 14,
    marginTop: 4,
  },
  selectorContainer: {
    marginBottom: 16,
  },
  categoryScroll: {
    marginTop: 8,
  },
  categoryChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#D3D3D3',
    marginRight: 8,
  },
  categoryChipActive: {
    backgroundColor: '#D4A373',
    borderColor: '#D4A373',
  },
  categoryChipText: {
    fontSize: 14,
    color: '#D4A373',
    fontWeight: '500',
  },
  categoryChipTextActive: {
    color: '#FFFFFF',
  },
  statusContainer: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 8,
  },
  statusChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#D3D3D3',
  },
  statusChipActive: {
    backgroundColor: '#A9B7A0',
    borderColor: '#A9B7A0',
  },
  statusChipText: {
    fontSize: 14,
    color: '#666',
    fontWeight: '500',
  },
  statusChipTextActive: {
    color: '#FFFFFF',
  },
  actions: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderTopWidth: 1,
    borderTopColor: '#D3D3D3',
    gap: 12,
  },
  cancelButton: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 8,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#D3D3D3',
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#666',
    fontSize: 16,
    fontWeight: '600',
  },
  saveButton: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 8,
    backgroundColor: '#D4A373',
    alignItems: 'center',
  },
  saveButtonDisabled: {
    backgroundColor: '#D3D3D3',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
});
