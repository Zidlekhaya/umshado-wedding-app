import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  Alert,
  SafeAreaView,
  Modal,
  TextInput,
  ScrollView,
} from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { useWeddingStore } from '@/stores/wedding';
import { formatDate } from '@/lib/date-utils';
import { DatePicker } from '@/components/ui/DatePicker';
import { 
  listBudgetItems, 
  deleteBudgetItem, 
  upsertBudgetItem, 
  getBudgetSummary,
  recordPayment,
  listExpensesByItem,
  updateExpense,
  deleteExpense,
  BudgetItem,
  Expense
} from '@/lib/budget';
import { Card } from '@/components/ui/Card';
import { Loading } from '@/components/ui/Loading';
import { Logo } from '@/src/components/ui/Logo';

// Updated color scheme with balanced colors
const modernColors = {
  background: '#f0fbea',
  surface: '#FFFFFF',
  primary: '#00a86b',
  secondary: '#FF6B35',
  text: '#1A1A1A',
  textSecondary: '#6B7280',
  textLight: '#9CA3AF',
  border: '#E5E7EB',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  accent: '#F3F4F6',
  cardBackground: '#FFFFFF',
  shadow: 'rgba(0, 0, 0, 0.1)',
  white: '#FFFFFF',
  overBudget: '#EF4444',
  onTrack: '#10B981',
  // New balanced colors
  headerBg: '#F8FAFC', // Light gray instead of green
  headerText: '#1E293B', // Dark gray text
  buttonPrimary: '#00a86b', // Keep green for primary actions only
  buttonSecondary: '#64748B', // Gray for secondary actions
  progressBg: '#E2E8F0', // Light gray progress background
  progressFill: '#00a86b', // Green only for progress fill
};
import { formatCurrency } from '@/lib/money';

// Using modernColors instead of old colors

export default function BudgetScreen() {
  const [budgetSummary, setBudgetSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showEditPaymentModal, setShowEditPaymentModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState<BudgetItem | null>(null);
  const [editingItem, setEditingItem] = useState<BudgetItem | null>(null);
  const [editingPayment, setEditingPayment] = useState<Expense | null>(null);
  const [newItemName, setNewItemName] = useState('');
  const [newItemCategory, setNewItemCategory] = useState('');
  const [newItemPlanned, setNewItemPlanned] = useState('');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentVendor, setPaymentVendor] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [paymentMemo, setPaymentMemo] = useState('');
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const router = useRouter();
  const { currentWedding } = useWeddingStore();

  const loadBudgetSummary = useCallback(async () => {
    if (!currentWedding?.id) return;
    
    try {
      setLoading(true);
      const summary = await getBudgetSummary(currentWedding.id);
      setBudgetSummary(summary);
    } catch (error) {
      console.error('Error loading budget summary:', error);
      Alert.alert('Error', 'Failed to load budget data');
    } finally {
      setLoading(false);
    }
  }, [currentWedding?.id]);

  const loadExpenses = useCallback(async (itemId: string) => {
    try {
      const data = await listExpensesByItem(itemId);
      setExpenses(data);
    } catch (error) {
      console.error('Error loading expenses:', error);
    }
  }, []);

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadBudgetSummary();
    setRefreshing(false);
  }, [loadBudgetSummary]);

  const handleAddItem = useCallback(async () => {
    if (!currentWedding?.id || !newItemName.trim() || !newItemPlanned.trim()) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    try {
      await upsertBudgetItem({
        wedding_id: currentWedding.id,
        name: newItemName.trim(),
        category: newItemCategory.trim() || 'Other',
        planned: parseFloat(newItemPlanned) || 0,
        notes: null,
      });
      
      setNewItemName('');
      setNewItemCategory('');
      setNewItemPlanned('');
      setShowAddModal(false);
      await loadBudgetSummary();
      Alert.alert('Success', 'Budget item added successfully!');
    } catch (error) {
      console.error('Error adding item:', error);
      Alert.alert('Error', 'Failed to add budget item');
    }
  }, [currentWedding?.id, newItemName, newItemCategory, newItemPlanned, loadBudgetSummary]);

  const handleEditItem = useCallback(async () => {
    if (!editingItem || !newItemName.trim() || !newItemPlanned.trim()) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    try {
      await upsertBudgetItem({
        id: editingItem.id,
        wedding_id: editingItem.wedding_id,
        name: newItemName.trim(),
        category: newItemCategory.trim() || 'Other',
        planned: parseFloat(newItemPlanned) || 0,
        notes: editingItem.notes,
      });
      
      setNewItemName('');
      setNewItemCategory('');
      setNewItemPlanned('');
      setEditingItem(null);
      setShowEditModal(false);
      await loadBudgetSummary();
      Alert.alert('Success', 'Budget item updated successfully!');
    } catch (error) {
      console.error('Error updating item:', error);
      Alert.alert('Error', 'Failed to update budget item');
    }
  }, [editingItem, newItemName, newItemCategory, newItemPlanned, loadBudgetSummary]);

  const openEditModal = useCallback((item: BudgetItem) => {
    setEditingItem(item);
    setNewItemName(item.name);
    setNewItemCategory(item.category);
    setNewItemPlanned(item.planned.toString());
    setShowEditModal(true);
  }, []);

  const openEditPaymentModal = useCallback((payment: Expense) => {
    setEditingPayment(payment);
    setPaymentAmount(payment.amount.toString());
    setPaymentVendor(payment.vendor || '');
    setPaymentMethod(payment.method || '');
    setPaymentMemo(payment.memo || '');
    setShowEditPaymentModal(true);
  }, []);

  const handleEditPayment = useCallback(async () => {
    if (!editingPayment || !paymentAmount.trim()) {
      Alert.alert('Error', 'Please enter payment amount');
      return;
    }

    try {
      await updateExpense(editingPayment.id, {
        amount: parseFloat(paymentAmount) || 0,
        vendor: paymentVendor.trim() || null,
        method: paymentMethod.trim() || null,
        memo: paymentMemo.trim() || null,
      });
      
      setPaymentAmount('');
      setPaymentVendor('');
      setPaymentMethod('');
      setPaymentMemo('');
      setEditingPayment(null);
      setShowEditPaymentModal(false);
      await loadBudgetSummary();
      Alert.alert('Success', 'Payment updated successfully!');
    } catch (error) {
      console.error('Error updating payment:', error);
      Alert.alert('Error', 'Failed to update payment');
    }
  }, [editingPayment, paymentAmount, paymentVendor, paymentMethod, paymentMemo, loadBudgetSummary]);

  const handleDeletePayment = useCallback(async (payment: Expense) => {
    Alert.alert(
      'Delete Payment',
      `Are you sure you want to delete this payment of ${formatCurrency(payment.amount)}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteExpense(payment.id);
              await loadBudgetSummary();
            } catch (error) {
              console.error('Error deleting payment:', error);
              Alert.alert('Error', 'Failed to delete payment');
            }
          },
        },
      ]
    );
  }, [loadBudgetSummary]);

  const handleRecordPayment = useCallback(async () => {
    if (!selectedItem || !paymentAmount.trim()) {
      Alert.alert('Error', 'Please enter payment amount');
      return;
    }

    try {
      await recordPayment(selectedItem.id, {
        amount: parseFloat(paymentAmount) || 0,
        vendor: paymentVendor.trim() || null,
        paid_on: new Date().toISOString(),
        method: paymentMethod.trim() || null,
        memo: paymentMemo.trim() || null,
      });
      
      setPaymentAmount('');
      setPaymentVendor('');
      setPaymentMethod('');
      setPaymentMemo('');
      setShowPaymentModal(false);
      setSelectedItem(null);
      await loadBudgetSummary();
      Alert.alert('Success', 'Payment recorded successfully!');
    } catch (error) {
      console.error('Error recording payment:', error);
      Alert.alert('Error', 'Failed to record payment');
    }
  }, [selectedItem, paymentAmount, paymentVendor, paymentMethod, paymentMemo, loadBudgetSummary]);

  const handleDeleteItem = useCallback(async (item: BudgetItem) => {
    Alert.alert(
      'Delete Item',
      `Are you sure you want to delete ${item.name}? This will also delete all associated payments.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteBudgetItem(item.id);
              await loadBudgetSummary();
            } catch (error) {
              console.error('Error deleting item:', error);
              Alert.alert('Error', 'Failed to delete item');
            }
          },
        },
      ]
    );
  }, [loadBudgetSummary]);

  const getBudgetStatusColor = useCallback((item: any) => {
    if (item.percentage >= 100) return modernColors.overBudget;
    if (item.percentage >= 80) return modernColors.warning;
    return modernColors.onTrack;
  }, []);

  const getTabColor = useCallback(() => {
    if (!budgetSummary) return modernColors.primary;
    if (budgetSummary.totalSpent > budgetSummary.totalPlanned) return modernColors.overBudget;
    if (budgetSummary.totalSpent > budgetSummary.totalPlanned * 0.8) return modernColors.warning;
    return modernColors.onTrack;
  }, [budgetSummary]);

  const renderItem = ({ item }: { item: any }) => {
    const statusColor = getBudgetStatusColor(item);
    const isOverBudget = item.percentage >= 100;
    const hasActivity = item.spent > 0;
    const progressPercentage = Math.min((item.spent / item.item.planned) * 100, 100);
    
    return (
      <TouchableOpacity
        style={styles.walletCard}
        onPress={() => router.push(`/(tabs)/budget/item/${item.item.id}`)}
      >
        <View style={styles.walletInfo}>
          <Text style={styles.walletName}>{item.item.name}</Text>
          <Text style={styles.walletBalance}>
            {formatCurrency(item.item.planned)}
          </Text>
          
          {/* Progress Slider */}
          <View style={styles.progressContainer}>
            <View style={styles.progressBar}>
              <View 
                style={[
                  styles.progressFill, 
                  { 
                    width: `${progressPercentage}%`,
                    backgroundColor: isOverBudget ? modernColors.error : modernColors.progressFill
                  }
                ]} 
              />
            </View>
            <Text style={styles.progressText}>
              {formatCurrency(item.spent)} of {formatCurrency(item.item.planned)}
            </Text>
          </View>
          
          <View style={styles.activitySection}>
            <View style={styles.activityItem}>
              <Text style={styles.activityLabel}>Spent</Text>
              <Text style={[
                styles.activityValue, 
                { color: hasActivity ? modernColors.text : modernColors.textSecondary }
              ]}>
                {formatCurrency(item.spent)}
              </Text>
            </View>
            <View style={styles.activityItem}>
              <Text style={styles.activityLabel}>Remaining</Text>
              <Text style={[
                styles.activityValue, 
                { color: (item.item.planned - item.spent) > 0 ? modernColors.text : modernColors.error }
              ]}>
                {formatCurrency(item.item.planned - item.spent)}
              </Text>
            </View>
          </View>
        </View>
        
        <TouchableOpacity
          style={styles.recordPaymentButton}
          onPress={(e) => {
            e.stopPropagation();
            setSelectedItem(item.item);
            setShowPaymentModal(true);
          }}
        >
          <Feather name="credit-card" size={14} color={modernColors.white} />
          <Text style={styles.recordPaymentText}>Record Payment</Text>
        </TouchableOpacity>
      </TouchableOpacity>
    );
  };

  const renderExpense = ({ expense }: { expense: Expense }) => (
    <View style={styles.expenseCard}>
      <View style={styles.expenseInfo}>
        <Text style={styles.expenseAmount}>{formatCurrency(expense.amount)}</Text>
        <Text style={styles.expenseVendor}>{expense.vendor || 'No vendor'}</Text>
        <Text style={styles.expenseMethod}>{expense.method || 'No method'}</Text>
        {expense.memo && (
          <Text style={styles.expenseMemo}>{expense.memo}</Text>
        )}
        <Text style={styles.expenseDate}>
          {expense.paid_on ? formatDate(expense.paid_on) : 'No date'}
        </Text>
      </View>
      <View style={styles.expenseActions}>
        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => openEditPaymentModal(expense)}
        >
          <Feather name="edit" size={14} color={modernColors.primary} />
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => handleDeletePayment(expense)}
        >
          <Feather name="trash-2" size={14} color={modernColors.error} />
        </TouchableOpacity>
      </View>
    </View>
  );

  useEffect(() => {
    if (currentWedding?.id) {
      loadBudgetSummary();
    }
  }, [loadBudgetSummary, currentWedding?.id]);

  if (!currentWedding) {
    return (
      <SafeAreaView style={styles.container}>
        <Stack.Screen
          options={{
            headerShown: false,
          }}
        />
        <View style={styles.noWeddingContainer}>
          <Logo size="large" showText={true} />
          <Text style={styles.noWeddingTitle}>No Wedding Selected</Text>
          <Text style={styles.noWeddingSubtitle}>
            Please create a wedding first to manage your budget
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <Stack.Screen
          options={{
            title: 'Budget',
            headerRight: () => (
              <TouchableOpacity
                style={styles.headerButton}
                onPress={() => setShowAddModal(true)}
              >
                <Feather name="plus" size={24} color={modernColors.primary} />
              </TouchableOpacity>
            ),
          }}
        />
        <Loading size="large" color={modernColors.primary} text="Loading budget..." />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen
        options={{
          headerShown: false,
        }}
      />
      
      {/* Clean Header Section */}
      <View style={styles.headerSection}>
        <View style={styles.headerTop}>
          <Logo size="small" showText={false} />
          <Text style={styles.headerTitle}>Budget</Text>
          <View style={styles.headerSpacer} />
        </View>
        
        {/* Summary Box */}
        <View style={styles.summaryBox}>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Total Budget</Text>
            <Text style={styles.summaryValue}>
              {formatCurrency(budgetSummary?.totalPlanned || 0)}
            </Text>
          </View>
          <View style={styles.summaryDivider} />
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Spent</Text>
            <Text style={[
              styles.summaryValue,
              { color: (budgetSummary?.totalSpent || 0) > (budgetSummary?.totalPlanned || 0) ? modernColors.error : modernColors.text }
            ]}>
              {formatCurrency(budgetSummary?.totalSpent || 0)}
            </Text>
          </View>
          <View style={styles.summaryDivider} />
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Remaining</Text>
            <Text style={[
              styles.summaryValue,
              { color: ((budgetSummary?.totalPlanned || 0) - (budgetSummary?.totalSpent || 0)) > 0 ? modernColors.text : modernColors.error }
            ]}>
              {formatCurrency((budgetSummary?.totalPlanned || 0) - (budgetSummary?.totalSpent || 0))}
            </Text>
          </View>
        </View>
        
        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <TouchableOpacity 
            style={styles.addButton}
            onPress={() => setShowAddModal(true)}
          >
            <Feather name="plus" size={16} color={modernColors.white} />
            <Text style={styles.addButtonText}>Add Budget Item</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Budget Items List */}
      <View style={styles.content}>
        <FlatList
          data={budgetSummary?.items || []}
          keyExtractor={(item) => item.item.id}
          renderItem={renderItem}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              colors={[modernColors.teal]}
            />
          }
          contentContainerStyle={styles.listContainer}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Feather name="credit-card" size={48} color={modernColors.border} />
              <Text style={styles.emptyTitle}>No budget items yet</Text>
              <Text style={styles.emptySubtitle}>
                Add your first budget item to get started
              </Text>
            </View>
          }
        />
      </View>

      {/* Add Item Modal */}
      <Modal
        visible={showAddModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowAddModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Budget Item</Text>
              <TouchableOpacity
                onPress={() => setShowAddModal(false)}
                style={styles.closeButton}
              >
                <Feather name="x" size={24} color={modernColors.text} />
              </TouchableOpacity>
            </View>
            
            <ScrollView style={styles.modalBody}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Item Name *</Text>
                <TextInput
                  style={styles.textInput}
                  value={newItemName}
                  onChangeText={setNewItemName}
                  placeholder="e.g., Wedding Venue"
                  placeholderTextColor={modernColors.textLight}
                />
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Category</Text>
                <TextInput
                  style={styles.textInput}
                  value={newItemCategory}
                  onChangeText={setNewItemCategory}
                  placeholder="e.g., Venue, Catering, Photography"
                  placeholderTextColor={modernColors.textLight}
                />
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Planned Amount *</Text>
                <TextInput
                  style={styles.textInput}
                  value={newItemPlanned}
                  onChangeText={setNewItemPlanned}
                  placeholder="0.00"
                  placeholderTextColor={modernColors.textLight}
                  keyboardType="numeric"
                />
              </View>
            </ScrollView>
            
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowAddModal(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={handleAddItem}
              >
                <Text style={styles.saveButtonText}>Add Item</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Edit Item Modal */}
      <Modal
        visible={showEditModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowEditModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Edit Budget Item</Text>
              <TouchableOpacity
                onPress={() => setShowEditModal(false)}
                style={styles.closeButton}
              >
                <Feather name="x" size={24} color={modernColors.text} />
              </TouchableOpacity>
            </View>
            
            <ScrollView style={styles.modalBody}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Item Name *</Text>
                <TextInput
                  style={styles.textInput}
                  value={newItemName}
                  onChangeText={setNewItemName}
                  placeholder="e.g., Wedding Venue"
                  placeholderTextColor={modernColors.textLight}
                />
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Category</Text>
                <TextInput
                  style={styles.textInput}
                  value={newItemCategory}
                  onChangeText={setNewItemCategory}
                  placeholder="e.g., Venue, Catering, Photography"
                  placeholderTextColor={modernColors.textLight}
                />
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Planned Amount *</Text>
                <TextInput
                  style={styles.textInput}
                  value={newItemPlanned}
                  onChangeText={setNewItemPlanned}
                  placeholder="0.00"
                  placeholderTextColor={modernColors.textLight}
                  keyboardType="numeric"
                />
              </View>
            </ScrollView>
            
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowEditModal(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={handleEditItem}
              >
                <Text style={styles.saveButtonText}>Update Item</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Record Payment Modal */}
      <Modal
        visible={showPaymentModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowPaymentModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Record Payment</Text>
              <TouchableOpacity
                onPress={() => setShowPaymentModal(false)}
                style={styles.closeButton}
              >
                <Feather name="x" size={24} color={modernColors.text} />
              </TouchableOpacity>
            </View>
            
            <ScrollView style={styles.modalBody}>
              <Text style={styles.paymentItemName}>{selectedItem?.name}</Text>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Amount *</Text>
                <TextInput
                  style={styles.textInput}
                  value={paymentAmount}
                  onChangeText={setPaymentAmount}
                  placeholder="0.00"
                  placeholderTextColor={modernColors.textLight}
                  keyboardType="numeric"
                />
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Vendor</Text>
                <TextInput
                  style={styles.textInput}
                  value={paymentVendor}
                  onChangeText={setPaymentVendor}
                  placeholder="e.g., ABC Catering"
                  placeholderTextColor={modernColors.textLight}
                />
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Payment Method</Text>
                <TextInput
                  style={styles.textInput}
                  value={paymentMethod}
                  onChangeText={setPaymentMethod}
                  placeholder="e.g., Bank Transfer, Cash, Card"
                  placeholderTextColor={modernColors.textLight}
                />
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Memo</Text>
                <TextInput
                  style={[styles.textInput, styles.textArea]}
                  value={paymentMemo}
                  onChangeText={setPaymentMemo}
                  placeholder="Additional notes..."
                  placeholderTextColor={modernColors.textLight}
                  multiline
                  numberOfLines={3}
                />
              </View>
            </ScrollView>
            
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowPaymentModal(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={handleRecordPayment}
              >
                <Text style={styles.saveButtonText}>Record Payment</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Edit Payment Modal */}
      <Modal
        visible={showEditPaymentModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowEditPaymentModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Edit Payment</Text>
              <TouchableOpacity
                onPress={() => setShowEditPaymentModal(false)}
                style={styles.closeButton}
              >
                <Feather name="x" size={24} color={modernColors.text} />
              </TouchableOpacity>
            </View>
            
            <ScrollView style={styles.modalBody}>
              <Text style={styles.paymentItemName}>{editingPayment?.item_id}</Text>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Amount *</Text>
                <TextInput
                  style={styles.textInput}
                  value={paymentAmount}
                  onChangeText={setPaymentAmount}
                  placeholder="0.00"
                  placeholderTextColor={modernColors.textLight}
                  keyboardType="numeric"
                />
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Vendor</Text>
                <TextInput
                  style={styles.textInput}
                  value={paymentVendor}
                  onChangeText={setPaymentVendor}
                  placeholder="e.g., ABC Catering"
                  placeholderTextColor={modernColors.textLight}
                />
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Payment Method</Text>
                <TextInput
                  style={styles.textInput}
                  value={paymentMethod}
                  onChangeText={setPaymentMethod}
                  placeholder="e.g., Bank Transfer, Cash, Card"
                  placeholderTextColor={modernColors.textLight}
                />
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Memo</Text>
                <TextInput
                  style={[styles.textInput, styles.textArea]}
                  value={paymentMemo}
                  onChangeText={setPaymentMemo}
                  placeholder="Additional notes..."
                  placeholderTextColor={modernColors.textLight}
                  multiline
                  numberOfLines={3}
                />
              </View>
            </ScrollView>
            
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowEditPaymentModal(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={handleEditPayment}
              >
                <Text style={styles.saveButtonText}>Update Payment</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: modernColors.background,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  
  // Header Section
  headerSection: {
    backgroundColor: modernColors.headerBg,
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: modernColors.border,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: modernColors.headerText,
  },
  headerSpacer: {
    width: 40, // Same width as the removed settings button for balance
  },
  summaryBox: {
    backgroundColor: modernColors.white,
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: modernColors.border,
    shadowColor: modernColors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  summaryItem: {
    flex: 1,
    alignItems: 'center',
  },
  summaryLabel: {
    fontSize: 12,
    color: modernColors.text,
    marginBottom: 4,
    fontWeight: '500',
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: '700',
    color: modernColors.text,
    textAlign: 'center',
  },
  summaryDivider: {
    width: 1,
    height: 40,
    backgroundColor: modernColors.border,
    marginHorizontal: 10,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  addButton: {
    backgroundColor: modernColors.buttonPrimary,
    borderRadius: 12,
    paddingHorizontal: 24,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  addButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: modernColors.white,
  },
  
  // Wallet Cards
  listContainer: {
    paddingBottom: 20,
  },
  walletCard: {
    backgroundColor: modernColors.cardBackground,
    borderRadius: 12,
    padding: 20,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: modernColors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  walletInfo: {
    flex: 1,
  },
  walletName: {
    fontSize: 18,
    fontWeight: '700',
    color: modernColors.text,
    marginBottom: 8,
  },
  walletBalance: {
    fontSize: 16,
    fontWeight: '700',
    color: modernColors.text,
    marginBottom: 12,
  },
  progressContainer: {
    marginBottom: 16,
  },
  progressBar: {
    height: 8,
    backgroundColor: modernColors.progressBg,
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  progressText: {
    fontSize: 12,
    color: modernColors.textSecondary,
    textAlign: 'center',
  },
  activitySection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  activityItem: {
    flex: 1,
  },
  activityLabel: {
    fontSize: 12,
    color: modernColors.textSecondary,
    marginBottom: 4,
  },
  activityValue: {
    fontSize: 14,
    fontWeight: '600',
  },
  recordPaymentButton: {
    backgroundColor: modernColors.buttonPrimary,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginLeft: 16,
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 100,
    flexDirection: 'row',
    gap: 6,
  },
  recordPaymentText: {
    fontSize: 12,
    fontWeight: '600',
    color: modernColors.white,
  },
  
  // Expense Cards
  expenseCard: {
    backgroundColor: modernColors.white,
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  expenseInfo: {
    flex: 1,
  },
  expenseAmount: {
    fontSize: 14,
    fontWeight: '600',
    color: modernColors.primary,
  },
  expenseVendor: {
    fontSize: 14,
    color: modernColors.text,
    marginTop: 2,
  },
  expenseMethod: {
    fontSize: 12,
    color: modernColors.textLight,
    marginTop: 1,
  },
  expenseMemo: {
    fontSize: 12,
    color: modernColors.textLight,
    marginTop: 2,
    fontStyle: 'italic',
  },
  expenseDate: {
    fontSize: 10,
    color: modernColors.textLight,
    marginTop: 2,
  },
  expenseActions: {
    flexDirection: 'row',
    gap: 4,
  },
  
  // Empty State
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: modernColors.text,
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 14,
    color: modernColors.textLight,
    marginTop: 8,
    textAlign: 'center',
  },
  
  // Modals
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: modernColors.white,
    borderRadius: 20,
    width: '100%',
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: modernColors.border,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: modernColors.text,
  },
  closeButton: {
    padding: 4,
  },
  modalBody: {
    padding: 20,
    maxHeight: 400,
  },
  paymentItemName: {
    fontSize: 16,
    fontWeight: '600',
    color: modernColors.primary,
    textAlign: 'center',
    marginBottom: 20,
    padding: 12,
    backgroundColor: modernColors.background,
    borderRadius: 8,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: modernColors.text,
    marginBottom: 8,
  },
  textInput: {
    borderWidth: 1,
    borderColor: modernColors.border,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: modernColors.text,
    backgroundColor: modernColors.white,
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  modalActions: {
    flexDirection: 'row',
    padding: 20,
    gap: 12,
  },
  modalButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: modernColors.background,
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: modernColors.textLight,
  },
  saveButton: {
    backgroundColor: modernColors.primary,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: modernColors.white,
  },
  
  // No Wedding State
  noWeddingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  noWeddingTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: modernColors.text,
    marginTop: 24,
    marginBottom: 12,
    textAlign: 'center',
  },
  noWeddingSubtitle: {
    fontSize: 16,
    color: modernColors.textSecondary,
    textAlign: 'center',
    marginBottom: 32,
    lineHeight: 24,
  },
});

