import { palette } from './palette';

export const tokens = {
  radius: { xs: 8, sm: 12, md: 16, lg: 20, xl: 24 },
  space:  { xs: 6, sm: 10, md: 14, lg: 18, xl: 24, '2xl': 32 },
  shadow: {
    soft: { elevation: 2, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 6, shadowOffset: { width: 0, height: 3 } },
    card: { elevation: 3, shadowColor: '#000', shadowOpacity: 0.08, shadowRadius: 8, shadowOffset: { width: 0, height: 4 } },
  },
  palette,
};

export { palette };
export type Tokens = typeof tokens;
