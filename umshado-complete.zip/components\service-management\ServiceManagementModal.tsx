import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Alert,
  Modal,
  Switch,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Loading } from '@/components/ui/Loading';
import { supabase } from '@/lib/supabase';

const colors = {
  background: '#f0fbea',
  primary: '#00a86b',
  text: '#1A1A1A',
  textLight: '#6B7280',
  border: '#E5E7EB',
  success: '#10B981',
  error: '#EF4444',
  warning: '#F59E0B',
  white: '#FFFFFF',
  accent: '#F3F4F6',
};

interface ServiceItem {
  id?: string;
  item_name: string;
  item_description: string;
}

interface ServiceAddon {
  id?: string;
  title: string;
  description: string;
  price: number;
  price_type: 'fixed' | 'per_hour' | 'per_person';
}

interface VendorService {
  id: string;
  service_name: string;
  description: string;
  price_type: 'fixed' | 'per_hour' | 'per_person';
  price_min: number;
  price_max: number;
  duration_hours: number;
  includes: string[];
  add_ons: string[];
  is_active: boolean;
}

interface ServiceManagementModalProps {
  visible: boolean;
  service: VendorService | null;
  onClose: () => void;
  onServiceUpdated: (updatedService: VendorService) => void;
}

export default function ServiceManagementModal({
  visible,
  service,
  onClose,
  onServiceUpdated,
}: ServiceManagementModalProps) {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'items' | 'addons'>('details');
  
  // Service details
  const [serviceName, setServiceName] = useState('');
  const [description, setDescription] = useState('');
  const [priceType, setPriceType] = useState<'fixed' | 'per_hour' | 'per_person'>('fixed');
  const [priceMin, setPriceMin] = useState('');
  const [priceMax, setPriceMax] = useState('');
  const [durationHours, setDurationHours] = useState('');
  const [isActive, setIsActive] = useState(true);
  
  // Service items
  const [items, setItems] = useState<ServiceItem[]>([]);
  const [newItemName, setNewItemName] = useState('');
  const [newItemDescription, setNewItemDescription] = useState('');
  
  // Service addons
  const [addons, setAddons] = useState<ServiceAddon[]>([]);
  const [newAddonTitle, setNewAddonTitle] = useState('');
  const [newAddonDescription, setNewAddonDescription] = useState('');
  const [newAddonPrice, setNewAddonPrice] = useState('');
  const [newAddonPriceType, setNewAddonPriceType] = useState<'fixed' | 'per_hour' | 'per_person'>('fixed');

  useEffect(() => {
    if (service) {
      setServiceName(service.service_name);
      setDescription(service.description);
      setPriceType(service.price_type);
      setPriceMin(service.price_min.toString());
      setPriceMax(service.price_max.toString());
      setDurationHours(service.duration_hours.toString());
      setIsActive(service.is_active);
      
      // Convert includes array to items
      setItems(service.includes.map((item, index) => ({
        id: `item-${index}`,
        item_name: item,
        item_description: '',
      })));
      
      // Convert add_ons array to addons
      setAddons(service.add_ons.map((addon, index) => ({
        id: `addon-${index}`,
        title: addon,
        description: '',
        price: 0,
        price_type: 'fixed' as const,
      })));
    } else {
      // Reset form for new service
      setServiceName('');
      setDescription('');
      setPriceType('fixed');
      setPriceMin('');
      setPriceMax('');
      setDurationHours('');
      setIsActive(true);
      setItems([]);
      setAddons([]);
    }
  }, [service]);

  const handleSave = async () => {
    if (!serviceName.trim()) {
      Alert.alert('Error', 'Service name is required');
      return;
    }
    
    if (!priceMin.trim() || !priceMax.trim()) {
      Alert.alert('Error', 'Price range is required');
      return;
    }

    setLoading(true);
    try {
      if (service) {
        // Update existing service
        const { error } = await supabase
          .from('vendor_services')
          .update({
            service_name: serviceName.trim(),
            description: description.trim(),
            price_type: priceType,
            price_min: parseInt(priceMin),
            price_max: parseInt(priceMax),
            duration_hours: parseInt(durationHours) || 0,
            includes: items.map(item => item.item_name).filter(name => name.trim()),
            add_ons: addons.map(addon => addon.title).filter(title => title.trim()),
            is_active: isActive,
            updated_at: new Date().toISOString(),
          })
          .eq('id', service.id);

        if (error) {
          console.error('Error updating service:', error);
          Alert.alert('Error', 'Failed to update service');
          return;
        }

        Alert.alert('Success', 'Service updated successfully!');
        onServiceUpdated({
          ...service,
          service_name: serviceName.trim(),
          description: description.trim(),
          price_type: priceType,
          price_min: parseInt(priceMin),
          price_max: parseInt(priceMax),
          duration_hours: parseInt(durationHours) || 0,
          includes: items.map(item => item.item_name).filter(name => name.trim()),
          add_ons: addons.map(addon => addon.title).filter(title => title.trim()),
          is_active: isActive,
        });
        onClose();
      } else {
        // Create new service
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          Alert.alert('Error', 'Please sign in to create services');
          return;
        }

        // Get vendor profile
        const { data: vendorProfile } = await supabase
          .from('vendor_profiles')
          .select('id')
          .eq('user_id', user.id)
          .single();

        if (!vendorProfile) {
          Alert.alert('Error', 'Vendor profile not found');
          return;
        }

        const { data: newService, error } = await supabase
          .from('vendor_services')
          .insert({
            vendor_id: vendorProfile.id,
            service_name: serviceName.trim(),
            description: description.trim(),
            price_type: priceType,
            price_min: parseInt(priceMin),
            price_max: parseInt(priceMax),
            duration_hours: parseInt(durationHours) || 0,
            includes: items.map(item => item.item_name).filter(name => name.trim()),
            add_ons: addons.map(addon => addon.title).filter(title => title.trim()),
            is_active: isActive,
          })
          .select()
          .single();

        if (error) {
          console.error('Error creating service:', error);
          Alert.alert('Error', 'Failed to create service');
          return;
        }

        Alert.alert('Success', 'Service created successfully!');
        onServiceUpdated(newService);
        onClose();
      }
    } catch (error) {
      console.error('Error saving service:', error);
      Alert.alert('Error', `Failed to ${service ? 'update' : 'create'} service`);
    } finally {
      setLoading(false);
    }
  };

  const addItem = () => {
    if (!newItemName.trim()) {
      Alert.alert('Error', 'Item name is required');
      return;
    }
    
    const newItem: ServiceItem = {
      id: `item-${Date.now()}`,
      item_name: newItemName.trim(),
      item_description: newItemDescription.trim(),
    };
    
    setItems([...items, newItem]);
    setNewItemName('');
    setNewItemDescription('');
  };

  const removeItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const addAddon = () => {
    if (!newAddonTitle.trim()) {
      Alert.alert('Error', 'Addon title is required');
      return;
    }
    
    const newAddon: ServiceAddon = {
      id: `addon-${Date.now()}`,
      title: newAddonTitle.trim(),
      description: newAddonDescription.trim(),
      price: parseFloat(newAddonPrice) || 0,
      price_type: newAddonPriceType,
    };
    
    setAddons([...addons, newAddon]);
    setNewAddonTitle('');
    setNewAddonDescription('');
    setNewAddonPrice('');
    setNewAddonPriceType('fixed');
  };

  const removeAddon = (index: number) => {
    setAddons(addons.filter((_, i) => i !== index));
  };

  const renderTabButton = (tab: 'details' | 'items' | 'addons', label: string, icon: string) => (
    <TouchableOpacity
      style={[styles.tabButton, activeTab === tab && styles.tabButtonActive]}
      onPress={() => setActiveTab(tab)}
    >
      <Feather name={icon as any} size={16} color={activeTab === tab ? colors.white : colors.textLight} />
      <Text style={[styles.tabButtonText, activeTab === tab && styles.tabButtonTextActive]}>
        {label}
      </Text>
    </TouchableOpacity>
  );

  const renderDetailsTab = () => (
    <ScrollView style={styles.tabContent} showsVerticalScrollIndicator={false}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Service Information</Text>
        
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Service Name *</Text>
          <Input
            value={serviceName}
            onChangeText={setServiceName}
            placeholder="Enter service name"
            style={styles.input}
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Description</Text>
          <TextInput
            value={description}
            onChangeText={setDescription}
            placeholder="Describe your service"
            multiline
            numberOfLines={4}
            style={styles.textArea}
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Price Type</Text>
          <View style={styles.priceTypeContainer}>
            {(['fixed', 'per_hour', 'per_person'] as const).map((type) => (
              <TouchableOpacity
                key={type}
                style={[styles.priceTypeButton, priceType === type && styles.priceTypeButtonActive]}
                onPress={() => setPriceType(type)}
              >
                <Text style={[styles.priceTypeText, priceType === type && styles.priceTypeTextActive]}>
                  {type.replace('_', ' ').toUpperCase()}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.inputRow}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Min Price (R)</Text>
            <Input
              value={priceMin}
              onChangeText={setPriceMin}
              placeholder="0"
              keyboardType="numeric"
              style={styles.input}
            />
          </View>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Max Price (R)</Text>
            <Input
              value={priceMax}
              onChangeText={setPriceMax}
              placeholder="0"
              keyboardType="numeric"
              style={styles.input}
            />
          </View>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Duration (hours)</Text>
          <Input
            value={durationHours}
            onChangeText={setDurationHours}
            placeholder="0"
            keyboardType="numeric"
            style={styles.input}
          />
        </View>

        <View style={styles.inputGroup}>
          <View style={styles.switchContainer}>
            <Text style={styles.label}>Active Service</Text>
            <Switch
              value={isActive}
              onValueChange={setIsActive}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor={colors.white}
            />
          </View>
        </View>
      </View>
    </ScrollView>
  );

  const renderItemsTab = () => (
    <ScrollView style={styles.tabContent} showsVerticalScrollIndicator={false}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Service Includes</Text>
        
        {items.map((item, index) => (
          <View key={item.id || `item-${index}`} style={styles.itemCard}>
            <View style={styles.itemHeader}>
              <Text style={styles.itemName}>{item.item_name}</Text>
              <TouchableOpacity onPress={() => removeItem(index)} style={styles.removeButton}>
                <Feather name="x" size={16} color={colors.error} />
              </TouchableOpacity>
            </View>
            {item.item_description && (
              <Text style={styles.itemDescription}>{item.item_description}</Text>
            )}
          </View>
        ))}

        <View style={styles.addItemContainer}>
          <Text style={styles.addItemTitle}>Add New Item</Text>
          <Input
            value={newItemName}
            onChangeText={setNewItemName}
            placeholder="Item name"
            style={styles.input}
          />
          <TextInput
            value={newItemDescription}
            onChangeText={setNewItemDescription}
            placeholder="Item description (optional)"
            multiline
            numberOfLines={2}
            style={styles.textArea}
          />
          <Button
            title="Add Item"
            onPress={addItem}
            style={styles.addButton}
            textStyle={styles.addButtonText}
          />
        </View>
      </View>
    </ScrollView>
  );

  const renderAddonsTab = () => (
    <ScrollView style={styles.tabContent} showsVerticalScrollIndicator={false}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Service Add-ons</Text>
        
        {addons.map((addon, index) => (
          <View key={addon.id || `addon-${index}`} style={styles.addonCard}>
            <View style={styles.addonHeader}>
              <Text style={styles.addonTitle}>{addon.title}</Text>
              <TouchableOpacity onPress={() => removeAddon(index)} style={styles.removeButton}>
                <Feather name="x" size={16} color={colors.error} />
              </TouchableOpacity>
            </View>
            {addon.description && (
              <Text style={styles.addonDescription}>{addon.description}</Text>
            )}
            <Text style={styles.addonPrice}>
              R{addon.price.toLocaleString()} ({addon.price_type.replace('_', ' ')})
            </Text>
          </View>
        ))}

        <View style={styles.addItemContainer}>
          <Text style={styles.addItemTitle}>Add New Add-on</Text>
          <Input
            value={newAddonTitle}
            onChangeText={setNewAddonTitle}
            placeholder="Add-on title"
            style={styles.input}
          />
          <TextInput
            value={newAddonDescription}
            onChangeText={setNewAddonDescription}
            placeholder="Add-on description (optional)"
            multiline
            numberOfLines={2}
            style={styles.textArea}
          />
          <View style={styles.inputRow}>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Price (R)</Text>
              <Input
                value={newAddonPrice}
                onChangeText={setNewAddonPrice}
                placeholder="0"
                keyboardType="numeric"
                style={styles.input}
              />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Price Type</Text>
              <View style={styles.priceTypeContainer}>
                {(['fixed', 'per_hour', 'per_person'] as const).map((type) => (
                  <TouchableOpacity
                    key={type}
                    style={[styles.priceTypeButton, newAddonPriceType === type && styles.priceTypeButtonActive]}
                    onPress={() => setNewAddonPriceType(type)}
                  >
                    <Text style={[styles.priceTypeText, newAddonPriceType === type && styles.priceTypeTextActive]}>
                      {type.replace('_', ' ').toUpperCase()}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </View>
          <Button
            title="Add Add-on"
            onPress={addAddon}
            style={styles.addButton}
            textStyle={styles.addButtonText}
          />
        </View>
      </View>
    </ScrollView>
  );

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <Feather name="x" size={24} color={colors.text} />
          </TouchableOpacity>
          <Text style={styles.title}>{service ? 'Edit Service' : 'Create Service'}</Text>
          <TouchableOpacity onPress={handleSave} style={styles.saveButton} disabled={loading}>
            {loading ? (
              <Loading size="small" color={colors.white} />
            ) : (
              <Text style={styles.saveButtonText}>{service ? 'Save Changes' : 'Create Service'}</Text>
            )}
          </TouchableOpacity>
        </View>

        <View style={styles.tabs}>
          {renderTabButton('details', 'Details', 'info')}
          {renderTabButton('items', 'Includes', 'check')}
          {renderTabButton('addons', 'Add-ons', 'plus')}
        </View>

        {activeTab === 'details' && renderDetailsTab()}
        {activeTab === 'items' && renderItemsTab()}
        {activeTab === 'addons' && renderAddonsTab()}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: colors.white,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  closeButton: {
    padding: 8,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  saveButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    minWidth: 60,
    alignItems: 'center',
  },
  saveButtonText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
  tabs: {
    flexDirection: 'row',
    backgroundColor: colors.white,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  tabButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    marginRight: 8,
    backgroundColor: colors.accent,
  },
  tabButtonActive: {
    backgroundColor: colors.primary,
  },
  tabButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.textLight,
    marginLeft: 6,
  },
  tabButtonTextActive: {
    color: colors.white,
  },
  tabContent: {
    flex: 1,
    padding: 20,
    maxHeight: 800,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 16,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputRow: {
    flexDirection: 'row',
    gap: 12,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
    marginBottom: 8,
  },
  input: {
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    fontSize: 16,
    color: colors.text,
  },
  textArea: {
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    fontSize: 16,
    color: colors.text,
    minHeight: 80,
    textAlignVertical: 'top',
  },
  priceTypeContainer: {
    flexDirection: 'row',
    gap: 8,
  },
  priceTypeButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.white,
  },
  priceTypeButtonActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  priceTypeText: {
    fontSize: 12,
    fontWeight: '500',
    color: colors.textLight,
  },
  priceTypeTextActive: {
    color: colors.white,
  },
  switchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  itemCard: {
    backgroundColor: colors.white,
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  itemHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  itemName: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
    flex: 1,
  },
  itemDescription: {
    fontSize: 14,
    color: colors.textLight,
    marginTop: 4,
  },
  addonCard: {
    backgroundColor: colors.white,
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  addonHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  addonTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
    flex: 1,
  },
  addonDescription: {
    fontSize: 14,
    color: colors.textLight,
    marginTop: 4,
  },
  addonPrice: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.primary,
    marginTop: 4,
  },
  removeButton: {
    padding: 4,
  },
  addItemContainer: {
    backgroundColor: colors.white,
    borderRadius: 8,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.border,
    marginTop: 16,
  },
  addItemTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  addButton: {
    backgroundColor: colors.primary,
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 12,
  },
  addButtonText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
});
