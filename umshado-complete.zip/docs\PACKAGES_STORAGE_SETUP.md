# Packages Storage Setup Guide

## Supabase Storage Configuration

### 1. Create Storage Bucket
```sql
-- Run in Supabase SQL Editor
INSERT INTO storage.buckets (id, name, public) VALUES ('packages', 'packages', true);
```

### 2. Storage Policy Configuration

#### Upload Policy (Vendors can upload to their own path)
```sql
CREATE POLICY "Vendors can upload package images" ON storage.objects
FOR INSERT WITH CHECK (
  bucket_id = 'packages' AND
  auth.uid() IS NOT NULL AND
  (storage.foldername(name))[1] = 'vendor_' || (
    SELECT vp.id::text FROM vendor_profiles vp 
    WHERE vp.user_id = auth.uid()
  )
);
```

#### Read Policy (Public read access)
```sql
CREATE POLICY "Public can view package images" ON storage.objects
FOR SELECT USING (bucket_id = 'packages');
```

#### Update Policy (Vendors can update their own images)
```sql
CREATE POLICY "Vendors can update package images" ON storage.objects
FOR UPDATE USING (
  bucket_id = 'packages' AND
  auth.uid() IS NOT NULL AND
  (storage.foldername(name))[1] = 'vendor_' || (
    SELECT vp.id::text FROM vendor_profiles vp 
    WHERE vp.user_id = auth.uid()
  )
);
```

#### Delete Policy (Vendors can delete their own images)
```sql
CREATE POLICY "Vendors can delete package images" ON storage.objects
FOR DELETE USING (
  bucket_id = 'packages' AND
  auth.uid() IS NOT NULL AND
  (storage.foldername(name))[1] = 'vendor_' || (
    SELECT vp.id::text FROM vendor_profiles vp 
    WHERE vp.user_id = auth.uid()
  )
);
```

### 3. Path Convention
- **Package Images**: `vendor_{vendor_id}/packages/{package_id}/{filename}`
- **Thumbnails**: `vendor_{vendor_id}/packages/{package_id}/thumbs/{filename}`

### 4. Edge Function for Thumbnails
Create `supabase/functions/generate-thumbnails/index.ts` to automatically generate thumbnails on image upload.

### 5. File Size Limits
- **Max file size**: 10MB per image
- **Allowed formats**: jpg, jpeg, png, webp
- **Max images per package**: 10

## Implementation Notes

1. **Path Validation**: Always validate upload paths in frontend before upload
2. **Image Optimization**: Compress images before upload
3. **CDN**: Supabase Storage automatically provides CDN
4. **Backup**: Consider implementing backup strategy for important images
