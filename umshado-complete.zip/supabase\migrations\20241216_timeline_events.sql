-- Create timeline_events table
CREATE TABLE IF NOT EXISTS public.timeline_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL REFERENCES public.wedding(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  event_type TEXT NOT NULL CHECK (event_type IN (
    'engagement', 'save_the_date', 'venue_booking', 'vendor_booking',
    'dress_fitting', 'cake_tasting', 'rehearsal', 'wedding_day',
    'honeymoon', 'anniversary', 'custom'
  )),
  event_date DATE NOT NULL,
  start_time TIME,
  end_time TIME,
  location TEXT,
  status TEXT NOT NULL DEFAULT 'upcoming' CHECK (status IN (
    'upcoming', 'completed', 'cancelled'
  )),
  priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN (
    'low', 'medium', 'high', 'urgent'
  )),
  reminder_days INTEGER DEFAULT 7, -- Days before event to remind
  notes TEXT,
  
  -- Timestamps
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS timeline_events_wedding_idx ON public.timeline_events(wedding_id);
CREATE INDEX IF NOT EXISTS timeline_events_date_idx ON public.timeline_events(event_date);
CREATE INDEX IF NOT EXISTS timeline_events_type_idx ON public.timeline_events(event_type);
CREATE INDEX IF NOT EXISTS timeline_events_status_idx ON public.timeline_events(status);
CREATE INDEX IF NOT EXISTS timeline_events_priority_idx ON public.timeline_events(priority);

-- Enable RLS
ALTER TABLE public.timeline_events ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "select_own_wedding_timeline_events" ON public.timeline_events
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "insert_own_wedding_timeline_events" ON public.timeline_events
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "update_own_wedding_timeline_events" ON public.timeline_events
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "delete_own_wedding_timeline_events" ON public.timeline_events
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_timeline_events_updated
  BEFORE UPDATE ON public.timeline_events
  FOR EACH ROW
  EXECUTE FUNCTION set_updated_at();

-- Add wedding date to wedding table if not exists
ALTER TABLE public.wedding 
ADD COLUMN IF NOT EXISTS wedding_date DATE;

-- Add engagement date to wedding table if not exists
ALTER TABLE public.wedding 
ADD COLUMN IF NOT EXISTS engagement_date DATE;

-- Create index for wedding_date
CREATE INDEX IF NOT EXISTS wedding_date_idx ON public.wedding(wedding_date);















