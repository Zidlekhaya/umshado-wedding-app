import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { formatDate, formatDateTime, getRelativeTime } from '@/lib/date-utils';

export const DateTest: React.FC = () => {
  const now = new Date();
  const testDate = '2024-12-25T10:30:00Z';
  const oldDate = '2024-01-15T08:00:00Z';

  // Test if the function is working
  console.log('DateTest: Testing formatDate function...');
  console.log('DateTest: Current date:', now);
  console.log('DateTest: Formatted current:', formatDate(now));
  console.log('DateTest: Test date:', testDate);
  console.log('DateTest: Formatted test:', formatDate(testDate));

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Date Formatting Test</Text>
      
      <Text style={styles.label}>Current Date:</Text>
      <Text style={styles.value}>{formatDate(now)}</Text>
      
      <Text style={styles.label}>Test Date (Christmas):</Text>
      <Text style={styles.value}>{formatDate(testDate)}</Text>
      
      <Text style={styles.label}>Date & Time:</Text>
      <Text style={styles.value}>{formatDateTime(testDate)}</Text>
      
      <Text style={styles.label}>Relative Time:</Text>
      <Text style={styles.value}>{getRelativeTime(oldDate)}</Text>
      
      <Text style={styles.label}>Expected Format:</Text>
      <Text style={styles.value}>DD/MM/YYYY (e.g., 25/12/2024)</Text>
      
      <Text style={styles.label}>Raw Test Date:</Text>
      <Text style={styles.value}>{testDate}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#f0f0f0',
    margin: 10,
    borderRadius: 8,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginTop: 10,
    marginBottom: 5,
  },
  value: {
    fontSize: 16,
    backgroundColor: '#fff',
    padding: 8,
    borderRadius: 4,
    fontFamily: 'monospace',
  },
});
