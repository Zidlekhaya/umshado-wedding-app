-- Create RPC function to add guests (bypasses RLS)
CREATE OR REPLACE FUNCTION add_guest_secure(
  p_wedding_id UUID,
  p_full_name TEXT,
  p_phone TEXT,
  p_category TEXT
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER -- This allows the function to bypass RLS
AS $$
DECLARE
  new_guest JSON;
BEGIN
  -- Check if user owns the wedding
  IF NOT EXISTS (
    SELECT 1 FROM wedding 
    WHERE id = p_wedding_id 
    AND owner_id = auth.uid()
  ) THEN
    RAISE EXCEPTION 'Not authorized to add guests to this wedding';
  END IF;

  -- Insert the guest
  INSERT INTO guests (
    wedding_id,
    full_name,
    phone,
    category,
    rsvp_status,
    plus_one
  ) VALUES (
    p_wedding_id,
    p_full_name,
    p_phone,
    p_category,
    'Pending',
    false
  ) RETURNING to_json(guests.*) INTO new_guest;

  RETURN new_guest;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION add_guest_secure TO authenticated;
