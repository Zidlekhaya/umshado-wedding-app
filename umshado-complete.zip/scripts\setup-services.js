#!/usr/bin/env node

/**
 * Setup Services Script
 * This script creates the vendor_services table and adds sample data
 */

const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing Supabase environment variables');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function setupServices() {
  console.log('🚀 Setting up vendor services...\n');

  try {
    // Check if table exists by trying to query it
    const { data: existingServices, error: queryError } = await supabase
      .from('vendor_services')
      .select('id')
      .limit(1);

    if (queryError && queryError.code === 'PGRST116') {
      console.log('❌ vendor_services table does not exist');
      console.log('💡 Please run the migration manually in your Supabase dashboard:');
      console.log('   1. Go to your Supabase project dashboard');
      console.log('   2. Go to SQL Editor');
      console.log('   3. Run the migration from: supabase/migrations/006_create_vendor_services.sql');
      console.log('   4. Then run this script again');
      return;
    }

    if (queryError) {
      console.error('❌ Error checking table:', queryError.message);
      return;
    }

    console.log('✅ vendor_services table exists');

    // Get vendor profiles
    const { data: vendorProfiles, error: profileError } = await supabase
      .from('vendor_profiles')
      .select('id, business_name, category');

    if (profileError) {
      console.error('❌ Error fetching vendor profiles:', profileError.message);
      return;
    }

    if (!vendorProfiles || vendorProfiles.length === 0) {
      console.log('❌ No vendor profiles found. Please create a vendor account first.');
      return;
    }

    console.log(`👤 Found ${vendorProfiles.length} vendor profile(s)`);

    // Check if services already exist
    const { data: existingServicesCount, error: countError } = await supabase
      .from('vendor_services')
      .select('id', { count: 'exact', head: true });

    if (countError) {
      console.error('❌ Error checking existing services:', countError.message);
      return;
    }

    if (existingServicesCount && existingServicesCount.length > 0) {
      console.log(`✅ Services already exist (${existingServicesCount.length} services)`);
      console.log('📱 You can now use the services functionality!');
      return;
    }

    // Add sample services for the first vendor
    const vendorProfile = vendorProfiles[0];
    console.log(`🎨 Adding sample services for: ${vendorProfile.business_name}`);

    const sampleServices = [
      {
        vendor_id: vendorProfile.id,
        service_name: 'Wedding Photography Package',
        description: 'Complete wedding photography coverage including ceremony, reception, and couple portraits.',
        price_min: 8000,
        price_max: 15000,
        price_type: 'package',
        duration_hours: 8,
        includes: ['8 hours coverage', '500+ edited photos', 'Online gallery', 'USB drive'],
        add_ons: ['Engagement shoot', 'Photo book', 'Drone footage'],
        is_active: true,
      },
      {
        vendor_id: vendorProfile.id,
        service_name: 'Bridal Makeup & Hair',
        description: 'Professional bridal makeup and hairstyling for the bride.',
        price_min: 2500,
        price_max: 4500,
        price_type: 'fixed',
        duration_hours: 4,
        includes: ['Trial session', 'Wedding day makeup', 'Wedding day hairstyling'],
        add_ons: ['Bridal party makeup', 'Mother of bride styling'],
        is_active: true,
      }
    ];

    const { data: insertedServices, error: insertError } = await supabase
      .from('vendor_services')
      .insert(sampleServices)
      .select();

    if (insertError) {
      console.error('❌ Error inserting services:', insertError.message);
      return;
    }

    console.log(`✅ Successfully added ${insertedServices.length} sample services!`);
    console.log('📱 You can now create and view services in the vendor dashboard');

  } catch (error) {
    console.error('❌ Setup failed:', error.message);
  }
}

setupServices().then(() => {
  console.log('\n✨ Setup completed');
  process.exit(0);
}).catch((error) => {
  console.error('❌ Script failed:', error);
  process.exit(1);
});
