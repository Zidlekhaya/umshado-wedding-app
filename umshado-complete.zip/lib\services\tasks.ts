import { supabase } from "@/lib/supabase";
import { getUpcomingTasks, setTaskStatus } from "@/services/tasks";

export async function listUpcomingTasks(weddingId: string, limit = 5) {
  return getUpcomingTasks(weddingId, limit);
}

export async function markTaskDone(taskId: string) {
  return setTaskStatus(taskId, "done");
}


