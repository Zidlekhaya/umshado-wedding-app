// components/ai/AIHub.tsx
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Modal,
  Dimensions,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import AIChatAssistant from './AIChatAssistant';
import AIBudgetAnalyzer from './AIBudgetAnalyzer';
import AITaskGenerator from './AITaskGenerator';

const { width: screenWidth } = Dimensions.get('window');

const colors = {
  background: '#f0fbea',
  surface: '#FFFFFF',
  primary: '#00a86b',
  secondary: '#FF6B35',
  text: '#1A1A1A',
  textSecondary: '#6B7280',
  border: '#E5E7EB',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  white: '#FFFFFF',
};

interface AIFeature {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  component: React.ComponentType<any>;
}

const aiFeatures: AIFeature[] = [
  {
    id: 'chat',
    title: 'AI Wedding Planner',
    description: 'Chat with your personal AI assistant for wedding planning advice',
    icon: 'message-circle',
    color: colors.primary,
    component: AIChatAssistant,
  },
  {
    id: 'budget',
    title: 'Budget Analyzer',
    description: 'Get AI-powered budget analysis and cost optimization suggestions',
    icon: 'trending-down',
    color: colors.success,
    component: AIBudgetAnalyzer,
  },
  {
    id: 'tasks',
    title: 'Task Generator',
    description: 'Generate personalized wedding planning tasks based on your details',
    icon: 'check-square',
    color: colors.warning,
    component: AITaskGenerator,
  },
];

export default function AIHub() {
  const [selectedFeature, setSelectedFeature] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);

  const openFeature = (featureId: string) => {
    setSelectedFeature(featureId);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedFeature(null);
  };

  const renderFeatureCard = (feature: AIFeature) => (
    <TouchableOpacity
      key={feature.id}
      style={styles.featureCard}
      onPress={() => openFeature(feature.id)}
    >
      <View style={[styles.featureIcon, { backgroundColor: feature.color }]}>
        <Feather name={feature.icon as any} size={24} color={colors.white} />
      </View>
      <View style={styles.featureContent}>
        <Text style={styles.featureTitle}>{feature.title}</Text>
        <Text style={styles.featureDescription}>{feature.description}</Text>
      </View>
      <Feather name="chevron-right" size={20} color={colors.textSecondary} />
    </TouchableOpacity>
  );

  const renderSelectedComponent = () => {
    const feature = aiFeatures.find(f => f.id === selectedFeature);
    if (!feature) return null;

    const Component = feature.component;
    return <Component onClose={closeModal} />;
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <View style={styles.aiIcon}>
            <Feather name="cpu" size={24} color={colors.white} />
          </View>
          <View>
            <Text style={styles.headerTitle}>AI Wedding Assistant</Text>
            <Text style={styles.headerSubtitle}>Powered by artificial intelligence</Text>
          </View>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.welcomeSection}>
          <Text style={styles.welcomeTitle}>Welcome to AI-Powered Planning</Text>
          <Text style={styles.welcomeText}>
            Let artificial intelligence help you plan the perfect wedding. Our AI features analyze your wedding details and provide personalized recommendations, insights, and assistance.
          </Text>
        </View>

        <View style={styles.featuresSection}>
          <Text style={styles.sectionTitle}>AI Features</Text>
          {aiFeatures.map(renderFeatureCard)}
        </View>

        <View style={styles.benefitsSection}>
          <Text style={styles.sectionTitle}>Why Use AI?</Text>
          <View style={styles.benefitsList}>
            <View style={styles.benefitItem}>
              <Feather name="zap" size={20} color={colors.primary} />
              <Text style={styles.benefitText}>Save time with automated suggestions</Text>
            </View>
            <View style={styles.benefitItem}>
              <Feather name="target" size={20} color={colors.success} />
              <Text style={styles.benefitText}>Get personalized recommendations</Text>
            </View>
            <View style={styles.benefitItem}>
              <Feather name="trending-up" size={20} color={colors.warning} />
              <Text style={styles.benefitText}>Optimize your budget and timeline</Text>
            </View>
            <View style={styles.benefitItem}>
              <Feather name="shield" size={20} color={colors.error} />
              <Text style={styles.benefitText}>Avoid common planning mistakes</Text>
            </View>
          </View>
        </View>

        <View style={styles.tipsSection}>
          <Text style={styles.sectionTitle}>Pro Tips</Text>
          <View style={styles.tipCard}>
            <Feather name="lightbulb" size={20} color={colors.warning} />
            <Text style={styles.tipText}>
              The more details you provide about your wedding, the better AI recommendations you'll receive.
            </Text>
          </View>
          <View style={styles.tipCard}>
            <Feather name="refresh-cw" size={20} color={colors.primary} />
            <Text style={styles.tipText}>
              Re-run AI analysis as your wedding plans evolve for updated insights.
            </Text>
          </View>
        </View>
      </ScrollView>

      <Modal
        visible={showModal}
        animationType="slide"
        presentationStyle="fullScreen"
      >
        {renderSelectedComponent()}
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: colors.white,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  aiIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
  },
  headerSubtitle: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  welcomeSection: {
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: 24,
    marginBottom: 24,
  },
  welcomeTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 12,
  },
  welcomeText: {
    fontSize: 16,
    color: colors.textSecondary,
    lineHeight: 24,
  },
  featuresSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 16,
  },
  featureCard: {
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: 20,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  featureIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  featureContent: {
    flex: 1,
  },
  featureTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  featureDescription: {
    fontSize: 14,
    color: colors.textSecondary,
    lineHeight: 20,
  },
  benefitsSection: {
    marginBottom: 24,
  },
  benefitsList: {
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: 20,
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  benefitText: {
    fontSize: 16,
    color: colors.text,
    marginLeft: 12,
    flex: 1,
  },
  tipsSection: {
    marginBottom: 24,
  },
  tipCard: {
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: 20,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  tipText: {
    fontSize: 15,
    color: colors.text,
    lineHeight: 22,
    marginLeft: 12,
    flex: 1,
  },
});
