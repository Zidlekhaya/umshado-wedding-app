// stores/session.ts
import '../polyfills';
import { create } from 'zustand';
import type { Session } from '@supabase/supabase-js';

type SessionState = {
  session: Session | null;
  setSession: (s: Session | null) => void;
  initialized: boolean;
  setInitialized: (v: boolean) => void;
};

export const useSessionStore = create<SessionState>((set) => ({
  session: null,
  setSession: (s) => set({ session: s }),
  initialized: false,
  setInitialized: (v) => set({ initialized: v }),
}));

// Note: Session management is now handled directly in _layout.tsx
// This store is kept for backward compatibility but not actively used
