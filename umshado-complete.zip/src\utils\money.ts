/**
 * Formats a number as currency using South African Rand (ZAR) by default
 * @param value - The numeric value to format
 * @param currency - The currency code (defaults to 'ZAR')
 * @returns Formatted currency string
 */
export const formatCurrency = (value: number | string | null | undefined, currency = 'ZAR'): string => {
  const n = typeof value === 'string' ? Number(value) : (value ?? 0);
  
  try {
    return new Intl.NumberFormat('en-ZA', { 
      style: 'currency', 
      currency 
    }).format(n);
  } catch {
    // Fallback formatting if Intl.NumberFormat fails
    return `R ${n.toFixed(2)}`;
  }
};

/**
 * Parses a currency string to a number
 * @param value - Currency string to parse
 * @returns Parsed number or 0 if invalid
 */
export const parseCurrency = (value: string): number => {
  if (!value) return 0;
  
  // Remove currency symbols and spaces
  const cleaned = value.replace(/[R$,\s]/g, '');
  const parsed = parseFloat(cleaned);
  
  return isNaN(parsed) ? 0 : parsed;
};

/**
 * Validates if a string represents a valid currency amount
 * @param value - String to validate
 * @returns True if valid currency amount
 */
export const isValidCurrency = (value: string): boolean => {
  if (!value.trim()) return false;
  
  const cleaned = value.replace(/[R$,\s]/g, '');
  const parsed = parseFloat(cleaned);
  
  return !isNaN(parsed) && parsed >= 0;
};




