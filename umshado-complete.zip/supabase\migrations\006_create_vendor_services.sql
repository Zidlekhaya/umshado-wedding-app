-- Create Vendor Services Table
-- This migration creates the vendor_services table for real vendor service data

-- Create vendor_services table if it doesn't exist
CREATE TABLE IF NOT EXISTS vendor_services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id UUID NOT NULL REFERENCES vendor_profiles(id) ON DELETE CASCADE,
  service_name TEXT NOT NULL,
  description TEXT,
  price_min NUMERIC(10,2),
  price_max NUMERIC(10,2),
  price_type TEXT DEFAULT 'fixed', -- 'fixed', 'hourly', 'per_person', 'custom'
  duration_hours INTEGER,
  includes TEXT[], -- What's included in the service
  add_ons TEXT[], -- Optional add-ons
  images TEXT[], -- Service-specific images
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create vendor_inquiries table if it doesn't exist
CREATE TABLE IF NOT EXISTS vendor_inquiries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id UUID NOT NULL REFERENCES vendor_profiles(id) ON DELETE CASCADE,
  couple_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  wedding_id UUID,
  
  -- Inquiry details
  inquiry_type TEXT DEFAULT 'general', -- 'general', 'quote', 'booking'
  message TEXT NOT NULL,
  wedding_date DATE,
  guest_count INTEGER,
  budget_range TEXT,
  
  -- Contact information
  contact_name TEXT NOT NULL,
  contact_email TEXT NOT NULL,
  contact_phone TEXT,
  
  -- Status
  status TEXT DEFAULT 'pending', -- 'pending', 'responded', 'closed'
  vendor_response TEXT,
  responded_at TIMESTAMPTZ,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create vendor_reviews table if it doesn't exist
CREATE TABLE IF NOT EXISTS vendor_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id UUID NOT NULL REFERENCES vendor_profiles(id) ON DELETE CASCADE,
  reviewer_name TEXT NOT NULL,
  reviewer_email TEXT,
  wedding_date DATE,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review_text TEXT,
  images TEXT[], -- Review images
  is_verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_vendor_services_vendor ON vendor_services(vendor_id);
CREATE INDEX IF NOT EXISTS idx_vendor_services_active ON vendor_services(is_active);
CREATE INDEX IF NOT EXISTS idx_vendor_inquiries_vendor ON vendor_inquiries(vendor_id);
CREATE INDEX IF NOT EXISTS idx_vendor_inquiries_couple ON vendor_inquiries(couple_id);
CREATE INDEX IF NOT EXISTS idx_vendor_inquiries_status ON vendor_inquiries(status);
CREATE INDEX IF NOT EXISTS idx_vendor_reviews_vendor ON vendor_reviews(vendor_id);
CREATE INDEX IF NOT EXISTS idx_vendor_reviews_rating ON vendor_reviews(rating);

-- Enable RLS for all tables
ALTER TABLE vendor_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE vendor_inquiries ENABLE ROW LEVEL SECURITY;
ALTER TABLE vendor_reviews ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for vendor_services
CREATE POLICY "Vendor services are publicly readable" ON vendor_services
  FOR SELECT USING (is_active = true);

CREATE POLICY "Vendors can manage their own services" ON vendor_services
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM vendor_profiles 
      WHERE vendor_profiles.id = vendor_services.vendor_id 
      AND vendor_profiles.user_id = auth.uid()
    )
  );

-- Create RLS policies for vendor_inquiries
CREATE POLICY "Vendors can view their inquiries" ON vendor_inquiries
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM vendor_profiles 
      WHERE vendor_profiles.id = vendor_inquiries.vendor_id 
      AND vendor_profiles.user_id = auth.uid()
    )
  );

CREATE POLICY "Anyone can create inquiries" ON vendor_inquiries
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Vendors can update their inquiries" ON vendor_inquiries
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM vendor_profiles 
      WHERE vendor_profiles.id = vendor_inquiries.vendor_id 
      AND vendor_profiles.user_id = auth.uid()
    )
  );

-- Create RLS policies for vendor_reviews
CREATE POLICY "Vendor reviews are publicly readable" ON vendor_reviews
  FOR SELECT USING (true);

CREATE POLICY "Anyone can create vendor reviews" ON vendor_reviews
  FOR INSERT WITH CHECK (true);

-- Create function to update inquiry count
CREATE OR REPLACE FUNCTION update_vendor_inquiry_count(vendor_uuid UUID)
RETURNS void AS $$
BEGIN
  UPDATE vendor_profiles 
  SET inquiry_count = inquiry_count + 1 
  WHERE id = vendor_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to update inquiry count
CREATE OR REPLACE FUNCTION trigger_update_inquiry_count()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM update_vendor_inquiry_count(NEW.vendor_id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_inquiry_count_trigger
  AFTER INSERT ON vendor_inquiries
  FOR EACH ROW
  EXECUTE FUNCTION trigger_update_inquiry_count();

-- Create function to calculate vendor rating
CREATE OR REPLACE FUNCTION calculate_vendor_rating(vendor_uuid UUID)
RETURNS void AS $$
DECLARE
  avg_rating DECIMAL(3,2);
  total_reviews INTEGER;
BEGIN
  SELECT AVG(rating)::DECIMAL(3,2), COUNT(*)
  INTO avg_rating, total_reviews
  FROM vendor_reviews
  WHERE vendor_id = vendor_uuid;
  
  UPDATE vendor_profiles 
  SET rating_average = COALESCE(avg_rating, 0.00),
      review_count = total_reviews
  WHERE id = vendor_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to update rating when reviews change
CREATE OR REPLACE FUNCTION trigger_update_vendor_rating()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    PERFORM calculate_vendor_rating(NEW.vendor_id);
  ELSIF TG_OP = 'DELETE' THEN
    PERFORM calculate_vendor_rating(OLD.vendor_id);
  END IF;
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_vendor_rating_trigger
  AFTER INSERT OR UPDATE OR DELETE ON vendor_reviews
  FOR EACH ROW
  EXECUTE FUNCTION trigger_update_vendor_rating();

-- Insert some sample services for existing vendors
INSERT INTO vendor_services (vendor_id, service_name, description, price_min, price_max, price_type, duration_hours, includes, add_ons)
SELECT 
  vp.id,
  CASE 
    WHEN vp.category = 'photography' THEN 'Wedding Photography Package'
    WHEN vp.category = 'catering' THEN 'Wedding Catering Service'
    WHEN vp.category = 'venue' THEN 'Wedding Venue Rental'
    WHEN vp.category = 'flowers' THEN 'Wedding Floral Arrangements'
    WHEN vp.category = 'music' THEN 'Wedding DJ Service'
    WHEN vp.category = 'beauty' THEN 'Wedding Makeup & Hair'
    ELSE 'Wedding Service Package'
  END,
  CASE 
    WHEN vp.category = 'photography' THEN 'Professional wedding photography with edited photos and online gallery'
    WHEN vp.category = 'catering' THEN 'Full wedding catering service with menu options and service staff'
    WHEN vp.category = 'venue' THEN 'Beautiful wedding venue with ceremony and reception areas'
    WHEN vp.category = 'flowers' THEN 'Custom floral arrangements for ceremony and reception'
    WHEN vp.category = 'music' THEN 'Professional DJ service with sound system and music selection'
    WHEN vp.category = 'beauty' THEN 'Professional makeup and hair styling for bride and bridal party'
    ELSE 'Professional wedding service tailored to your needs'
  END,
  CASE 
    WHEN vp.category = 'photography' THEN 5000.00
    WHEN vp.category = 'catering' THEN 8000.00
    WHEN vp.category = 'venue' THEN 12000.00
    WHEN vp.category = 'flowers' THEN 3000.00
    WHEN vp.category = 'music' THEN 2500.00
    WHEN vp.category = 'beauty' THEN 2000.00
    ELSE 5000.00
  END,
  CASE 
    WHEN vp.category = 'photography' THEN 15000.00
    WHEN vp.category = 'catering' THEN 25000.00
    WHEN vp.category = 'venue' THEN 35000.00
    WHEN vp.category = 'flowers' THEN 8000.00
    WHEN vp.category = 'music' THEN 5000.00
    WHEN vp.category = 'beauty' THEN 5000.00
    ELSE 15000.00
  END,
  'fixed',
  CASE 
    WHEN vp.category = 'photography' THEN 8
    WHEN vp.category = 'catering' THEN 6
    WHEN vp.category = 'venue' THEN 12
    WHEN vp.category = 'flowers' THEN 4
    WHEN vp.category = 'music' THEN 6
    WHEN vp.category = 'beauty' THEN 4
    ELSE 6
  END,
  CASE 
    WHEN vp.category = 'photography' THEN ARRAY['8 hours coverage', 'Edited photos', 'Online gallery', 'USB drive']
    WHEN vp.category = 'catering' THEN ARRAY['Menu planning', 'Food preparation', 'Service staff', 'Tableware']
    WHEN vp.category = 'venue' THEN ARRAY['Ceremony space', 'Reception area', 'Parking', 'Basic decorations']
    WHEN vp.category = 'flowers' THEN ARRAY['Bridal bouquet', 'Ceremony flowers', 'Reception centerpieces']
    WHEN vp.category = 'music' THEN ARRAY['Sound system', 'Music selection', 'MC services', 'Lighting']
    WHEN vp.category = 'beauty' THEN ARRAY['Bride makeup', 'Bride hair', 'Trial session', 'Touch-up kit']
    ELSE ARRAY['Professional service', 'Consultation', 'Setup', 'Cleanup']
  END,
  CASE 
    WHEN vp.category = 'photography' THEN ARRAY['Additional photographer', 'Engagement session', 'Photo book', 'Drone footage']
    WHEN vp.category = 'catering' THEN ARRAY['Premium menu', 'Bar service', 'Late night snacks', 'Special dietary options']
    WHEN vp.category = 'venue' THEN ARRAY['Premium decorations', 'Outdoor ceremony', 'Bridal suite', 'Guest accommodation']
    WHEN vp.category = 'flowers' THEN ARRAY['Extra bouquets', 'Ceremony arch', 'Petals', 'Preserved flowers']
    WHEN vp.category = 'music' THEN ARRAY['Live band', 'Ceremony music', 'Reception entertainment', 'Photo booth']
    WHEN vp.category = 'beauty' THEN ARRAY['Bridal party styling', 'Mother of bride', 'Groom styling', 'Nail services']
    ELSE ARRAY['Premium options', 'Extended service', 'Additional staff', 'Special requests']
  END
FROM vendor_profiles vp
WHERE NOT EXISTS (
  SELECT 1 FROM vendor_services vs 
  WHERE vs.vendor_id = vp.id
);

-- Insert some sample inquiries for existing vendors
INSERT INTO vendor_inquiries (vendor_id, inquiry_type, message, wedding_date, guest_count, budget_range, contact_name, contact_email, contact_phone, status)
SELECT 
  vp.id,
  'quote',
  'Hi! We are planning our wedding for next year and would love to get a quote for your services. We are looking for a beautiful ceremony and reception.',
  CURRENT_DATE + INTERVAL '6 months',
  80,
  'R15000 - R25000',
  'Sarah & John',
  'sarah.john@example.com',
  '+27 82 123 4567',
  'pending'
FROM vendor_profiles vp
WHERE NOT EXISTS (
  SELECT 1 FROM vendor_inquiries vi 
  WHERE vi.vendor_id = vp.id
)
LIMIT 2;

-- Insert some sample reviews for existing vendors
INSERT INTO vendor_reviews (vendor_id, reviewer_name, reviewer_email, wedding_date, rating, review_text, is_verified)
SELECT 
  vp.id,
  'Emma & Michael',
  'emma.michael@example.com',
  CURRENT_DATE - INTERVAL '2 months',
  5,
  'Absolutely amazing service! They made our wedding day perfect. Highly recommended!',
  true
FROM vendor_profiles vp
WHERE NOT EXISTS (
  SELECT 1 FROM vendor_reviews vr 
  WHERE vr.vendor_id = vp.id
)
LIMIT 1;

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT ALL ON ALL TABLES IN SCHEMA public TO anon, authenticated;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO anon, authenticated;
