import { Linking } from 'react-native';

export interface WeddingInfo {
  brideName: string;
  groomName: string;
  date: string;
  location?: string;
  rsvpLink?: string;
}

export function generateWeddingMessage(info: WeddingInfo): string {
  const { brideName, groomName, date, location, rsvpLink } = info;
  
  let message = `🎉 You're invited to ${brideName} & ${groomName}'s wedding!\n\n`;
  message += `📅 Date: ${date}\n`;
  
  if (location) {
    message += `📍 Location: ${location}\n`;
  }
  
  message += `\nWe can't wait to celebrate with you! 💕`;
  
  if (rsvpLink) {
    message += `\n\nRSVP here: ${rsvpLink}`;
  }
  
  return message;
}

export function shareViaWhatsApp(phoneNumber: string, message: string): void {
  const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
  const encodedMessage = encodeURIComponent(message);
  const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodedMessage}`;
  
  Linking.openURL(whatsappUrl).catch((error) => {
    console.error('Error opening WhatsApp:', error);
  });
}

export function shareWeddingInvite(phoneNumber: string, weddingInfo: WeddingInfo): void {
  const message = generateWeddingMessage(weddingInfo);
  shareViaWhatsApp(phoneNumber, message);
}































