import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { Stack, router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Loading } from '@/components/ui/Loading';
import { BackButton } from '@/src/components/ui/BackButton';
// Using consistent colors instead of design system
const colors = {
  background: '#f0fbea',
  primary: '#00a86b',
  text: '#1A1A1A',
  textLight: '#6B7280',
  border: '#E5E7EB',
  success: '#10B981',
  error: '#EF4444',
  warning: '#F59E0B',
  white: '#FFFFFF',
  headerBg: '#F8FAFC',
  headerText: '#1E293B',
  cardShadow: 'rgba(0, 0, 0, 0.1)',
  accent: '#F3F4F6',
};
import { supabase } from '@/lib/supabase';
import { getVendorStats, getVendorInquiries } from '@/lib/vendor-stats-service';

export default function VendorAnalytics() {
  const [loading, setLoading] = useState(true);
  const [analytics, setAnalytics] = useState({
    totalViews: 0,
    totalInquiries: 0,
    totalReviews: 0,
    averageRating: 0,
    totalServices: 0,
    activeServices: 0,
    totalPackages: 0,
    conversionRate: 0,
    monthlyViews: [0, 0, 0, 0, 0, 0],
    topServices: [],
    recentInquiries: [],
  });

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        Alert.alert('Error', 'Please sign in to continue');
        router.replace('/(auth)/vendor-sign-in');
        return;
      }

      console.log('Loading real analytics for vendor:', user.id);

      // Get vendor profile to get vendor_id
      const { data: vendorProfile, error: profileError } = await supabase
        .from('vendor_profiles')
        .select('id, business_name')
        .eq('user_id', user.id)
        .single();

      if (profileError) {
        console.error('Error loading vendor profile:', profileError);
        throw profileError;
      }

      console.log('Vendor profile found:', vendorProfile.business_name, 'ID:', vendorProfile.id);

      // Get real vendor stats
      const vendorStats = await getVendorStats(vendorProfile.id);
      console.log('Vendor stats loaded:', vendorStats);

      // Get vendor inquiries
      const inquiries = await getVendorInquiries(vendorProfile.id);
      console.log('Vendor inquiries loaded:', inquiries.length);

      // Get vendor services count
      const { data: services, error: servicesError } = await supabase
        .from('vendor_services')
        .select('id, service_name, is_active')
        .eq('vendor_id', vendorProfile.id);

      if (servicesError) {
        console.error('Error loading services:', servicesError);
      }

      // Get vendor packages count
      const { data: packages, error: packagesError } = await supabase
        .from('packages')
        .select('id')
        .eq('vendor_id', vendorProfile.id);

      if (packagesError) {
        console.error('Error loading packages:', packagesError);
      }

      // Calculate conversion rate (inquiries to bookings)
      const totalInquiries = inquiries.length;
      const bookedInquiries = inquiries.filter(inq => inq.status === 'booked').length;
      const conversionRate = totalInquiries > 0 ? (bookedInquiries / totalInquiries) * 100 : 0;

      // Generate monthly views data (simulate based on total views)
      const monthlyViews = generateMonthlyViews(vendorStats.totalViews);

      // Get top services (services with most inquiries)
      const topServices = services?.map(service => {
        const serviceInquiries = inquiries.filter(inq => inq.service_type === service.service_name);
        return {
          name: service.service_name,
          inquiries: serviceInquiries.length,
          bookings: serviceInquiries.filter(inq => inq.status === 'booked').length,
        };
      }).sort((a, b) => b.inquiries - a.inquiries).slice(0, 3) || [];

      // Get recent inquiries
      const recentInquiries = inquiries.slice(0, 5);

      setAnalytics({
        totalViews: vendorStats.totalViews,
        totalInquiries: vendorStats.totalInquiries,
        totalReviews: vendorStats.totalReviews,
        averageRating: vendorStats.averageRating,
        totalServices: services?.length || 0,
        activeServices: services?.filter(s => s.is_active).length || 0,
        totalPackages: packages?.length || 0,
        conversionRate: Math.round(conversionRate * 10) / 10, // Round to 1 decimal
        monthlyViews,
        topServices,
        recentInquiries,
      });
    } catch (error: any) {
      console.error('Error loading analytics:', error);
      Alert.alert('Error', 'Failed to load analytics');
    } finally {
      setLoading(false);
    }
  };

  // Helper function to generate monthly views data
  const generateMonthlyViews = (totalViews: number) => {
    // Generate realistic monthly distribution based on total views
    const months = 6;
    const baseViews = Math.floor(totalViews / months);
    const variation = Math.floor(baseViews * 0.3); // 30% variation
    
    return Array.from({ length: months }, (_, i) => {
      const randomVariation = Math.floor(Math.random() * variation * 2) - variation;
      return Math.max(0, baseViews + randomVariation);
    });
  };

  // Helper function to get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new': return colors.primary;
      case 'contacted': return colors.warning;
      case 'quoted': return colors.success;
      case 'booked': return colors.success;
      case 'cancelled': return colors.error;
      default: return colors.textLight;
    }
  };

  const handleSignOut = async () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Logout', 
          style: 'destructive',
          onPress: async () => {
            try {
              await supabase.auth.signOut();
              router.replace('/(auth)');
            } catch (error) {
              Alert.alert('Error', 'Failed to logout');
            }
          }
        }
      ]
    );
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <Loading size="large" color={colors.primary} text="Loading analytics..." />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Stack.Screen
        options={{
          title: 'Analytics',
          headerLeft: () => <BackButton color={colors.text} />,
          headerRight: () => (
            <TouchableOpacity onPress={handleSignOut} style={styles.signOutButton}>
              <Feather name="log-out" size={16} color={colors.white} />
              <Text style={styles.signOutButtonText}>Logout</Text>
            </TouchableOpacity>
          ),
        }}
      />

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <Card variant="elevated" padding="lg" style={styles.headerCard}>
          <View style={styles.headerContent}>
            <View style={styles.headerIcon}>
              <Feather name="bar-chart-2" size={24} color={colors.primary} />
            </View>
            <View style={styles.headerText}>
              <Text style={styles.headerTitle}>Analytics</Text>
              <Text style={styles.headerSubtitle}>Track your business performance</Text>
            </View>
          </View>
        </Card>

        {/* Key Metrics */}
        <View style={styles.metricsContainer}>
          <Card variant="default" padding="md" style={styles.metricCard}>
            <View style={styles.metricIcon}>
              <Feather name="eye" size={20} color={colors.success} />
            </View>
            <Text style={styles.metricValue}>{analytics.totalViews.toLocaleString()}</Text>
            <Text style={styles.metricLabel}>Profile Views</Text>
            <Text style={styles.metricChange}>Real customer interest</Text>
          </Card>

          <Card variant="default" padding="md" style={styles.metricCard}>
            <View style={styles.metricIcon}>
              <Feather name="message-circle" size={20} color={colors.warning} />
            </View>
            <Text style={styles.metricValue}>{analytics.totalInquiries}</Text>
            <Text style={styles.metricLabel}>Inquiries</Text>
            <Text style={styles.metricChange}>Customer requests</Text>
          </Card>

          <Card variant="default" padding="md" style={styles.metricCard}>
            <View style={styles.metricIcon}>
              <Feather name="star" size={20} color={colors.primary} />
            </View>
            <Text style={styles.metricValue}>{analytics.averageRating.toFixed(1)}</Text>
            <Text style={styles.metricLabel}>Average Rating</Text>
            <Text style={styles.metricChange}>{analytics.totalReviews} reviews</Text>
          </Card>

          <Card variant="default" padding="md" style={styles.metricCard}>
            <View style={styles.metricIcon}>
              <Feather name="briefcase" size={20} color={colors.error} />
            </View>
            <Text style={styles.metricValue}>{analytics.activeServices}</Text>
            <Text style={styles.metricLabel}>Active Services</Text>
            <Text style={styles.metricChange}>Out of {analytics.totalServices} total</Text>
          </Card>
        </View>

        {/* Monthly Views Chart */}
        <Card variant="elevated" padding="lg" style={styles.chartCard}>
          <Text style={styles.chartTitle}>Monthly Views</Text>
          <View style={styles.chartContainer}>
            {analytics.monthlyViews.map((value, index) => {
              const maxValue = Math.max(...analytics.monthlyViews);
              const height = maxValue > 0 ? (value / maxValue) * 100 : 0;
              return (
                <View key={index} style={styles.chartBar}>
                  <View 
                    style={[
                      styles.chartBarFill, 
                      { height: `${height}%` }
                    ]} 
                  />
                  <Text style={styles.chartBarLabel}>{value}</Text>
                </View>
              );
            })}
          </View>
          <View style={styles.chartLabels}>
            <Text style={styles.chartLabel}>Jan</Text>
            <Text style={styles.chartLabel}>Feb</Text>
            <Text style={styles.chartLabel}>Mar</Text>
            <Text style={styles.chartLabel}>Apr</Text>
            <Text style={styles.chartLabel}>May</Text>
            <Text style={styles.chartLabel}>Jun</Text>
          </View>
        </Card>

        {/* Top Services */}
        <Card variant="elevated" padding="lg" style={styles.servicesCard}>
          <Text style={styles.servicesTitle}>Top Performing Services</Text>
          {analytics.topServices.map((service, index) => (
            <View key={index} style={styles.serviceItem}>
              <View style={styles.serviceRank}>
                <Text style={styles.serviceRankText}>{index + 1}</Text>
              </View>
              <View style={styles.serviceInfo}>
                <Text style={styles.serviceName}>{service.name}</Text>
                <Text style={styles.serviceStats}>
                  {service.inquiries} inquiries • {service.bookings} bookings
                </Text>
              </View>
              <View style={styles.servicePerformance}>
                <Text style={styles.serviceRate}>
                  {Math.round((service.bookings / service.inquiries) * 100)}%
                </Text>
                <Text style={styles.serviceRateLabel}>conversion</Text>
              </View>
            </View>
          ))}
        </Card>

        {/* Recent Inquiries */}
        {analytics.recentInquiries.length > 0 && (
          <Card variant="elevated" padding="lg" style={styles.inquiriesCard}>
            <Text style={styles.inquiriesTitle}>Recent Inquiries</Text>
            {analytics.recentInquiries.map((inquiry, index) => (
              <View key={index} style={styles.inquiryItem}>
                <View style={styles.inquiryInfo}>
                  <Text style={styles.inquiryCustomer}>{inquiry.customer_name}</Text>
                  <Text style={styles.inquiryService}>{inquiry.service_type}</Text>
                </View>
                <View style={styles.inquiryStatus}>
                  <Text style={[styles.inquiryStatusText, { color: getStatusColor(inquiry.status) }]}>
                    {inquiry.status.toUpperCase()}
                  </Text>
                  <Text style={styles.inquiryDate}>
                    {new Date(inquiry.created_at).toLocaleDateString()}
                  </Text>
                </View>
              </View>
            ))}
          </Card>
        )}

        {/* Performance Tips */}
        <Card variant="elevated" padding="lg" style={styles.tipsCard}>
          <Text style={styles.tipsTitle}>Performance Insights</Text>
          
          {analytics.totalViews > 0 && (
            <View style={styles.tipItem}>
              <View style={styles.tipIcon}>
                <Feather name="eye" size={16} color={colors.success} />
              </View>
              <Text style={styles.tipText}>
                You have {analytics.totalViews} profile views. Keep your profile updated with fresh photos and descriptions.
              </Text>
            </View>
          )}

          {analytics.totalInquiries > 0 && (
            <View style={styles.tipItem}>
              <View style={styles.tipIcon}>
                <Feather name="message-circle" size={16} color={colors.warning} />
              </View>
              <Text style={styles.tipText}>
                You have {analytics.totalInquiries} inquiries. Respond quickly to improve your conversion rate.
              </Text>
            </View>
          )}

          {analytics.totalServices === 0 && (
            <View style={styles.tipItem}>
              <View style={styles.tipIcon}>
                <Feather name="plus-circle" size={16} color={colors.primary} />
              </View>
              <Text style={styles.tipText}>
                Add more services to your profile to attract more customers and increase bookings.
              </Text>
            </View>
          )}

          {analytics.averageRating > 0 && (
            <View style={styles.tipItem}>
              <View style={styles.tipIcon}>
                <Feather name="star" size={16} color={colors.warning} />
              </View>
              <Text style={styles.tipText}>
                Great! You have a {analytics.averageRating.toFixed(1)} star rating from {analytics.totalReviews} reviews.
              </Text>
            </View>
          )}

          <View style={styles.tipItem}>
            <View style={styles.tipIcon}>
              <Feather name="clock" size={16} color={colors.primary} />
            </View>
            <Text style={styles.tipText}>
              Respond to inquiries within 2 hours to improve your conversion rate and customer satisfaction.
            </Text>
          </View>
        </Card>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  signOutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: colors.error || '#EF4444',
    gap: 6,
    shadowColor: 'rgba(0, 0, 0, 0.1)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    marginRight: 10,
  },
  signOutButtonText: {
    color: colors.white,
    fontSize: 12,
    fontWeight: '600',
  },
  headerCard: {
    marginBottom: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  headerText: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: colors.textLight,
  },
  metricsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 24,
    gap: 12,
  },
  metricCard: {
    flex: 1,
    minWidth: '45%',
    alignItems: 'center',
  },
  metricIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  metricValue: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  metricLabel: {
    fontSize: 14,
    color: colors.textLight,
    marginBottom: 4,
  },
  metricChange: {
    fontSize: 12,
    color: colors.success,
    fontWeight: '500',
  },
  chartCard: {
    marginBottom: 24,
  },
  chartTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 16,
  },
  chartContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    height: 120,
    marginBottom: 12,
  },
  chartBar: {
    flex: 1,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  chartBarFill: {
    width: '100%',
    backgroundColor: colors.primary,
    borderRadius: 8,
    marginBottom: 4,
  },
  chartBarLabel: {
    fontSize: 12,
    color: colors.textLight,
  },
  chartLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  chartLabel: {
    fontSize: 12,
    color: colors.textLight,
    flex: 1,
    textAlign: 'center',
  },
  servicesCard: {
    marginBottom: 24,
  },
  servicesTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 16,
  },
  serviceItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  serviceRank: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  serviceRankText: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.white,
  },
  serviceInfo: {
    flex: 1,
  },
  serviceName: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
    marginBottom: 4,
  },
  serviceStats: {
    fontSize: 14,
    color: colors.textLight,
  },
  servicePerformance: {
    alignItems: 'center',
  },
  serviceRate: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.success,
  },
  serviceRateLabel: {
    fontSize: 12,
    color: colors.textLight,
  },
  tipsCard: {
    marginBottom: 24,
  },
  tipsTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 16,
  },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  tipIcon: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
    marginTop: 4,
  },
  tipText: {
    flex: 1,
    fontSize: 14,
    color: colors.text,
    lineHeight: 20,
  },
  inquiriesCard: {
    marginBottom: 24,
  },
  inquiriesTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 16,
  },
  inquiryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  inquiryInfo: {
    flex: 1,
  },
  inquiryCustomer: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  inquiryService: {
    fontSize: 14,
    color: colors.textLight,
  },
  inquiryStatus: {
    alignItems: 'flex-end',
  },
  inquiryStatusText: {
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 4,
  },
  inquiryDate: {
    fontSize: 12,
    color: colors.textLight,
  },
});

