-- Fix RLS policy for guests table
-- This script fixes the table name mismatch between the RLS policy and actual table

-- Drop the old policy (if it exists)
DROP POLICY IF EXISTS "Users can manage guests of their weddings" ON guest;
DROP POLICY IF EXISTS "Users can manage guests of their weddings" ON guests;

-- Create a simple policy for the 'guests' table (plural) - only check wedding ownership
CREATE POLICY "Users can manage guests of their weddings" ON guests FOR ALL USING (
  wedding_id IN (SELECT id FROM wedding WHERE owner_id = auth.uid())
);

-- Verify the policy was created
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual 
FROM pg_policies 
WHERE tablename = 'guests';
