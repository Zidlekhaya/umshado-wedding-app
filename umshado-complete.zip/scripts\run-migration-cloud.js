#!/usr/bin/env node

/**
 * Run Migration on Supabase Cloud
 * This script runs the vendor_services migration directly on the cloud database
 */

const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing Supabase environment variables');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function runMigration() {
  console.log('🚀 Running vendor_services migration on cloud database...\n');

  try {
    // Create vendor_services table
    console.log('📋 Creating vendor_services table...');
    
    const { error: createError } = await supabase.rpc('exec_sql', {
      sql: `
        -- Create vendor_services table if it doesn't exist
        CREATE TABLE IF NOT EXISTS vendor_services (
          id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
          vendor_id UUID NOT NULL REFERENCES vendor_profiles(id) ON DELETE CASCADE,
          service_name TEXT NOT NULL,
          description TEXT,
          price_min DECIMAL(10,2),
          price_max DECIMAL(10,2),
          price_type TEXT DEFAULT 'fixed' CHECK (price_type IN ('fixed', 'package', 'hourly', 'per_person')),
          duration_hours DECIMAL(5,2),
          includes TEXT[] DEFAULT '{}',
          add_ons TEXT[] DEFAULT '{}',
          is_active BOOLEAN DEFAULT true,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- Create indexes
        CREATE INDEX IF NOT EXISTS idx_vendor_services_vendor ON vendor_services(vendor_id);
        CREATE INDEX IF NOT EXISTS idx_vendor_services_active ON vendor_services(is_active);
        CREATE INDEX IF NOT EXISTS idx_vendor_services_price ON vendor_services(price_min, price_max);

        -- Enable RLS
        ALTER TABLE vendor_services ENABLE ROW LEVEL SECURITY;

        -- Create RLS policies
        CREATE POLICY "Vendor services are publicly readable" ON vendor_services
          FOR SELECT USING (true);

        CREATE POLICY "Vendors can manage their own services" ON vendor_services
          FOR ALL USING (
            EXISTS (
              SELECT 1 FROM vendor_profiles 
              WHERE vendor_profiles.id = vendor_services.vendor_id 
              AND vendor_profiles.user_id = auth.uid()
            )
          );
      `
    });

    if (createError) {
      console.error('❌ Error creating table:', createError.message);
      return;
    }

    console.log('✅ vendor_services table created successfully!');

    // Add sample services
    console.log('\n🎨 Adding sample services...');
    
    // Get the first vendor profile
    const { data: vendorProfiles, error: profileError } = await supabase
      .from('vendor_profiles')
      .select('id, business_name, category')
      .limit(1);

    if (profileError) {
      console.error('❌ Error fetching vendor profiles:', profileError.message);
      return;
    }

    if (!vendorProfiles || vendorProfiles.length === 0) {
      console.log('❌ No vendor profiles found. Please create a vendor account first.');
      return;
    }

    const vendorProfile = vendorProfiles[0];
    console.log(`👤 Adding services for vendor: ${vendorProfile.business_name}`);

    // Sample services
    const sampleServices = [
      {
        vendor_id: vendorProfile.id,
        service_name: 'Wedding Photography Package',
        description: 'Complete wedding photography coverage including ceremony, reception, and couple portraits. Professional editing and online gallery included.',
        price_min: 8000,
        price_max: 15000,
        price_type: 'package',
        duration_hours: 8,
        includes: ['8 hours coverage', '500+ edited photos', 'Online gallery', 'USB drive', 'Engagement consultation'],
        add_ons: ['Engagement shoot', 'Photo book', 'Drone footage', 'Extended coverage'],
        is_active: true,
      },
      {
        vendor_id: vendorProfile.id,
        service_name: 'Bridal Makeup & Hair',
        description: 'Professional bridal makeup and hairstyling for the bride, including trial session and touch-ups throughout the day.',
        price_min: 2500,
        price_max: 4500,
        price_type: 'fixed',
        duration_hours: 4,
        includes: ['Trial session', 'Wedding day makeup', 'Wedding day hairstyling', 'Touch-up kit', 'False lashes'],
        add_ons: ['Bridal party makeup', 'Mother of bride styling', 'Early morning start', 'Travel to venue'],
        is_active: true,
      },
      {
        vendor_id: vendorProfile.id,
        service_name: 'Wedding Venue Decoration',
        description: 'Complete venue decoration service including ceremony and reception setup, floral arrangements, and lighting.',
        price_min: 12000,
        price_max: 25000,
        price_type: 'package',
        duration_hours: 12,
        includes: ['Ceremony setup', 'Reception decoration', 'Floral arrangements', 'Lighting design', 'Setup & breakdown'],
        add_ons: ['Custom centerpieces', 'Photo booth setup', 'Outdoor ceremony arch', 'Candle arrangements'],
        is_active: true,
      }
    ];

    // Insert sample services
    const { data: insertedServices, error: insertError } = await supabase
      .from('vendor_services')
      .insert(sampleServices)
      .select();

    if (insertError) {
      console.error('❌ Error inserting services:', insertError.message);
      return;
    }

    console.log(`✅ Successfully added ${insertedServices.length} sample services:`);
    insertedServices.forEach((service, index) => {
      console.log(`   ${index + 1}. ${service.service_name} - R${service.price_min} - R${service.price_max}`);
    });

    console.log('\n🎉 Migration completed successfully!');
    console.log('📱 You can now create and view services in the vendor dashboard');

  } catch (error) {
    console.error('❌ Migration failed:', error.message);
  }
}

// Run the migration
runMigration().then(() => {
  console.log('\n✨ Migration script completed');
  process.exit(0);
}).catch((error) => {
  console.error('❌ Script failed:', error);
  process.exit(1);
});
