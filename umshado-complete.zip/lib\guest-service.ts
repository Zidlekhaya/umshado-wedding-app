// lib/guest-service.ts
import { supabase } from './supabase';
import { Guest, RSVPStatus } from '../types/guest';

export type GuestCategory = 'family' | 'friends' | 'colleagues' | 'other';

export type CreateGuestInput = {
  weddingId: string;
  fullName: string;
  phone: string;
  category?: GuestCategory; // default to 'family' if undefined
};

export type CreateGuestData = {
  full_name: string;
  email?: string | null;
  phone?: string | null;
  side?: 'Bride' | 'Groom' | 'Both';
  category?: GuestCategory;
  plus_one?: boolean;
  plus_one_name?: string | null;
  dietary?: string | null;
  table_number?: number | null;
  notes?: string | null;
};

export type UpdateGuestData = {
  id: string;
  full_name?: string;
  email?: string | null;
  phone?: string | null;
  side?: 'Bride' | 'Groom' | 'Both' | string;
  category?: GuestCategory;
  plus_one?: boolean;
  plus_one_name?: string | null;
  dietary?: string | null;
  table_number?: number | null;
  notes?: string | null;
  rsvp?: RSVPStatus;
};

export async function createGuestRPC(input: CreateGuestInput) {
  const { weddingId, fullName, phone, category } = input;

  const params = {
    p_wedding_id: weddingId,
    p_full_name: fullName.trim(),
    p_phone: phone.trim(),
    p_category: (category ?? 'family').toLowerCase(),
  };

  const { data, error } = await supabase.rpc('add_guest_secure', params);

  if (error) {
    console.error('RPC add_guest_secure error:', error, params);
    throw new Error(error.message || 'Failed to add guest');
  }

  return data; // inserted guest row
}

export async function listGuests(weddingId: string) {
  const { data, error } = await supabase
    .from('guest')
    .select('id, wedding_id, full_name, phone, email, rsvp, side, notes, created_at')
    .eq('wedding_id', weddingId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return (data ?? []) as Guest[];
}

export function generateInviteMessage(guestName: string, weddingName: string, rsvpLink: string): string {
  return `Hey ${guestName} — you're invited to our wedding "${weddingName}" 🎊. Tap to RSVP: ${rsvpLink}`;
}

export function getWhatsAppUrl(phone: string, message: string): string {
  const encodedMessage = encodeURIComponent(message);
  return `whatsapp://send?phone=${phone}&text=${encodedMessage}`;
}

export function getSMSUrl(phone: string, message: string): string {
  const encodedMessage = encodeURIComponent(message);
  return `sms:${phone}?body=${encodedMessage}`;
}

export async function getGuestById(guestId: string) {
  const { data, error } = await supabase
    .from('guest')
    .select('*')
    .eq('id', guestId)
    .single();

  if (error) {
    console.error('Get guest by ID error:', error);
    throw error;
  }

  return data as Guest;
}

export async function updateGuest(updates: UpdateGuestData) {
  const { id, ...updateData } = updates;
  
  // Convert side to lowercase if provided
  if (updateData.side) {
    updateData.side = updateData.side.toLowerCase() as any;
  }
  
  const { data, error } = await supabase
    .from('guest')
    .update(updateData)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('Update guest error:', error);
    throw error;
  }

  return data;
}

export async function createGuest(guestData: CreateGuestData & { wedding_id: string }) {
  const { data, error } = await supabase
    .from('guest')
    .insert([{
      wedding_id: guestData.wedding_id,
      full_name: guestData.full_name,
      email: guestData.email,
      phone: guestData.phone,
      side: guestData.side?.toLowerCase() || 'both', // use provided side or default to 'both'
      rsvp: 'no_reply', // default RSVP status
      notes: guestData.notes,
    }])
    .select()
    .single();

  if (error) {
    console.error('Create guest error:', error);
    throw error;
  }

  return data as Guest;
}

export async function deleteGuest(guestId: string) {
  const { error } = await supabase
    .from('guest')
    .delete()
    .eq('id', guestId);

  if (error) {
    console.error('Delete guest error:', error);
    throw error;
  }
}