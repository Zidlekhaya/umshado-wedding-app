// Unified Design System for Umshado Wedding App
// This consolidates all design tokens into a single, consistent system

export const DesignSystem = {
  // Color Palette - Warm, elegant wedding theme
  colors: {
    // Primary Brand Colors
    primary: {
      50: '#FDF6E3',   // Very light beige
      100: '#F5E8C7',  // Light beige (main surface)
      200: '#E8D5B7',  // Medium beige
      300: '#D4A373',  // Main brand color
      400: '#C8965F',  // Darker brand
      500: '#B8945F',  // Dark brand
      600: '#A67C4A',  // Darker
      700: '#8C6B3A',  // Dark
      800: '#6B4F3A',  // Very dark
      900: '#4A3526',  // Darkest
    },
    
    // Secondary Colors
    secondary: {
      50: '#F0F9F0',   // Very light green
      100: '#E5F3E5',  // Light green
      200: '#C4D1BC',  // Medium light green
      300: '#A9B7A0',  // Main accent green
      400: '#8FA085',  // Darker green
      500: '#7A8A70',  // Dark green
      600: '#6B7A60',  // Darker
      700: '#5C6A50',  // Dark
      800: '#4D5A40',  // Very dark
      900: '#3E4A30',  // Darkest
    },
    
    // Neutral Colors
    neutral: {
      0: '#FFFFFF',    // Pure white
      50: '#FAFAFA',   // Very light gray
      100: '#F5F5F5',  // Light gray
      200: '#E5E5E5',  // Medium light gray
      300: '#D4D4D4',  // Medium gray
      400: '#A3A3A3',  // Medium dark gray
      500: '#737373',  // Base gray
      600: '#525252',  // Dark gray
      700: '#404040',  // Darker gray
      800: '#262626',  // Very dark gray
      900: '#171717',  // Almost black
      950: '#0A0A0A',  // Pure black
    },
    
    // Status Colors
    success: {
      50: '#F0FDF4',
      100: '#DCFCE7',
      200: '#BBF7D0',
      300: '#86EFAC',
      400: '#4ADE80',
      500: '#22C55E',
      600: '#16A34A',
      700: '#15803D',
      800: '#166534',
      900: '#14532D',
    },
    
    warning: {
      50: '#FFFBEB',
      100: '#FEF3C7',
      200: '#FDE68A',
      300: '#FCD34D',
      400: '#FBBF24',
      500: '#F59E0B',
      600: '#D97706',
      700: '#B45309',
      800: '#92400E',
      900: '#78350F',
    },
    
    error: {
      50: '#FEF2F2',
      100: '#FEE2E2',
      200: '#FECACA',
      300: '#FCA5A5',
      400: '#F87171',
      500: '#EF4444',
      600: '#DC2626',
      700: '#B91C1C',
      800: '#991B1B',
      900: '#7F1D1D',
    },
    
    // Semantic Colors
    background: {
      primary: '#f0fbe9',    // Light mint green (new brand background)
      secondary: '#FFFFFF',  // White
      tertiary: '#F5F5F5',   // Light gray
    },
    
    surface: {
      primary: '#FFFFFF',    // White cards
      secondary: '#f0fbe9',  // Light mint green
      tertiary: '#F5F5F5',   // Light gray
    },
    
    text: {
      primary: '#2C2C2C',    // Dark text
      secondary: '#737373',  // Medium gray
      tertiary: '#A3A3A3',   // Light gray
      inverse: '#FFFFFF',    // White text
      accent: '#A9B7A0',     // Green accent
    },
    
    border: {
      primary: '#E5E5E5',    // Light border
      secondary: '#D4D4D4',  // Medium border
      accent: '#A9B7A0',     // Green border
    },
  },
  
  // Typography System
  typography: {
    fontFamily: {
      primary: 'System',     // iOS: SF Pro, Android: Roboto
      heading: 'System',
      mono: 'Courier New',
    },
    
    fontSize: {
      xs: 12,
      sm: 14,
      base: 16,
      lg: 18,
      xl: 20,
      '2xl': 24,
      '3xl': 30,
      '4xl': 36,
      '5xl': 48,
      '6xl': 60,
    },
    
    fontWeight: {
      normal: '400',
      medium: '500',
      semibold: '600',
      bold: '700',
      extrabold: '800',
    },
    
    lineHeight: {
      tight: 1.25,
      normal: 1.5,
      relaxed: 1.75,
    },
    
    letterSpacing: {
      tight: -0.5,
      normal: 0,
      wide: 0.5,
    },
  },
  
  // Spacing System (8px base)
  spacing: {
    0: 0,
    1: 4,    // 0.25rem
    2: 8,    // 0.5rem
    3: 12,   // 0.75rem
    4: 16,   // 1rem
    5: 20,   // 1.25rem
    6: 24,   // 1.5rem
    8: 32,   // 2rem
    10: 40,  // 2.5rem
    12: 48,  // 3rem
    16: 64,  // 4rem
    20: 80,  // 5rem
    24: 96,  // 6rem
    32: 128, // 8rem
  },
  
  // Border Radius System
  borderRadius: {
    none: 0,
    xs: 4,
    sm: 8,
    md: 12,
    lg: 16,
    xl: 20,
    '2xl': 24,
    '3xl': 32,
    full: 9999,
  },
  
  // Shadow System
  shadows: {
    none: {
      shadowColor: 'transparent',
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 0,
      shadowRadius: 0,
      elevation: 0,
    },
    sm: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.05,
      shadowRadius: 2,
      elevation: 1,
    },
    md: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 2,
    },
    lg: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.15,
      shadowRadius: 8,
      elevation: 4,
    },
    xl: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 8 },
      shadowOpacity: 0.2,
      shadowRadius: 16,
      elevation: 8,
    },
  },
  
  // Animation System
  animations: {
    duration: {
      fast: 150,
      normal: 300,
      slow: 500,
    },
    easing: {
      linear: 'linear',
      ease: 'ease',
      easeIn: 'ease-in',
      easeOut: 'ease-out',
      easeInOut: 'ease-in-out',
    },
  },
  
  // Component Sizes
  sizes: {
    button: {
      sm: { height: 32, paddingHorizontal: 12 },
      md: { height: 40, paddingHorizontal: 16 },
      lg: { height: 48, paddingHorizontal: 20 },
      xl: { height: 56, paddingHorizontal: 24 },
    },
    input: {
      sm: { height: 32, paddingHorizontal: 12 },
      md: { height: 40, paddingHorizontal: 16 },
      lg: { height: 48, paddingHorizontal: 20 },
    },
    card: {
      sm: { padding: 12 },
      md: { padding: 16 },
      lg: { padding: 20 },
      xl: { padding: 24 },
    },
  },
};

// Export individual systems for easy access
export const colors = DesignSystem.colors;
export const typography = DesignSystem.typography;
export const spacing = DesignSystem.spacing;
export const borderRadius = DesignSystem.borderRadius;
export const shadows = DesignSystem.shadows;
export const animations = DesignSystem.animations;
export const sizes = DesignSystem.sizes;

// Common style combinations
export const commonStyles = {
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  
  card: {
    backgroundColor: colors.surface.primary,
    borderRadius: borderRadius.lg,
    ...shadows.md,
  },
  
  button: {
    borderRadius: borderRadius.lg,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  
  input: {
    backgroundColor: colors.surface.primary,
    borderWidth: 1,
    borderColor: colors.border.primary,
    borderRadius: borderRadius.lg,
    color: colors.text.primary,
  },
  
  text: {
    color: colors.text.primary,
    fontSize: typography.fontSize.base,
    lineHeight: typography.lineHeight.normal * typography.fontSize.base,
  },
  
  heading: {
    color: colors.text.primary,
    fontWeight: typography.fontWeight.bold,
  },
  
  subheading: {
    color: colors.text.secondary,
    fontWeight: typography.fontWeight.medium,
  },
  
  caption: {
    color: colors.text.tertiary,
    fontSize: typography.fontSize.sm,
  },
};

