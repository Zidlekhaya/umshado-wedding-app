import { useWeddingStore } from '@/stores/wedding';
import { act, renderHook } from '@testing-library/react-native';

describe('Wedding Store', () => {
  beforeEach(() => {
    // Reset the store before each test
    useWeddingStore.getState().setCurrentWedding(null);
    useWeddingStore.getState().setHasWedding(false);
  });

  it('should have initial state', () => {
    const { result } = renderHook(() => useWeddingStore());
    
    expect(result.current.currentWedding).toBeNull();
    expect(result.current.hasWedding).toBe(false);
  });

  it('should set current wedding', () => {
    const { result } = renderHook(() => useWeddingStore());
    
    const mockWedding = {
      id: 'test-id',
      name: 'Test Wedding',
      date: '2025-12-20',
      city: 'Johannesburg',
      culture: 'Zulu',
      owner_id: 'user-id',
      created_at: '2025-01-01T00:00:00Z',
      updated_at: '2025-01-01T00:00:00Z',
    };

    act(() => {
      result.current.setCurrentWedding(mockWedding);
    });

    expect(result.current.currentWedding).toEqual(mockWedding);
  });

  it('should set has wedding flag', () => {
    const { result } = renderHook(() => useWeddingStore());
    
    act(() => {
      result.current.setHasWedding(true);
    });

    expect(result.current.hasWedding).toBe(true);
  });

  it('should clear wedding data', () => {
    const { result } = renderHook(() => useWeddingStore());
    
    const mockWedding = {
      id: 'test-id',
      name: 'Test Wedding',
      date: '2025-12-20',
      city: 'Johannesburg',
      culture: 'Zulu',
      owner_id: 'user-id',
      created_at: '2025-01-01T00:00:00Z',
      updated_at: '2025-01-01T00:00:00Z',
    };

    // Set initial data
    act(() => {
      result.current.setCurrentWedding(mockWedding);
      result.current.setHasWedding(true);
    });

    expect(result.current.currentWedding).toEqual(mockWedding);
    expect(result.current.hasWedding).toBe(true);

    // Clear data
    act(() => {
      result.current.setCurrentWedding(null);
      result.current.setHasWedding(false);
    });

    expect(result.current.currentWedding).toBeNull();
    expect(result.current.hasWedding).toBe(false);
  });

  it('should update wedding data', () => {
    const { result } = renderHook(() => useWeddingStore());
    
    const initialWedding = {
      id: 'test-id',
      name: 'Test Wedding',
      date: '2025-12-20',
      city: 'Johannesburg',
      culture: 'Zulu',
      owner_id: 'user-id',
      created_at: '2025-01-01T00:00:00Z',
      updated_at: '2025-01-01T00:00:00Z',
    };

    const updatedWedding = {
      ...initialWedding,
      name: 'Updated Wedding',
      city: 'Cape Town',
    };

    act(() => {
      result.current.setCurrentWedding(initialWedding);
    });

    expect(result.current.currentWedding).toEqual(initialWedding);

    act(() => {
      result.current.setCurrentWedding(updatedWedding);
    });

    expect(result.current.currentWedding).toEqual(updatedWedding);
  });
});


