-- 009_migrate_vendor_services_to_packages.sql
-- IMPORTANT: Run this on staging first and validate before production!
BEGIN;

-- Create mapping table to help idempotency
CREATE TABLE IF NOT EXISTS migration_vendor_service_map (
  old_service_id uuid PRIMARY KEY,
  new_package_id uuid
);

-- Migrate vendor_services to vendor_packages
INSERT INTO vendor_packages (vendor_id, package_name, short_description, long_description, price_type, price_min, price_max, duration_hours, created_at, updated_at)
SELECT 
  vs.vendor_id, 
  vs.service_name, 
  LEFT(COALESCE(vs.description,''), 255) as short_description,
  vs.description as long_description, 
  vs.price_type, 
  vs.price_min, 
  vs.price_max, 
  vs.duration_hours, 
  vs.created_at, 
  vs.updated_at
FROM vendor_services vs
LEFT JOIN migration_vendor_service_map m ON m.old_service_id = vs.id
WHERE m.old_service_id IS NULL;

-- Populate migration map (match by vendor_id + package_name)
INSERT INTO migration_vendor_service_map (old_service_id, new_package_id)
SELECT vs.id, vp.id 
FROM vendor_services vs
JOIN vendor_packages vp ON vp.vendor_id = vs.vendor_id AND vp.package_name = vs.service_name
WHERE NOT EXISTS (
  SELECT 1 FROM migration_vendor_service_map m 
  WHERE m.old_service_id = vs.id
);

-- Convert includes array into package_items where possible
INSERT INTO package_items (package_id, item_name, order_index)
SELECT 
  m.new_package_id, 
  unnest(vs.includes) as item_name,
  row_number() OVER (PARTITION BY m.new_package_id ORDER BY unnest(vs.includes)) - 1 as order_index
FROM vendor_services vs
JOIN migration_vendor_service_map m ON m.old_service_id = vs.id
WHERE cardinality(vs.includes) > 0;

-- Convert add_ons array into package_addons where possible
INSERT INTO package_addons (package_id, title, description, price, price_type, is_active)
SELECT 
  m.new_package_id, 
  unnest(vs.add_ons) as title,
  'Migrated from vendor_services' as description,
  0 as price, -- Default price, vendor should update
  'fixed' as price_type,
  true as is_active
FROM vendor_services vs
JOIN migration_vendor_service_map m ON m.old_service_id = vs.id
WHERE cardinality(vs.add_ons) > 0;

-- Generate slugs for migrated packages (simple slug generation)
UPDATE vendor_packages 
SET slug = LOWER(REGEXP_REPLACE(REGEXP_REPLACE(package_name, '[^a-zA-Z0-9\s]', '', 'g'), '\s+', '-', 'g'))
WHERE slug IS NULL;

-- Handle duplicate slugs by appending vendor_id
UPDATE vendor_packages 
SET slug = slug || '-' || SUBSTRING(vendor_id::text, 1, 8)
WHERE id IN (
  SELECT id FROM (
    SELECT id, slug, ROW_NUMBER() OVER (PARTITION BY slug ORDER BY created_at) as rn
    FROM vendor_packages
  ) t WHERE rn > 1
);

COMMIT;

-- Verification queries (run these after migration to validate)
-- SELECT COUNT(*) as migrated_packages FROM vendor_packages;
-- SELECT COUNT(*) as migrated_items FROM package_items;
-- SELECT COUNT(*) as migrated_addons FROM package_addons;
-- SELECT COUNT(*) as services_with_includes FROM vendor_services WHERE cardinality(includes) > 0;
-- SELECT COUNT(*) as services_with_addons FROM vendor_services WHERE cardinality(add_ons) > 0;
