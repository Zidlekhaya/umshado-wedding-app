// components/ui/Button.tsx
import React from 'react';
import { TouchableOpacity, Text, ActivityIndicator, StyleSheet, ViewStyle, TextStyle, Animated } from 'react-native';
import { colors, typography, spacing, borderRadius, shadows, animations } from '@/src/theme/design-system';

interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'success' | 'warning' | 'error' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  loading?: boolean;
  disabled?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  style?: ViewStyle;
  textStyle?: TextStyle;
  fullWidth?: boolean;
}

export function Button({
  title,
  onPress,
  variant = 'primary',
  size = 'md',
  loading = false,
  disabled = false,
  leftIcon,
  rightIcon,
  style,
  textStyle,
  fullWidth = false,
}: ButtonProps) {
  const [scaleValue] = React.useState(new Animated.Value(1));

  const handlePressIn = () => {
    Animated.spring(scaleValue, {
      toValue: 0.95,
      duration: animations.duration.fast,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.spring(scaleValue, {
      toValue: 1,
      duration: animations.duration.fast,
      useNativeDriver: true,
    }).start();
  };

  const buttonStyle = [
    styles.base,
    styles[variant],
    styles[size],
    fullWidth && styles.fullWidth,
    disabled && styles.disabled,
    style,
  ];

  const textStyleCombined = [
    styles.text,
    styles[`${variant}Text`],
    styles[`${size}Text`],
    disabled && styles.disabledText,
    textStyle,
  ];

  const getLoadingColor = () => {
    switch (variant) {
      case 'primary':
      case 'success':
      case 'warning':
      case 'error':
        return colors.neutral[0];
      case 'secondary':
      case 'outline':
      case 'ghost':
        return colors.primary[500];
      default:
        return colors.neutral[0];
    }
  };

  return (
    <Animated.View style={{ transform: [{ scale: scaleValue }] }}>
      <TouchableOpacity
        style={buttonStyle}
        onPress={onPress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        disabled={disabled || loading}
        activeOpacity={0.8}
      >
        {loading && (
          <ActivityIndicator 
            color={getLoadingColor()} 
            size="small" 
            style={styles.loadingIndicator}
          />
        )}
        {!loading && leftIcon && (
          <Text style={styles.leftIcon}>{leftIcon}</Text>
        )}
        <Text style={textStyleCombined}>{title}</Text>
        {!loading && rightIcon && (
          <Text style={styles.rightIcon}>{rightIcon}</Text>
        )}
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  base: {
    borderRadius: borderRadius.lg,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    ...shadows.sm,
  },
  
  // Variants
  primary: {
    backgroundColor: colors.primary[300],
  },
  secondary: {
    backgroundColor: colors.secondary[300],
  },
  success: {
    backgroundColor: colors.success[500],
  },
  warning: {
    backgroundColor: colors.warning[500],
  },
  error: {
    backgroundColor: colors.error[500],
  },
  outline: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: colors.border.primary,
  },
  ghost: {
    backgroundColor: 'transparent',
  },
  
  // Sizes
  sm: {
    height: 32,
    paddingHorizontal: spacing[3],
  },
  md: {
    height: 40,
    paddingHorizontal: spacing[4],
  },
  lg: {
    height: 48,
    paddingHorizontal: spacing[5],
  },
  xl: {
    height: 56,
    paddingHorizontal: spacing[6],
  },
  
  // States
  disabled: {
    opacity: 0.5,
  },
  fullWidth: {
    width: '100%',
  },
  
  // Text styles
  text: {
    fontWeight: typography.fontWeight.semibold,
    textAlign: 'center',
  },
  primaryText: {
    color: colors.text.inverse,
  },
  secondaryText: {
    color: colors.text.inverse,
  },
  successText: {
    color: colors.text.inverse,
  },
  warningText: {
    color: colors.text.inverse,
  },
  errorText: {
    color: colors.text.inverse,
  },
  outlineText: {
    color: colors.text.primary,
  },
  ghostText: {
    color: colors.text.primary,
  },
  disabledText: {
    opacity: 0.7,
  },
  
  // Text sizes
  smText: {
    fontSize: typography.fontSize.sm,
  },
  mdText: {
    fontSize: typography.fontSize.base,
  },
  lgText: {
    fontSize: typography.fontSize.lg,
  },
  xlText: {
    fontSize: typography.fontSize.xl,
  },
  
  // Icons
  loadingIndicator: {
    marginRight: spacing[2],
  },
  leftIcon: {
    marginRight: spacing[2],
  },
  rightIcon: {
    marginLeft: spacing[2],
  },
});


