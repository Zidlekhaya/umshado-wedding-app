// lib/ai-service.ts
import { supabase } from './supabase';

// AI Service for wedding planning assistance
export class AIWeddingPlanner {
  private apiKey: string;
  private baseUrl: string;

  constructor() {
    // You'll need to add these to your .env file
    this.apiKey = process.env.EXPO_PUBLIC_OPENAI_API_KEY || '';
    this.baseUrl = 'https://api.openai.com/v1';
  }

  /**
   * AI Chat Assistant for wedding planning
   */
  async chatWithPlanner(message: string, context: {
    weddingId: string;
    guestCount?: number;
    budget?: number;
    location?: string;
    weddingDate?: string;
    preferences?: any;
  }): Promise<string> {
    try {
      // Get wedding context from database
      const weddingContext = await this.getWeddingContext(context.weddingId);
      
      const systemPrompt = `You are an expert wedding planner AI assistant for the Umshado app. 
      You help couples plan their perfect wedding with practical, actionable advice.
      
      Current wedding context:
      - Guest count: ${weddingContext.guestCount || 'Not specified'}
      - Budget: R${weddingContext.budget || 'Not specified'}
      - Location: ${weddingContext.location || 'Not specified'}
      - Wedding date: ${weddingContext.date || 'Not specified'}
      - Style preferences: ${weddingContext.style || 'Not specified'}
      
      Provide helpful, specific advice. Always consider South African context, pricing in Rands, and local vendors.
      Keep responses concise but informative.`;

      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: message }
          ],
          max_tokens: 500,
          temperature: 0.7,
        }),
      });

      const data = await response.json();
      return data.choices[0]?.message?.content || 'Sorry, I couldn\'t process your request.';
    } catch (error) {
      console.error('AI Chat error:', error);
      return 'Sorry, I\'m having trouble connecting right now. Please try again later.';
    }
  }

  /**
   * AI Budget Analysis and Optimization
   */
  async analyzeBudget(weddingId: string): Promise<{
    analysis: string;
    suggestions: string[];
    optimizations: Array<{
      category: string;
      currentSpending: number;
      suggestedSpending: number;
      savings: number;
      reason: string;
    }>;
  }> {
    try {
      // Get budget data
      const budgetData = await this.getBudgetData(weddingId);
      const weddingContext = await this.getWeddingContext(weddingId);

      const prompt = `Analyze this wedding budget and provide optimization suggestions:
      
      Wedding Details:
      - Guest count: ${weddingContext.guestCount}
      - Location: ${weddingContext.location}
      - Budget: R${budgetData.totalPlanned}
      
      Current Spending:
      ${budgetData.items.map(item => 
        `- ${item.item.name}: R${item.spent} / R${item.item.planned} (${item.percentage.toFixed(1)}%)`
      ).join('\n')}
      
      Provide analysis and suggestions for South African weddings. Focus on practical cost-saving opportunities.`;

      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [{ role: 'user', content: prompt }],
          max_tokens: 800,
          temperature: 0.5,
        }),
      });

      const data = await response.json();
      const analysis = data.choices[0]?.message?.content || '';

      // Parse the response to extract structured data
      return this.parseBudgetAnalysis(analysis, budgetData);
    } catch (error) {
      console.error('Budget analysis error:', error);
      return {
        analysis: 'Unable to analyze budget at this time.',
        suggestions: [],
        optimizations: []
      };
    }
  }

  /**
   * AI Task Generation and Prioritization
   */
  async generateTasks(weddingId: string): Promise<Array<{
    title: string;
    description: string;
    category: string;
    priority: 'low' | 'medium' | 'high';
    dueDate: string;
    estimatedHours: number;
  }>> {
    try {
      const weddingContext = await this.getWeddingContext(weddingId);
      const existingTasks = await this.getExistingTasks(weddingId);

      const prompt = `Generate wedding planning tasks for this couple:
      
      Wedding Details:
      - Date: ${weddingContext.date}
      - Guest count: ${weddingContext.guestCount}
      - Location: ${weddingContext.location}
      - Budget: R${weddingContext.budget}
      
      Existing tasks: ${existingTasks.map(t => t.title).join(', ')}
      
      Generate 5-8 new tasks that aren't already covered. Include:
      - Task title
      - Description
      - Category (venue, catering, photography, music, flowers, decor, transport, attire, invitations, general)
      - Priority (low, medium, high)
      - Suggested due date (relative to wedding date)
      - Estimated hours to complete
      
      Format as JSON array.`;

      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [{ role: 'user', content: prompt }],
          max_tokens: 1000,
          temperature: 0.6,
        }),
      });

      const data = await response.json();
      const content = data.choices[0]?.message?.content || '[]';
      
      try {
        return JSON.parse(content);
      } catch {
        return [];
      }
    } catch (error) {
      console.error('Task generation error:', error);
      return [];
    }
  }

  /**
   * AI Vendor Recommendations
   */
  async recommendVendors(weddingId: string, category: string): Promise<Array<{
    name: string;
    reason: string;
    estimatedCost: string;
    location: string;
    specialties: string[];
  }>> {
    try {
      const weddingContext = await this.getWeddingContext(weddingId);
      const existingVendors = await this.getExistingVendors(weddingId);

      const prompt = `Recommend ${category} vendors for this wedding:
      
      Wedding Details:
      - Location: ${weddingContext.location}
      - Guest count: ${weddingContext.guestCount}
      - Budget: R${weddingContext.budget}
      - Style: ${weddingContext.style || 'Not specified'}
      
      Existing vendors: ${existingVendors.map(v => v.name).join(', ')}
      
      Recommend 3-5 ${category} vendors in South Africa. Include:
      - Vendor name
      - Why they're a good fit
      - Estimated cost range
      - Location
      - Specialties
      
      Format as JSON array.`;

      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [{ role: 'user', content: prompt }],
          max_tokens: 800,
          temperature: 0.7,
        }),
      });

      const data = await response.json();
      const content = data.choices[0]?.message?.content || '[]';
      
      try {
        return JSON.parse(content);
      } catch {
        return [];
      }
    } catch (error) {
      console.error('Vendor recommendation error:', error);
      return [];
    }
  }

  /**
   * AI Guest List Optimization
   */
  async optimizeGuestList(weddingId: string): Promise<{
    analysis: string;
    suggestions: string[];
    seatingSuggestions: Array<{
      tableNumber: number;
      guests: string[];
      reason: string;
    }>;
  }> {
    try {
      const guests = await this.getGuestList(weddingId);
      const weddingContext = await this.getWeddingContext(weddingId);

      const prompt = `Analyze this guest list and provide optimization suggestions:
      
      Wedding Details:
      - Guest count: ${guests.length}
      - Venue capacity: ${weddingContext.venueCapacity || 'Not specified'}
      - Budget: R${weddingContext.budget}
      
      Guest breakdown:
      - Family: ${guests.filter(g => g.category === 'family').length}
      - Friends: ${guests.filter(g => g.category === 'friends').length}
      - Colleagues: ${guests.filter(g => g.category === 'colleagues').length}
      - Other: ${guests.filter(g => g.category === 'other').length}
      
      Provide analysis and suggestions for guest list optimization and seating arrangements.`;

      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [{ role: 'user', content: prompt }],
          max_tokens: 800,
          temperature: 0.6,
        }),
      });

      const data = await response.json();
      const analysis = data.choices[0]?.message?.content || '';

      return this.parseGuestAnalysis(analysis, guests);
    } catch (error) {
      console.error('Guest optimization error:', error);
      return {
        analysis: 'Unable to analyze guest list at this time.',
        suggestions: [],
        seatingSuggestions: []
      };
    }
  }

  // Helper methods
  private async getWeddingContext(weddingId: string) {
    const { data } = await supabase
      .from('weddings')
      .select('*')
      .eq('id', weddingId)
      .single();
    
    return data || {};
  }

  private async getBudgetData(weddingId: string) {
    const { getBudgetSummary } = await import('./budget');
    return await getBudgetSummary(weddingId);
  }

  private async getExistingTasks(weddingId: string) {
    const { listTasks } = await import('./task-service');
    return await listTasks(weddingId);
  }

  private async getExistingVendors(weddingId: string) {
    const { listVendors } = await import('./vendor-service');
    return await listVendors(weddingId);
  }

  private async getGuestList(weddingId: string) {
    const { listGuests } = await import('./guest-service');
    return await listGuests(weddingId);
  }

  private parseBudgetAnalysis(analysis: string, budgetData: any) {
    // Simple parsing - in production, you'd want more sophisticated parsing
    return {
      analysis,
      suggestions: [
        'Consider DIY decorations to save on decor costs',
        'Look for package deals with venues that include catering',
        'Book vendors during off-peak seasons for better rates'
      ],
      optimizations: budgetData.items.map((item: any) => ({
        category: item.item.name,
        currentSpending: item.spent,
        suggestedSpending: item.item.planned * 0.8, // 20% reduction
        savings: item.item.planned * 0.2,
        reason: 'Industry average suggests 20% savings possible'
      }))
    };
  }

  private parseGuestAnalysis(analysis: string, guests: any[]) {
    // Simple parsing - in production, you'd want more sophisticated parsing
    return {
      analysis,
      suggestions: [
        'Consider A/B list for venue capacity management',
        'Group family members at tables together',
        'Mix friends and colleagues for better conversation'
      ],
      seatingSuggestions: [
        {
          tableNumber: 1,
          guests: guests.filter(g => g.category === 'family').slice(0, 8).map(g => g.full_name),
          reason: 'Family table for close relatives'
        }
      ]
    };
  }
}

// Export singleton instance
export const aiPlanner = new AIWeddingPlanner();
