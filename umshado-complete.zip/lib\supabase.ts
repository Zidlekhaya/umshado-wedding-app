// lib/supabase.ts
import 'react-native-url-polyfill/auto'; // URL polyfill for React Native

import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import { Platform } from 'react-native';

// These come from your .env file. They must start with EXPO_PUBLIC_ to be available in the app.
const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

console.log('Supabase: Initializing client with URL:', SUPABASE_URL ? 'Found' : 'Missing');

// Create a single Supabase client for the whole app
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: Platform.OS === 'web' ? undefined : AsyncStorage,  // Use AsyncStorage only on mobile
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: Platform.OS === 'web',  // Enable URL detection on web
    flowType: 'pkce',              // Use PKCE flow for better security
  },
});

// Add session debugging
supabase.auth.onAuthStateChange((event, session) => {
  console.log('Supabase Auth State Change:', event, session ? 'Session found' : 'No session');
  if (session) {
    console.log('Supabase Session User ID:', session.user.id);
  }
});
