import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Image } from 'react-native';
import { router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { Colors, Typography, Spacing } from '@/constants/Design';

export default function UserTypeSelection() {
  return (
    <ScrollView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.logoContainer}>
          <Image 
            source={require('../assets/images/logo.png')}
            style={styles.logoImage}
            resizeMode="contain"
          />
        </View>
        <Text style={styles.title}>Welcome to Umshado</Text>
        <Text style={styles.subtitle}>Choose how you'd like to use our wedding platform</Text>
      </View>

      {/* User Type Selection */}
      <View style={styles.selectionContainer}>
        <TouchableOpacity 
          style={styles.optionCard}
          onPress={() => router.push('/(auth)/sign-in')}
        >
          <View style={styles.optionIcon}>
            <Feather name="heart" size={32} color="#FFB366" />
          </View>
          <Text style={styles.optionTitle}>I'm Planning a Wedding</Text>
          <Text style={styles.optionDescription}>
            Sign in as a couple to plan your perfect wedding day with our comprehensive planning tools
          </Text>
          <View style={styles.optionArrow}>
            <Feather name="arrow-right" size={20} color={Colors.textSecondary} />
          </View>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.optionCard}
          onPress={() => router.push('/(auth)/vendor-sign-in')}
        >
          <View style={styles.optionIcon}>
            <Feather name="gift" size={32} color="#FFB366" />
          </View>
          <Text style={styles.optionTitle}>I'm a Wedding Vendor</Text>
          <Text style={styles.optionDescription}>
            Sign in as a vendor to showcase your services and connect with couples planning their special day
          </Text>
          <View style={styles.optionArrow}>
            <Feather name="arrow-right" size={20} color={Colors.textSecondary} />
          </View>
        </TouchableOpacity>
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>Don't have an account?</Text>
        <View style={styles.footerLinks}>
          <Text style={styles.footerLink} onPress={() => router.push('/(auth)/sign-up')}>
            Sign up as a couple
          </Text>
          <Text style={styles.footerText}> or </Text>
          <Text style={styles.footerLink} onPress={() => router.push('/(auth)/vendor-sign-up')}>
            Sign up as a vendor
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0fbea',
  },
  header: {
    alignItems: 'center',
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.lg,
    paddingHorizontal: Spacing.lg,
  },
  logoContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.md,
  },
  logoImage: {
    width: 104,
    height: 104,
  },
  title: {
    fontSize: Typography.fontSize['3xl'],
    fontWeight: Typography.fontWeight.bold as any,
    color: Colors.primary,
    marginBottom: Spacing.md,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: Typography.fontSize.base,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: Typography.lineHeight.relaxed * Typography.fontSize.base,
  },
  selectionContainer: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.lg,
    gap: Spacing.lg,
  },
  optionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: Spacing.lg,
    alignItems: 'center',
    textAlign: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  optionIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'transparent',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.md,
  },
  optionTitle: {
    fontSize: Typography.fontSize.xl,
    fontWeight: Typography.fontWeight.semibold as any,
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
    textAlign: 'center',
  },
  optionDescription: {
    fontSize: Typography.fontSize.base,
    color: Colors.textSecondary,
    lineHeight: Typography.lineHeight.relaxed * Typography.fontSize.base,
    marginBottom: Spacing.md,
    textAlign: 'center',
  },
  optionArrow: {
    alignSelf: 'center',
  },
  footer: {
    alignItems: 'center',
    paddingTop: Spacing.lg,
    paddingBottom: Spacing.xl,
    paddingHorizontal: Spacing.lg,
    gap: Spacing.sm,
  },
  footerText: {
    fontSize: Typography.fontSize.base,
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  footerLinks: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  footerLink: {
    color: Colors.primary,
    fontWeight: Typography.fontWeight.semibold as any,
    fontSize: Typography.fontSize.base,
  },
});
