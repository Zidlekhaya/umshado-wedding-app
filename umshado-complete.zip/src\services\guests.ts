import { supabase } from '@/lib/supabase';
import type { Guest, RSVPStatus, GuestSide } from '@/types/guest';

export type RsvpCounts = { going: number; maybe: number; declined: number; no_reply: number };

export async function listGuests(weddingId: string, search?: string, rsvpFilter?: RSVPStatus) {
  let query = supabase
    .from('guest')
    .select('*')
    .eq('wedding_id', weddingId)
    .order('created_at', { ascending: false });

  if (search) {
    query = query.or(`full_name.ilike.%${search}%,phone.ilike.%${search}%,email.ilike.%${search}%`);
  }

  if (rsvpFilter) {
    query = query.eq('rsvp', rsvpFilter);
  }

  const { data, error } = await query.returns<Guest[]>();
  if (error) throw error;
  return data ?? [];
}

export async function addGuest(input: {
  wedding_id: string;
  full_name: string;
  phone?: string;
  email?: string;
  side?: GuestSide;
  notes?: string;
}) {
  const { data, error } = await supabase
    .from('guest')
    .insert({
      ...input,
      side: input.side ?? 'both',
      rsvp: 'no_reply',
    })
    .select()
    .single<Guest>();
  
  if (error) throw error;
  return data!;
}

export async function getGuestById(guestId: string) {
  const { data, error } = await supabase
    .from('guest')
    .select('*')
    .eq('id', guestId)
    .single<Guest>();
  
  if (error) throw error;
  return data!;
}

export async function updateGuest(guestId: string, updates: Partial<{
  full_name: string;
  phone: string;
  email: string;
  side: GuestSide;
  rsvp: RSVPStatus;
  notes: string;
}>) {
  const { data, error } = await supabase
    .from('guest')
    .update({
      ...updates,
      updated_at: new Date().toISOString(),
    })
    .eq('id', guestId)
    .select()
    .single<Guest>();
  
  if (error) throw error;
  return data!;
}

export async function deleteGuest(guestId: string) {
  const { error } = await supabase
    .from('guest')
    .delete()
    .eq('id', guestId);
  
  if (error) throw error;
}

export async function rsvpCounts(weddingId: string): Promise<RsvpCounts> {
  const statuses: RSVPStatus[] = ['going', 'maybe', 'declined', 'no_reply'];
  const counts: RsvpCounts = { going: 0, maybe: 0, declined: 0, no_reply: 0 };
  
  await Promise.all(
    statuses.map(async (status) => {
      const { count, error } = await supabase
        .from('guest')
        .select('id', { count: 'exact', head: true })
        .eq('wedding_id', weddingId)
        .eq('rsvp', status);
      
      if (error) throw error;
      counts[status] = count ?? 0;
    })
  );
  
  return counts;
}

export function subscribeGuests(weddingId: string, callback: (guests: Guest[]) => void) {
  const channel = supabase
    .channel('guests-changes')
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'guest',
        filter: `wedding_id=eq.${weddingId}`,
      },
      async () => {
        // Refetch guests when changes occur
        try {
          const guests = await listGuests(weddingId);
          callback(guests);
        } catch (error) {
          console.error('Error fetching guests after change:', error);
        }
      }
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
}

export function subscribeRsvpCounts(weddingId: string, callback: (counts: RsvpCounts) => void) {
  const channel = supabase
    .channel('rsvp-counts-changes')
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'guest',
        filter: `wedding_id=eq.${weddingId}`,
      },
      async () => {
        // Refetch counts when changes occur
        try {
          const counts = await rsvpCounts(weddingId);
          callback(counts);
        } catch (error) {
          console.error('Error fetching RSVP counts after change:', error);
        }
      }
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
}
