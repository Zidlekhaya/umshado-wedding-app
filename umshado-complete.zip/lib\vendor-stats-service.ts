import { supabase } from './supabase';

export interface VendorStats {
  totalViews: number;
  totalInquiries: number;
  totalReviews: number;
  averageRating: number;
}

export interface VendorInquiry {
  id: string;
  vendor_id: string;
  customer_name: string;
  customer_email: string;
  customer_phone?: string;
  service_type: string;
  event_date?: string;
  budget_range?: string;
  message: string;
  status: 'new' | 'contacted' | 'quoted' | 'booked' | 'cancelled';
  created_at: string;
  updated_at: string;
}

export interface VendorReview {
  id: string;
  vendor_id: string;
  customer_name: string;
  rating: number;
  review_text?: string;
  service_type: string;
  created_at: string;
}

/**
 * Track a profile view for a vendor
 */
export async function trackVendorView(vendorId: string): Promise<void> {
  try {
    // Get current view count and increment it
    const { data: profile, error: fetchError } = await supabase
      .from('vendor_profiles')
      .select('view_count')
      .eq('id', vendorId)
      .single();

    if (fetchError) {
      console.error('Error fetching vendor profile for view tracking:', fetchError);
      return;
    }

    const currentViews = profile.view_count || 0;
    
    // Update view count
    const { error: updateError } = await supabase
      .from('vendor_profiles')
      .update({ 
        view_count: currentViews + 1,
        updated_at: new Date().toISOString()
      })
      .eq('id', vendorId);

    if (updateError) {
      console.error('Error updating vendor view count:', updateError);
    }
  } catch (error) {
    console.error('Error tracking vendor view:', error);
  }
}

/**
 * Get vendor statistics
 */
export async function getVendorStats(vendorId: string): Promise<VendorStats> {
  try {
    const { data: profile, error: profileError } = await supabase
      .from('vendor_profiles')
      .select('view_count, inquiry_count, review_count, rating_average')
      .eq('id', vendorId)
      .single();

    if (profileError) {
      console.error('Error loading vendor stats:', profileError);
      return {
        totalViews: 0,
        totalInquiries: 0,
        totalReviews: 0,
        averageRating: 0,
      };
    }

    return {
      totalViews: profile.view_count || 0,
      totalInquiries: profile.inquiry_count || 0,
      totalReviews: profile.review_count || 0,
      averageRating: profile.rating_average || 0,
    };
  } catch (error) {
    console.error('Error getting vendor stats:', error);
    return {
      totalViews: 0,
      totalInquiries: 0,
      totalReviews: 0,
      averageRating: 0,
    };
  }
}

/**
 * Get vendor inquiries
 */
export async function getVendorInquiries(vendorId: string): Promise<VendorInquiry[]> {
  try {
    const { data: inquiries, error } = await supabase
      .from('vendor_inquiries')
      .select('*')
      .eq('vendor_id', vendorId)
      .order('created_at', { ascending: false });

    if (error) {
      // If table doesn't exist yet, return empty array silently
      if (error.code === 'PGRST205' && error.message.includes('vendor_inquiries')) {
        console.log('vendor_inquiries table not found, returning empty array');
        return [];
      }
      
      console.error('Error loading vendor inquiries:', error);
      return [];
    }

    return inquiries || [];
  } catch (error) {
    // If table doesn't exist yet, return empty array silently
    if (error && typeof error === 'object' && 'code' in error && error.code === 'PGRST205') {
      console.log('vendor_inquiries table not found, returning empty array');
      return [];
    }
    
    console.error('Error getting vendor inquiries:', error);
    return [];
  }
}

/**
 * Update inquiry status
 */
export async function updateInquiryStatus(inquiryId: string, status: VendorInquiry['status']): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('vendor_inquiries')
      .update({ 
        status,
        updated_at: new Date().toISOString()
      })
      .eq('id', inquiryId);

    if (error) {
      // If table doesn't exist yet, return false silently
      if (error.code === 'PGRST205' && error.message.includes('vendor_inquiries')) {
        console.log('vendor_inquiries table not found, cannot update status');
        return false;
      }
      
      console.error('Error updating inquiry status:', error);
      return false;
    }

    return true;
  } catch (error) {
    // If table doesn't exist yet, return false silently
    if (error && typeof error === 'object' && 'code' in error && error.code === 'PGRST205') {
      console.log('vendor_inquiries table not found, cannot update status');
      return false;
    }
    
    console.error('Error updating inquiry status:', error);
    return false;
  }
}

/**
 * Get vendor reviews
 */
export async function getVendorReviews(vendorId: string): Promise<VendorReview[]> {
  try {
    const { data: reviews, error } = await supabase
      .from('vendor_reviews')
      .select('*')
      .eq('vendor_id', vendorId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error loading vendor reviews:', error);
      return [];
    }

    return reviews || [];
  } catch (error) {
    console.error('Error getting vendor reviews:', error);
    return [];
  }
}


/**
 * Add a new review for a vendor
 */
export async function addVendorReview(
  vendorId: string,
  customerName: string,
  rating: number,
  reviewText?: string,
  serviceType?: string
): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('vendor_reviews')
      .insert([{
        vendor_id: vendorId,
        customer_name: customerName,
        rating,
        review_text: reviewText,
        service_type: serviceType || 'General',
        created_at: new Date().toISOString()
      }]);

    if (error) {
      console.error('Error adding vendor review:', error);
      return false;
    }

    // Update vendor profile with new review stats
    await updateVendorReviewStats(vendorId);

    return true;
  } catch (error) {
    console.error('Error adding vendor review:', error);
    return false;
  }
}

/**
 * Update vendor review statistics
 */
async function updateVendorReviewStats(vendorId: string): Promise<void> {
  try {
    // Get all reviews for this vendor
    const { data: reviews, error } = await supabase
      .from('vendor_reviews')
      .select('rating')
      .eq('vendor_id', vendorId);

    if (error) {
      console.error('Error loading reviews for stats update:', error);
      return;
    }

    const reviewCount = reviews?.length || 0;
    const averageRating = reviewCount > 0 
      ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviewCount 
      : 0;

    // Update vendor profile
    const { error: updateError } = await supabase
      .from('vendor_profiles')
      .update({
        review_count: reviewCount,
        rating_average: Math.round(averageRating * 10) / 10, // Round to 1 decimal place
        updated_at: new Date().toISOString()
      })
      .eq('id', vendorId);

    if (updateError) {
      console.error('Error updating vendor review stats:', updateError);
    }
  } catch (error) {
    console.error('Error updating vendor review stats:', error);
  }
}

/**
 * Add a new inquiry for a vendor
 */
export async function addVendorInquiry(
  vendorId: string,
  customerName: string,
  customerEmail: string,
  customerPhone: string,
  serviceType: string,
  message: string,
  eventDate?: string,
  budgetRange?: string
): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('vendor_inquiries')
      .insert([{
        vendor_id: vendorId,
        customer_name: customerName,
        customer_email: customerEmail,
        customer_phone: customerPhone,
        service_type: serviceType,
        event_date: eventDate,
        budget_range: budgetRange,
        message,
        status: 'new',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }]);

    if (error) {
      // If table doesn't exist yet, return false silently
      if (error.code === 'PGRST205' && error.message.includes('vendor_inquiries')) {
        console.log('vendor_inquiries table not found, cannot add inquiry');
        return false;
      }
      
      console.error('Error adding vendor inquiry:', error);
      return false;
    }

    // Update vendor profile with new inquiry count
    await updateVendorInquiryStats(vendorId);

    return true;
  } catch (error) {
    // If table doesn't exist yet, return false silently
    if (error && typeof error === 'object' && 'code' in error && error.code === 'PGRST205') {
      console.log('vendor_inquiries table not found, cannot add inquiry');
      return false;
    }
    
    console.error('Error adding vendor inquiry:', error);
    return false;
  }
}

/**
 * Update vendor inquiry statistics
 */
async function updateVendorInquiryStats(vendorId: string): Promise<void> {
  try {
    // Get inquiry count for this vendor
    const { count, error } = await supabase
      .from('vendor_inquiries')
      .select('*', { count: 'exact', head: true })
      .eq('vendor_id', vendorId);

    if (error) {
      console.error('Error loading inquiry count:', error);
      return;
    }

    // Update vendor profile
    const { error: updateError } = await supabase
      .from('vendor_profiles')
      .update({
        inquiry_count: count || 0,
        updated_at: new Date().toISOString()
      })
      .eq('id', vendorId);

    if (updateError) {
      console.error('Error updating vendor inquiry stats:', updateError);
    }
  } catch (error) {
    console.error('Error updating vendor inquiry stats:', error);
  }
}
