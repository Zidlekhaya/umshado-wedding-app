-- Create vendor_profiles table for marketplace
-- This table stores vendor marketplace profiles linked to auth.users

CREATE TABLE IF NOT EXISTS vendor_profiles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  business_name TEXT NOT NULL,
  business_description TEXT,
  category TEXT NOT NULL,
  location TEXT,
  city TEXT,
  price_range TEXT,
  contact_email TEXT,
  contact_phone TEXT,
  website TEXT,
  social_media TEXT,
  languages TEXT,
  service_areas TEXT,
  experience_years INTEGER,
  portfolio_images TEXT[], -- Array of image URLs
  certifications BOOLEAN DEFAULT FALSE,
  insurance BOOLEAN DEFAULT FALSE,
  company_logo TEXT, -- URL to company logo
  is_active BOOLEAN DEFAULT TRUE,
  is_verified BOOLEAN DEFAULT FALSE,
  view_count INTEGER DEFAULT 0,
  inquiry_count INTEGER DEFAULT 0,
  review_count INTEGER DEFAULT 0,
  rating_average DECIMAL(3,2) DEFAULT 0.00,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_vendor_profiles_user_id ON vendor_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_vendor_profiles_category ON vendor_profiles(category);
CREATE INDEX IF NOT EXISTS idx_vendor_profiles_city ON vendor_profiles(city);
CREATE INDEX IF NOT EXISTS idx_vendor_profiles_is_active ON vendor_profiles(is_active);
CREATE INDEX IF NOT EXISTS idx_vendor_profiles_rating ON vendor_profiles(rating_average DESC);

-- Enable Row Level Security (RLS)
ALTER TABLE vendor_profiles ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Vendors can view their own profile" ON vendor_profiles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Vendors can update their own profile" ON vendor_profiles
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Vendors can insert their own profile" ON vendor_profiles
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Anyone can view active vendor profiles" ON vendor_profiles
  FOR SELECT USING (is_active = TRUE);

-- Create function to automatically create vendor profile on signup
CREATE OR REPLACE FUNCTION create_vendor_profile_on_signup()
RETURNS TRIGGER AS $$
BEGIN
  -- Only create profile if user_type is 'vendor'
  IF NEW.raw_user_meta_data->>'user_type' = 'vendor' THEN
    INSERT INTO vendor_profiles (
      user_id,
      business_name,
      business_description,
      category,
      contact_email,
      is_active,
      is_verified
    ) VALUES (
      NEW.id,
      COALESCE(NEW.raw_user_meta_data->>'business_name', 'My Business'),
      'Professional wedding services',
      COALESCE(NEW.raw_user_meta_data->>'category', 'other'),
      NEW.email,
      TRUE,
      FALSE
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to automatically create vendor profile
CREATE TRIGGER trigger_create_vendor_profile_on_signup
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION create_vendor_profile_on_signup();

-- Create function to update vendor profile timestamps
CREATE OR REPLACE FUNCTION update_vendor_profile_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to update timestamps
CREATE TRIGGER trigger_update_vendor_profile_timestamp
  BEFORE UPDATE ON vendor_profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_vendor_profile_timestamp();









