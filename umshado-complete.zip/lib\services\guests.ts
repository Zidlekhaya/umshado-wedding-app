import { supabase } from "@/lib/supabase";
import type { RSVPStatus } from "@/types/guest";

export type RsvpCounts = { going: number; maybe: number; declined: number; none: number };

export async function getRsvpCounts(weddingId: string): Promise<RsvpCounts> {
  const { data, error } = await supabase
    .from("guest")
    .select("rsvp_status")
    .eq("wedding_id", weddingId);

  if (error) throw error;
  const counts: RsvpCounts = { going: 0, maybe: 0, declined: 0, none: 0 };
  (data ?? []).forEach((g: any) => {
    const s = (g.rsvp_status ?? "no_reply") as RSVPStatus;
    if (s === "no_reply") counts.none++;
    else if (s in counts) counts[s as keyof RsvpCounts]++;
  });
  return counts;
}

