#!/usr/bin/env node

/**
 * Add Sample Services Script
 * This script adds sample services to the vendor_services table
 */

const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing Supabase environment variables');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function addSampleServices() {
  console.log('🎨 Adding sample services...\n');

  try {
    // Get the first vendor profile
    const { data: vendorProfiles, error: profileError } = await supabase
      .from('vendor_profiles')
      .select('id, business_name, category')
      .limit(1);

    if (profileError) {
      console.error('❌ Error fetching vendor profiles:', profileError.message);
      return;
    }

    if (!vendorProfiles || vendorProfiles.length === 0) {
      console.log('❌ No vendor profiles found. Please create a vendor account first.');
      return;
    }

    const vendorProfile = vendorProfiles[0];
    console.log(`👤 Adding services for vendor: ${vendorProfile.business_name}`);

    // Sample services based on category
    const sampleServices = [
      {
        vendor_id: vendorProfile.id,
        service_name: 'Wedding Photography Package',
        description: 'Complete wedding photography coverage including ceremony, reception, and couple portraits. Professional editing and online gallery included.',
        price_min: 8000,
        price_max: 15000,
        price_type: 'package',
        duration_hours: 8,
        includes: ['8 hours coverage', '500+ edited photos', 'Online gallery', 'USB drive', 'Engagement consultation'],
        add_ons: ['Engagement shoot', 'Photo book', 'Drone footage', 'Extended coverage'],
        is_active: true,
      },
      {
        vendor_id: vendorProfile.id,
        service_name: 'Bridal Makeup & Hair',
        description: 'Professional bridal makeup and hairstyling for the bride, including trial session and touch-ups throughout the day.',
        price_min: 2500,
        price_max: 4500,
        price_type: 'fixed',
        duration_hours: 4,
        includes: ['Trial session', 'Wedding day makeup', 'Wedding day hairstyling', 'Touch-up kit', 'False lashes'],
        add_ons: ['Bridal party makeup', 'Mother of bride styling', 'Early morning start', 'Travel to venue'],
        is_active: true,
      },
      {
        vendor_id: vendorProfile.id,
        service_name: 'Wedding Venue Decoration',
        description: 'Complete venue decoration service including ceremony and reception setup, floral arrangements, and lighting.',
        price_min: 12000,
        price_max: 25000,
        price_type: 'package',
        duration_hours: 12,
        includes: ['Ceremony setup', 'Reception decoration', 'Floral arrangements', 'Lighting design', 'Setup & breakdown'],
        add_ons: ['Custom centerpieces', 'Photo booth setup', 'Outdoor ceremony arch', 'Candle arrangements'],
        is_active: true,
      }
    ];

    // Insert sample services
    const { data: insertedServices, error: insertError } = await supabase
      .from('vendor_services')
      .insert(sampleServices)
      .select();

    if (insertError) {
      console.error('❌ Error inserting services:', insertError.message);
      return;
    }

    console.log(`✅ Successfully added ${insertedServices.length} sample services:`);
    insertedServices.forEach((service, index) => {
      console.log(`   ${index + 1}. ${service.service_name} - R${service.price_min} - R${service.price_max}`);
    });

    console.log('\n🎉 Sample services added successfully!');
    console.log('📱 You can now view these services in the vendor dashboard');

  } catch (error) {
    console.error('❌ Script failed:', error.message);
  }
}

// Run the script
addSampleServices().then(() => {
  console.log('\n✨ Sample services script completed');
  process.exit(0);
}).catch((error) => {
  console.error('❌ Script failed:', error);
  process.exit(1);
});
