// components/ui/Input.tsx
import React, { useState, useRef } from 'react';
import { TextInput, Text, View, StyleSheet, TextInputProps, ViewStyle, TextStyle, Animated } from 'react-native';
import { colors, typography, spacing, borderRadius, animations } from '@/src/theme/design-system';

interface InputProps extends TextInputProps {
  label?: string;
  error?: string;
  success?: boolean;
  helperText?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  containerStyle?: ViewStyle;
  inputStyle?: TextStyle;
  labelStyle?: TextStyle;
  variant?: 'default' | 'filled' | 'outlined';
  size?: 'sm' | 'md' | 'lg';
}

export function Input({
  label,
  error,
  success = false,
  helperText,
  leftIcon,
  rightIcon,
  containerStyle,
  inputStyle,
  labelStyle,
  variant = 'default',
  size = 'md',
  ...props
}: InputProps) {
  const [isFocused, setIsFocused] = useState(false);
  const [hasValue, setHasValue] = useState(!!props.value || !!props.defaultValue);
  const scaleValue = useRef(new Animated.Value(1)).current;

  const handleFocus = () => {
    setIsFocused(true);
    Animated.spring(scaleValue, {
      toValue: 1.02,
      duration: animations.duration.fast,
      useNativeDriver: true,
    }).start();
  };

  const handleBlur = () => {
    setIsFocused(false);
    Animated.spring(scaleValue, {
      toValue: 1,
      duration: animations.duration.fast,
      useNativeDriver: true,
    }).start();
  };

  const handleChangeText = (text: string) => {
    setHasValue(text.length > 0);
    props.onChangeText?.(text);
  };

  const getBorderColor = () => {
    if (error) return colors.error[500];
    if (success) return colors.success[500];
    if (isFocused) return colors.primary[300];
    return colors.border.primary;
  };

  const getBackgroundColor = () => {
    switch (variant) {
      case 'filled':
        return colors.background.secondary;
      case 'outlined':
        return 'transparent';
      default:
        return colors.surface.primary;
    }
  };

  return (
    <Animated.View style={[{ transform: [{ scale: scaleValue }] }, containerStyle]}>
      <View style={styles.container}>
        {label && (
          <Text style={[styles.label, labelStyle]}>
            {label}
          </Text>
        )}
        <View style={styles.inputContainer}>
          {leftIcon && (
            <View style={styles.leftIconContainer}>
              {leftIcon}
            </View>
          )}
          <TextInput
            style={[
              styles.input,
              styles[variant],
              styles[size],
              { 
                borderColor: getBorderColor(),
                backgroundColor: getBackgroundColor(),
                paddingLeft: leftIcon ? spacing[10] : spacing[4],
                paddingRight: rightIcon ? spacing[10] : spacing[4],
              },
              inputStyle,
            ]}
            placeholderTextColor={colors.text.tertiary}
            onFocus={handleFocus}
            onBlur={handleBlur}
            onChangeText={handleChangeText}
            {...props}
          />
          {rightIcon && (
            <View style={styles.rightIconContainer}>
              {rightIcon}
            </View>
          )}
        </View>
        {(error || helperText) && (
          <Text style={[styles.helperText, error && styles.errorText]}>
            {error || helperText}
          </Text>
        )}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: spacing[4],
  },
  label: {
    fontSize: typography.fontSize.sm,
    fontWeight: typography.fontWeight.medium,
    color: colors.text.primary,
    marginBottom: spacing[2],
  },
  inputContainer: {
    position: 'relative',
  },
  input: {
    borderWidth: 1,
    borderRadius: borderRadius.lg,
    fontSize: typography.fontSize.base,
    color: colors.text.primary,
  },
  default: {
    backgroundColor: colors.surface.primary,
  },
  filled: {
    backgroundColor: colors.background.secondary,
  },
  outlined: {
    backgroundColor: 'transparent',
  },
  sm: {
    height: 32,
    paddingVertical: spacing[2],
    fontSize: typography.fontSize.sm,
  },
  md: {
    height: 40,
    paddingVertical: spacing[3],
    fontSize: typography.fontSize.base,
  },
  lg: {
    height: 48,
    paddingVertical: spacing[4],
    fontSize: typography.fontSize.lg,
  },
  leftIconContainer: {
    position: 'absolute',
    left: spacing[3],
    top: '50%',
    transform: [{ translateY: -10 }],
    zIndex: 1,
  },
  rightIconContainer: {
    position: 'absolute',
    right: spacing[3],
    top: '50%',
    transform: [{ translateY: -10 }],
    zIndex: 1,
  },
  helperText: {
    fontSize: typography.fontSize.sm,
    color: colors.text.secondary,
    marginTop: spacing[2],
  },
  errorText: {
    color: colors.error[500],
  },
});


