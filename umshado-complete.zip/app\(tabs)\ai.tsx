// app/(tabs)/ai.tsx
import React from 'react';
import { Stack } from 'expo-router';
import AIHub from '@/components/ai/AIHub';

export default function AIScreen() {
  return (
    <>
      <Stack.Screen
        options={{
          title: 'AI Assistant',
          headerShown: true,
          headerStyle: {
            backgroundColor: '#f0fbea',
          },
          headerTintColor: '#1A1A1A',
          headerTitleStyle: {
            fontWeight: '600',
          },
        }}
      />
      <AIHub />
    </>
  );
}
