import { writeAsStringAsync, cacheDirectory, EncodingType } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { supabase } from '@/lib/supabase';
import { toCSV } from '@/src/utils/csv';
import type { Guest } from '@/types/guest';

/**
 * Formats a date string to ISO format for CSV export
 */
function formatISO(d?: string | null): string {
  return d ? new Date(d).toISOString() : '';
}

/**
 * Exports all guests for a wedding to CSV and opens share sheet
 * @param weddingId - The wedding ID to export guests for
 * @returns Object with file URI and guest count
 */
export async function exportGuestsCSV(weddingId: string): Promise<{ fileUri: string; count: number }> {
  // 1) Fetch guests from Supabase
  const { data, error } = await supabase
    .from('guests')
    .select('id,full_name,phone,email,notes,created_at,updated_at')
    .eq('wedding_id', weddingId)
    .order('full_name', { ascending: true });

  if (error) {
    throw new Error(`Failed to fetch guests: ${error.message}`);
  }

  const guests = (data ?? []) as Guest[];

  // 2) Build CSV headers and rows
  const headers = [
    'Full Name',
    'Phone', 
    'Email',
    'Notes',
    'Created At',
    'Updated At'
  ];

  const rows = guests.map(guest => [
    guest.full_name ?? '',
    guest.phone ?? '',
    guest.email ?? '',
    guest.notes ?? '',
    formatISO(guest.created_at),
    formatISO(guest.updated_at),
  ]);

  const csv = toCSV(headers, rows);

  // 3) Save to device cache
  const fileName = `guests_${new Date().toISOString().slice(0, 10)}.csv`;
  const fileUri = cacheDirectory! + fileName;
  
  await writeAsStringAsync(fileUri, csv, { 
    encoding: EncodingType.UTF8 
  });

  // 4) Open system share sheet
  const canShare = await Sharing.isAvailableAsync();
  if (canShare) {
    await Sharing.shareAsync(fileUri, {
      mimeType: 'text/csv',
      dialogTitle: 'Export Guests CSV',
      UTI: 'public.comma-separated-values-text',
    });
  } else {
    throw new Error('Sharing is not available on this device');
  }

  return { fileUri, count: guests.length };
}
