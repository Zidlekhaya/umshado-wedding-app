import React from 'react';
import { render, fireEvent } from '@testing-library/react-native';
import { Input } from '@/components/ui/Input';

describe('Input Component', () => {
  it('renders correctly with default props', () => {
    const { getByPlaceholderText } = render(
      <Input placeholder="Enter text" value="" onChangeText={() => {}} />
    );
    expect(getByPlaceholderText('Enter text')).toBeTruthy();
  });

  it('renders with label', () => {
    const { getByText, getByPlaceholderText } = render(
      <Input 
        label="Email" 
        placeholder="Enter email" 
        value="" 
        onChangeText={() => {}} 
      />
    );
    expect(getByText('Email')).toBeTruthy();
    expect(getByPlaceholderText('Enter email')).toBeTruthy();
  });

  it('calls onChangeText when text changes', () => {
    const mockOnChangeText = jest.fn();
    const { getByPlaceholderText } = render(
      <Input 
        placeholder="Enter text" 
        value="" 
        onChangeText={mockOnChangeText} 
      />
    );
    
    const input = getByPlaceholderText('Enter text');
    fireEvent.changeText(input, 'test input');
    expect(mockOnChangeText).toHaveBeenCalledWith('test input');
  });

  it('displays error message when error prop is provided', () => {
    const { getByText } = render(
      <Input 
        placeholder="Enter text" 
        value="" 
        onChangeText={() => {}} 
        error="This field is required"
      />
    );
    expect(getByText('This field is required')).toBeTruthy();
  });

  it('applies error styling when error is present', () => {
    const { getByPlaceholderText } = render(
      <Input 
        placeholder="Enter text" 
        value="" 
        onChangeText={() => {}} 
        error="This field is required"
      />
    );
    const input = getByPlaceholderText('Enter text');
    expect(input).toBeTruthy();
  });

  it('renders with different keyboard types', () => {
    const { getByPlaceholderText: getEmail } = render(
      <Input 
        placeholder="Email" 
        value="" 
        onChangeText={() => {}} 
        keyboardType="email-address"
      />
    );
    const { getByPlaceholderText: getNumeric } = render(
      <Input 
        placeholder="Number" 
        value="" 
        onChangeText={() => {}} 
        keyboardType="numeric"
      />
    );

    expect(getEmail('Email')).toBeTruthy();
    expect(getNumeric('Number')).toBeTruthy();
  });

  it('applies custom styles', () => {
    const customStyle = { borderColor: 'red' };
    const { getByPlaceholderText } = render(
      <Input 
        placeholder="Enter text" 
        value="" 
        onChangeText={() => {}} 
        inputStyle={customStyle}
      />
    );
    expect(getByPlaceholderText('Enter text')).toBeTruthy();
  });
});


