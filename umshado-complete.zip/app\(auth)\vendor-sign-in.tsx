import { useState, useEffect } from 'react';
import { View, Text, Alert, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { Link, Redirect, router } from 'expo-router';
import { supabase } from '@/lib/supabase';
import type { Session } from '@supabase/supabase-js';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Card } from '@/components/ui/Card';
import { colors, typography, spacing, borderRadius } from '@/src/theme/design-system';
import { Feather } from '@expo/vector-icons';

export default function VendorSignIn() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [session, setSession] = useState<Session | null | undefined>(undefined);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => subscription.unsubscribe();
  }, []);

  if (session) return <Redirect href="/(vendor)" />;

  async function handleSignIn() {
    if (!email.trim()) {
      Alert.alert('Error', 'Email is required');
      return;
    }

    if (!password.trim()) {
      Alert.alert('Error', 'Password is required');
      return;
    }

    try {
      setLoading(true);
      
      console.log('Attempting vendor sign in for:', email);
      
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      
      if (error) {
        console.error('Vendor sign in error:', error);
        throw error;
      }

      console.log('Vendor sign in successful:', data);
      
      // Check if user is actually a vendor
      let userType = data.user?.user_metadata?.user_type;
      
      // If user type is not vendor but they have a vendor profile, fix it
      if (userType !== 'vendor') {
        console.log('User type is not vendor, checking for vendor profile...');
        
        try {
          const { data: vendorProfile, error: profileError } = await supabase
            .from('vendor_profiles')
            .select('*')
            .eq('user_id', data.user.id)
            .single();

          if (!profileError && vendorProfile) {
            console.log('Vendor profile found, updating user metadata...');
            
            // Update user metadata to vendor
            const { error: updateError } = await supabase.auth.updateUser({
              data: {
                user_type: 'vendor',
                business_name: vendorProfile.business_name,
                category: vendorProfile.category,
                location: vendorProfile.location || vendorProfile.city
              }
            });

            if (!updateError) {
              console.log('✅ User metadata updated to vendor');
              userType = 'vendor';
            } else {
              console.error('Error updating user metadata:', updateError);
            }
          } else {
            console.warn('No vendor profile found for user');
            Alert.alert(
              'Account Type Mismatch', 
              'This account is not registered as a vendor. Please use the couple sign-in instead.',
              [
                {
                  text: 'OK',
                  onPress: () => {
                    supabase.auth.signOut();
                    router.push('/(auth)/sign-in');
                  }
                }
              ]
            );
            return;
          }
        } catch (error) {
          console.error('Error checking vendor profile:', error);
        }
      }
      
      if (userType !== 'vendor') {
        Alert.alert(
          'Account Type Mismatch', 
          'This account is not registered as a vendor. Please use the couple sign-in instead.',
          [
            {
              text: 'OK',
              onPress: () => {
                supabase.auth.signOut();
                router.push('/(auth)/sign-in');
              }
            }
          ]
        );
        return;
      }
      
      // Redirect handled by Index route or the Redirect above once session updates
    } catch (err: any) {
      console.error('Vendor sign in failed:', err);
      
      let errorMessage = 'Failed to sign in';
      if (err.message?.includes('Invalid login credentials')) {
        errorMessage = 'Invalid email or password. Please check your credentials and try again.';
      } else if (err.message?.includes('Email not confirmed')) {
        errorMessage = 'Please check your email and click the verification link before signing in.';
      } else if (err.message?.includes('network')) {
        errorMessage = 'Network error. Please check your connection and try again.';
      } else if (err.message) {
        errorMessage = err.message;
      }
      
      Alert.alert('Sign in failed', errorMessage);
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.logoContainer}>
          <Image 
            source={require('../../assets/images/logo.png')}
            style={styles.logoImage}
            resizeMode="contain"
          />
        </View>
        <Text style={styles.title}>Welcome back, Vendor</Text>
        <Text style={styles.subtitle}>Sign in to manage your wedding services</Text>
      </View>

      <Card style={styles.formCard}>
        <Input
          label="Email"
          placeholder="thandi@tandiphotography.co.za"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          autoComplete="email"
        />
        
        <Input
          label="Password"
          placeholder="Enter your password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          autoComplete="password"
        />

        <Button
          title="Sign In"
          onPress={handleSignIn}
          loading={loading}
          fullWidth
          style={styles.signInButton}
        />

        <View style={styles.divider}>
          <View style={styles.dividerLine} />
          <Text style={styles.dividerText}>or</Text>
          <View style={styles.dividerLine} />
        </View>

        <TouchableOpacity 
          style={styles.switchButton}
          onPress={() => router.push('/(auth)/vendor-sign-up')}
        >
          <Text style={styles.switchButtonText}>Don't have an account? Sign up as a vendor</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.fixAccountButton}
          onPress={async () => {
            try {
              const { data: { user } } = await supabase.auth.getUser();
              if (user) {
                const { data: vendorProfile, error: profileError } = await supabase
                  .from('vendor_profiles')
                  .select('*')
                  .eq('user_id', user.id)
                  .single();

                if (!profileError && vendorProfile) {
                  await supabase.auth.updateUser({
                    data: {
                      user_type: 'vendor',
                      business_name: vendorProfile.business_name,
                      category: vendorProfile.category,
                      location: vendorProfile.location || vendorProfile.city
                    }
                  });
                  Alert.alert('Success', 'Account type fixed! Please refresh the app.');
                } else {
                  Alert.alert('Error', 'No vendor profile found for this account.');
                }
              }
            } catch (error) {
              Alert.alert('Error', 'Failed to fix account type.');
            }
          }}
        >
          <Text style={styles.fixAccountButtonText}>Fix Account Type</Text>
        </TouchableOpacity>
      </Card>

      <View style={styles.footer}>
        <TouchableOpacity 
          style={styles.coupleLink}
          onPress={() => router.push('/(auth)/sign-in')}
        >
          <Text style={styles.coupleLinkText}>Are you a couple? Sign in here</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  header: {
    alignItems: 'center',
    paddingTop: spacing[12],
    paddingBottom: spacing[6],
    paddingHorizontal: spacing[6],
  },
  logoContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing[6],
  },
  logoImage: {
    width: 80,
    height: 80,
  },
  title: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: typography.fontWeight.bold,
    color: colors.text.primary,
    marginBottom: spacing[2],
    textAlign: 'center',
  },
  subtitle: {
    fontSize: typography.fontSize.base,
    color: colors.text.secondary,
    textAlign: 'center',
    lineHeight: typography.lineHeight.relaxed * typography.fontSize.base,
  },
  formCard: {
    marginHorizontal: spacing[6],
    marginBottom: spacing[6],
  },
  signInButton: {
    marginTop: spacing[4],
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: spacing[6],
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: colors.border.primary,
  },
  dividerText: {
    marginHorizontal: spacing[4],
    fontSize: typography.fontSize.sm,
    color: colors.text.tertiary,
  },
  switchButton: {
    alignItems: 'center',
    paddingVertical: spacing[3],
  },
  switchButtonText: {
    fontSize: typography.fontSize.sm,
    color: colors.primary[500],
    fontWeight: typography.fontWeight.medium,
  },
  fixAccountButton: {
    alignItems: 'center',
    paddingVertical: spacing[3],
    marginTop: spacing[2],
    backgroundColor: colors.warning[100],
    borderRadius: borderRadius.sm,
  },
  fixAccountButtonText: {
    fontSize: typography.fontSize.sm,
    color: colors.warning[700],
    fontWeight: typography.fontWeight.medium,
  },
  footer: {
    alignItems: 'center',
    paddingHorizontal: spacing[6],
    paddingBottom: spacing[8],
  },
  coupleLink: {
    paddingVertical: spacing[3],
  },
  coupleLinkText: {
    fontSize: typography.fontSize.sm,
    color: colors.text.secondary,
    textAlign: 'center',
  },
});

