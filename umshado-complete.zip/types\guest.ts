export type RSVPStatus = 'going' | 'maybe' | 'declined' | 'no_reply';
export type GuestSide = 'bride' | 'groom' | 'both';

export interface Guest {
  id: string;
  wedding_id: string;
  full_name: string;
  phone?: string | null;
  email?: string | null;
  side: GuestSide;
  rsvp: RSVPStatus;
  invite_sent_at?: string | null;
  notes?: string | null;
  created_at?: string;
  updated_at?: string;
}
