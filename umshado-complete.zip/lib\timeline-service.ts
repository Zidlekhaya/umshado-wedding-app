import { supabase } from '@/lib/supabase';

export type TimelineEventType = 
  | 'engagement' | 'save_the_date' | 'venue_booking' | 'vendor_booking'
  | 'dress_fitting' | 'cake_tasting' | 'rehearsal' | 'wedding_day'
  | 'honeymoon' | 'anniversary' | 'custom';

export type TimelineEventStatus = 'upcoming' | 'completed' | 'cancelled';

export interface TimelineEvent {
  id: string;
  wedding_id: string;
  title: string;
  description?: string;
  event_type: TimelineEventType;
  event_date: string;
  start_time?: string;
  end_time?: string;
  location?: string;
  status: TimelineEventStatus;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  reminder_days?: number; // Days before event to remind
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface CreateTimelineEventData {
  title: string;
  description?: string;
  event_type: TimelineEventType;
  event_date: string;
  start_time?: string;
  end_time?: string;
  location?: string;
  status?: TimelineEventStatus;
  priority?: 'low' | 'medium' | 'high' | 'urgent';
  reminder_days?: number;
  notes?: string;
}

export interface UpdateTimelineEventData extends Partial<CreateTimelineEventData> {}

// Get all timeline events for a wedding
export async function listTimelineEvents(weddingId: string): Promise<TimelineEvent[]> {
  const { data, error } = await supabase
    .from('timeline_events')
    .select('*')
    .eq('wedding_id', weddingId)
    .order('event_date', { ascending: true });

  if (error) {
    console.error('List timeline events error:', error);
    throw error;
  }

  return data as TimelineEvent[];
}

// Get timeline event by ID
export async function getTimelineEvent(id: string): Promise<TimelineEvent | null> {
  const { data, error } = await supabase
    .from('timeline_events')
    .select('*')
    .eq('id', id)
    .single();

  if (error) {
    console.error('Get timeline event error:', error);
    throw error;
  }

  return data as TimelineEvent;
}

// Create new timeline event
export async function createTimelineEvent(weddingId: string, eventData: CreateTimelineEventData): Promise<TimelineEvent> {
  const { data, error } = await supabase
    .from('timeline_events')
    .insert([{
      wedding_id: weddingId,
      ...eventData,
      status: eventData.status || 'upcoming',
      priority: eventData.priority || 'medium',
    }])
    .select()
    .single();

  if (error) {
    console.error('Create timeline event error:', error);
    throw error;
  }

  return data as TimelineEvent;
}

// Update timeline event
export async function updateTimelineEvent(id: string, updates: UpdateTimelineEventData): Promise<TimelineEvent> {
  const { data, error } = await supabase
    .from('timeline_events')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('Update timeline event error:', error);
    throw error;
  }

  return data as TimelineEvent;
}

// Delete timeline event
export async function deleteTimelineEvent(id: string): Promise<void> {
  const { error } = await supabase
    .from('timeline_events')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Delete timeline event error:', error);
    throw error;
  }
}

// Get upcoming events (next 30 days)
export async function getUpcomingEvents(weddingId: string, days: number = 30): Promise<TimelineEvent[]> {
  const futureDate = new Date();
  futureDate.setDate(futureDate.getDate() + days);
  
  const { data, error } = await supabase
    .from('timeline_events')
    .select('*')
    .eq('wedding_id', weddingId)
    .eq('status', 'upcoming')
    .gte('event_date', new Date().toISOString().split('T')[0])
    .lte('event_date', futureDate.toISOString().split('T')[0])
    .order('event_date', { ascending: true });

  if (error) {
    console.error('Get upcoming events error:', error);
    throw error;
  }

  return data as TimelineEvent[];
}

// Get events by type
export async function getEventsByType(weddingId: string, eventType: TimelineEventType): Promise<TimelineEvent[]> {
  const { data, error } = await supabase
    .from('timeline_events')
    .select('*')
    .eq('wedding_id', weddingId)
    .eq('event_type', eventType)
    .order('event_date', { ascending: true });

  if (error) {
    console.error('Get events by type error:', error);
    throw error;
  }

  return data as TimelineEvent[];
}

// Get event type icon
export function getEventTypeIcon(eventType: TimelineEventType): string {
  switch (eventType) {
    case 'engagement': return 'heart';
    case 'save_the_date': return 'mail';
    case 'venue_booking': return 'map-pin';
    case 'vendor_booking': return 'briefcase';
    case 'dress_fitting': return 'shopping-bag';
    case 'cake_tasting': return 'gift';
    case 'rehearsal': return 'users';
    case 'wedding_day': return 'heart';
    case 'honeymoon': return 'plane';
    case 'anniversary': return 'calendar';
    case 'custom': return 'star';
    default: return 'calendar';
  }
}

// Get event type color
export function getEventTypeColor(eventType: TimelineEventType): string {
  switch (eventType) {
    case 'engagement': return '#FF6B6B';
    case 'save_the_date': return '#4ECDC4';
    case 'venue_booking': return '#45B7D1';
    case 'vendor_booking': return '#96CEB4';
    case 'dress_fitting': return '#FFEAA7';
    case 'cake_tasting': return '#DDA0DD';
    case 'rehearsal': return '#98D8C8';
    case 'wedding_day': return '#FF6B6B';
    case 'honeymoon': return '#F7DC6F';
    case 'anniversary': return '#BB8FCE';
    case 'custom': return '#AEB6BF';
    default: return '#D5DBDB';
  }
}

// Get priority color
export function getPriorityColor(priority: 'low' | 'medium' | 'high' | 'urgent'): string {
  switch (priority) {
    case 'urgent': return '#FF6B6B';
    case 'high': return '#FF8E53';
    case 'medium': return '#FFA500';
    case 'low': return '#4ECDC4';
    default: return '#AEB6BF';
  }
}

// Get status color
export function getStatusColor(status: TimelineEventStatus): string {
  switch (status) {
    case 'upcoming': return '#4ECDC4';
    case 'completed': return '#95E1A3';
    case 'cancelled': return '#E74C3C';
    default: return '#AEB6BF';
  }
}

// Calculate days until event
export function getDaysUntilEvent(eventDate: string): number {
  const today = new Date();
  const event = new Date(eventDate);
  const diffTime = event.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
}

// Check if event is overdue
export function isEventOverdue(eventDate: string, status: TimelineEventStatus): boolean {
  if (status === 'completed' || status === 'cancelled') return false;
  const today = new Date();
  const event = new Date(eventDate);
  return event < today;
}

// Format date for display
export function formatEventDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

// Format time for display
export function formatEventTime(timeString?: string): string {
  if (!timeString) return '';
  const [hours, minutes] = timeString.split(':');
  const hour = parseInt(hours);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  const displayHour = hour % 12 || 12;
  return `${displayHour}:${minutes} ${ampm}`;
}















