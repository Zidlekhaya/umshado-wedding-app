-- Update tasks table to use simplified categories
ALTER TABLE public.tasks DROP CONSTRAINT IF EXISTS tasks_category_check;

ALTER TABLE public.tasks ADD CONSTRAINT tasks_category_check CHECK (category IN (
  'venue', 'catering', 'photography', 'music', 'flowers', 'decor', 
  'transport', 'attire', 'invitations', 'general'
));

-- Update any existing tasks with old category names
UPDATE public.tasks SET category = 'transport' WHERE category = 'transportation';
UPDATE public.tasks SET category = 'general' WHERE category IN ('makeup', 'hair', 'rings', 'cake', 'officiant', 'ceremony', 'reception', 'honeymoon', 'other');















