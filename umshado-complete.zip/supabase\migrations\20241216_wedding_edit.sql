-- Add description column to wedding table for editing functionality
-- This migration adds the description field to support wedding editing

-- Add description column if it doesn't exist
ALTER TABLE public.wedding 
ADD COLUMN IF NOT EXISTS description TEXT;

-- Add updated_at column if it doesn't exist
ALTER TABLE public.wedding 
ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- Create or replace the updated_at trigger
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS wedding_updated_at ON public.wedding;

-- Create the updated_at trigger
CREATE TRIGGER wedding_updated_at
  BEFORE UPDATE ON public.wedding
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- Update existing records to have updated_at set to created_at
UPDATE public.wedding 
SET updated_at = created_at 
WHERE updated_at IS NULL;
















