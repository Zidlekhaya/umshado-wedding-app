// Complete system test script
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL || 'YOUR_SUPABASE_URL';
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || 'YOUR_SUPABASE_ANON_KEY';

const supabase = createClient(supabaseUrl, supabaseKey);

async function testCompleteSystem() {
  console.log('🚀 Starting complete system test...\n');
  
  try {
    // Test 1: Database Connection
    console.log('1️⃣ Testing database connection...');
    const { data: connectionTest, error: connectionError } = await supabase
      .from('wedding')
      .select('count')
      .limit(1);
    
    if (connectionError) {
      throw new Error(`Database connection failed: ${connectionError.message}`);
    }
    console.log('✅ Database connection successful\n');
    
    // Test 2: Create test couple account
    console.log('2️⃣ Creating test couple account...');
    const coupleEmail = `test-couple-${Date.now()}@example.com`;
    const couplePassword = 'testpassword123';
    
    const { data: coupleAuth, error: coupleAuthError } = await supabase.auth.signUp({
      email: coupleEmail,
      password: couplePassword,
      options: {
        data: {
          user_type: 'couple',
          full_name: 'Test Couple'
        }
      }
    });
    
    if (coupleAuthError) {
      throw new Error(`Couple signup failed: ${coupleAuthError.message}`);
    }
    console.log('✅ Test couple account created:', coupleEmail);
    
    // Test 3: Create test vendor account
    console.log('3️⃣ Creating test vendor account...');
    const vendorEmail = `test-vendor-${Date.now()}@example.com`;
    const vendorPassword = 'testpassword123';
    
    const { data: vendorAuth, error: vendorAuthError } = await supabase.auth.signUp({
      email: vendorEmail,
      password: vendorPassword,
      options: {
        data: {
          user_type: 'vendor',
          business_name: 'Test Vendor Business'
        }
      }
    });
    
    if (vendorAuthError) {
      throw new Error(`Vendor signup failed: ${vendorAuthError.message}`);
    }
    console.log('✅ Test vendor account created:', vendorEmail);
    
    // Test 4: Create test wedding (as couple)
    console.log('4️⃣ Creating test wedding...');
    const { data: wedding, error: weddingError } = await supabase
      .from('wedding')
      .insert({
        owner_id: coupleAuth.user.id,
        name: 'Test Wedding',
        date: '2025-12-25',
        location: 'Test City',
        culture: 'Traditional'
      })
      .select()
      .single();
    
    if (weddingError) {
      throw new Error(`Wedding creation failed: ${weddingError.message}`);
    }
    console.log('✅ Test wedding created:', wedding.name);
    
    // Test 5: Create test vendor profile
    console.log('5️⃣ Creating test vendor profile...');
    const { data: vendorProfile, error: vendorProfileError } = await supabase
      .from('vendor_profile')
      .insert({
        user_id: vendorAuth.user.id,
        business_name: 'Test Vendor Business',
        category: 'Photography',
        business_description: 'Professional wedding photography services',
        city: 'Test City',
        phone: '+27 11 123 4567',
        email: vendorEmail,
        price_range: '$1000-$3000',
        years_experience: 5,
        is_active: true,
        is_featured: true,
        rating_average: 4.5,
        review_count: 10
      })
      .select()
      .single();
    
    if (vendorProfileError) {
      throw new Error(`Vendor profile creation failed: ${vendorProfileError.message}`);
    }
    console.log('✅ Test vendor profile created:', vendorProfile.business_name);
    
    // Test 6: Test vendor marketplace data
    console.log('6️⃣ Testing vendor marketplace data...');
    const { data: marketplaceVendors, error: marketplaceError } = await supabase
      .from('vendor_profile')
      .select('*')
      .eq('is_active', true);
    
    if (marketplaceError) {
      throw new Error(`Marketplace query failed: ${marketplaceError.message}`);
    }
    console.log('✅ Marketplace data accessible:', marketplaceVendors.length, 'vendors');
    
    // Test 7: Test wedding data retrieval
    console.log('7️⃣ Testing wedding data retrieval...');
    const { data: weddings, error: weddingsError } = await supabase
      .from('wedding')
      .select('*')
      .eq('owner_id', coupleAuth.user.id);
    
    if (weddingsError) {
      throw new Error(`Wedding retrieval failed: ${weddingsError.message}`);
    }
    console.log('✅ Wedding data accessible:', weddings.length, 'weddings');
    
    // Test 8: Test authentication persistence
    console.log('8️⃣ Testing authentication persistence...');
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    
    if (sessionError) {
      throw new Error(`Session retrieval failed: ${sessionError.message}`);
    }
    
    if (session) {
      console.log('✅ Session persistence working');
      console.log('   User type:', session.user.user_metadata?.user_type);
      console.log('   User ID:', session.user.id);
    } else {
      console.log('⚠️ No active session (this is normal for new accounts)');
    }
    
    console.log('\n🎉 Complete system test PASSED!');
    console.log('\n📋 Test Results Summary:');
    console.log('✅ Database connection');
    console.log('✅ Couple account creation');
    console.log('✅ Vendor account creation');
    console.log('✅ Wedding creation');
    console.log('✅ Vendor profile creation');
    console.log('✅ Marketplace data access');
    console.log('✅ Wedding data access');
    console.log('✅ Authentication system');
    
    console.log('\n🔑 Test Credentials:');
    console.log('Couple:', coupleEmail, '/', couplePassword);
    console.log('Vendor:', vendorEmail, '/', vendorPassword);
    
    console.log('\n🚀 System is ready for testing!');
    
  } catch (error) {
    console.error('\n❌ System test FAILED:', error.message);
    console.log('\n🔧 Troubleshooting:');
    console.log('1. Check your Supabase credentials in .env file');
    console.log('2. Ensure database migrations have been run');
    console.log('3. Check Supabase project is active');
    console.log('4. Verify RLS policies are set up correctly');
  }
}

testCompleteSystem();










