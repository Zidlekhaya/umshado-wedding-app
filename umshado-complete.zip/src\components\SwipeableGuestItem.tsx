import React from 'react';
import { View, Text, StyleSheet, Pressable, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { updateGuest } from '@/src/services/guests';
import type { Guest, RSVPStatus } from '@/types/guest';

const palette = {
  background: '#D4A373',
  card: '#F5E8C7',
  text: '#FFFFFF',
  outline: '#D3D3D3',
  accent: '#A9B7A0',
  deepMaroon: '#7D1F1A',
  successGreen: '#2ECC71',
  warningAmber: '#FFAF45',
  textDark: '#3B2F2F',
  mutedText: '#8B6E4E',
};

interface Props {
  guest: Guest;
  onPress: () => void;
  onUpdate: (guest: Guest) => void;
}

export default function SwipeableGuestItem({ guest, onPress, onUpdate }: Props) {
  const handleQuickRsvp = async (rsvp: RSVPStatus) => {
    try {
      const updatedGuest = await updateGuest(guest.id, { rsvp });
      onUpdate(updatedGuest);
    } catch (error) {
      console.error('Error updating RSVP:', error);
    }
  };

  const getRsvpColor = (rsvp: RSVPStatus) => {
    switch (rsvp) {
      case 'going': return palette.successGreen;
      case 'maybe': return palette.warningAmber;
      case 'declined': return '#E74C3C';
      default: return palette.mutedText;
    }
  };

  const getRsvpLabel = (rsvp: RSVPStatus) => {
    switch (rsvp) {
      case 'going': return 'Going';
      case 'maybe': return 'Maybe';
      case 'declined': return 'Declined';
      default: return 'No Reply';
    }
  };

  const getSideLabel = (side: string) => {
    switch (side) {
      case 'bride': return 'Bride';
      case 'groom': return 'Groom';
      default: return 'Both';
    }
  };

  return (
    <View style={styles.container}>
      <Pressable onPress={onPress} style={styles.guestCard}>
        <View style={styles.guestContent}>
          <View style={styles.guestInfo}>
            <Text style={styles.guestName}>{guest.full_name}</Text>
            <View style={styles.guestDetails}>
              {guest.phone && <Text style={styles.guestDetail}>{guest.phone}</Text>}
              {guest.email && <Text style={styles.guestDetail}>{guest.email}</Text>}
            </View>
            <Text style={styles.guestSide}>{getSideLabel(guest.side)}</Text>
          </View>
          <View style={[styles.rsvpPill, { backgroundColor: getRsvpColor(guest.rsvp) }]}>
            <Text style={styles.rsvpText}>{getRsvpLabel(guest.rsvp)}</Text>
          </View>
        </View>
        
        {/* Quick action buttons */}
        <View style={styles.quickActions}>
          <TouchableOpacity
            style={[styles.quickActionButton, { backgroundColor: palette.accent }]}
            onPress={() => router.push(`/(tabs)/guests/templates/use?guestId=${guest.id}`)}
          >
            <Feather name="message-square" size={16} color={palette.text} />
            <Text style={styles.quickActionText}>Message</Text>
          </TouchableOpacity>
          <Pressable
            style={[styles.quickActionButton, { backgroundColor: palette.successGreen }]}
            onPress={() => handleQuickRsvp('going')}
          >
            <Text style={styles.quickActionText}>✓ Going</Text>
          </Pressable>
          <Pressable
            style={[styles.quickActionButton, { backgroundColor: '#E74C3C' }]}
            onPress={() => handleQuickRsvp('declined')}
          >
            <Text style={styles.quickActionText}>✗ Declined</Text>
          </Pressable>
        </View>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 12,
  },
  guestCard: {
    backgroundColor: palette.card,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  guestContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  guestInfo: {
    flex: 1,
  },
  guestName: {
    fontSize: 16,
    fontWeight: '600',
    color: palette.textDark,
    marginBottom: 4,
  },
  guestDetails: {
    marginBottom: 4,
  },
  guestDetail: {
    fontSize: 14,
    color: palette.mutedText,
  },
  guestSide: {
    fontSize: 12,
    color: palette.mutedText,
    fontWeight: '500',
  },
  rsvpPill: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  rsvpText: {
    color: palette.text,
    fontWeight: '600',
    fontSize: 12,
  },
  quickActions: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingBottom: 12,
    gap: 8,
  },
  quickActionButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 4,
  },
  quickActionText: {
    color: palette.text,
    fontWeight: '600',
    fontSize: 12,
  },
});
