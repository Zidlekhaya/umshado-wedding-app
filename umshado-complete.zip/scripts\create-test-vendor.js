// Script to create a test vendor account
// Run with: node scripts/create-test-vendor.js

const { createClient } = require('@supabase/supabase-js');

// You'll need to add your Supabase URL and anon key here
const supabaseUrl = 'YOUR_SUPABASE_URL';
const supabaseKey = 'YOUR_SUPABASE_ANON_KEY';

const supabase = createClient(supabaseUrl, supabaseKey);

async function createTestVendor() {
  try {
    console.log('Creating test vendor account...');
    
    // Create auth user
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: 'vendor@test.com',
      password: 'testpassword123',
      options: {
        data: {
          user_type: 'vendor',
          business_name: 'Test Wedding Vendor',
          full_name: 'Test Vendor'
        }
      }
    });

    if (authError) {
      console.error('Auth error:', authError);
      return;
    }

    console.log('Auth user created:', authData.user?.id);

    // Create vendor profile
    const { data: profileData, error: profileError } = await supabase
      .from('vendor_profile')
      .insert({
        user_id: authData.user.id,
        business_name: 'Test Wedding Vendor',
        category: 'Photography',
        contact_email: 'vendor@test.com',
        phone: '+1234567890',
        business_description: 'Professional wedding photography services',
        service_areas: ['New York', 'New Jersey'],
        price_range: '$2000-$5000',
        years_experience: 5,
        is_active: true,
        is_featured: true
      })
      .select();

    if (profileError) {
      console.error('Profile error:', profileError);
      return;
    }

    console.log('Vendor profile created:', profileData);
    console.log('\n✅ Test vendor created successfully!');
    console.log('Email: vendor@test.com');
    console.log('Password: testpassword123');
    console.log('\nYou can now test the vendor login flow.');

  } catch (error) {
    console.error('Error:', error);
  }
}

createTestVendor();










