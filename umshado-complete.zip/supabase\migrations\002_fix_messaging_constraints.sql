-- Fix messaging constraints to work with current vendor structure
-- The vendors table contains vendor records created by couples, not actual vendor user accounts

-- Drop the foreign key constraints that are causing issues
ALTER TABLE conversations DROP CONSTRAINT IF EXISTS conversations_couple_id_fkey;
ALTER TABLE conversations DROP CONSTRAINT IF EXISTS conversations_vendor_id_fkey;
ALTER TABLE messages DROP CONSTRAINT IF EXISTS messages_sender_id_fkey;

-- Add new constraints that don't require auth.users references
-- For conversations, we'll allow any UUID for couple_id and vendor_id
-- For messages, we'll allow any UUID for sender_id

-- Update RLS policies to work with the new structure
DROP POLICY IF EXISTS "Users can view their own conversations" ON conversations;
DROP POLICY IF EXISTS "Users can create conversations" ON conversations;
DROP POLICY IF EXISTS "Users can update their own conversations" ON conversations;

DROP POLICY IF EXISTS "Users can view messages in their conversations" ON messages;
DROP POLICY IF EXISTS "Users can send messages in their conversations" ON messages;
DROP POLICY IF EXISTS "Users can update their own messages" ON messages;

-- Create new RLS policies that work with the current structure
CREATE POLICY "Users can view their own conversations" ON conversations
  FOR SELECT USING (
    auth.uid() = couple_id
  );

CREATE POLICY "Users can create conversations" ON conversations
  FOR INSERT WITH CHECK (
    auth.uid() = couple_id
  );

CREATE POLICY "Users can update their own conversations" ON conversations
  FOR UPDATE USING (
    auth.uid() = couple_id
  );

-- For messages, allow users to view messages in conversations they're part of
CREATE POLICY "Users can view messages in their conversations" ON messages
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM conversations 
      WHERE id = conversation_id 
      AND couple_id = auth.uid()
    )
  );

CREATE POLICY "Users can send messages in their conversations" ON messages
  FOR INSERT WITH CHECK (
    sender_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM conversations 
      WHERE id = conversation_id 
      AND couple_id = auth.uid()
    )
  );

CREATE POLICY "Users can update their own messages" ON messages
  FOR UPDATE USING (
    sender_id = auth.uid()
  );

-- Update the get_user_conversations function to work with the new structure
CREATE OR REPLACE FUNCTION get_user_conversations(user_id UUID, user_type TEXT)
RETURNS TABLE (
  id UUID,
  couple_id UUID,
  vendor_id UUID,
  vendor_name TEXT,
  vendor_avatar TEXT,
  couple_name TEXT,
  couple_avatar TEXT,
  last_message TEXT,
  last_message_at TIMESTAMP WITH TIME ZONE,
  unread_count INTEGER,
  created_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
  IF user_type = 'couple' THEN
    RETURN QUERY
    SELECT 
      c.id,
      c.couple_id,
      c.vendor_id,
      c.vendor_name,
      c.vendor_avatar,
      c.couple_name,
      c.couple_avatar,
      c.last_message,
      c.last_message_at,
      c.unread_count,
      c.created_at,
      c.updated_at
    FROM conversations c
    WHERE c.couple_id = user_id
    ORDER BY c.updated_at DESC;
  ELSE
    -- For vendors, we'll need to implement this differently
    -- For now, return empty result since vendors aren't real users in our current structure
    RETURN QUERY
    SELECT 
      c.id,
      c.couple_id,
      c.vendor_id,
      c.vendor_name,
      c.vendor_avatar,
      c.couple_name,
      c.couple_avatar,
      c.last_message,
      c.last_message_at,
      c.unread_count,
      c.created_at,
      c.updated_at
    FROM conversations c
    WHERE FALSE; -- Return no results for vendors for now
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;









