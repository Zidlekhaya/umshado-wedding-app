import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  FlatList,
  TouchableOpacity,
  TextInput,
  Alert,
  SafeAreaView,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import * as Contacts from 'expo-contacts';
import { useWeddingStore } from '@/stores/wedding';
import { createGuest } from '@/lib/guest-service';

const colors = {
  background: '#F5E8C7',
  primary: '#D4A373',
  text: '#2C1810',
  textLight: '#666666',
  border: '#D3D3D3',
  success: '#A9B7A0',
  error: '#E74C3C',
  white: '#FFFFFF',
  overlay: 'rgba(0, 0, 0, 0.5)',
};

interface Contact {
  id: string;
  name: string;
  phoneNumbers: string[];
  emails: string[];
}

interface ContactSelectorProps {
  visible: boolean;
  onClose: () => void;
  onGuestsAdded: (count: number) => void;
}

export default function ContactSelector({ visible, onClose, onGuestsAdded }: ContactSelectorProps) {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [filteredContacts, setFilteredContacts] = useState<Contact[]>([]);
  const [selectedContacts, setSelectedContacts] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [adding, setAdding] = useState(false);
  const { currentWedding } = useWeddingStore();

  const loadContacts = useCallback(async () => {
    try {
      setLoading(true);
      
      const { status } = await Contacts.requestPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Please grant permission to access your contacts to add guests.');
        return;
      }

      const { data } = await Contacts.getContactsAsync({
        fields: [Contacts.Fields.Name, Contacts.Fields.PhoneNumbers, Contacts.Fields.Emails],
      });

      const formattedContacts: Contact[] = data
        .filter(contact => contact.name && contact.name.trim().length > 0)
        .map((contact, index) => ({
          id: `${contact.id || index}`,
          name: contact.name.trim(),
          phoneNumbers: contact.phoneNumbers?.map(p => p.number) || [],
          emails: contact.emails?.map(e => e.email) || [],
        }));

      setContacts(formattedContacts);
      setFilteredContacts(formattedContacts);
    } catch (error) {
      console.error('Error loading contacts:', error);
      Alert.alert('Error', 'Failed to load contacts');
    } finally {
      setLoading(false);
    }
  }, []);

  const handleSearch = useCallback((query: string) => {
    setSearchQuery(query);

    if (!query.trim()) {
      setFilteredContacts(contacts);
      return;
    }

    const searchTerm = query.toLowerCase().trim();
    const filtered = contacts.filter(contact => {
      const nameMatch = contact.name.toLowerCase().includes(searchTerm);
      const phoneMatch = contact.phoneNumbers.some(phone => 
        phone.replace(/\D/g, '').includes(searchTerm.replace(/\D/g, ''))
      );
      const emailMatch = contact.emails.some(email =>
        email.toLowerCase().includes(searchTerm)
      );

      return nameMatch || phoneMatch || emailMatch;
    });

    setFilteredContacts(filtered);
  }, [contacts]);

  const toggleContactSelection = useCallback((contactId: string) => {
    setSelectedContacts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(contactId)) {
        newSet.delete(contactId);
      } else {
        newSet.add(contactId);
      }
      return newSet;
    });
  }, []);

  const handleAddSelected = useCallback(async () => {
    if (!currentWedding?.id) {
      Alert.alert('Error', 'No wedding selected');
      return;
    }

    if (selectedContacts.size === 0) {
      Alert.alert('No Selection', 'Please select at least one contact to add');
      return;
    }

    try {
      setAdding(true);
      let addedCount = 0;

      for (const contactId of selectedContacts) {
        const contact = contacts.find(c => c.id === contactId);
        if (!contact) continue;

        try {
          await createGuest({
            wedding_id: currentWedding.id,
            full_name: contact.name,
            email: contact.emails[0] || null,
            phone: contact.phoneNumbers[0] || null,
          });
          addedCount++;
        } catch (error) {
          console.error(`Error adding ${contact.name}:`, error);
        }
      }

      onGuestsAdded(addedCount);
      setSelectedContacts(new Set());
      setSearchQuery('');
      onClose();

      if (addedCount > 0) {
        Alert.alert('Success', `Successfully added ${addedCount} guest${addedCount === 1 ? '' : 's'} to your wedding!`);
      }
    } catch (error) {
      console.error('Error adding guests:', error);
      Alert.alert('Error', 'Failed to add guests');
    } finally {
      setAdding(false);
    }
  }, [selectedContacts, contacts, currentWedding?.id, onGuestsAdded, onClose]);

  const renderContact = ({ item }: { item: Contact }) => {
    const isSelected = selectedContacts.has(item.id);

    return (
      <TouchableOpacity
        style={[styles.contactItem, isSelected && styles.selectedContactItem]}
        onPress={() => toggleContactSelection(item.id)}
        activeOpacity={0.7}
      >
        <View style={styles.contactInfo}>
          <Text style={styles.contactName}>{item.name}</Text>
          {item.phoneNumbers[0] && (
            <Text style={styles.contactPhone}>{item.phoneNumbers[0]}</Text>
          )}
          {item.emails[0] && (
            <Text style={styles.contactEmail}>{item.emails[0]}</Text>
          )}
        </View>
        <View style={styles.contactActions}>
          {isSelected && (
            <Feather name="check-circle" size={24} color={colors.success} />
          )}
        </View>
      </TouchableOpacity>
    );
  };

  useEffect(() => {
    if (visible) {
      loadContacts();
    } else {
      setSelectedContacts(new Set());
      setSearchQuery('');
    }
  }, [visible, loadContacts]);

  useEffect(() => {
    handleSearch(searchQuery);
  }, [searchQuery, handleSearch]);

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={() => {
        setSelectedContacts(new Set());
        setSearchQuery('');
        onClose();
      }}
    >
      <SafeAreaView style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity onPress={() => {
              setSelectedContacts(new Set());
              setSearchQuery('');
              onClose();
            }} style={styles.closeButton}>
              <Feather name="x" size={24} color={colors.text} />
            </TouchableOpacity>
            <Text style={styles.title}>Add from Contacts</Text>
            <TouchableOpacity
              onPress={handleAddSelected}
              disabled={selectedContacts.size === 0 || adding}
              style={[styles.addButton, (selectedContacts.size === 0 || adding) && styles.addButtonDisabled]}
            >
              <Text style={[styles.addButtonText, (selectedContacts.size === 0 || adding) && styles.addButtonTextDisabled]}>
                Add ({selectedContacts.size})
              </Text>
            </TouchableOpacity>
          </View>

          {/* Search Bar */}
          <View style={styles.searchContainer}>
            <View style={styles.searchBar}>
              <Feather name="search" size={20} color={colors.border} />
              <TextInput
                style={styles.searchInput}
                placeholder="Search contacts..."
                placeholderTextColor={colors.border}
                value={searchQuery}
                onChangeText={handleSearch}
                autoCorrect={false}
                autoCapitalize="none"
              />
              {searchQuery.length > 0 && (
                <TouchableOpacity
                  onPress={() => handleSearch('')}
                  style={styles.clearButton}
                >
                  <Feather name="x" size={16} color={colors.border} />
                </TouchableOpacity>
              )}
            </View>
          </View>

          {/* Contacts List */}
          <View style={styles.listContainer}>
            {loading ? (
              <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color={colors.primary} />
                <Text style={styles.loadingText}>Loading contacts...</Text>
              </View>
            ) : (
              <FlatList
                data={filteredContacts}
                keyExtractor={(item) => item.id}
                renderItem={renderContact}
                showsVerticalScrollIndicator={false}
                contentContainerStyle={styles.contactsList}
                ListEmptyComponent={
                  <View style={styles.emptyContainer}>
                    <Feather name="users" size={48} color={colors.border} />
                    <Text style={styles.emptyTitle}>No contacts found</Text>
                    <Text style={styles.emptySubtitle}>
                      {searchQuery ? 'Try a different search term' : 'No contacts available'}
                    </Text>
                  </View>
                }
              />
            )}
          </View>

          {/* Adding Indicator */}
          {adding && (
            <View style={styles.addingOverlay}>
              <View style={styles.addingContainer}>
                <ActivityIndicator size="large" color={colors.white} />
                <Text style={styles.addingText}>Adding guests...</Text>
              </View>
            </View>
          )}
        </View>
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: colors.overlay,
  },
  modalContent: {
    flex: 1,
    backgroundColor: colors.background,
    marginTop: Platform.OS === 'ios' ? 50 : 0,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  closeButton: {
    padding: 4,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    flex: 1,
    textAlign: 'center',
  },
  addButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  addButtonDisabled: {
    backgroundColor: colors.border,
  },
  addButtonText: {
    color: colors.white,
    fontWeight: '600',
    fontSize: 14,
  },
  addButtonTextDisabled: {
    color: colors.textLight,
  },
  searchContainer: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.white,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    color: colors.text,
  },
  clearButton: {
    padding: 4,
    marginLeft: 8,
  },
  listContainer: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: colors.textLight,
  },
  contactsList: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  contactItem: {
    backgroundColor: colors.white,
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  selectedContactItem: {
    backgroundColor: colors.primary + '20',
    borderWidth: 2,
    borderColor: colors.primary,
  },
  contactInfo: {
    flex: 1,
  },
  contactName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  contactPhone: {
    fontSize: 14,
    color: colors.textLight,
    marginBottom: 2,
  },
  contactEmail: {
    fontSize: 14,
    color: colors.textLight,
  },
  contactActions: {
    marginLeft: 12,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 14,
    color: colors.textLight,
    marginTop: 8,
    textAlign: 'center',
  },
  addingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: colors.overlay,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addingContainer: {
    backgroundColor: colors.text,
    paddingHorizontal: 32,
    paddingVertical: 24,
    borderRadius: 16,
    alignItems: 'center',
  },
  addingText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: '600',
    marginTop: 12,
  },
});










