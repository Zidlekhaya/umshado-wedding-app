import React from "react";
import { Pressable, Text, StyleSheet, ViewStyle } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { tokens } from "@/src/theme/tokens";
import { palette } from "@/src/theme/palette";

type Props = {
  label: string;
  icon: React.ComponentProps<typeof MaterialCommunityIcons>["name"];
  bg?: string;               // background color
  onPress?: () => void;
  style?: ViewStyle;
};

export default function ActionTile({ label, icon, bg = palette.primary, onPress, style }: Props) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [
      styles.tile,
      { backgroundColor: bg, opacity: pressed ? 0.9 : 1 },
      style,
    ]}>
      <MaterialCommunityIcons name={icon} size={28} color={palette.textOnDark} />
      <Text
        style={styles.label}
        numberOfLines={2}
        ellipsizeMode="tail"
        adjustsFontSizeToFit
        minimumFontScale={0.8}
      >
        {label}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  tile: {
    flex: 1,
    minHeight: 112,
    borderRadius: tokens.radius.lg,
    paddingVertical: 12,
    paddingHorizontal: 10,
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    ...tokens.shadow.card,
  },
  label: {
    color: palette.textOnDark,
    textAlign: "center",
    fontWeight: "700",
    fontSize: 16,
    lineHeight: 18,
  },
});
