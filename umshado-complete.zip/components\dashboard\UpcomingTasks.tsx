import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, Pressable, ActivityIndicator } from "react-native";
import { listTasks, updateTask, Task, TaskStatus } from "@/lib/task-service";
import { router, useFocusEffect } from "expo-router";
import { Feather } from "@expo/vector-icons";

export default function UpcomingTasks({ weddingId }: { weddingId: string }) {
  const [loading, setLoading] = useState(true);
  const [tasks, setTasks] = useState<Task[]>([]);

  const loadTasks = async () => {
    try {
      const allTasks = await listTasks(weddingId);
      console.log('All tasks loaded:', allTasks.length, 'tasks');
      console.log('Task statuses:', allTasks.map(t => ({ title: t.title, status: t.status })));
      
      // Get upcoming tasks (pending or in_progress, sorted by due date)
      const upcomingTasks = allTasks
        .filter(task => task.status === 'pending' || task.status === 'in_progress')
        .sort((a, b) => {
          if (!a.due_date) return 1;
          if (!b.due_date) return -1;
          return new Date(a.due_date).getTime() - new Date(b.due_date).getTime();
        })
        .slice(0, 3);
      
      console.log('Upcoming tasks:', upcomingTasks.length, 'tasks');
      setTasks(upcomingTasks);
    } catch (error) {
      console.error('Error loading tasks:', error);
    }
  };

  useEffect(() => {
    (async () => {
      setLoading(true);
      await loadTasks();
      setLoading(false);
    })();
  }, [weddingId]);

  // Refresh tasks when screen comes into focus
  useFocusEffect(
    React.useCallback(() => {
      loadTasks();
    }, [weddingId])
  );

  const handleMarkDone = async (taskId: string) => {
    try {
      await updateTask({ id: taskId, status: 'completed' });
      // Reload tasks
      await loadTasks();
    } catch (error) {
      console.error('Error updating task:', error);
    }
  };

  if (loading) return <Card><ActivityIndicator /></Card>;

  return (
    <Card>
      <View style={s.header}>
        <Text style={s.title}>Upcoming Tasks</Text>
        <View style={s.headerButtons}>
          <Pressable style={s.viewAllBtn} onPress={() => router.push('/(tabs)/tasks')}>
            <Text style={s.viewAllText}>View all</Text>
          </Pressable>
          <Pressable style={s.addBtn} onPress={() => router.push('/(tabs)/tasks')}>
            <Text style={s.addText}>+ Add</Text>
          </Pressable>
        </View>
      </View>
      
      {tasks.length === 0 ? (
        <Text style={s.empty}>You&apos;re all caught up 🎉</Text>
      ) : (
             tasks.map((task, index) => {
               const isOverdue = task.due_date && new Date(task.due_date) < new Date() && task.status !== 'completed';
               const dueDate = task.due_date ? new Date(task.due_date).toLocaleDateString() : null;
               
               return (
                 <View key={task.id}>
                   <View style={s.item}>
                     <View style={{ flex: 1 }}>
                       <View style={s.titleRow}>
                         <Text style={[s.itemTitle, isOverdue && s.overdueText]}>{task.title}</Text>
                         {isOverdue && (
                           <Feather name="alert-circle" size={16} color="#EF4444" />
                         )}
                       </View>
                       {dueDate ? (
                         <Text style={[s.sub, isOverdue && s.overdueSub]}>
                           Due {dueDate}
                         </Text>
                       ) : null}
                       {task.category && (
                         <Text style={s.categoryText}>
                           {task.category.charAt(0).toUpperCase() + task.category.slice(1)}
                         </Text>
                       )}
                     </View>
                     <Pressable style={s.doneBtn} onPress={() => handleMarkDone(task.id)}>
                       <Text style={s.doneTxt}>✓ Done</Text>
                     </Pressable>
                   </View>
                   {index < tasks.length - 1 && <View style={s.divider} />}
                 </View>
               );
             })
      )}
    </Card>
  );
}

function Card({ children }: { children: React.ReactNode }) {
  return <View style={s.card}>{children}</View>;
}

const s = StyleSheet.create({
  card: { 
    backgroundColor: '#F5E8C7',
    borderRadius: 16, 
    padding: 18, 
    marginBottom: 16, 
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  title: { 
    fontWeight: "800", 
    fontSize: 16, 
    color: '#3B2F2F'
  },
  headerButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  viewAllBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(0,0,0,0.06)',
  },
  viewAllText: {
    color: '#3B2F2F',
    fontWeight: '600',
    fontSize: 12,
  },
  addBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: '#A9B7A0',
  },
  addText: {
    color: '#3B2F2F',
    fontWeight: '700',
    fontSize: 12,
  },
  item: { 
    flexDirection: "row", 
    alignItems: "center", 
    paddingVertical: 8, 
    gap: 10 
  },
  itemTitle: { 
    fontWeight: "600",
    color: '#3B2F2F',
    fontSize: 14,
  },
  sub: { 
    color: '#8B6E4E',
    fontSize: 12,
    marginTop: 2
  },
  empty: { 
    color: '#8B6E4E',
    textAlign: "center",
    paddingVertical: 20,
    fontSize: 14,
  },
  doneBtn: { 
    backgroundColor: '#A9B7A0',
    paddingHorizontal: 10, 
    paddingVertical: 6, 
    borderRadius: 999 
  },
  doneTxt: { 
    color: '#3B2F2F',
    fontWeight: "700",
    fontSize: 12
  },
  divider: {
    height: 1,
    backgroundColor: 'rgba(0,0,0,0.06)',
    marginVertical: 4,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  overdueText: {
    color: '#EAC4B0', // Soft warning color
  },
  overdueSub: {
    color: '#EAC4B0',
  },
  categoryText: {
    color: '#8B6E4E',
    fontSize: 11,
    marginTop: 2,
    fontStyle: 'italic',
  },
});
