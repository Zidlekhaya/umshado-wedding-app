-- 007_create_vendor_packages.sql
BEGIN;

CREATE TABLE IF NOT EXISTS vendor_packages (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  vendor_id uuid NOT NULL REFERENCES vendor_profiles(id) ON DELETE CASCADE,
  package_name text NOT NULL,
  slug text UNIQUE,
  short_description text,
  long_description text,
  price_type text NOT NULL DEFAULT 'fixed' CHECK (price_type IN ('fixed','range','hourly','per_person')),
  price_min numeric(12,2),
  price_max numeric(12,2),
  currency text NOT NULL DEFAULT 'ZAR',
  duration_hours numeric(6,2),
  has_availability boolean DEFAULT false,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS package_items (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  package_id uuid NOT NULL REFERENCES vendor_packages(id) ON DELETE CASCADE,
  item_name text NOT NULL,
  item_description text,
  quantity integer DEFAULT 1,
  order_index integer DEFAULT 0
);

CREATE TABLE IF NOT EXISTS package_addons (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  package_id uuid NOT NULL REFERENCES vendor_packages(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  price numeric(12,2) NOT NULL,
  price_type text DEFAULT 'fixed' CHECK (price_type IN ('fixed','per_person','hourly')),
  is_active boolean DEFAULT true
);

CREATE TABLE IF NOT EXISTS package_images (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  package_id uuid NOT NULL REFERENCES vendor_packages(id) ON DELETE CASCADE,
  storage_path text NOT NULL,
  alt_text text,
  order_index integer DEFAULT 0
);

CREATE TABLE IF NOT EXISTS package_availability (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  package_id uuid NOT NULL REFERENCES vendor_packages(id) ON DELETE CASCADE,
  date date,
  start_time time,
  end_time time,
  is_available boolean DEFAULT true,
  note text
);

CREATE TABLE IF NOT EXISTS package_bookings (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  package_id uuid NOT NULL REFERENCES vendor_packages(id) ON DELETE CASCADE,
  couple_user_id uuid NOT NULL REFERENCES auth.users(id),
  vendor_user_id uuid NOT NULL,
  booking_status text NOT NULL DEFAULT 'pending' CHECK (booking_status IN ('pending','confirmed','declined','cancelled')),
  selected_addons uuid[] DEFAULT '{}',
  total_price numeric(12,2),
  event_date timestamptz,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_vendor_packages_vendor ON vendor_packages(vendor_id);
CREATE INDEX IF NOT EXISTS idx_vendor_packages_active ON vendor_packages(is_active);
CREATE INDEX IF NOT EXISTS idx_vendor_packages_slug ON vendor_packages(slug);
CREATE INDEX IF NOT EXISTS idx_package_items_package ON package_items(package_id);
CREATE INDEX IF NOT EXISTS idx_package_addons_package ON package_addons(package_id);
CREATE INDEX IF NOT EXISTS idx_package_images_package ON package_images(package_id);
CREATE INDEX IF NOT EXISTS idx_package_availability_package ON package_availability(package_id);
CREATE INDEX IF NOT EXISTS idx_package_bookings_package ON package_bookings(package_id);
CREATE INDEX IF NOT EXISTS idx_package_bookings_couple ON package_bookings(couple_user_id);
CREATE INDEX IF NOT EXISTS idx_package_bookings_status ON package_bookings(booking_status);

COMMIT;
