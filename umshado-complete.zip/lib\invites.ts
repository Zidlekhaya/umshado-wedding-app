// lib/invites.ts
import { supabase } from '@/lib/supabase';
import * as Linking from 'expo-linking';
import type { WeddingInvite } from './types';

export async function listInvites(weddingId: string): Promise<WeddingInvite[]> {
  const { data, error } = await supabase
    .from('wedding_invites')
    .select('*')
    .eq('wedding_id', weddingId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data || [];
}

export async function createInvite(
  weddingId: string,
  email: string,
  role: 'guest' | 'partner' | 'planner' = 'guest'
): Promise<WeddingInvite> {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth?.user) throw new Error('You must be signed in');

  // Generate a unique token (UUID format)
  const token = `xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx`.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });

  const { data, error } = await supabase
    .from('wedding_invites')
    .insert({
      wedding_id: weddingId,
      email,
      role,
      invited_by: auth.user.id,
      token,
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function revokeInvite(inviteId: string): Promise<void> {
  const { error } = await supabase
    .from('wedding_invites')
    .update({ status: 'revoked' })
    .eq('id', inviteId);

  if (error) throw error;
}

export async function acceptInvite(token: string): Promise<void> {
  const { error } = await supabase
    .from('wedding_invites')
    .update({ status: 'accepted' })
    .eq('token', token);

  if (error) throw error;
}

export function inviteLink(token: string): string {
  // Creates umshado://invite/<token>
  return Linking.createURL(`/invite/${token}`);
}

export function publicRSVPLink(weddingSlug: string): string {
  // Creates umshado://rsvp/<weddingSlug>
  return Linking.createURL(`/rsvp/${weddingSlug}`);
}

export function whatsappInviteLink(phoneNumber: string, message: string): string {
  // Creates WhatsApp link with pre-filled message
  const encodedMessage = encodeURIComponent(message);
  return `https://wa.me/${phoneNumber.replace(/[^0-9]/g, '')}?text=${encodedMessage}`;
}

export function generateInviteMessage(weddingName: string, inviteLink: string): string {
  return `🎉 You're invited to ${weddingName}! 

Click here to RSVP: ${inviteLink}

Looking forward to celebrating with you! 💕`;
}
