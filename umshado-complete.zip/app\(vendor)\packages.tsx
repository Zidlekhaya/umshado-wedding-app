import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Alert, Image } from 'react-native';
import { Stack, router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { Card } from '@/components/ui/Card';
import { Loading } from '@/components/ui/Loading';
import { BackButton } from '@/src/components/ui/BackButton';
import { supabase } from '@/lib/supabase';
import PackageManagementModal from '@/components/package-management/PackageManagementModal';
import { Package, listPackages, deletePackage } from '@/lib/package-service';

const colors = {
  background: '#f0fbea',
  primary: '#00a86b',
  text: '#1A1A1A',
  textLight: '#6B7280',
  border: '#E5E7EB',
  success: '#10B981',
  error: '#EF4444',
  warning: '#F59E0B',
  white: '#FFFFFF',
  urgent: '#FF6B6B',
  high: '#FF8E53',
  medium: '#FFA500',
  low: '#4ECDC4',
  completed: '#95E1A3',
  pending: '#FFD93D',
  inProgress: '#6BCF7F',
  // Enhanced colors for better UI
  headerBg: '#F8FAFC',
  headerText: '#1E293B',
  cardShadow: 'rgba(0, 0, 0, 0.1)',
  accent: '#F3F4F6',
};

export default function VendorPackages() {
  const [loading, setLoading] = useState(true);
  const [packages, setPackages] = useState<Package[]>([]);
  const [showManagementModal, setShowManagementModal] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<Package | null>(null);

  useEffect(() => {
    loadPackages();
  }, []);

  const loadPackages = async () => {
    try {
      setLoading(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        Alert.alert('Error', 'Please sign in to continue');
        router.replace('/(auth)/vendor-sign-in');
        return;
      }

      console.log('Loading packages for vendor:', user.id);

      // Get vendor profile first
      const { data: vendorProfile, error: profileError } = await supabase
        .from('vendor_profiles')
        .select('id, business_name, user_id')
        .eq('user_id', user.id)
        .single();

      if (profileError) {
        console.error('Error loading vendor profile:', profileError);
        Alert.alert('Error', 'Failed to load vendor profile');
        return;
      }

      console.log('Vendor profile found:', vendorProfile.business_name, 'ID:', vendorProfile.id);

      // Use the new package service to load packages
      const vendorPackages = await listPackages(vendorProfile.id);
      console.log('Packages loaded:', vendorPackages?.length || 0);
      setPackages(vendorPackages || []);
    } catch (error: any) {
      console.error('Error loading packages:', error);
      Alert.alert('Error', 'Failed to load packages');
    } finally {
      setLoading(false);
    }
  };

  const handleEditPackage = (pkg: Package) => {
    console.log('Edit package clicked:', pkg);
    setSelectedPackage(pkg);
    setShowManagementModal(true);
  };

  const handleDeletePackage = async (pkg: Package) => {
    console.log('Delete package clicked:', pkg);
    Alert.alert(
      'Delete Package',
      `Are you sure you want to delete "${pkg.package_name}"? This action cannot be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              console.log('Deleting package:', pkg.id);
              setLoading(true);
              await deletePackage(pkg.id);
              await loadPackages();
              Alert.alert('Success', 'Package deleted successfully!');
            } catch (error) {
              console.error('Error deleting package:', error);
              Alert.alert('Error', 'Failed to delete package');
            } finally {
              setLoading(false);
            }
          },
        },
      ]
    );
  };

  const handlePackageUpdated = async (updatedPackage: Package) => {
    // Check if this is a new package (not in current list) or an update
    const existingPackage = packages.find(pkg => pkg.id === updatedPackage.id);
    
    if (existingPackage) {
      // Update existing package
      setPackages(packages.map(pkg => pkg.id === updatedPackage.id ? updatedPackage : pkg));
    } else {
      // Add new package to the list
      setPackages([updatedPackage, ...packages]);
    }
    
    setShowManagementModal(false);
    setSelectedPackage(null);
  };

  const handleSignOut = async () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Logout', 
          style: 'destructive',
          onPress: async () => {
            try {
              await supabase.auth.signOut();
              router.replace('/(auth)');
            } catch (error) {
              Alert.alert('Error', 'Failed to logout');
            }
          }
        }
      ]
    );
  };

  const formatPrice = (pkg: Package) => {
    if (pkg.price_type === 'fixed') {
      return `R${pkg.price_min?.toLocaleString()}`;
    } else if (pkg.price_type === 'range') {
      return `R${pkg.price_min?.toLocaleString()} - R${pkg.price_max?.toLocaleString()}`;
    } else if (pkg.price_type === 'per_person') {
      return `R${pkg.price_min?.toLocaleString()}/person`;
    } else if (pkg.price_type === 'hourly') {
      return `R${pkg.price_min?.toLocaleString()}/hour`;
    }
    return 'Price on request';
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <Loading size="large" color={colors.primary} text="Loading packages..." />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Stack.Screen
        options={{
          title: 'Packages',
          headerLeft: () => <BackButton color={colors.text} />,
          headerRight: () => (
            <View style={styles.headerButtons}>
              <TouchableOpacity onPress={loadPackages} style={styles.refreshButton}>
                <Feather name="refresh-cw" size={20} color={colors.textLight} />
              </TouchableOpacity>
              <TouchableOpacity onPress={handleSignOut} style={styles.signOutButton}>
                <Feather name="log-out" size={16} color={colors.white} />
                <Text style={styles.signOutButtonText}>Logout</Text>
              </TouchableOpacity>
            </View>
          ),
        }}
      />

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <Card variant="elevated" padding="lg" style={styles.headerCard}>
          <View style={styles.headerContent}>
            <View style={styles.headerIcon}>
              <Feather name="package" size={24} color={colors.primary} />
            </View>
            <View style={styles.headerText}>
              <Text style={styles.headerTitle}>My Packages</Text>
              <Text style={styles.headerSubtitle}>Manage your wedding packages and pricing</Text>
            </View>
          </View>
        </Card>


        {/* Packages List */}
        <View style={styles.packagesList}>
          {packages.map((pkg) => (
            <Card key={pkg.id} variant="default" padding="md" style={styles.packageCard}>
              <View style={styles.packageHeader}>
                <View style={styles.packageImageContainer}>
                  {pkg.package_images && pkg.package_images.length > 0 ? (
                    <Image 
                      source={{ uri: pkg.package_images[0].storage_path }} 
                      style={styles.packageImage}
                      resizeMode="cover"
                    />
                  ) : (
                    <View style={styles.packageImagePlaceholder}>
                      <Feather name="package" size={24} color={colors.textLight} />
                    </View>
                  )}
                  
                </View>
                <View style={styles.packageInfo}>
                  <Text style={styles.packageName}>{pkg.package_name}</Text>
                  <Text style={styles.packageDescription}>
                    {pkg.short_description || 'No description available'}
                  </Text>
                  <View style={styles.packageMeta}>
                    <Text style={styles.packagePrice}>{formatPrice(pkg)}</Text>
                    {pkg.duration_hours && (
                      <Text style={styles.packageDuration}>{pkg.duration_hours}h</Text>
                    )}
                  </View>
                </View>
              </View>

              {/* Package Items Preview */}
              {pkg.package_items && pkg.package_items.length > 0 && (
                <View style={styles.packageItems}>
                  <Text style={styles.itemsTitle}>Includes:</Text>
                  {pkg.package_items.slice(0, 3).map((item, index) => (
                    <Text key={index} style={styles.itemText}>• {item.item_name}</Text>
                  ))}
                  {pkg.package_items.length > 3 && (
                    <Text style={styles.itemText}>• +{pkg.package_items.length - 3} more</Text>
                  )}
                </View>
              )}

              {/* Package Addons Preview */}
              {pkg.package_addons && pkg.package_addons.length > 0 && (
                <View style={styles.packageAddons}>
                  <Text style={styles.addonsTitle}>Add-ons:</Text>
                  {pkg.package_addons.slice(0, 2).map((addon, index) => (
                    <Text key={index} style={styles.addonText}>
                      {addon.title} - R{addon.price.toLocaleString()}
                    </Text>
                  ))}
                  {pkg.package_addons.length > 2 && (
                    <Text style={styles.addonText}>+{pkg.package_addons.length - 2} more</Text>
                  )}
                </View>
              )}

              {/* Status Badge */}
              <View style={styles.statusContainer}>
                <View style={[
                  styles.statusBadge, 
                  { backgroundColor: pkg.is_active ? colors.success : colors.error }
                ]}>
                  <Text style={[
                    styles.statusText,
                    { color: pkg.is_active ? colors.success : colors.error }
                  ]}>
                    {pkg.is_active ? 'Active' : 'Inactive'}
                  </Text>
                </View>
              </View>

              {/* Action Buttons */}
              <View style={styles.actionButtonsContainer}>
                <TouchableOpacity
                  style={styles.actionButton}
                  onPress={() => handleEditPackage(pkg)}
                >
                  <Feather name="edit" size={16} color={colors.primary} />
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.actionButton}
                  onPress={() => handleDeletePackage(pkg)}
                >
                  <Feather name="trash-2" size={16} color={colors.error} />
                </TouchableOpacity>
              </View>
            </Card>
          ))}
        </View>

        {/* Add New Package Button */}
        <TouchableOpacity 
          style={styles.addButton}
          onPress={() => handleEditPackage(null)}
        >
          <View style={styles.addButtonContent}>
            <Feather name="plus" size={20} color={colors.white} />
            <Text style={styles.addButtonText}>Add New Package</Text>
          </View>
        </TouchableOpacity>

        {packages.length === 0 && (
          <Card variant="default" padding="lg" style={styles.emptyCard}>
            <View style={styles.emptyIcon}>
              <Feather name="package" size={48} color={colors.textLight} />
            </View>
            <Text style={styles.emptyTitle}>No Packages Yet</Text>
            <Text style={styles.emptySubtitle}>
              Create your first package to start attracting couples
            </Text>
          </Card>
        )}
      </ScrollView>

      {/* Package Management Modal */}
      <PackageManagementModal
        visible={showManagementModal}
        package={selectedPackage}
        onClose={() => {
          setShowManagementModal(false);
          setSelectedPackage(null);
        }}
        onPackageUpdated={handlePackageUpdated}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  headerButtons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  refreshButton: {
    padding: 8,
    marginRight: 8,
  },
  signOutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: colors.error || '#EF4444',
    gap: 6,
    shadowColor: 'rgba(0, 0, 0, 0.1)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  signOutButtonText: {
    color: colors.white,
    fontSize: 12,
    fontWeight: '600',
  },
  headerCard: {
    marginBottom: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  headerText: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: colors.textLight,
  },
  packagesList: {
    gap: 12,
  },
  packageCard: {
    marginBottom: 12,
  },
  packageHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  packageImageContainer: {
    width: 60,
    height: 60,
    borderRadius: 8,
    overflow: 'hidden',
    marginRight: 12,
  },
  packageImage: {
    width: '100%',
    height: '100%',
  },
  packageImagePlaceholder: {
    width: '100%',
    height: '100%',
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  packageInfo: {
    flex: 1,
  },
  packageName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  packageDescription: {
    fontSize: 14,
    color: colors.textLight,
    marginBottom: 8,
    lineHeight: 20,
  },
  packageMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  packagePrice: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.primary,
  },
  packageDuration: {
    fontSize: 12,
    color: colors.textLight,
  },
  packageItems: {
    marginBottom: 8,
  },
  itemsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  itemText: {
    fontSize: 12,
    color: colors.textLight,
    marginBottom: 2,
  },
  packageAddons: {
    marginBottom: 8,
  },
  addonsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  addonText: {
    fontSize: 12,
    color: colors.textLight,
    marginBottom: 2,
  },
  statusContainer: {
    alignItems: 'flex-end',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
  },
  emptyCard: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyIcon: {
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: colors.textLight,
    textAlign: 'center',
    lineHeight: 20,
  },
  // Action Buttons (matching task system style)
  actionButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: 12,
    gap: 8,
  },
  actionButton: {
    backgroundColor: colors.white,
    borderRadius: 8,
    width: 36,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  // Add New Package Button
  addButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    marginVertical: 16,
    marginHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  addButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
  },
  addButtonText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
});
