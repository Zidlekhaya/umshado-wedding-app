import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { Stack, router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Loading } from '@/components/ui/Loading';
import { BackButton } from '@/src/components/ui/BackButton';
// Using consistent colors instead of design system
const colors = {
  background: '#f0fbea',
  primary: '#00a86b',
  text: '#1A1A1A',
  textLight: '#6B7280',
  border: '#E5E7EB',
  success: '#10B981',
  error: '#EF4444',
  warning: '#F59E0B',
  white: '#FFFFFF',
  headerBg: '#F8FAFC',
  headerText: '#1E293B',
  cardShadow: 'rgba(0, 0, 0, 0.1)',
  accent: '#F3F4F6',
};
import { supabase } from '@/lib/supabase';
import ServiceManagementModal from '@/components/service-management/ServiceManagementModal';

export default function VendorServices() {
  const [loading, setLoading] = useState(true);
  const [services, setServices] = useState<any[]>([]);
  const [showManagementModal, setShowManagementModal] = useState(false);
  const [selectedService, setSelectedService] = useState<any>(null);

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    try {
      setLoading(true);
      
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        Alert.alert('Error', 'Please sign in to continue');
        router.replace('/(auth)/vendor-sign-in');
        return;
      }

      console.log('Loading services for vendor:', user.id);

      // Get vendor profile first to get vendor_id
      const { data: vendorProfile, error: profileError } = await supabase
        .from('vendor_profiles')
        .select('id, business_name')
        .eq('user_id', user.id)
        .single();

      if (profileError) {
        console.error('Error loading vendor profile:', profileError);
        Alert.alert('Error', 'Failed to load vendor profile');
        return;
      }

      console.log('Vendor profile found:', vendorProfile.business_name, 'ID:', vendorProfile.id);

      // Get vendor services using the vendor profile id
      const { data: vendorServices, error } = await supabase
        .from('vendor_services')
        .select('*')
        .eq('vendor_id', vendorProfile.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error loading services:', error);
        Alert.alert('Error', 'Failed to load services');
        return;
      }

      console.log('Raw services query result:', vendorServices);
      console.log('Services loaded:', vendorServices?.length || 0);
      
      // Filter active services
      const activeServices = vendorServices?.filter(service => service.is_active !== false) || [];
      console.log('Active services:', activeServices.length);
      
      setServices(activeServices);
    } catch (error: any) {
      console.error('Error loading services:', error);
      Alert.alert('Error', 'Failed to load services');
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Logout', 
          style: 'destructive',
          onPress: async () => {
            try {
              await supabase.auth.signOut();
              router.replace('/(auth)');
            } catch (error) {
              Alert.alert('Error', 'Failed to logout');
            }
          }
        }
      ]
    );
  };

  const handleEditService = (service: any) => {
    console.log('Edit service:', service ? service.service_name : 'Creating new service');
    setSelectedService(service);
    setShowManagementModal(true);
  };

  const handleDeleteService = async (service: any) => {
    console.log('Delete service:', service.service_name);
    
    Alert.alert(
      'Delete Service',
      `Are you sure you want to delete "${service.service_name}"? This action cannot be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('vendor_services')
                .delete()
                .eq('id', service.id);

              if (error) {
                console.error('Error deleting service:', error);
                Alert.alert('Error', 'Failed to delete service. Please try again.');
                return;
              }

              Alert.alert('Success', 'Service deleted successfully!');
              // Reload services to reflect the change
              loadServices();
            } catch (error) {
              console.error('Error deleting service:', error);
              Alert.alert('Error', 'Failed to delete service. Please try again.');
            }
          }
        }
      ]
    );
  };

  const handleServiceUpdated = (updatedService: any) => {
    // Check if this is a new service (not in current list) or an update
    const existingService = services.find(service => service.id === updatedService.id);
    
    if (existingService) {
      // Update existing service
      setServices(services.map(service => 
        service.id === updatedService.id ? updatedService : service
      ));
    } else {
      // Add new service to the list
      setServices([updatedService, ...services]);
    }
    
    setShowManagementModal(false);
    setSelectedService(null);
  };

  const handleCloseModal = () => {
    setShowManagementModal(false);
    setSelectedService(null);
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <Loading size="large" color={colors.primary} text="Loading services..." />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Stack.Screen
        options={{
          title: 'Services',
          headerLeft: () => <BackButton color={colors.text} />,
          headerRight: () => (
            <View style={styles.headerButtons}>
              <TouchableOpacity onPress={loadServices} style={styles.refreshButton}>
                <Feather name="refresh-cw" size={20} color={colors.textLight} />
              </TouchableOpacity>
              <TouchableOpacity onPress={handleSignOut} style={styles.signOutButton}>
                <Feather name="log-out" size={16} color={colors.white} />
                <Text style={styles.signOutButtonText}>Logout</Text>
              </TouchableOpacity>
            </View>
          ),
        }}
      />

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <Card variant="elevated" padding="lg" style={styles.headerCard}>
          <View style={styles.headerContent}>
            <View style={styles.headerIcon}>
              <Feather name="briefcase" size={24} color={colors.primary} />
            </View>
            <View style={styles.headerText}>
              <Text style={styles.headerTitle}>My Services</Text>
              <Text style={styles.headerSubtitle}>Manage your wedding services and pricing</Text>
            </View>
          </View>
        </Card>

        {/* Add Service Button */}
        <TouchableOpacity 
          style={styles.addButton}
          onPress={() => handleEditService(null)}
        >
          <View style={styles.addButtonContent}>
            <Feather name="plus" size={20} color={colors.white} />
            <Text style={styles.addButtonText}>Add New Service</Text>
          </View>
        </TouchableOpacity>

        {/* Services List */}
        <View style={styles.servicesList}>
          {services.map((service) => (
            <Card key={service.id} variant="default" padding="md" style={styles.serviceCard}>
              <View style={styles.serviceHeader}>
                <View style={styles.serviceIcon}>
                  <Feather name="star" size={16} color={colors.primary} />
                </View>
                <View style={styles.serviceInfo}>
                  <Text style={styles.serviceName}>{service.service_name}</Text>
                  <Text style={styles.serviceCategory}>{service.price_type}</Text>
                </View>
              </View>
              <Text style={styles.serviceDescription}>{service.description}</Text>
              <View style={styles.servicePriceContainer}>
                <Text style={styles.servicePrice}>
                  R{service.price_min?.toLocaleString()} - R{service.price_max?.toLocaleString()}
                </Text>
                {service.duration_hours && (
                  <Text style={styles.serviceDuration}>{service.duration_hours} hours</Text>
                )}
              </View>
              {service.includes && service.includes.length > 0 && (
                <View style={styles.serviceIncludes}>
                  <Text style={styles.includesTitle}>Includes:</Text>
                  {service.includes.slice(0, 3).map((item, index) => (
                    <Text key={index} style={styles.includesItem}>• {item}</Text>
                  ))}
                  {service.includes.length > 3 && (
                    <Text style={styles.includesItem}>• +{service.includes.length - 3} more</Text>
                  )}
                </View>
              )}

              {/* Action Buttons */}
              <View style={styles.actionButtonsContainer}>
                <TouchableOpacity
                  style={styles.actionButton}
                  onPress={() => handleEditService(service)}
                >
                  <Feather name="edit" size={16} color={colors.primary} />
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.actionButton}
                  onPress={() => handleDeleteService(service)}
                >
                  <Feather name="trash-2" size={16} color={colors.error} />
                </TouchableOpacity>
              </View>
            </Card>
          ))}
        </View>

        {services.length === 0 && (
          <Card variant="default" padding="lg" style={styles.emptyCard}>
            <View style={styles.emptyIcon}>
              <Feather name="briefcase" size={48} color={colors.text.tertiary} />
            </View>
            <Text style={styles.emptyTitle}>No Services Yet</Text>
            <Text style={styles.emptySubtitle}>
              Add your first service to start attracting couples
            </Text>
          </Card>
        )}
      </ScrollView>

      {/* Service Management Modal */}
      <ServiceManagementModal
        visible={showManagementModal}
        service={selectedService}
        onClose={handleCloseModal}
        onServiceUpdated={handleServiceUpdated}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  headerButtons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  refreshButton: {
    padding: 8,
    marginRight: 8,
  },
  signOutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: colors.error || '#EF4444',
    gap: 6,
    shadowColor: 'rgba(0, 0, 0, 0.1)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  signOutButtonText: {
    color: colors.white,
    fontSize: 12,
    fontWeight: '600',
  },
  headerCard: {
    marginBottom: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  headerText: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: colors.textLight,
  },
  addButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  addButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
  },
  addButtonText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
  servicesList: {
    gap: 12,
  },
  serviceCard: {
    marginBottom: 12,
  },
  serviceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  serviceIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  serviceInfo: {
    flex: 1,
  },
  serviceName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  serviceCategory: {
    fontSize: 14,
    color: colors.textLight,
  },
  serviceActions: {
    padding: 8,
  },
  serviceDescription: {
    fontSize: 14,
    color: colors.textLight,
    marginBottom: 8,
    lineHeight: 20,
  },
  servicePriceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  servicePrice: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.primary[300],
  },
  serviceDuration: {
    fontSize: 14,
    color: colors.textLight,
  },
  serviceIncludes: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: colors.border.primary,
  },
  includesTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  includesItem: {
    fontSize: 14,
    color: colors.textLight,
    marginBottom: 4,
  },
  emptyCard: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyIcon: {
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: colors.textLight,
    textAlign: 'center',
    lineHeight: 20,
  },
  actionButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: 12,
    gap: 8,
  },
  actionButton: {
    backgroundColor: colors.white,
    borderRadius: 8,
    width: 36,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
});

