export type Wedding = {
  id: string;
  owner_id: string;
  name: string;                 // single name column in DB
  date: string | null;
  location: string | null;
  culture: string | null;
  ceremony_location?: string | null;
  reception_location?: string | null;
  city?: string | null;
  slug?: string | null;
  created_at?: string;
  updated_at?: string;
};






