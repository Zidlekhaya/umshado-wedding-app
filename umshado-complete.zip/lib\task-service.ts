import { supabase } from './supabase';

export type TaskCategory = 
  | 'venue' | 'catering' | 'photography' | 'music' | 'flowers' | 'decor'
  | 'transport' | 'attire' | 'invitations' | 'general';

export type TaskPriority = 'low' | 'medium' | 'high';
export type TaskStatus = 'pending' | 'in_progress' | 'completed';

export interface Task {
  id: string;
  wedding_id: string;
  title: string;
  description?: string | null;
  category: TaskCategory;
  priority: TaskPriority;
  status: TaskStatus;
  due_date?: string | null; // ISO date
  completed_at?: string | null;
  assigned_to?: string | null;
  estimated_hours?: number | null;
  actual_hours?: number | null;
  notes?: string | null;
  checklist?: ChecklistItem[] | null;
  created_at?: string;
  updated_at?: string;
}

export interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
}

export interface CreateTaskData {
  wedding_id: string;
  title: string;
  description?: string;
  category: TaskCategory;
  priority: TaskPriority;
  status: TaskStatus;
  due_date?: string;
  assigned_to?: string;
  estimated_hours?: number;
  notes?: string;
}

export async function listTasks(weddingId: string): Promise<Task[]> {
  try {
    const { data, error } = await supabase
      .from('tasks')
      .select('*')
      .eq('wedding_id', weddingId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching tasks:', error);
    throw error;
  }
}

export async function createTask(taskData: CreateTaskData): Promise<Task> {
  try {
    const { data, error } = await supabase
      .from('tasks')
      .insert([taskData])
      .select()
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error creating task:', error);
    throw error;
  }
}

export async function updateTask(taskData: Partial<CreateTaskData> & { id: string }): Promise<Task> {
  try {
    const { id, ...updates } = taskData;
    
    // Set completed_at if status is being changed to completed
    if (updates.status === 'completed') {
      updates.completed_at = new Date().toISOString();
    } else if (updates.status !== 'completed') {
      updates.completed_at = null;
    }

    const { data, error } = await supabase
      .from('tasks')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error updating task:', error);
    throw error;
  }
}

export async function deleteTask(taskId: string): Promise<void> {
  try {
    const { error } = await supabase
      .from('tasks')
      .delete()
      .eq('id', taskId);

    if (error) throw error;
  } catch (error) {
    console.error('Error deleting task:', error);
    throw error;
  }
}

export async function getTask(taskId: string): Promise<Task | null> {
  try {
    const { data, error } = await supabase
      .from('tasks')
      .select('*')
      .eq('id', taskId)
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        return null; // Task not found
      }
      throw error;
    }
    
    return data;
  } catch (error) {
    console.error('Error fetching task:', error);
    throw error;
  }
}

export function getCategoryIcon(category: TaskCategory): string {
  const iconMap: Record<TaskCategory, string> = {
    venue: 'map-pin',
    catering: 'coffee',
    photography: 'camera',
    music: 'music',
    flowers: 'heart',
    decor: 'star',
    transport: 'truck',
    attire: 'user',
    invitations: 'mail',
    general: 'clipboard',
  };
  return iconMap[category] || 'clipboard';
}

export function getPriorityColor(priority: TaskPriority): string {
  switch (priority) {
    case 'high': return '#EF4444';
    case 'medium': return '#F59E0B';
    case 'low': return '#22C55E';
    default: return '#9CA3AF';
  }
}

export function getStatusColor(status: TaskStatus): string {
  switch (status) {
    case 'completed': return '#22C55E';
    case 'in_progress': return '#3B82F6';
    case 'pending': return '#F59E0B';
    default: return '#9CA3AF';
  }
}