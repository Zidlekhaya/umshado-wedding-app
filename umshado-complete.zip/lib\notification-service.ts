import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import { Platform } from 'react-native';
import { supabase } from './supabase';

// Configure notification behavior
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

export interface PushToken {
  token: string;
  userId: string;
  deviceType: 'ios' | 'android';
  createdAt: string;
  updatedAt: string;
}

/**
 * Request notification permissions and get push token
 */
export async function registerForPushNotifications(): Promise<string | null> {
  let token = null;

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'default',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#00a86b',
    });
  }

  if (Device.isDevice) {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    
    if (finalStatus !== 'granted') {
      console.log('Failed to get push token for push notification!');
      return null;
    }
    
    try {
      const projectId = Constants.expoConfig?.extra?.eas?.projectId ?? Constants.easConfig?.projectId;
      if (!projectId) {
        console.log('📱 Push tokens require a development build. Running in Expo Go - push notifications will work on device build.');
        return null;
      }
      
      token = (await Notifications.getExpoPushTokenAsync({
        projectId,
      })).data;
      
      console.log('Push token obtained:', token);
    } catch (error) {
      console.log('📱 Push notifications not available in Expo Go. This is normal for development.');
      console.log('   For full push notification support, use EAS Build or development build.');
      return null;
    }
  } else {
    console.log('Must use physical device for Push Notifications');
    return null;
  }

  return token;
}

/**
 * Save push token to database
 */
export async function savePushToken(token: string): Promise<void> {
  try {
    const { data: sessionData } = await supabase.auth.getSession();
    if (!sessionData.session?.user) {
      throw new Error('User not authenticated');
    }

    const deviceType = Platform.OS as 'ios' | 'android';
    
    // Upsert push token
    const { error } = await supabase
      .from('push_tokens')
      .upsert({
        user_id: sessionData.session.user.id,
        token,
        device_type: deviceType,
        updated_at: new Date().toISOString(),
      }, {
        onConflict: 'user_id,device_type'
      });

    if (error) throw error;
    console.log('Push token saved successfully');
  } catch (error) {
    console.error('Error saving push token:', error);
    throw error;
  }
}

/**
 * Initialize push notifications for the current user
 */
export async function initializePushNotifications(): Promise<void> {
  try {
    const token = await registerForPushNotifications();
    if (token) {
      await savePushToken(token);
    }
  } catch (error) {
    console.error('Error initializing push notifications:', error);
  }
}

/**
 * Send push notification via Supabase Edge Function
 */
export async function sendPushNotification({
  userIds,
  title,
  body,
  data = {},
}: {
  userIds: string[];
  title: string;
  body: string;
  data?: Record<string, any>;
}): Promise<void> {
  try {
    const { error } = await supabase.functions.invoke('send-push-notification', {
      body: {
        userIds,
        title,
        body,
        data,
      },
    });

    if (error) throw error;
  } catch (error) {
    console.error('Error sending push notification:', error);
    throw error;
  }
}

/**
 * Handle notification received while app is in foreground
 */
export function setupForegroundNotificationHandler() {
  return Notifications.addNotificationReceivedListener(notification => {
    console.log('🔔 Notification received in foreground:', notification);
    // You can show a custom in-app notification here
  });
}

/**
 * Handle notification tap (when user taps notification)
 */
export function setupNotificationTapHandler(navigationCallback: (data: any) => void) {
  return Notifications.addNotificationResponseReceivedListener(response => {
    console.log('🔔 Notification tapped:', response);
    const data = response.notification.request.content.data;
    
    if (data?.conversationId) {
      navigationCallback(data);
    }
  });
}

/**
 * Send message notification
 */
export async function sendMessageNotification({
  recipientId,
  senderName,
  messageText,
  conversationId,
}: {
  recipientId: string;
  senderName: string;
  messageText: string;
  conversationId: string;
}): Promise<void> {
  await sendPushNotification({
    userIds: [recipientId],
    title: `New message from ${senderName}`,
    body: messageText,
    data: {
      type: 'message',
      conversationId,
      senderName,
    },
  });
}

/**
 * Send booking notification
 */
export async function sendBookingNotification({
  recipientId,
  title,
  body,
  bookingId,
}: {
  recipientId: string;
  title: string;
  body: string;
  bookingId: string;
}): Promise<void> {
  await sendPushNotification({
    userIds: [recipientId],
    title,
    body,
    data: {
      type: 'booking',
      bookingId,
    },
  });
}
