-- Fix Vendor Signup Issues
-- This migration consolidates vendor tables and fixes signup triggers

-- First, let's check what tables exist and clean up conflicts
-- Drop existing triggers that might be causing issues
DROP TRIGGER IF EXISTS trigger_create_vendor_profile_on_signup ON auth.users;
DROP FUNCTION IF EXISTS create_vendor_profile_on_signup();

-- Ensure we have the correct vendor_profiles table structure
-- Drop and recreate to avoid conflicts
DROP TABLE IF EXISTS vendor_profiles CASCADE;

-- Create the consolidated vendor_profiles table
CREATE TABLE vendor_profiles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  business_name TEXT NOT NULL,
  business_description TEXT,
  category TEXT NOT NULL,
  location TEXT,
  city TEXT,
  province TEXT DEFAULT 'Western Cape',
  country TEXT DEFAULT 'South Africa',
  
  -- Contact Information
  contact_email TEXT,
  contact_phone TEXT,
  website TEXT,
  
  -- Social Media
  instagram TEXT,
  facebook TEXT,
  twitter TEXT,
  linkedin TEXT,
  
  -- Business Details
  years_experience INTEGER DEFAULT 0,
  price_range TEXT,
  service_areas TEXT[],
  languages TEXT[] DEFAULT '{"English"}',
  
  -- Portfolio
  portfolio_images TEXT[],
  featured_image TEXT,
  
  -- Verification
  is_verified BOOLEAN DEFAULT FALSE,
  verification_documents TEXT[],
  
  -- Status
  is_active BOOLEAN DEFAULT TRUE,
  is_featured BOOLEAN DEFAULT FALSE,
  
  -- Analytics
  view_count INTEGER DEFAULT 0,
  inquiry_count INTEGER DEFAULT 0,
  rating_average DECIMAL(3,2) DEFAULT 0.00,
  review_count INTEGER DEFAULT 0,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(user_id)
);

-- Create indexes for better performance
CREATE INDEX idx_vendor_profiles_user_id ON vendor_profiles(user_id);
CREATE INDEX idx_vendor_profiles_category ON vendor_profiles(category);
CREATE INDEX idx_vendor_profiles_city ON vendor_profiles(city);
CREATE INDEX idx_vendor_profiles_is_active ON vendor_profiles(is_active);
CREATE INDEX idx_vendor_profiles_rating ON vendor_profiles(rating_average DESC);

-- Enable Row Level Security (RLS)
ALTER TABLE vendor_profiles ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Vendors can view their own profile" ON vendor_profiles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Vendors can update their own profile" ON vendor_profiles
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Vendors can insert their own profile" ON vendor_profiles
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Anyone can view active vendor profiles" ON vendor_profiles
  FOR SELECT USING (is_active = TRUE);

-- Create function to automatically create vendor profile on signup
CREATE OR REPLACE FUNCTION create_vendor_profile_on_signup()
RETURNS TRIGGER AS $$
BEGIN
  -- Only create profile if user_type is 'vendor'
  IF NEW.raw_user_meta_data->>'user_type' = 'vendor' THEN
    INSERT INTO vendor_profiles (
      user_id,
      business_name,
      business_description,
      category,
      contact_email,
      city,
      location,
      is_active,
      is_verified
    ) VALUES (
      NEW.id,
      COALESCE(NEW.raw_user_meta_data->>'business_name', 'My Business'),
      'Professional wedding services',
      COALESCE(NEW.raw_user_meta_data->>'category', 'other'),
      NEW.email,
      COALESCE(NEW.raw_user_meta_data->>'location', 'Cape Town'),
      COALESCE(NEW.raw_user_meta_data->>'location', 'Cape Town'),
      TRUE,
      FALSE
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to automatically create vendor profile
CREATE TRIGGER trigger_create_vendor_profile_on_signup
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION create_vendor_profile_on_signup();

-- Create function to update vendor profile timestamps
CREATE OR REPLACE FUNCTION update_vendor_profile_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to update timestamps
CREATE TRIGGER trigger_update_vendor_profile_timestamp
  BEFORE UPDATE ON vendor_profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_vendor_profile_timestamp();

-- Create vendor services table (if it doesn't exist)
CREATE TABLE IF NOT EXISTS vendor_services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id UUID NOT NULL REFERENCES vendor_profiles(id) ON DELETE CASCADE,
  service_name TEXT NOT NULL,
  description TEXT,
  price_min NUMERIC(10,2),
  price_max NUMERIC(10,2),
  price_type TEXT DEFAULT 'fixed',
  duration_hours INTEGER,
  includes TEXT[],
  add_ons TEXT[],
  images TEXT[],
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS for vendor services
ALTER TABLE vendor_services ENABLE ROW LEVEL SECURITY;

-- Create policies for vendor services
CREATE POLICY "Vendor services are publicly readable" ON vendor_services
  FOR SELECT USING (is_active = true);

CREATE POLICY "Vendors can manage their own services" ON vendor_services
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM vendor_profiles 
      WHERE vendor_profiles.id = vendor_services.vendor_id 
      AND vendor_profiles.user_id = auth.uid()
    )
  );

-- Create vendor inquiries table (if it doesn't exist)
CREATE TABLE IF NOT EXISTS vendor_inquiries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id UUID NOT NULL REFERENCES vendor_profiles(id) ON DELETE CASCADE,
  couple_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  wedding_id UUID,
  
  -- Inquiry details
  inquiry_type TEXT DEFAULT 'general',
  message TEXT NOT NULL,
  wedding_date DATE,
  guest_count INTEGER,
  budget_range TEXT,
  
  -- Contact information
  contact_name TEXT NOT NULL,
  contact_email TEXT NOT NULL,
  contact_phone TEXT,
  
  -- Status
  status TEXT DEFAULT 'pending',
  vendor_response TEXT,
  responded_at TIMESTAMPTZ,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS for vendor inquiries
ALTER TABLE vendor_inquiries ENABLE ROW LEVEL SECURITY;

-- Create policies for vendor inquiries
CREATE POLICY "Vendors can view their inquiries" ON vendor_inquiries
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM vendor_profiles 
      WHERE vendor_profiles.id = vendor_inquiries.vendor_id 
      AND vendor_profiles.user_id = auth.uid()
    )
  );

CREATE POLICY "Anyone can create inquiries" ON vendor_inquiries
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Vendors can update their inquiries" ON vendor_inquiries
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM vendor_profiles 
      WHERE vendor_profiles.id = vendor_inquiries.vendor_id 
      AND vendor_profiles.user_id = auth.uid()
    )
  );

-- Create vendor reviews table (if it doesn't exist)
CREATE TABLE IF NOT EXISTS vendor_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id UUID NOT NULL REFERENCES vendor_profiles(id) ON DELETE CASCADE,
  reviewer_name TEXT NOT NULL,
  reviewer_email TEXT,
  wedding_date DATE,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review_text TEXT,
  images TEXT[],
  is_verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS for vendor reviews
ALTER TABLE vendor_reviews ENABLE ROW LEVEL SECURITY;

-- Create policies for vendor reviews
CREATE POLICY "Vendor reviews are publicly readable" ON vendor_reviews
  FOR SELECT USING (true);

CREATE POLICY "Anyone can create vendor reviews" ON vendor_reviews
  FOR INSERT WITH CHECK (true);

-- Create function to calculate vendor rating
CREATE OR REPLACE FUNCTION calculate_vendor_rating(vendor_uuid UUID)
RETURNS void AS $$
DECLARE
  avg_rating DECIMAL(3,2);
  total_reviews INTEGER;
BEGIN
  SELECT AVG(rating)::DECIMAL(3,2), COUNT(*)
  INTO avg_rating, total_reviews
  FROM vendor_reviews
  WHERE vendor_id = vendor_uuid;
  
  UPDATE vendor_profiles 
  SET rating_average = COALESCE(avg_rating, 0.00),
      review_count = total_reviews
  WHERE id = vendor_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to update rating when reviews change
CREATE OR REPLACE FUNCTION trigger_update_vendor_rating()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    PERFORM calculate_vendor_rating(NEW.vendor_id);
  ELSIF TG_OP = 'DELETE' THEN
    PERFORM calculate_vendor_rating(OLD.vendor_id);
  END IF;
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_vendor_rating_trigger
  AFTER INSERT OR UPDATE OR DELETE ON vendor_reviews
  FOR EACH ROW
  EXECUTE FUNCTION trigger_update_vendor_rating();

-- Insert some default vendor categories if they don't exist
INSERT INTO vendor_profiles (user_id, business_name, category, contact_email, is_active, is_verified)
SELECT 
  gen_random_uuid(),
  'Sample Photography Studio',
  'photography',
  'sample@photography.com',
  false,
  false
WHERE NOT EXISTS (SELECT 1 FROM vendor_profiles WHERE business_name = 'Sample Photography Studio');

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT ALL ON ALL TABLES IN SCHEMA public TO anon, authenticated;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO anon, authenticated;
