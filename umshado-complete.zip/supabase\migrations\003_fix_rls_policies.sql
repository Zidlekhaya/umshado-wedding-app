-- Fix RLS policies for messages table to allow both couples and vendors

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view messages in their conversations" ON messages;
DROP POLICY IF EXISTS "Users can insert messages in their conversations" ON messages;
DROP POLICY IF EXISTS "Users can update their own messages" ON messages;

-- Create new comprehensive policies
CREATE POLICY "Users can view messages in their conversations" ON messages
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM conversations 
      WHERE conversations.id = messages.conversation_id 
      AND (conversations.couple_id = auth.uid() OR conversations.vendor_id = auth.uid())
    )
  );

CREATE POLICY "Users can insert messages in their conversations" ON messages
  FOR INSERT WITH CHECK (
    -- Check if user is part of the conversation
    EXISTS (
      SELECT 1 FROM conversations 
      WHERE conversations.id = messages.conversation_id 
      AND (conversations.couple_id = auth.uid() OR conversations.vendor_id = auth.uid())
    )
    AND
    -- Check if sender_id matches current user
    messages.sender_id = auth.uid()
    AND
    -- Check if sender_type matches user role in conversation
    (
      (messages.sender_type = 'couple' AND EXISTS (
        SELECT 1 FROM conversations 
        WHERE conversations.id = messages.conversation_id 
        AND conversations.couple_id = auth.uid()
      ))
      OR
      (messages.sender_type = 'vendor' AND EXISTS (
        SELECT 1 FROM conversations 
        WHERE conversations.id = messages.conversation_id 
        AND conversations.vendor_id = auth.uid()
      ))
    )
  );

CREATE POLICY "Users can update their own messages" ON messages
  FOR UPDATE USING (sender_id = auth.uid())
  WITH CHECK (sender_id = auth.uid());

-- Also update conversations RLS policies
DROP POLICY IF EXISTS "Users can view their own conversations" ON conversations;
DROP POLICY IF EXISTS "Users can insert conversations they participate in" ON conversations;
DROP POLICY IF EXISTS "Users can update their own conversations" ON conversations;

CREATE POLICY "Users can view their own conversations" ON conversations
  FOR SELECT USING (couple_id = auth.uid() OR vendor_id = auth.uid());

CREATE POLICY "Users can insert conversations they participate in" ON conversations
  FOR INSERT WITH CHECK (couple_id = auth.uid() OR vendor_id = auth.uid());

CREATE POLICY "Users can update their own conversations" ON conversations
  FOR UPDATE USING (couple_id = auth.uid() OR vendor_id = auth.uid())
  WITH CHECK (couple_id = auth.uid() OR vendor_id = auth.uid());



