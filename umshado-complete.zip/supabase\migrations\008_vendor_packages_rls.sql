-- 008_vendor_packages_rls.sql
BEGIN;

ALTER TABLE vendor_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE package_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE package_addons ENABLE ROW LEVEL SECURITY;
ALTER TABLE package_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE package_availability ENABLE ROW LEVEL SECURITY;
ALTER TABLE package_bookings ENABLE ROW LEVEL SECURITY;

-- Public read access for marketplace
CREATE POLICY IF NOT EXISTS "public_can_read_vendor_packages" ON vendor_packages
  FOR SELECT USING (true);

-- Vendors manage their own packages
CREATE POLICY IF NOT EXISTS "vendor_manage_packages" ON vendor_packages
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM vendor_profiles vp
      WHERE vp.id = vendor_packages.vendor_id
        AND vp.user_id = auth.uid()
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM vendor_profiles vp
      WHERE vp.id = vendor_packages.vendor_id
        AND vp.user_id = auth.uid()
    )
  );

-- Insert restriction (vendor must own vendor_id)
CREATE POLICY IF NOT EXISTS "vendor_insert_packages" ON vendor_packages
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM vendor_profiles vp
      WHERE vp.id = vendor_packages.vendor_id
        AND vp.user_id = auth.uid()
    )
  );

-- package_items: vendor ownership via package
CREATE POLICY IF NOT EXISTS "vendor_manage_package_items" ON package_items
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM vendor_packages vpkg JOIN vendor_profiles vp ON vpkg.vendor_id = vp.id
      WHERE vpkg.id = package_items.package_id
        AND vp.user_id = auth.uid()
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM vendor_packages vpkg JOIN vendor_profiles vp ON vpkg.vendor_id = vp.id
      WHERE vpkg.id = package_items.package_id
        AND vp.user_id = auth.uid()
    )
  );

-- package_addons: vendor ownership via package
CREATE POLICY IF NOT EXISTS "vendor_manage_package_addons" ON package_addons
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM vendor_packages vpkg JOIN vendor_profiles vp ON vpkg.vendor_id = vp.id
      WHERE vpkg.id = package_addons.package_id
        AND vp.user_id = auth.uid()
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM vendor_packages vpkg JOIN vendor_profiles vp ON vpkg.vendor_id = vp.id
      WHERE vpkg.id = package_addons.package_id
        AND vp.user_id = auth.uid()
    )
  );

-- package_images: vendor ownership via package
CREATE POLICY IF NOT EXISTS "vendor_manage_package_images" ON package_images
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM vendor_packages vpkg JOIN vendor_profiles vp ON vpkg.vendor_id = vp.id
      WHERE vpkg.id = package_images.package_id
        AND vp.user_id = auth.uid()
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM vendor_packages vpkg JOIN vendor_profiles vp ON vpkg.vendor_id = vp.id
      WHERE vpkg.id = package_images.package_id
        AND vp.user_id = auth.uid()
    )
  );

-- package_availability: vendor ownership via package
CREATE POLICY IF NOT EXISTS "vendor_manage_package_availability" ON package_availability
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM vendor_packages vpkg JOIN vendor_profiles vp ON vpkg.vendor_id = vp.id
      WHERE vpkg.id = package_availability.package_id
        AND vp.user_id = auth.uid()
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM vendor_packages vpkg JOIN vendor_profiles vp ON vpkg.vendor_id = vp.id
      WHERE vpkg.id = package_availability.package_id
        AND vp.user_id = auth.uid()
    )
  );

-- bookings: couples can insert for themselves; vendors can read bookings for their packages
CREATE POLICY IF NOT EXISTS "couple_insert_bookings" ON package_bookings
  FOR INSERT WITH CHECK (auth.uid() = couple_user_id);

CREATE POLICY IF NOT EXISTS "vendor_read_bookings" ON package_bookings
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM vendor_packages vpkg JOIN vendor_profiles vp ON vpkg.vendor_id = vp.id
      WHERE vpkg.id = package_bookings.package_id
        AND vp.user_id = auth.uid()
    )
  );

CREATE POLICY IF NOT EXISTS "couple_read_own_bookings" ON package_bookings
  FOR SELECT USING (package_bookings.couple_user_id = auth.uid());

-- Vendors can update booking status for their packages
CREATE POLICY IF NOT EXISTS "vendor_update_booking_status" ON package_bookings
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM vendor_packages vpkg JOIN vendor_profiles vp ON vpkg.vendor_id = vp.id
      WHERE vpkg.id = package_bookings.package_id
        AND vp.user_id = auth.uid()
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM vendor_packages vpkg JOIN vendor_profiles vp ON vpkg.vendor_id = vp.id
      WHERE vpkg.id = package_bookings.package_id
        AND vp.user_id = auth.uid()
    )
  );

COMMIT;
