-- Budget Tracker: budget items and expenses
-- budget item (planned vs actual via expense rows)
create table if not exists public.budget_item (
  id uuid primary key default gen_random_uuid(),
  wedding_id uuid not null references public.wedding(id) on delete cascade,
  category text not null,         -- e.g. Venue, Catering, Dress
  name text not null,             -- item label
  planned numeric(12,2) not null default 0,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- expenses linked to item
create table if not exists public.expense (
  id uuid primary key default gen_random_uuid(),
  wedding_id uuid not null references public.wedding(id) on delete cascade,
  item_id uuid not null references public.budget_item(id) on delete cascade,
  amount numeric(12,2) not null check (amount >= 0),
  vendor text,
  paid_on date,
  method text, -- Cash/Card/Transfer
  memo text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Create indexes for efficient queries
create index if not exists budget_item_wedding_idx on public.budget_item(wedding_id);
create index if not exists expense_wedding_idx on public.expense(wedding_id);
create index if not exists expense_item_idx on public.expense(item_id);

-- Enable RLS
alter table public.budget_item enable row level security;
alter table public.expense enable row level security;

-- RLS policies: only wedding owner can access budget data
create policy "select own budget items"
  on public.budget_item for select
  using (exists (select 1 from public.wedding w where w.id = wedding_id and w.owner_id = auth.uid()));

create policy "insert own budget items"
  on public.budget_item for insert
  with check (exists (select 1 from public.wedding w where w.id = wedding_id and w.owner_id = auth.uid()));

create policy "update own budget items"
  on public.budget_item for update
  using (exists (select 1 from public.wedding w where w.id = wedding_id and w.owner_id = auth.uid()));

create policy "delete own budget items"
  on public.budget_item for delete
  using (exists (select 1 from public.wedding w where w.id = wedding_id and w.owner_id = auth.uid()));

create policy "select own expenses"
  on public.expense for select
  using (exists (select 1 from public.wedding w where w.id = wedding_id and w.owner_id = auth.uid()));

create policy "insert own expenses"
  on public.expense for insert
  with check (exists (select 1 from public.wedding w where w.id = wedding_id and w.owner_id = auth.uid()));

create policy "update own expenses"
  on public.expense for update
  using (exists (select 1 from public.wedding w where w.id = wedding_id and w.owner_id = auth.uid()));

create policy "delete own expenses"
  on public.expense for delete
  using (exists (select 1 from public.wedding w where w.id = wedding_id and w.owner_id = auth.uid()));

-- Updated_at triggers
create or replace function set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_budget_item_updated on public.budget_item;
create trigger trg_budget_item_updated before update on public.budget_item
for each row execute function set_updated_at();

drop trigger if exists trg_expense_updated on public.expense;
create trigger trg_expense_updated before update on public.expense
for each row execute function set_updated_at();




