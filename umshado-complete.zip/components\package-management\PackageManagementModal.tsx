import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Switch,
  ActivityIndicator,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { supabase } from '@/lib/supabase';
import {
  Package,
  PackageItem,
  PackageAddon,
  PackageImage,
  createPackage,
  updatePackage,
} from '@/lib/package-service';

const colors = {
  background: '#f0fbea',
  primary: '#00a86b',
  text: '#1A1A1A',
  textLight: '#6B7280',
  border: '#E5E7EB',
  success: '#10B981',
  error: '#EF4444',
  warning: '#F59E0B',
  white: '#FFFFFF',
  headerBg: '#F8FAFC',
  headerText: '#1E293B',
  cardShadow: 'rgba(0, 0, 0, 0.1)',
  accent: '#F3F4F6',
};

interface PackageManagementModalProps {
  visible: boolean;
  package: Package | null;
  onClose: () => void;
  onPackageUpdated: (updatedPackage: Package) => void;
}

export default function PackageManagementModal({
  visible,
  package: pkg,
  onClose,
  onPackageUpdated,
}: PackageManagementModalProps) {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'items' | 'addons' | 'images'>('details');
  
  // Package details state
  const [packageName, setPackageName] = useState('');
  const [shortDescription, setShortDescription] = useState('');
  const [longDescription, setLongDescription] = useState('');
  const [priceType, setPriceType] = useState<'fixed' | 'range' | 'hourly' | 'per_person'>('fixed');
  const [priceMin, setPriceMin] = useState('');
  const [priceMax, setPriceMax] = useState('');
  const [currency, setCurrency] = useState('ZAR');
  const [durationHours, setDurationHours] = useState('');
  const [hasAvailability, setHasAvailability] = useState(false);
  const [isActive, setIsActive] = useState(true);

  // Items state
  const [items, setItems] = useState<PackageItem[]>([]);
  const [newItemName, setNewItemName] = useState('');
  const [newItemDescription, setNewItemDescription] = useState('');
  const [newItemQuantity, setNewItemQuantity] = useState('1');

  // Addons state
  const [addons, setAddons] = useState<PackageAddon[]>([]);
  const [newAddonTitle, setNewAddonTitle] = useState('');
  const [newAddonDescription, setNewAddonDescription] = useState('');
  const [newAddonPrice, setNewAddonPrice] = useState('');
  const [newAddonPriceType, setNewAddonPriceType] = useState<'fixed' | 'per_person' | 'hourly'>('fixed');

  // Images state
  const [images, setImages] = useState<PackageImage[]>([]);

  useEffect(() => {
    if (pkg) {
      // Initialize form with package data
      setPackageName(pkg.package_name);
      setShortDescription(pkg.short_description || '');
      setLongDescription(pkg.long_description || '');
      setPriceType(pkg.price_type);
      setPriceMin(pkg.price_min?.toString() || '');
      setPriceMax(pkg.price_max?.toString() || '');
      setCurrency(pkg.currency);
      setDurationHours(pkg.duration_hours?.toString() || '');
      setHasAvailability(pkg.has_availability);
      setIsActive(pkg.is_active);
      
      // Initialize related data
      setItems(pkg.package_items || []);
      setAddons(pkg.package_addons || []);
      setImages(pkg.package_images || []);
    } else {
      // Reset form for new package
      setPackageName('');
      setShortDescription('');
      setLongDescription('');
      setPriceType('fixed');
      setPriceMin('');
      setPriceMax('');
      setCurrency('ZAR');
      setDurationHours('');
      setHasAvailability(false);
      setIsActive(true);
      setItems([]);
      setAddons([]);
      setImages([]);
    }
  }, [pkg]);

  const handleSavePackage = async () => {
    if (!packageName.trim()) {
      Alert.alert('Error', 'Please enter a package name');
      return;
    }

    try {
      setLoading(true);
      
      if (pkg) {
        // Update existing package
        const updatedPackage = await updatePackage({
          id: pkg.id,
          package_name: packageName.trim(),
          short_description: shortDescription.trim() || undefined,
          long_description: longDescription.trim() || undefined,
          price_type: priceType,
          price_min: priceMin ? parseFloat(priceMin) : undefined,
          price_max: priceMax ? parseFloat(priceMax) : undefined,
          currency: currency,
          duration_hours: durationHours ? parseFloat(durationHours) : undefined,
          has_availability: hasAvailability,
          is_active: isActive,
        });

        onPackageUpdated(updatedPackage);
        Alert.alert('Success', 'Package updated successfully!');
      } else {
        // Create new package
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          Alert.alert('Error', 'Please sign in to create packages');
          return;
        }

        // Get vendor profile
        const { data: vendorProfile } = await supabase
          .from('vendor_profiles')
          .select('id')
          .eq('user_id', user.id)
          .single();

        if (!vendorProfile) {
          Alert.alert('Error', 'Vendor profile not found');
          return;
        }

        const newPackage = await createPackage(vendorProfile.id, {
          package_name: packageName.trim(),
          short_description: shortDescription.trim() || undefined,
          long_description: longDescription.trim() || undefined,
          price_type: priceType,
          price_min: priceMin ? parseFloat(priceMin) : undefined,
          price_max: priceMax ? parseFloat(priceMax) : undefined,
          currency: currency,
          duration_hours: durationHours ? parseFloat(durationHours) : undefined,
          has_availability: hasAvailability,
          is_active: isActive,
        });

        onPackageUpdated(newPackage);
        Alert.alert('Success', 'Package created successfully!');
      }
    } catch (error) {
      console.error('Error saving package:', error);
      Alert.alert('Error', `Failed to ${pkg ? 'update' : 'create'} package`);
    } finally {
      setLoading(false);
    }
  };

  const handleAddItem = async () => {
    if (!pkg || !newItemName.trim()) {
      Alert.alert('Error', 'Please enter an item name');
      return;
    }

    try {
      setLoading(true);
      
      // Temporarily disabled - package_items table doesn't exist yet
      // const newItem = await addPackageItem(pkg.id, {
      //   item_name: newItemName.trim(),
      //   item_description: newItemDescription.trim() || undefined,
      //   quantity: parseInt(newItemQuantity) || 1,
      //   order_index: items.length,
      // });

      // For now, just add to local state
      const newItem: PackageItem = {
        id: `temp-${Date.now()}`,
        package_id: pkg?.id || 'temp',
        item_name: newItemName.trim(),
        item_description: newItemDescription.trim() || undefined,
        quantity: parseInt(newItemQuantity) || 1,
        order_index: items.length,
        created_at: new Date().toISOString(),
      };
      setItems([...items, newItem]);
      setNewItemName('');
      setNewItemDescription('');
      setNewItemQuantity('1');
    } catch (error) {
      console.error('Error adding item:', error);
      Alert.alert('Error', 'Failed to add item');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteItem = async (itemId: string) => {
    Alert.alert(
      'Delete Item',
      'Are you sure you want to delete this item?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              setLoading(true);
              // Temporarily disabled - package_items table doesn't exist yet
              // await deletePackageItem(itemId);
              setItems(items.filter(item => item.id !== itemId));
            } catch (error) {
              console.error('Error deleting item:', error);
              Alert.alert('Error', 'Failed to delete item');
            } finally {
              setLoading(false);
            }
          },
        },
      ]
    );
  };

  const handleAddAddon = async () => {
    if (!pkg || !newAddonTitle.trim() || !newAddonPrice.trim()) {
      Alert.alert('Error', 'Please enter addon title and price');
      return;
    }

    try {
      setLoading(true);
      
      // Temporarily disabled - package_addons table doesn't exist yet
      // const newAddon = await addPackageAddon(pkg.id, {
      //   title: newAddonTitle.trim(),
      //   description: newAddonDescription.trim() || undefined,
      //   price: parseFloat(newAddonPrice),
      //   price_type: newAddonPriceType,
      //   is_active: true,
      // });

      // For now, just add to local state
      const newAddon: PackageAddon = {
        id: `temp-${Date.now()}`,
        package_id: pkg?.id || 'temp',
        title: newAddonTitle.trim(),
        description: newAddonDescription.trim() || undefined,
        price: parseFloat(newAddonPrice),
        price_type: newAddonPriceType,
        is_active: true,
        created_at: new Date().toISOString(),
      };
      setAddons([...addons, newAddon]);
      setNewAddonTitle('');
      setNewAddonDescription('');
      setNewAddonPrice('');
      setNewAddonPriceType('fixed');
    } catch (error) {
      console.error('Error adding addon:', error);
      Alert.alert('Error', 'Failed to add addon');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAddon = async (addonId: string) => {
    Alert.alert(
      'Delete Addon',
      'Are you sure you want to delete this addon?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              setLoading(true);
              // Temporarily disabled - package_addons table doesn't exist yet
              // await deletePackageAddon(addonId);
              setAddons(addons.filter(addon => addon.id !== addonId));
            } catch (error) {
              console.error('Error deleting addon:', error);
              Alert.alert('Error', 'Failed to delete addon');
            } finally {
              setLoading(false);
            }
          },
        },
      ]
    );
  };

  const renderTabButton = (tab: typeof activeTab, label: string, icon: string) => (
    <TouchableOpacity
      style={[styles.tabButton, activeTab === tab && styles.activeTabButton]}
      onPress={() => setActiveTab(tab)}
    >
      <Feather name={icon as any} size={16} color={activeTab === tab ? colors.white : colors.textLight} />
      <Text style={[styles.tabButtonText, activeTab === tab && styles.activeTabButtonText]}>
        {label}
      </Text>
    </TouchableOpacity>
  );

  const renderDetailsTab = () => (
    <ScrollView style={styles.tabContent}>
      <View style={styles.inputGroup}>
        <Text style={styles.inputLabel}>Package Name *</Text>
        <TextInput
          style={styles.textInput}
          value={packageName}
          onChangeText={setPackageName}
          placeholder="Enter package name"
          placeholderTextColor={colors.textLight}
        />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.inputLabel}>Short Description</Text>
        <TextInput
          style={[styles.textInput, styles.textArea]}
          value={shortDescription}
          onChangeText={setShortDescription}
          placeholder="Brief description for listings"
          placeholderTextColor={colors.textLight}
          multiline
          numberOfLines={3}
        />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.inputLabel}>Long Description</Text>
        <TextInput
          style={[styles.textInput, styles.textArea]}
          value={longDescription}
          onChangeText={setLongDescription}
          placeholder="Detailed description"
          placeholderTextColor={colors.textLight}
          multiline
          numberOfLines={5}
        />
      </View>

      <View style={styles.inputRow}>
        <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
          <Text style={styles.inputLabel}>Price Type</Text>
          <TouchableOpacity
            style={styles.pickerButton}
            onPress={() => {
              Alert.alert(
                'Select Price Type',
                'Choose how this package is priced',
                [
                  { text: 'Fixed', onPress: () => setPriceType('fixed') },
                  { text: 'Range', onPress: () => setPriceType('range') },
                  { text: 'Per Person', onPress: () => setPriceType('per_person') },
                  { text: 'Hourly', onPress: () => setPriceType('hourly') },
                ]
              );
            }}
          >
            <Text style={styles.pickerButtonText}>
              {priceType.charAt(0).toUpperCase() + priceType.slice(1).replace('_', ' ')}
            </Text>
            <Feather name="chevron-down" size={16} color={colors.textLight} />
          </TouchableOpacity>
        </View>
        <View style={[styles.inputGroup, { flex: 1, marginLeft: 8 }]}>
          <Text style={styles.inputLabel}>Currency</Text>
          <TextInput
            style={styles.textInput}
            value={currency}
            onChangeText={setCurrency}
            placeholder="ZAR"
            placeholderTextColor={colors.textLight}
          />
        </View>
      </View>

      <View style={styles.inputRow}>
        <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
          <Text style={styles.inputLabel}>Min Price</Text>
          <TextInput
            style={styles.textInput}
            value={priceMin}
            onChangeText={setPriceMin}
            placeholder="0"
            placeholderTextColor={colors.textLight}
            keyboardType="numeric"
          />
        </View>
        {priceType === 'range' && (
          <View style={[styles.inputGroup, { flex: 1, marginLeft: 8 }]}>
            <Text style={styles.inputLabel}>Max Price</Text>
            <TextInput
              style={styles.textInput}
              value={priceMax}
              onChangeText={setPriceMax}
              placeholder="0"
              placeholderTextColor={colors.textLight}
              keyboardType="numeric"
            />
          </View>
        )}
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.inputLabel}>Duration (Hours)</Text>
        <TextInput
          style={styles.textInput}
          value={durationHours}
          onChangeText={setDurationHours}
          placeholder="e.g., 2.5"
          placeholderTextColor={colors.textLight}
          keyboardType="numeric"
        />
      </View>

      <View style={styles.switchGroup}>
        <View style={styles.switchItem}>
          <Text style={styles.switchLabel}>Has Availability</Text>
          <Switch
            value={hasAvailability}
            onValueChange={setHasAvailability}
            trackColor={{ false: colors.border, true: colors.primary }}
            thumbColor={hasAvailability ? colors.white : colors.textLight}
          />
        </View>
        <View style={styles.switchItem}>
          <Text style={styles.switchLabel}>Active</Text>
          <Switch
            value={isActive}
            onValueChange={setIsActive}
            trackColor={{ false: colors.border, true: colors.primary }}
            thumbColor={isActive ? colors.white : colors.textLight}
          />
        </View>
      </View>
    </ScrollView>
  );

  const renderItemsTab = () => (
    <ScrollView style={styles.tabContent}>
      {/* Add new item */}
      <View style={styles.addSection}>
        <Text style={styles.sectionTitle}>Add New Item</Text>
        <View style={styles.inputGroup}>
          <Text style={styles.inputLabel}>Item Name *</Text>
          <TextInput
            style={styles.textInput}
            value={newItemName}
            onChangeText={setNewItemName}
            placeholder="Enter item name"
            placeholderTextColor={colors.textLight}
          />
        </View>
        <View style={styles.inputGroup}>
          <Text style={styles.inputLabel}>Description</Text>
          <TextInput
            style={[styles.textInput, styles.textArea]}
            value={newItemDescription}
            onChangeText={setNewItemDescription}
            placeholder="Item description"
            placeholderTextColor={colors.textLight}
            multiline
            numberOfLines={2}
          />
        </View>
        <View style={styles.inputGroup}>
          <Text style={styles.inputLabel}>Quantity</Text>
          <TextInput
            style={styles.textInput}
            value={newItemQuantity}
            onChangeText={setNewItemQuantity}
            placeholder="1"
            placeholderTextColor={colors.textLight}
            keyboardType="numeric"
          />
        </View>
        <TouchableOpacity style={styles.addButton} onPress={handleAddItem}>
          <Feather name="plus" size={16} color={colors.white} />
          <Text style={styles.addButtonText}>Add Item</Text>
        </TouchableOpacity>
      </View>

      {/* Existing items */}
      <View style={styles.listSection}>
        <Text style={styles.sectionTitle}>Package Items ({items.length})</Text>
        {items.map((item, index) => {
          console.log('Rendering item:', item, 'index:', index, 'id:', item.id);
          return (
            <View key={item.id || `item-${index}`} style={styles.listItem}>
            <View style={styles.listItemContent}>
              <Text style={styles.listItemTitle}>{item.item_name}</Text>
              {item.item_description && (
                <Text style={styles.listItemDescription}>{item.item_description}</Text>
              )}
              <Text style={styles.listItemMeta}>Quantity: {item.quantity}</Text>
            </View>
            <TouchableOpacity
              style={styles.deleteButton}
              onPress={() => handleDeleteItem(item.id)}
            >
              <Feather name="trash-2" size={16} color={colors.error} />
            </TouchableOpacity>
          </View>
          );
        })}
        {items.length === 0 && (
          <Text style={styles.emptyText}>No items added yet</Text>
        )}
      </View>
    </ScrollView>
  );

  const renderAddonsTab = () => (
    <ScrollView style={styles.tabContent}>
      {/* Add new addon */}
      <View style={styles.addSection}>
        <Text style={styles.sectionTitle}>Add New Addon</Text>
        <View style={styles.inputGroup}>
          <Text style={styles.inputLabel}>Addon Title *</Text>
          <TextInput
            style={styles.textInput}
            value={newAddonTitle}
            onChangeText={setNewAddonTitle}
            placeholder="Enter addon title"
            placeholderTextColor={colors.textLight}
          />
        </View>
        <View style={styles.inputGroup}>
          <Text style={styles.inputLabel}>Description</Text>
          <TextInput
            style={[styles.textInput, styles.textArea]}
            value={newAddonDescription}
            onChangeText={setNewAddonDescription}
            placeholder="Addon description"
            placeholderTextColor={colors.textLight}
            multiline
            numberOfLines={2}
          />
        </View>
        <View style={styles.inputRow}>
          <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
            <Text style={styles.inputLabel}>Price *</Text>
            <TextInput
              style={styles.textInput}
              value={newAddonPrice}
              onChangeText={setNewAddonPrice}
              placeholder="0"
              placeholderTextColor={colors.textLight}
              keyboardType="numeric"
            />
          </View>
          <View style={[styles.inputGroup, { flex: 1, marginLeft: 8 }]}>
            <Text style={styles.inputLabel}>Price Type</Text>
            <TouchableOpacity
              style={styles.pickerButton}
              onPress={() => {
                Alert.alert(
                  'Select Price Type',
                  'Choose how this addon is priced',
                  [
                    { text: 'Fixed', onPress: () => setNewAddonPriceType('fixed') },
                    { text: 'Per Person', onPress: () => setNewAddonPriceType('per_person') },
                    { text: 'Hourly', onPress: () => setNewAddonPriceType('hourly') },
                  ]
                );
              }}
            >
              <Text style={styles.pickerButtonText}>
                {newAddonPriceType.charAt(0).toUpperCase() + newAddonPriceType.slice(1).replace('_', ' ')}
              </Text>
              <Feather name="chevron-down" size={16} color={colors.textLight} />
            </TouchableOpacity>
          </View>
        </View>
        <TouchableOpacity style={styles.addButton} onPress={handleAddAddon}>
          <Feather name="plus" size={16} color={colors.white} />
          <Text style={styles.addButtonText}>Add Addon</Text>
        </TouchableOpacity>
      </View>

      {/* Existing addons */}
      <View style={styles.listSection}>
        <Text style={styles.sectionTitle}>Package Addons ({addons.length})</Text>
        {addons.map((addon, index) => {
          console.log('Rendering addon:', addon, 'index:', index, 'id:', addon.id);
          return (
            <View key={addon.id || `addon-${index}`} style={styles.listItem}>
            <View style={styles.listItemContent}>
              <Text style={styles.listItemTitle}>{addon.title}</Text>
              {addon.description && (
                <Text style={styles.listItemDescription}>{addon.description}</Text>
              )}
              <Text style={styles.listItemMeta}>
                {currency}{addon.price} ({addon.price_type.replace('_', ' ')})
              </Text>
            </View>
            <TouchableOpacity
              style={styles.deleteButton}
              onPress={() => handleDeleteAddon(addon.id)}
            >
              <Feather name="trash-2" size={16} color={colors.error} />
            </TouchableOpacity>
          </View>
          );
        })}
        {addons.length === 0 && (
          <Text style={styles.emptyText}>No addons added yet</Text>
        )}
      </View>
    </ScrollView>
  );

  const renderImagesTab = () => (
    <ScrollView style={styles.tabContent}>
      <View style={styles.addSection}>
        <Text style={styles.sectionTitle}>Package Images ({images.length})</Text>
        <Text style={styles.sectionDescription}>
          Image management functionality will be added in a future update.
        </Text>
      </View>
    </ScrollView>
  );

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>{pkg ? 'Edit Package' : 'Create Package'}</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Feather name="x" size={24} color={colors.text} />
            </TouchableOpacity>
          </View>

          {/* Tabs */}
          <View style={styles.tabsContainer}>
            {renderTabButton('details', 'Details', 'edit-3')}
            {renderTabButton('items', 'Items', 'list')}
            {renderTabButton('addons', 'Addons', 'plus-circle')}
            {renderTabButton('images', 'Images', 'image')}
          </View>

          {/* Tab Content */}
          {activeTab === 'details' && renderDetailsTab()}
          {activeTab === 'items' && renderItemsTab()}
          {activeTab === 'addons' && renderAddonsTab()}
          {activeTab === 'images' && renderImagesTab()}

          {/* Actions */}
          <View style={styles.modalActions}>
            <TouchableOpacity
              style={[styles.modalButton, styles.cancelButton]}
              onPress={onClose}
            >
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.modalButton, styles.saveButton]}
              onPress={handleSavePackage}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator size="small" color={colors.white} />
              ) : (
                <Text style={styles.saveButtonText}>{pkg ? 'Save Changes' : 'Create Package'}</Text>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: colors.white,
    borderRadius: 20,
    width: '100%',
    height: '95%',
    maxHeight: '95%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
  },
  closeButton: {
    padding: 4,
  },
  tabsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  tabButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    marginHorizontal: 4,
    gap: 6,
  },
  activeTabButton: {
    backgroundColor: colors.primary,
  },
  tabButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.textLight,
  },
  activeTabButtonText: {
    color: colors.white,
  },
  tabContent: {
    flex: 1,
    padding: 20,
    maxHeight: 800,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputRow: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 8,
  },
  textInput: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    padding: 12,
    fontSize: 16,
    color: colors.text,
    backgroundColor: colors.white,
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  pickerButton: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    backgroundColor: colors.accent,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  pickerButtonText: {
    fontSize: 16,
    color: colors.text,
    flex: 1,
  },
  switchGroup: {
    marginTop: 16,
  },
  switchItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  switchLabel: {
    fontSize: 16,
    color: colors.text,
    fontWeight: '500',
  },
  addSection: {
    backgroundColor: colors.accent,
    padding: 16,
    borderRadius: 12,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  sectionDescription: {
    fontSize: 14,
    color: colors.textLight,
    marginBottom: 12,
  },
  addButton: {
    backgroundColor: colors.primary,
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  addButtonText: {
    color: colors.white,
    fontSize: 14,
    fontWeight: '600',
  },
  listSection: {
    marginBottom: 20,
  },
  listItem: {
    backgroundColor: colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  listItemContent: {
    flex: 1,
  },
  listItemTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  listItemDescription: {
    fontSize: 14,
    color: colors.textLight,
    marginBottom: 4,
  },
  listItemMeta: {
    fontSize: 12,
    color: colors.textLight,
  },
  deleteButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: colors.accent,
  },
  emptyText: {
    fontSize: 14,
    color: colors.textLight,
    textAlign: 'center',
    paddingVertical: 20,
    fontStyle: 'italic',
  },
  modalActions: {
    flexDirection: 'row',
    padding: 20,
    gap: 12,
  },
  modalButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: colors.accent,
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textLight,
  },
  saveButton: {
    backgroundColor: colors.primary,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.white,
  },
});
