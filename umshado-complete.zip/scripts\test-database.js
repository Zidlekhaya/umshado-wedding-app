// Test database connection and create test data
const { createClient } = require('@supabase/supabase-js');

// You'll need to add your Supabase URL and anon key here
const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL || 'YOUR_SUPABASE_URL';
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || 'YOUR_SUPABASE_ANON_KEY';

const supabase = createClient(supabaseUrl, supabaseKey);

async function testDatabase() {
  try {
    console.log('🔍 Testing database connection...');
    
    // Test 1: Check if we can connect
    const { data: testData, error: testError } = await supabase
      .from('wedding')
      .select('count')
      .limit(1);
    
    if (testError) {
      console.error('❌ Database connection failed:', testError);
      return;
    }
    
    console.log('✅ Database connection successful');
    
    // Test 2: Check vendor_profile table
    const { data: vendorData, error: vendorError } = await supabase
      .from('vendor_profile')
      .select('count')
      .limit(1);
    
    if (vendorError) {
      console.error('❌ Vendor profile table error:', vendorError);
      return;
    }
    
    console.log('✅ Vendor profile table accessible');
    
    // Test 3: Create test vendor data
    console.log('📝 Creating test vendor data...');
    
    const testVendors = [
      {
        business_name: 'Elegant Photography',
        category: 'Photography',
        business_description: 'Professional wedding photography with a creative touch',
        city: 'Cape Town',
        phone: '+27 21 123 4567',
        email: 'info@elegantphoto.co.za',
        website: 'https://elegantphoto.co.za',
        instagram: '@elegantphoto',
        price_range: '$1500-$3000',
        years_experience: 8,
        is_active: true,
        is_featured: true,
        rating_average: 4.8,
        review_count: 24
      },
      {
        business_name: 'Dream Venues',
        category: 'Venue',
        business_description: 'Beautiful wedding venues in stunning locations',
        city: 'Johannesburg',
        phone: '+27 11 987 6543',
        email: 'bookings@dreamvenues.co.za',
        website: 'https://dreamvenues.co.za',
        facebook: 'DreamVenuesSA',
        price_range: '$5000-$15000',
        years_experience: 12,
        is_active: true,
        is_featured: true,
        rating_average: 4.9,
        review_count: 156
      },
      {
        business_name: 'Flower Power',
        category: 'Florist',
        business_description: 'Exquisite floral arrangements for your special day',
        city: 'Durban',
        phone: '+27 31 555 1234',
        email: 'hello@flowerpower.co.za',
        instagram: '@flowerpower_durban',
        price_range: '$800-$2500',
        years_experience: 6,
        is_active: true,
        is_featured: false,
        rating_average: 4.6,
        review_count: 18
      }
    ];
    
    const { data: insertedVendors, error: insertError } = await supabase
      .from('vendor_profile')
      .insert(testVendors)
      .select();
    
    if (insertError) {
      console.error('❌ Error inserting test vendors:', insertError);
      return;
    }
    
    console.log('✅ Test vendors created successfully:', insertedVendors.length);
    
    // Test 4: Verify data can be retrieved
    const { data: allVendors, error: fetchError } = await supabase
      .from('vendor_profile')
      .select('*')
      .eq('is_active', true);
    
    if (fetchError) {
      console.error('❌ Error fetching vendors:', fetchError);
      return;
    }
    
    console.log('✅ Successfully fetched', allVendors.length, 'active vendors');
    console.log('📊 Sample vendor data:');
    allVendors.slice(0, 2).forEach(vendor => {
      console.log(`  - ${vendor.business_name} (${vendor.category}) - ${vendor.city}`);
    });
    
    console.log('\n🎉 Database test completed successfully!');
    console.log('📋 Next steps:');
    console.log('1. Test the app with real data');
    console.log('2. Create test user accounts');
    console.log('3. Test vendor login flow');
    
  } catch (error) {
    console.error('❌ Unexpected error:', error);
  }
}

testDatabase();










