// Test guest creation functionality
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL || 'YOUR_SUPABASE_URL';
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || 'YOUR_SUPABASE_ANON_KEY';

const supabase = createClient(supabaseUrl, supabaseKey);

async function testGuestCreation() {
  try {
    console.log('🧪 Testing guest creation...\n');
    
    // Test 1: Check if guest table exists
    console.log('1️⃣ Checking guest table...');
    const { data: guestTable, error: tableError } = await supabase
      .from('guest')
      .select('count')
      .limit(1);
    
    if (tableError) {
      console.error('❌ Guest table error:', tableError);
      console.log('💡 The guest table might not exist or have permission issues');
      return;
    }
    
    console.log('✅ Guest table accessible');
    
    // Test 2: Check if we have any weddings
    console.log('2️⃣ Checking for weddings...');
    const { data: weddings, error: weddingError } = await supabase
      .from('wedding')
      .select('id, name')
      .limit(1);
    
    if (weddingError) {
      console.error('❌ Wedding table error:', weddingError);
      return;
    }
    
    if (!weddings || weddings.length === 0) {
      console.log('⚠️ No weddings found. You need to create a wedding first.');
      return;
    }
    
    console.log('✅ Found wedding:', weddings[0].name);
    
    // Test 3: Try to create a test guest
    console.log('3️⃣ Testing guest creation...');
    const testGuest = {
      wedding_id: weddings[0].id,
      full_name: 'Test Guest',
      email: 'test@example.com',
      phone: '+1234567890',
      side: 'both',
      rsvp: 'no_reply',
    };
    
    console.log('Creating guest with data:', testGuest);
    
    const { data: newGuest, error: createError } = await supabase
      .from('guest')
      .insert([testGuest])
      .select()
      .single();
    
    if (createError) {
      console.error('❌ Guest creation failed:', createError);
      console.log('💡 This might be due to:');
      console.log('   - Missing required fields');
      console.log('   - Permission issues');
      console.log('   - Database constraints');
      return;
    }
    
    console.log('✅ Guest created successfully:', newGuest);
    
    // Test 4: Clean up test guest
    console.log('4️⃣ Cleaning up test guest...');
    const { error: deleteError } = await supabase
      .from('guest')
      .delete()
      .eq('id', newGuest.id);
    
    if (deleteError) {
      console.error('⚠️ Failed to delete test guest:', deleteError);
    } else {
      console.log('✅ Test guest cleaned up');
    }
    
    console.log('\n🎉 Guest creation test PASSED!');
    console.log('📋 The contact selector should work properly now.');
    
  } catch (error) {
    console.error('\n❌ Test failed:', error.message);
    console.log('\n🔧 Troubleshooting:');
    console.log('1. Check your Supabase credentials');
    console.log('2. Ensure database migrations have been run');
    console.log('3. Check if you have a wedding created');
    console.log('4. Verify RLS policies allow guest creation');
  }
}

testGuestCreation();










