// components/ai/AITaskGenerator.tsx
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { aiPlanner } from '@/lib/ai-service';
import { createTask } from '@/lib/task-service';
import { useWeddingStore } from '@/stores/wedding';

interface GeneratedTask {
  title: string;
  description: string;
  category: string;
  priority: 'low' | 'medium' | 'high';
  dueDate: string;
  estimatedHours: number;
}

const colors = {
  background: '#f0fbea',
  surface: '#FFFFFF',
  primary: '#00a86b',
  secondary: '#FF6B35',
  text: '#1A1A1A',
  textSecondary: '#6B7280',
  border: '#E5E7EB',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  white: '#FFFFFF',
};

export default function AITaskGenerator() {
  const [generatedTasks, setGeneratedTasks] = useState<GeneratedTask[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasGenerated, setHasGenerated] = useState(false);
  const { currentWedding } = useWeddingStore();

  const generateTasks = async () => {
    if (!currentWedding?.id) {
      Alert.alert('Error', 'No wedding selected');
      return;
    }

    setIsLoading(true);
    try {
      const tasks = await aiPlanner.generateTasks(currentWedding.id);
      setGeneratedTasks(tasks);
      setHasGenerated(true);
    } catch (error) {
      console.error('Task generation error:', error);
      Alert.alert('Error', 'Failed to generate tasks. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const addTaskToWedding = async (task: GeneratedTask) => {
    if (!currentWedding?.id) return;

    try {
      // Calculate due date based on wedding date
      const weddingDate = new Date(currentWedding.date || '');
      const dueDate = new Date(weddingDate.getTime() - (30 * 24 * 60 * 60 * 1000)); // 30 days before

      await createTask({
        wedding_id: currentWedding.id,
        title: task.title,
        description: task.description,
        category: task.category as any,
        priority: task.priority,
        status: 'pending',
        due_date: dueDate.toISOString(),
        estimated_hours: task.estimatedHours,
      });

      Alert.alert('Success', 'Task added to your wedding planning list!');
    } catch (error) {
      console.error('Error adding task:', error);
      Alert.alert('Error', 'Failed to add task. Please try again.');
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return colors.error;
      case 'medium': return colors.warning;
      case 'low': return colors.success;
      default: return colors.textSecondary;
    }
  };

  const getCategoryIcon = (category: string) => {
    const iconMap: Record<string, string> = {
      venue: 'map-pin',
      catering: 'coffee',
      photography: 'camera',
      music: 'music',
      flowers: 'heart',
      decor: 'star',
      transport: 'truck',
      attire: 'user',
      invitations: 'mail',
      general: 'clipboard',
    };
    return iconMap[category] || 'clipboard';
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <View style={styles.aiIcon}>
            <Feather name="check-square" size={20} color={colors.white} />
          </View>
          <View>
            <Text style={styles.headerTitle}>AI Task Generator</Text>
            <Text style={styles.headerSubtitle}>Smart wedding planning tasks</Text>
          </View>
        </View>
        {!hasGenerated && (
          <TouchableOpacity
            onPress={generateTasks}
            style={styles.generateButton}
            disabled={isLoading}
          >
            {isLoading ? (
              <ActivityIndicator size="small" color={colors.white} />
            ) : (
              <Text style={styles.generateButtonText}>Generate</Text>
            )}
          </TouchableOpacity>
        )}
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {!hasGenerated && !isLoading && (
          <View style={styles.welcomeCard}>
            <Feather name="zap" size={48} color={colors.primary} />
            <Text style={styles.welcomeTitle}>Smart Task Generation</Text>
            <Text style={styles.welcomeText}>
              Let AI analyze your wedding details and generate personalized tasks to help you stay organized and on track with your planning.
            </Text>
            <TouchableOpacity
              onPress={generateTasks}
              style={styles.startGenerationButton}
            >
              <Text style={styles.startGenerationButtonText}>Generate Tasks</Text>
              <Feather name="arrow-right" size={16} color={colors.white} />
            </TouchableOpacity>
          </View>
        )}

        {isLoading && (
          <View style={styles.loadingCard}>
            <ActivityIndicator size="large" color={colors.primary} />
            <Text style={styles.loadingText}>Generating tasks...</Text>
            <Text style={styles.loadingSubtext}>
              Analyzing your wedding details
            </Text>
          </View>
        )}

        {generatedTasks.length > 0 && (
          <>
            <View style={styles.resultsHeader}>
              <Text style={styles.resultsTitle}>
                Generated Tasks ({generatedTasks.length})
              </Text>
              <Text style={styles.resultsSubtitle}>
                Tap any task to add it to your wedding planning list
              </Text>
            </View>

            {generatedTasks.map((task, index) => (
              <TouchableOpacity
                key={index}
                style={styles.taskCard}
                onPress={() => addTaskToWedding(task)}
              >
                <View style={styles.taskHeader}>
                  <View style={styles.taskIconContainer}>
                    <Feather
                      name={getCategoryIcon(task.category) as any}
                      size={20}
                      color={colors.primary}
                    />
                  </View>
                  <View style={styles.taskInfo}>
                    <Text style={styles.taskTitle}>{task.title}</Text>
                    <Text style={styles.taskCategory}>
                      {task.category.charAt(0).toUpperCase() + task.category.slice(1)}
                    </Text>
                  </View>
                  <View style={[
                    styles.priorityBadge,
                    { backgroundColor: getPriorityColor(task.priority) }
                  ]}>
                    <Text style={styles.priorityText}>
                      {task.priority.toUpperCase()}
                    </Text>
                  </View>
                </View>

                <Text style={styles.taskDescription}>{task.description}</Text>

                <View style={styles.taskDetails}>
                  <View style={styles.taskDetail}>
                    <Feather name="clock" size={14} color={colors.textSecondary} />
                    <Text style={styles.taskDetailText}>
                      {task.estimatedHours}h estimated
                    </Text>
                  </View>
                  <View style={styles.taskDetail}>
                    <Feather name="calendar" size={14} color={colors.textSecondary} />
                    <Text style={styles.taskDetailText}>
                      Due: {task.dueDate}
                    </Text>
                  </View>
                </View>

                <View style={styles.addTaskButton}>
                  <Feather name="plus" size={16} color={colors.primary} />
                  <Text style={styles.addTaskButtonText}>Add to Wedding Tasks</Text>
                </View>
              </TouchableOpacity>
            ))}

            <View style={styles.actionButtons}>
              <TouchableOpacity
                onPress={generateTasks}
                style={styles.refreshButton}
              >
                <Feather name="refresh-cw" size={16} color={colors.primary} />
                <Text style={styles.refreshButtonText}>Generate More Tasks</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: colors.white,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  aiIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  headerSubtitle: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  generateButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  generateButtonText: {
    color: colors.white,
    fontWeight: '600',
    fontSize: 14,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  welcomeCard: {
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    marginBottom: 20,
  },
  welcomeTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.text,
    marginTop: 16,
    marginBottom: 8,
  },
  welcomeText: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 24,
  },
  startGenerationButton: {
    backgroundColor: colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 25,
  },
  startGenerationButtonText: {
    color: colors.white,
    fontWeight: '600',
    fontSize: 16,
    marginRight: 8,
  },
  loadingCard: {
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: 40,
    alignItems: 'center',
    marginBottom: 20,
  },
  loadingText: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginTop: 16,
    marginBottom: 8,
  },
  loadingSubtext: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  resultsHeader: {
    marginBottom: 20,
  },
  resultsTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  resultsSubtitle: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  taskCard: {
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: colors.border,
  },
  taskHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  taskIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  taskInfo: {
    flex: 1,
  },
  taskTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 2,
  },
  taskCategory: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  priorityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  priorityText: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.white,
  },
  taskDescription: {
    fontSize: 15,
    color: colors.text,
    lineHeight: 22,
    marginBottom: 16,
  },
  taskDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  taskDetail: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  taskDetailText: {
    fontSize: 14,
    color: colors.textSecondary,
    marginLeft: 6,
  },
  addTaskButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: colors.background,
  },
  addTaskButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.primary,
    marginLeft: 8,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  refreshButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  refreshButtonText: {
    color: colors.primary,
    fontWeight: '600',
    fontSize: 16,
    marginLeft: 8,
  },
});
