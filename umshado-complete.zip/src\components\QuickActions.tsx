import React from 'react';
import { View, Pressable, Text, StyleSheet } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { colors, typography, spacing, borderRadius, shadows } from '../theme/design-system';

type Props = {
  onManageGuests: () => void;
  onInvitePartner: () => void;
};

export default function QuickActions({
  onManageGuests,
  onInvitePartner,
}: Props) {
  return (
    <View style={styles.row}>
      <ActionPill
        icon={<Ionicons name="people-outline" size={18} color={colors.primary[500]} />}
        label="Guests"
        onPress={onManageGuests}
      />
      <ActionPill
        icon={<MaterialCommunityIcons name="heart" size={18} color={colors.error[500]} />}
        label="Add partner"
        onPress={onInvitePartner}
      />
    </View>
  );
}

function ActionPill({
  icon,
  label,
  onPress,
  kind = 'ghost',
}: {
  icon: React.ReactNode;
  label: string;
  onPress: () => void;
  kind?: 'ghost' | 'filled';
}) {
  const style = [
    styles.pill,
    kind === 'ghost' && styles.pillGhost,
    kind === 'filled' && styles.pillFilled,
  ];
  const labelStyle = [
    styles.pillLabel,
    kind === 'ghost' && { color: colors.primary[500] },
    kind === 'filled' && { color: colors.text.inverse },
  ];
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [style, pressed && { opacity: 0.85 }]}>
      <View style={styles.icon}>{icon}</View>
      <Text style={labelStyle} numberOfLines={1}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    gap: spacing[3],
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  pill: {
    minHeight: 44,
    flex: 1,
    borderRadius: borderRadius.lg,
    paddingHorizontal: spacing[4],
    paddingVertical: spacing[3],
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    ...shadows.sm,
  },
  pillGhost: {
    backgroundColor: colors.surface.primary,
    borderWidth: 1,
    borderColor: colors.border.primary,
  },
  pillFilled: {
    backgroundColor: colors.secondary[300],
  },
  icon: { marginRight: spacing[2] },
  pillLabel: {
    fontSize: typography.fontSize.sm,
    fontWeight: typography.fontWeight.semibold,
    letterSpacing: 0.2,
    textAlign: 'center',
    flexShrink: 1,
  },
});
