import { createWedding, getCurrentWedding, getWeddings } from '@/lib/wedding-service';
import { supabase } from '@/lib/supabase';

// Mock the supabase client
jest.mock('@/lib/supabase', () => ({
  supabase: {
    from: jest.fn(),
    auth: {
      getUser: jest.fn(),
    },
  },
}));

describe('Wedding Service', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('createWedding', () => {
    it('should create a wedding successfully', async () => {
      const mockWedding = {
        id: 'test-id',
        name: 'Test Wedding',
        date: '2025-12-20',
        city: 'Johannesburg',
        culture: 'Zulu',
        owner_id: 'user-id',
        created_at: '2025-01-01T00:00:00Z',
        updated_at: '2025-01-01T00:00:00Z',
      };

      const mockInsert = jest.fn().mockReturnValue({
        select: jest.fn().mockReturnValue({
          single: jest.fn().mockResolvedValue({
            data: mockWedding,
            error: null,
          }),
        }),
      });

      const mockFrom = jest.fn().mockReturnValue({
        insert: mockInsert,
      });

      (supabase.from as jest.Mock).mockImplementation(mockFrom);
      (supabase.auth.getUser as jest.Mock).mockResolvedValue({
        data: { user: { id: 'user-id' } },
        error: null,
      });

      const result = await createWedding({
        name: 'Test Wedding',
        date: '2025-12-20',
        city: 'Johannesburg',
        culture: 'Zulu',
      });

      expect(result).toEqual(mockWedding);
      expect(mockFrom).toHaveBeenCalledWith('wedding');
      expect(mockInsert).toHaveBeenCalledWith([{
        name: 'Test Wedding',
        date: '2025-12-20',
        location: 'Johannesburg',
        culture: 'Zulu',
        owner_id: 'user-id',
      }]);
    });

    it('should throw error when user is not authenticated', async () => {
      (supabase.auth.getUser as jest.Mock).mockResolvedValue({
        data: { user: null },
        error: null,
      });

      await expect(createWedding({
        name: 'Test Wedding',
        date: '2025-12-20',
        city: 'Johannesburg',
        culture: 'Zulu',
      })).rejects.toThrow('No authenticated user');
    });

    it('should throw error when database insert fails', async () => {
      const mockInsert = jest.fn().mockReturnValue({
        select: jest.fn().mockReturnValue({
          single: jest.fn().mockResolvedValue({
            data: null,
            error: { message: 'Database error' },
          }),
        }),
      });

      const mockFrom = jest.fn().mockReturnValue({
        insert: mockInsert,
      });

      (supabase.from as jest.Mock).mockImplementation(mockFrom);
      (supabase.auth.getUser as jest.Mock).mockResolvedValue({
        data: { user: { id: 'user-id' } },
        error: null,
      });

      await expect(createWedding({
        name: 'Test Wedding',
        date: '2025-12-20',
        city: 'Johannesburg',
        culture: 'Zulu',
      })).rejects.toEqual({ message: 'Database error' });
    });
  });

  describe('getCurrentWedding', () => {
    it('should get current wedding successfully', async () => {
      const mockWedding = {
        id: 'test-id',
        name: 'Test Wedding',
        date: '2025-12-20',
        city: 'Johannesburg',
        culture: 'Zulu',
        owner_id: 'user-id',
      };

      const mockOrder = jest.fn().mockResolvedValue({
        data: [mockWedding],
        error: null,
      });

      const mockEq = jest.fn().mockReturnValue({
        order: mockOrder,
      });

      const mockSelect = jest.fn().mockReturnValue({
        eq: mockEq,
      });

      const mockFrom = jest.fn().mockReturnValue({
        select: mockSelect,
      });

      (supabase.from as jest.Mock).mockImplementation(mockFrom);
      (supabase.auth.getUser as jest.Mock).mockResolvedValue({
        data: { user: { id: 'user-id' } },
        error: null,
      });

      const result = await getCurrentWedding();

      expect(result).toEqual(mockWedding);
      expect(mockFrom).toHaveBeenCalledWith('wedding');
    });

    it('should return null when no wedding found', async () => {
      const mockOrder = jest.fn().mockResolvedValue({
        data: [],
        error: null,
      });

      const mockEq = jest.fn().mockReturnValue({
        order: mockOrder,
      });

      const mockSelect = jest.fn().mockReturnValue({
        eq: mockEq,
      });

      const mockFrom = jest.fn().mockReturnValue({
        select: mockSelect,
      });

      (supabase.from as jest.Mock).mockImplementation(mockFrom);
      (supabase.auth.getUser as jest.Mock).mockResolvedValue({
        data: { user: { id: 'user-id' } },
        error: null,
      });

      const result = await getCurrentWedding();

      expect(result).toBeNull();
    });
  });

  describe('getWeddings', () => {
    it('should get all weddings successfully', async () => {
      const mockWedding = {
        id: 'test-id',
        name: 'Test Wedding',
        date: '2025-12-20',
        city: 'Johannesburg',
        culture: 'Zulu',
        owner_id: 'user-id',
      };

      const mockOrder = jest.fn().mockResolvedValue({
        data: [mockWedding],
        error: null,
      });

      const mockEq = jest.fn().mockReturnValue({
        order: mockOrder,
      });

      const mockSelect = jest.fn().mockReturnValue({
        eq: mockEq,
      });

      const mockFrom = jest.fn().mockReturnValue({
        select: mockSelect,
      });

      (supabase.from as jest.Mock).mockImplementation(mockFrom);
      (supabase.auth.getUser as jest.Mock).mockResolvedValue({
        data: { user: { id: 'user-id' } },
        error: null,
      });

      const result = await getWeddings();

      expect(result).toEqual([mockWedding]);
      expect(mockFrom).toHaveBeenCalledWith('wedding');
    });

    it('should return empty array when no weddings found', async () => {
      const mockOrder = jest.fn().mockResolvedValue({
        data: [],
        error: null,
      });

      const mockEq = jest.fn().mockReturnValue({
        order: mockOrder,
      });

      const mockSelect = jest.fn().mockReturnValue({
        eq: mockEq,
      });

      const mockFrom = jest.fn().mockReturnValue({
        select: mockSelect,
      });

      (supabase.from as jest.Mock).mockImplementation(mockFrom);
      (supabase.auth.getUser as jest.Mock).mockResolvedValue({
        data: { user: { id: 'user-id' } },
        error: null,
      });

      const result = await getWeddings();
      expect(result).toEqual([]);
    });
  });
});


