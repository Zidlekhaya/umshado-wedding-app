// Umshado TypeScript Types
// These types match our database schema

export type UserRole = 'owner' | 'co_owner' | 'viewer';
export type GuestSide = 'Bride' | 'Groom' | 'Both';
export type RSVPStatus = 'Pending' | 'Yes' | 'No' | 'Maybe';
export type TaskStatus = 'Todo' | 'InProgress' | 'Done';
export type TaskPriority = 'Low' | 'Medium' | 'High';
export type VendorStatus = 'Shortlisted' | 'Contacted' | 'Confirmed' | 'Rejected';

export interface AppUser {
  id: string;
  email: string;
  full_name?: string;
  avatar_url?: string;
  created_at: string;
  updated_at: string;
}

export interface Wedding {
  id: string;
  owner_id: string;
  name: string;
  date?: string;
  location?: string;
  culture?: string;
  ceremony_location?: string;
  reception_location?: string;
  city?: string;
  cover_image_url?: string;
  slug: string;
  notes?: string;
  colors: {
    primary: string;
    secondary: string;
  };
  created_at: string;
  updated_at: string;
  deleted_at?: string;
}

export interface WeddingCoOwner {
  wedding_id: string;
  user_id: string;
  role: UserRole;
  created_at: string;
  user?: AppUser; // Populated when joining with app_user
}

export interface Guest {
  id: string;
  wedding_id: string;
  full_name: string;
  email?: string;
  phone?: string;
  side: GuestSide;
  party_size: number;
  dietary?: string;
  table_name?: string;
  tags: string[];
  rsvp_status: RSVPStatus;
  invite_code?: string;
  created_at: string;
  updated_at: string;
}

export interface Task {
  id: string;
  wedding_id: string;
  title: string;
  status: TaskStatus;
  priority: TaskPriority;
  due_date?: string;
  assignee_id?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
  assignee?: AppUser; // Populated when joining with app_user
}

export interface Vendor {
  id: string;
  wedding_id: string;
  name: string;
  category?: string;
  phone?: string;
  email?: string;
  website?: string;
  quote_amount?: number;
  status: VendorStatus;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface BudgetItem {
  id: string;
  wedding_id: string;
  title: string;
  category?: string;
  estimated: number;
  actual: number;
  paid: number;
  due_date?: string;
  vendor_id?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
  vendor?: Vendor; // Populated when joining with vendor
}

export interface TimelineEvent {
  id: string;
  wedding_id: string;
  starts_at: string;
  title: string;
  location?: string;
  responsible_user_id?: string;
  notes?: string;
  order_index: number;
  created_at: string;
  updated_at: string;
  responsible_user?: AppUser; // Populated when joining with app_user
}

export interface WeddingInvite {
  id: string;
  wedding_id: string;
  email: string;
  role: 'guest' | 'partner' | 'planner';
  status: 'pending' | 'accepted' | 'revoked' | 'expired';
  token?: string;
  invited_by?: string;
  created_at: string;
  updated_at: string;
}

// Dashboard summary types
export interface WeddingSummary {
  wedding: Wedding;
  guest_counts: {
    total: number;
    pending: number;
    confirmed: number;
    declined: number;
  };
  task_counts: {
    total: number;
    todo: number;
    in_progress: number;
    done: number;
    overdue: number;
  };
  budget_summary: {
    estimated_total: number;
    actual_total: number;
    paid_total: number;
    outstanding: number;
  };
  upcoming_events: TimelineEvent[];
}

// API Response types
export interface ApiResponse<T> {
  data: T;
  error?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  count: number;
  page: number;
  limit: number;
  has_more: boolean;
}

// Form types
export interface CreateWeddingData {
  name: string;
  date?: string;
  location?: string;
  culture?: string;
  ceremony_location?: string;
  reception_location?: string;
  city?: string;
  cover_image_url?: string;
  notes?: string;
  colors?: {
    primary: string;
    secondary: string;
  };
}

export interface UpdateWeddingData extends Partial<CreateWeddingData> {
  id: string;
}

export interface CreateGuestData {
  name?: string;                    // NOT full_name
  full_name?: string;               // fallback for compatibility
  email?: string;
  phone?: string;
  category?: string;
  side?: GuestSide;
  party_size?: number;
  plus_one?: boolean;               // alternative to party_size
  dietary?: string;                 // fallback for compatibility
  dietary_requirements?: string;    // NOT dietary
  table_name?: string;
  notes?: string;
  tags?: string[];
}

export interface UpdateGuestData extends Partial<CreateGuestData> {
  id: string;
}

export interface CreateTaskData {
  title: string;
  status?: TaskStatus;
  priority?: TaskPriority;
  due_date?: string;
  assignee_id?: string;
  notes?: string;
}

export interface UpdateTaskData extends Partial<CreateTaskData> {
  id: string;
}

export interface CreateVendorData {
  name: string;
  category?: string;
  phone?: string;
  email?: string;
  website?: string;
  quote_amount?: number;
  status?: VendorStatus;
  notes?: string;
}

export interface UpdateVendorData extends Partial<CreateVendorData> {
  id: string;
}

export interface CreateBudgetItemData {
  title: string;
  category?: string;
  estimated?: number;
  actual?: number;
  paid?: number;
  due_date?: string;
  vendor_id?: string;
  notes?: string;
}

export interface UpdateBudgetItemData extends Partial<CreateBudgetItemData> {
  id: string;
}

export interface CreateTimelineEventData {
  starts_at: string;
  title: string;
  location?: string;
  responsible_user_id?: string;
  notes?: string;
  order_index?: number;
}

export interface UpdateTimelineEventData extends Partial<CreateTimelineEventData> {
  id: string;
}

// Filter and search types
export interface GuestFilters {
  search?: string;
  rsvp_status?: RSVPStatus;
  side?: GuestSide;
  tags?: string[];
}

export interface TaskFilters {
  status?: TaskStatus;
  priority?: TaskPriority;
  assignee_id?: string;
  due_date_from?: string;
  due_date_to?: string;
}

export interface VendorFilters {
  category?: string;
  status?: VendorStatus;
  search?: string;
}

// CSV Import/Export types
export interface GuestCSVRow {
  full_name: string;
  email?: string;
  phone?: string;
  side?: GuestSide;
  party_size?: number;
  dietary?: string;
  table_name?: string;
  tags?: string;
}

export interface BudgetCSVRow {
  title: string;
  category?: string;
  estimated?: number;
  actual?: number;
  paid?: number;
  due_date?: string;
  vendor_name?: string;
  notes?: string;
}

