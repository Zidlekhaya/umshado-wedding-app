import React from 'react';
import { render, fireEvent } from '@testing-library/react-native';
import { Button } from '@/components/ui/Button';

describe('Button Component', () => {
  it('renders correctly with default props', () => {
    const { getByText } = render(<Button title="Test Button" onPress={() => {}} />);
    expect(getByText('Test Button')).toBeTruthy();
  });

  it('renders with different variants', () => {
    const { getByText: getPrimary } = render(
      <Button title="Primary" onPress={() => {}} variant="primary" />
    );
    const { getByText: getSecondary } = render(
      <Button title="Secondary" onPress={() => {}} variant="secondary" />
    );
    const { getByText: getOutline } = render(
      <Button title="Outline" onPress={() => {}} variant="outline" />
    );

    expect(getPrimary('Primary')).toBeTruthy();
    expect(getSecondary('Secondary')).toBeTruthy();
    expect(getOutline('Outline')).toBeTruthy();
  });

  it('renders with different sizes', () => {
    const { getByText: getSmall } = render(
      <Button title="Small" onPress={() => {}} size="sm" />
    );
    const { getByText: getMedium } = render(
      <Button title="Medium" onPress={() => {}} size="md" />
    );
    const { getByText: getLarge } = render(
      <Button title="Large" onPress={() => {}} size="lg" />
    );

    expect(getSmall('Small')).toBeTruthy();
    expect(getMedium('Medium')).toBeTruthy();
    expect(getLarge('Large')).toBeTruthy();
  });

  it('calls onPress when pressed', () => {
    const mockOnPress = jest.fn();
    const { getByText } = render(<Button title="Test Button" onPress={mockOnPress} />);
    
    fireEvent.press(getByText('Test Button'));
    expect(mockOnPress).toHaveBeenCalledTimes(1);
  });

  it('shows loading state', () => {
    const { getByText } = render(
      <Button title="Test Button" onPress={() => {}} loading={true} />
    );
    
    // Button should still be rendered but with loading state
    expect(getByText('Test Button')).toBeTruthy();
  });

  it('is disabled when disabled prop is true', () => {
    const mockOnPress = jest.fn();
    const { getByText } = render(
      <Button title="Test Button" onPress={mockOnPress} disabled={true} />
    );
    
    fireEvent.press(getByText('Test Button'));
    expect(mockOnPress).not.toHaveBeenCalled();
  });

  it('does not call onPress when loading', () => {
    const mockOnPress = jest.fn();
    const { getByText } = render(
      <Button title="Test Button" onPress={mockOnPress} loading={true} />
    );
    
    fireEvent.press(getByText('Test Button'));
    expect(mockOnPress).not.toHaveBeenCalled();
  });
});
