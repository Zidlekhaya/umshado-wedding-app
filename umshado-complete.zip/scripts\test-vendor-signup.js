#!/usr/bin/env node

/**
 * Test Vendor Signup Script
 * This script tests the vendor signup process and database setup
 */

const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing Supabase environment variables');
  console.error('Please ensure EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_ANON_KEY are set');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function testVendorSignup() {
  console.log('🧪 Testing Vendor Signup Process...\n');

  try {
    // Test 1: Check if vendor_profiles table exists
    console.log('1️⃣ Checking vendor_profiles table...');
    const { data: tableCheck, error: tableError } = await supabase
      .from('vendor_profiles')
      .select('id')
      .limit(1);

    if (tableError) {
      console.error('❌ vendor_profiles table error:', tableError.message);
      console.log('💡 Run the database migration: supabase/migrations/004_fix_vendor_signup.sql');
      return;
    }

    console.log('✅ vendor_profiles table exists and is accessible');

    // Test 2: Create a test vendor account
    console.log('\n2️⃣ Creating test vendor account...');
    const testEmail = `test-vendor-${Date.now()}@example.com`;
    const testPassword = 'testpassword123';

    const { data: signupData, error: signupError } = await supabase.auth.signUp({
      email: testEmail,
      password: testPassword,
      options: {
        data: {
          user_type: 'vendor',
          business_name: 'Test Photography Studio',
          category: 'photography',
          location: 'Cape Town'
        }
      }
    });

    if (signupError) {
      console.error('❌ Vendor signup error:', signupError.message);
      return;
    }

    console.log('✅ Test vendor account created:', testEmail);

    // Test 3: Check if vendor profile was created automatically
    console.log('\n3️⃣ Checking if vendor profile was created...');
    
    // Wait a moment for the trigger to execute
    await new Promise(resolve => setTimeout(resolve, 2000));

    const { data: profileData, error: profileError } = await supabase
      .from('vendor_profiles')
      .select('*')
      .eq('user_id', signupData.user.id)
      .single();

    if (profileError) {
      console.error('❌ Vendor profile not created:', profileError.message);
      console.log('💡 The trigger function may not be working properly');
      return;
    }

    console.log('✅ Vendor profile created automatically:', profileData.business_name);

    // Test 4: Test vendor sign in
    console.log('\n4️⃣ Testing vendor sign in...');
    
    // Sign out first
    await supabase.auth.signOut();

    const { data: signinData, error: signinError } = await supabase.auth.signInWithPassword({
      email: testEmail,
      password: testPassword
    });

    if (signinError) {
      console.error('❌ Vendor sign in error:', signinError.message);
      return;
    }

    console.log('✅ Vendor sign in successful');
    console.log('   User type:', signinData.user.user_metadata?.user_type);

    // Test 5: Clean up test data
    console.log('\n5️⃣ Cleaning up test data...');
    
    // Delete the vendor profile
    await supabase
      .from('vendor_profiles')
      .delete()
      .eq('user_id', signupData.user.id);

    // Delete the user account
    await supabase.auth.admin.deleteUser(signupData.user.id);

    console.log('✅ Test data cleaned up');

    console.log('\n🎉 All vendor signup tests passed!');
    console.log('\n📋 Summary:');
    console.log('✅ vendor_profiles table exists');
    console.log('✅ Vendor account creation works');
    console.log('✅ Automatic profile creation works');
    console.log('✅ Vendor sign in works');
    console.log('✅ User type is correctly set');

  } catch (error) {
    console.error('❌ Test failed with error:', error.message);
    console.error('Stack trace:', error.stack);
  }
}

// Run the test
testVendorSignup().then(() => {
  console.log('\n✨ Vendor signup test completed');
  process.exit(0);
}).catch((error) => {
  console.error('❌ Test script failed:', error);
  process.exit(1);
});
