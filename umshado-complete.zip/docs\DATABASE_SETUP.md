# Database Setup Instructions

## Messaging Feature Setup

To enable the real-time messaging feature, you need to run the database migration that creates the required tables.

### Steps:

1. **Access your Supabase Dashboard**
   - Go to your Supabase project dashboard
   - Navigate to the SQL Editor

2. **Run the Migration**
   - Copy the contents of `supabase/migrations/001_create_messaging_tables.sql`
   - Paste it into the SQL Editor
   - Click "Run" to execute the migration

3. **Verify Tables Created**
   - Go to the Table Editor in Supabase
   - You should see two new tables:
     - `conversations` - Stores conversation metadata
     - `messages` - Stores individual messages

### What the Migration Creates:

- **conversations table**: Stores conversation metadata, participants, and unread counts
- **messages table**: Stores individual messages with sender information
- **Real-time triggers**: Automatic updates when messages are sent/received
- **Row Level Security**: Ensures users can only access their own conversations
- **Performance indexes**: Optimized for fast message retrieval

### After Setup:

Once the database tables are created, the messaging feature will work automatically:
- Couples can message vendors from the marketplace
- Vendors can receive and respond to messages
- Real-time updates will work seamlessly
- All conversations will be persisted

### Troubleshooting:

If you encounter any issues:
1. Make sure you're running the migration in the correct Supabase project
2. Check that you have the necessary permissions
3. Verify the tables were created successfully in the Table Editor

The messaging feature is fully implemented and ready to use once the database is set up!









