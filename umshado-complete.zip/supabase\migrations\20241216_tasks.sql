-- Create tasks table
CREATE TABLE IF NOT EXISTS public.tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL CHECK (category IN (
    'venue', 'catering', 'photography', 'music', 'flowers', 'decor', 
    'transportation', 'makeup', 'hair', 'attire', 'rings', 'cake', 
    'invitations', 'officiant', 'ceremony', 'reception', 'honeymoon', 'other'
  )),
  priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN (
    'low', 'medium', 'high', 'urgent'
  )),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN (
    'pending', 'in_progress', 'completed', 'cancelled'
  )),
  due_date DATE,
  completed_at TIMESTAMPTZ,
  assigned_to TEXT, -- email or name of person assigned
  estimated_hours DECIMAL(4,1), -- estimated time to complete
  actual_hours DECIMAL(4,1), -- actual time spent
  notes TEXT,
  checklist JSONB, -- array of checklist items
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS tasks_wedding_idx ON public.tasks(wedding_id);
CREATE INDEX IF NOT EXISTS tasks_category_idx ON public.tasks(category);
CREATE INDEX IF NOT EXISTS tasks_status_idx ON public.tasks(status);
CREATE INDEX IF NOT EXISTS tasks_priority_idx ON public.tasks(priority);
CREATE INDEX IF NOT EXISTS tasks_due_date_idx ON public.tasks(due_date);

-- Enable RLS
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "select_own_wedding_tasks" ON public.tasks
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "insert_own_wedding_tasks" ON public.tasks
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "update_own_wedding_tasks" ON public.tasks
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "delete_own_wedding_tasks" ON public.tasks
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_tasks_updated
  BEFORE UPDATE ON public.tasks
  FOR EACH ROW
  EXECUTE FUNCTION set_updated_at();

