import { useState, useEffect } from 'react';
import { View, Text, Alert, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Link, Redirect, router } from 'expo-router';
import { supabase } from '@/lib/supabase';
import type { Session } from '@supabase/supabase-js';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Card } from '@/components/ui/Card';
import { colors, typography, spacing, borderRadius } from '@/src/theme/design-system';
import { Feather } from '@expo/vector-icons';

export default function VendorSignUp() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [category, setCategory] = useState('');
  const [location, setLocation] = useState('');
  const [session, setSession] = useState<Session | null | undefined>(undefined);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => subscription.unsubscribe();
  }, []);

  if (session) return <Redirect href="/(vendor)" />;

  async function handleSignUp() {
    // Validation
    if (!businessName.trim()) {
      Alert.alert('Error', 'Business name is required');
      return;
    }

    if (!category.trim()) {
      Alert.alert('Error', 'Service category is required');
      return;
    }

    if (!email.trim()) {
      Alert.alert('Error', 'Email is required');
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return;
    }

    if (password.length < 6) {
      Alert.alert('Error', 'Password must be at least 6 characters');
      return;
    }

    try {
      setLoading(true);
      
      console.log('Creating vendor account with data:', {
        email,
        business_name: businessName,
        category,
        location
      });

      // First create the user account without vendor metadata
      const { data, error } = await supabase.auth.signUp({ 
        email, 
        password
      });

      if (error) {
        console.error('Vendor signup error:', error);
        throw error;
      }

      console.log('User account created successfully:', data);
      
      // Update user metadata to vendor
      if (data.user) {
        try {
          console.log('Updating user metadata to vendor...');
          const { error: updateError } = await supabase.auth.updateUser({
            data: {
              user_type: 'vendor',
              business_name: businessName.trim(),
              category: category.trim(),
              location: location.trim() || 'Cape Town'
            }
          });

          if (updateError) {
            console.error('Failed to update user metadata:', updateError);
            throw new Error('Failed to update user metadata: ' + updateError.message);
          } else {
            console.log('User metadata updated to vendor');
          }
        } catch (updateErr) {
          console.error('Error updating user metadata:', updateErr);
          throw new Error('Failed to update user metadata: ' + updateErr.message);
        }

        // Create vendor profile manually
        try {
          console.log('Creating vendor profile...');
          const { error: profileError } = await supabase
            .from('vendor_profiles')
            .insert([{
              user_id: data.user.id,
              business_name: businessName.trim(),
              business_description: 'Professional wedding services',
              category: category.trim(),
              contact_email: email,
              city: location.trim() || 'Cape Town',
              location: location.trim() || 'Cape Town',
              is_active: true,
              is_verified: false
            }]);

          if (profileError) {
            console.error('Failed to create vendor profile:', profileError);
            throw new Error('Failed to create vendor profile: ' + profileError.message);
          } else {
            console.log('Vendor profile created successfully');
          }
        } catch (profileErr) {
          console.error('Error creating vendor profile:', profileErr);
          throw new Error('Failed to create vendor profile: ' + profileErr.message);
        }
      }
      
      Alert.alert(
        'Account Created!', 
        'Your vendor account has been created successfully. Please check your email to verify your account before signing in.',
        [
          {
            text: 'OK',
            onPress: () => router.push('/(auth)/vendor-sign-in')
          }
        ]
      );
    } catch (err: any) {
      console.error('Vendor signup failed:', err);
      
      let errorMessage = 'Failed to create vendor account';
      if (err.message?.includes('duplicate')) {
        errorMessage = 'An account with this email already exists';
      } else if (err.message?.includes('invalid')) {
        errorMessage = 'Please enter a valid email address';
      } else if (err.message?.includes('network')) {
        errorMessage = 'Network error. Please check your connection and try again';
      } else if (err.message) {
        errorMessage = err.message;
      }
      
      Alert.alert('Sign up failed', errorMessage);
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.logoContainer}>
          <Feather name="briefcase" size={32} color={colors.primary[300]} />
        </View>
        <Text style={styles.title}>Join as a Vendor</Text>
        <Text style={styles.subtitle}>Showcase your wedding services to couples</Text>
      </View>

      <Card style={styles.formCard}>
        <Input
          label="Business Name"
          placeholder="e.g., Thandi's Photography"
          value={businessName}
          onChangeText={setBusinessName}
          autoCapitalize="words"
        />

        <Input
          label="Service Category"
          placeholder="e.g., Photography, Catering, Venue"
          value={category}
          onChangeText={setCategory}
          autoCapitalize="words"
        />

        <Input
          label="Location"
          placeholder="e.g., Johannesburg, Gauteng"
          value={location}
          onChangeText={setLocation}
          autoCapitalize="words"
        />

        <Input
          label="Email"
          placeholder="thandi@tandiphotography.co.za"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          autoComplete="email"
        />
        
        <Input
          label="Password"
          placeholder="Create a password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          autoComplete="new-password"
        />

        <Input
          label="Confirm Password"
          placeholder="Confirm your password"
          value={confirmPassword}
          onChangeText={setConfirmPassword}
          secureTextEntry
          autoComplete="new-password"
        />

        <Button
          title="Create Vendor Account"
          onPress={handleSignUp}
          loading={loading}
          fullWidth
          style={styles.signUpButton}
        />

        <View style={styles.divider}>
          <View style={styles.dividerLine} />
          <Text style={styles.dividerText}>or</Text>
          <View style={styles.dividerLine} />
        </View>

        <TouchableOpacity 
          style={styles.switchButton}
          onPress={() => router.push('/(auth)/vendor-sign-in')}
        >
          <Text style={styles.switchButtonText}>Already have an account? Sign in</Text>
        </TouchableOpacity>
      </Card>

      <View style={styles.benefits}>
        <Text style={styles.benefitsTitle}>Why join as a vendor?</Text>
        <View style={styles.benefitItem}>
          <Feather name="users" size={20} color={colors.success[500]} />
          <Text style={styles.benefitText}>Reach thousands of couples planning their weddings</Text>
        </View>
        <View style={styles.benefitItem}>
          <Feather name="star" size={20} color={colors.success[500]} />
          <Text style={styles.benefitText}>Showcase your portfolio and get reviews</Text>
        </View>
        <View style={styles.benefitItem}>
          <Feather name="message-circle" size={20} color={colors.success[500]} />
          <Text style={styles.benefitText}>Direct inquiries from interested couples</Text>
        </View>
        <View style={styles.benefitItem}>
          <Feather name="trending-up" size={20} color={colors.success[500]} />
          <Text style={styles.benefitText}>Grow your business with our platform</Text>
        </View>
      </View>

      <View style={styles.footer}>
        <TouchableOpacity 
          style={styles.coupleLink}
          onPress={() => router.push('/(auth)/sign-up')}
        >
          <Text style={styles.coupleLinkText}>Are you a couple? Sign up here</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  header: {
    alignItems: 'center',
    paddingTop: spacing[16],
    paddingBottom: spacing[8],
    paddingHorizontal: spacing[6],
  },
  logoContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.surface.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing[4],
    shadowColor: colors.neutral[900],
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  title: {
    fontSize: typography.fontSize['3xl'],
    fontWeight: typography.fontWeight.bold,
    color: colors.text.primary,
    marginBottom: spacing[2],
    textAlign: 'center',
  },
  subtitle: {
    fontSize: typography.fontSize.base,
    color: colors.text.secondary,
    textAlign: 'center',
    lineHeight: typography.lineHeight.relaxed * typography.fontSize.base,
  },
  formCard: {
    marginHorizontal: spacing[6],
    marginBottom: spacing[6],
  },
  signUpButton: {
    marginTop: spacing[4],
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: spacing[6],
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: colors.border.primary,
  },
  dividerText: {
    marginHorizontal: spacing[4],
    fontSize: typography.fontSize.sm,
    color: colors.text.tertiary,
  },
  switchButton: {
    alignItems: 'center',
    paddingVertical: spacing[3],
  },
  switchButtonText: {
    fontSize: typography.fontSize.sm,
    color: colors.primary[500],
    fontWeight: typography.fontWeight.medium,
  },
  benefits: {
    marginHorizontal: spacing[6],
    marginBottom: spacing[6],
    padding: spacing[6],
    backgroundColor: colors.surface.primary,
    borderRadius: borderRadius.lg,
  },
  benefitsTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text.primary,
    marginBottom: spacing[4],
    textAlign: 'center',
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing[3],
  },
  benefitText: {
    fontSize: typography.fontSize.sm,
    color: colors.text.secondary,
    marginLeft: spacing[3],
    flex: 1,
  },
  footer: {
    alignItems: 'center',
    paddingHorizontal: spacing[6],
    paddingBottom: spacing[8],
  },
  coupleLink: {
    paddingVertical: spacing[3],
  },
  coupleLinkText: {
    fontSize: typography.fontSize.sm,
    color: colors.text.secondary,
    textAlign: 'center',
  },
});

