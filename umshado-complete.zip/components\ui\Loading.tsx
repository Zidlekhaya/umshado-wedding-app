// components/ui/Loading.tsx
import React from 'react';
import { View, Text, ActivityIndicator, StyleSheet, ViewStyle } from 'react-native';
import { colors, typography, spacing } from '@/src/theme/design-system';

interface LoadingProps {
  size?: 'small' | 'large';
  color?: string;
  text?: string;
  overlay?: boolean;
  style?: ViewStyle;
}

export function Loading({
  size = 'large',
  color = colors.primary[300],
  text,
  overlay = false,
  style,
}: LoadingProps) {
  const containerStyle = [
    styles.container,
    overlay && styles.overlay,
    style,
  ];

  return (
    <View style={containerStyle}>
      <ActivityIndicator size={size} color={color} />
      {text && <Text style={styles.text}>{text}</Text>}
    </View>
  );
}

interface SkeletonProps {
  width?: number | string;
  height?: number;
  borderRadius?: number;
  style?: ViewStyle;
}

export function Skeleton({
  width = '100%',
  height = 20,
  borderRadius = 8,
  style,
}: SkeletonProps) {
  return (
    <View
      style={[
        styles.skeleton,
        {
          width,
          height,
          borderRadius,
        },
        style,
      ]}
    />
  );
}

interface LoadingCardProps {
  lines?: number;
  showAvatar?: boolean;
  style?: ViewStyle;
}

export function LoadingCard({
  lines = 3,
  showAvatar = false,
  style,
}: LoadingCardProps) {
  return (
    <View style={[styles.card, style]}>
      {showAvatar && <Skeleton width={40} height={40} borderRadius={20} />}
      <View style={styles.content}>
        {Array.from({ length: lines }).map((_, index) => (
          <Skeleton
            key={index}
            width={index === lines - 1 ? '60%' : '100%'}
            height={16}
            style={{ marginBottom: index < lines - 1 ? spacing[2] : 0 }}
          />
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing[4],
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    zIndex: 1000,
  },
  text: {
    marginTop: spacing[3],
    fontSize: typography.fontSize.sm,
    color: colors.text.secondary,
    textAlign: 'center',
  },
  skeleton: {
    backgroundColor: colors.neutral[200],
  },
  card: {
    flexDirection: 'row',
    padding: spacing[4],
    backgroundColor: colors.surface.primary,
    borderRadius: 12,
    marginBottom: spacing[3],
  },
  content: {
    flex: 1,
    marginLeft: spacing[3],
  },
});











