import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Initialize Supabase client
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { userIds, title, body, data = {} } = await req.json()

    if (!userIds || !Array.isArray(userIds) || userIds.length === 0) {
      throw new Error('userIds array is required')
    }

    if (!title || !body) {
      throw new Error('title and body are required')
    }

    // Get push tokens for the specified users
    const { data: tokens, error: tokensError } = await supabase
      .from('push_tokens')
      .select('token, user_id, device_type')
      .in('user_id', userIds)

    if (tokensError) {
      throw tokensError
    }

    if (!tokens || tokens.length === 0) {
      console.log('No push tokens found for users:', userIds)
      return new Response(
        JSON.stringify({ success: true, message: 'No tokens found' }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      )
    }

    // Prepare notification payload
    const messages = tokens.map(tokenData => ({
      to: tokenData.token,
      sound: 'default',
      title,
      body,
      data: {
        ...data,
        userId: tokenData.user_id,
        deviceType: tokenData.device_type,
      },
      priority: 'high',
      channelId: 'default',
    }))

    // Send push notifications via Expo's push service
    const response = await fetch('https://exp.host/--/api/v2/push/send', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Accept-encoding': 'gzip, deflate',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(messages),
    })

    const result = await response.json()
    
    if (!response.ok) {
      throw new Error(`Push service error: ${JSON.stringify(result)}`)
    }

    console.log('Push notifications sent successfully:', {
      userIds,
      tokensCount: tokens.length,
      result,
    })

    return new Response(
      JSON.stringify({ 
        success: true, 
        sentTo: tokens.length,
        result 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    console.error('Error sending push notification:', error)
    
    return new Response(
      JSON.stringify({ 
        error: error.message,
        success: false 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    )
  }
})



