// Chat service for Supabase messaging system
import { supabase } from './supabase';
import { sendMessageNotification } from './notification-service';
// Generate simple random ID for file names
const generateId = () => Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);

export interface Conversation {
  id: string;
  couple_id: string;
  vendor_id: string;
  couple_name: string;
  vendor_name: string;
  vendor_avatar?: string;
  couple_avatar?: string;
  last_message?: string;
  last_message_at?: string;
  unread_count?: number;
  created_at: string;
  updated_at: string;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  sender_type: string;
  content?: string;
  message_type: string;
  is_read: boolean;
  read_at?: string;
  created_at: string;
}

export interface GiftedChatMessage {
  _id: string;
  text: string;
  createdAt: Date;
  user: {
    _id: string;
    name: string;
    avatar?: string;
  };
  image?: string;
  file?: {
    url: string;
    name: string;
  };
  read_at?: string;
  is_read?: boolean;
}

/**
 * Get or create a conversation between a couple and vendor
 */
export async function getOrCreateConversation({
  weddingId,
  weddingName,
  vendorUserId,
  vendorName,
  vendorAvatar,
}: {
  weddingId: string;
  weddingName: string;
  vendorUserId: string;
  vendorName: string;
  vendorAvatar?: string;
}): Promise<string> {
  try {
    const { data, error } = await supabase.rpc('get_or_create_conversation', {
      p_wedding_id: weddingId,
      p_wedding_name: weddingName,
      p_vendor_user_id: vendorUserId,
      p_vendor_name: vendorName,
      p_vendor_avatar: vendorAvatar,
    });

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error getting/creating conversation:', error);
    throw error;
  }
}

/**
 * Send a message in a conversation
 */
export async function sendMessage({
  conversationId,
  senderName,
  senderAvatar,
  messageText,
  messageType = 'text',
  imageUrl,
  fileUrl,
  fileName,
}: {
  conversationId: string;
  senderName: string;
  senderAvatar?: string;
  messageText?: string;
  messageType?: 'text' | 'image' | 'file';
  imageUrl?: string;
  fileUrl?: string;
  fileName?: string;
}): Promise<Message> {
  try {
    const { data: sessionData } = await supabase.auth.getSession();
    if (!sessionData.session?.user) {
      throw new Error('User not authenticated');
    }

    // Get conversation to determine sender type and recipient
    const { data: conversation, error: convError } = await supabase
      .from('conversations')
      .select('couple_id, vendor_id, couple_name, vendor_name')
      .eq('id', conversationId)
      .single();

    if (convError) throw convError;

    // Determine if current user is couple or vendor
    const currentUserId = sessionData.session.user.id;
    const senderType = currentUserId === conversation.couple_id ? 'couple' : 'vendor';
    const recipientId = currentUserId === conversation.couple_id ? conversation.vendor_id : conversation.couple_id;

    const { data, error } = await supabase
      .from('messages')
      .insert({
        conversation_id: conversationId,
        sender_id: currentUserId,
        sender_type: senderType,
        content: messageText,
        message_type: messageType,
      })
      .select()
      .single();

    if (error) throw error;

    // Send push notification to recipient
    if (messageText && messageText.trim()) {
      try {
        const senderDisplayName = senderType === 'couple' ? conversation.couple_name : conversation.vendor_name;
        await sendMessageNotification({
          recipientId,
          senderName: senderDisplayName || senderName,
          messageText: messageText.trim(),
          conversationId,
        });
      } catch (notificationError) {
        console.error('Error sending push notification:', notificationError);
        // Don't throw here - message was sent successfully, notification is optional
      }
    }

    return data;
  } catch (error) {
    console.error('Error sending message:', error);
    throw error;
  }
}

/**
 * Upload file to Supabase Storage
 */
export async function uploadFileToStorage(
  uri: string,
  fileName: string,
  conversationId: string
): Promise<string> {
  try {
    // Fetch the file from URI
    const response = await fetch(uri);
    const blob = await response.blob();

    // Create unique file name
    const fileExt = fileName.split('.').pop();
    const uniqueFileName = `${conversationId}/${generateId()}.${fileExt}`;

    // Upload to Supabase Storage
    const { data, error } = await supabase.storage
      .from('chat-files')
      .upload(uniqueFileName, blob, {
        contentType: blob.type,
        upsert: false,
      });

    if (error) throw error;

    // Get public URL
    const { data: publicUrlData } = supabase.storage
      .from('chat-files')
      .getPublicUrl(data.path);

    return publicUrlData.publicUrl;
  } catch (error) {
    console.error('Error uploading file:', error);
    throw error;
  }
}

/**
 * Get conversations for current user (both as couple and vendor)
 */
export async function getUserConversations(): Promise<Conversation[]> {
  try {
    const { data: sessionData } = await supabase.auth.getSession();
    if (!sessionData.session?.user) {
      throw new Error('User not authenticated');
    }

    const { data, error } = await supabase
      .from('conversations')
      .select('*')
      .or(`couple_id.eq.${sessionData.session.user.id},vendor_id.eq.${sessionData.session.user.id}`)
      .order('updated_at', { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching conversations:', error);
    throw error;
  }
}

/**
 * Get vendor conversations only
 */
export async function getVendorConversations(): Promise<Conversation[]> {
  try {
    const { data: sessionData } = await supabase.auth.getSession();
    if (!sessionData.session?.user) {
      throw new Error('User not authenticated');
    }

    const { data, error } = await supabase
      .from('conversations')
      .select('*')
      .eq('vendor_id', sessionData.session.user.id)
      .order('updated_at', { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching vendor conversations:', error);
    throw error;
  }
}

/**
 * Get couple conversations only
 */
export async function getCoupleConversations(): Promise<Conversation[]> {
  try {
    const { data: sessionData } = await supabase.auth.getSession();
    if (!sessionData.session?.user) {
      throw new Error('User not authenticated');
    }

    const { data, error } = await supabase
      .from('conversations')
      .select('*')
      .eq('couple_id', sessionData.session.user.id)
      .order('updated_at', { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching couple conversations:', error);
    throw error;
  }
}

/**
 * Convert Supabase message to GiftedChat format
 */
export function messageToGiftedChat(message: Message, conversation?: Conversation): GiftedChatMessage {
  // Get sender name based on sender type and conversation data
  let senderName = message.sender_type;
  if (conversation) {
    if (message.sender_type === 'couple') {
      senderName = conversation.couple_name || 'Couple';
    } else if (message.sender_type === 'vendor') {
      senderName = conversation.vendor_name || 'Vendor';
    }
  }

  return {
    _id: message.id,
    text: message.content || '',
    createdAt: new Date(message.created_at),
    user: {
      _id: message.sender_id,
      name: senderName,
      avatar: '', // No avatar field in your table
    },
    read_at: message.read_at,
    is_read: message.is_read,
  };
}

/**
 * Get conversation by ID
 */
export async function getConversation(conversationId: string): Promise<Conversation | null> {
  try {
    const { data, error } = await supabase
      .from('conversations')
      .select('*')
      .eq('id', conversationId)
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error fetching conversation:', error);
    return null;
  }
}

/**
 * Subscribe to messages in a conversation
 */
export function subscribeToMessages(
  conversationId: string,
  callback: (messages: GiftedChatMessage[]) => void
) {
  const channel = supabase
    .channel(`messages-${conversationId}`)
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `conversation_id=eq.${conversationId}`,
      },
      (payload) => {
        // Re-fetch messages when there's a new message
        fetchMessages(conversationId).then(callback);
      }
    )
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'messages',
        filter: `conversation_id=eq.${conversationId}`,
      },
      (payload) => {
        // Re-fetch messages when a message is updated
        fetchMessages(conversationId).then(callback);
      }
    )
    .subscribe((status) => {
      console.log('Subscription status:', status);
    });

  return channel;
}

/**
 * Fetch messages for a conversation
 */
async function fetchMessages(conversationId: string): Promise<GiftedChatMessage[]> {
  try {
    // Get conversation data for proper name display
    const conversation = await getConversation(conversationId);
    
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: false })
      .limit(50);

    if (error) throw error;
    
    return (data || []).map(msg => messageToGiftedChat(msg, conversation));
  } catch (error) {
    console.error('Error fetching messages:', error);
    return [];
  }
}

/**
 * Mark messages as read for the current user
 */
export async function markMessagesAsRead(conversationId: string): Promise<void> {
  try {
    const { data: sessionData } = await supabase.auth.getSession();
    if (!sessionData.session?.user) {
      throw new Error('User not authenticated');
    }

    // Mark all unread messages in this conversation as read for the current user
    const { error } = await supabase
      .from('messages')
      .update({ 
        is_read: true,
        read_at: new Date().toISOString()
      })
      .eq('conversation_id', conversationId)
      .neq('sender_id', sessionData.session.user.id) // Don't mark own messages as read
      .eq('is_read', false);

    if (error) throw error;
  } catch (error) {
    console.error('Error marking messages as read:', error);
    throw error;
  }
}

/**
 * Subscribe to conversation list changes
 */
export function subscribeToConversations(callback: (conversations: Conversation[]) => void) {
  return supabase
    .channel('conversations')
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'conversations',
      },
      () => {
        // Re-fetch conversations when there's a change
        getUserConversations().then(callback);
      }
    )
    .subscribe();
}
