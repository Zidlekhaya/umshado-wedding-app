// components/ai/AIBudgetAnalyzer.tsx
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { aiPlanner } from '@/lib/ai-service';
import { useWeddingStore } from '@/stores/wedding';

interface BudgetOptimization {
  category: string;
  currentSpending: number;
  suggestedSpending: number;
  savings: number;
  reason: string;
}

interface AIBudgetAnalysis {
  analysis: string;
  suggestions: string[];
  optimizations: BudgetOptimization[];
}

const colors = {
  background: '#f0fbea',
  surface: '#FFFFFF',
  primary: '#00a86b',
  secondary: '#FF6B35',
  text: '#1A1A1A',
  textSecondary: '#6B7280',
  border: '#E5E7EB',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  white: '#FFFFFF',
};

export default function AIBudgetAnalyzer() {
  const [analysis, setAnalysis] = useState<AIBudgetAnalysis | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [hasAnalyzed, setHasAnalyzed] = useState(false);
  const { currentWedding } = useWeddingStore();

  const runAnalysis = async () => {
    if (!currentWedding?.id) {
      Alert.alert('Error', 'No wedding selected');
      return;
    }

    setIsLoading(true);
    try {
      const result = await aiPlanner.analyzeBudget(currentWedding.id);
      setAnalysis(result);
      setHasAnalyzed(true);
    } catch (error) {
      console.error('Budget analysis error:', error);
      Alert.alert('Error', 'Failed to analyze budget. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZA', {
      style: 'currency',
      currency: 'ZAR',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const getSavingsColor = (savings: number) => {
    if (savings > 1000) return colors.success;
    if (savings > 500) return colors.warning;
    return colors.textSecondary;
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <View style={styles.aiIcon}>
            <Feather name="trending-down" size={20} color={colors.white} />
          </View>
          <View>
            <Text style={styles.headerTitle}>AI Budget Analyzer</Text>
            <Text style={styles.headerSubtitle}>Optimize your wedding spending</Text>
          </View>
        </View>
        {!hasAnalyzed && (
          <TouchableOpacity
            onPress={runAnalysis}
            style={styles.analyzeButton}
            disabled={isLoading}
          >
            {isLoading ? (
              <ActivityIndicator size="small" color={colors.white} />
            ) : (
              <Text style={styles.analyzeButtonText}>Analyze</Text>
            )}
          </TouchableOpacity>
        )}
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {!hasAnalyzed && !isLoading && (
          <View style={styles.welcomeCard}>
            <Feather name="lightbulb" size={48} color={colors.primary} />
            <Text style={styles.welcomeTitle}>Smart Budget Analysis</Text>
            <Text style={styles.welcomeText}>
              Get AI-powered insights on your wedding budget. I'll analyze your spending patterns and suggest optimizations to help you save money while maintaining your dream wedding.
            </Text>
            <TouchableOpacity
              onPress={runAnalysis}
              style={styles.startAnalysisButton}
            >
              <Text style={styles.startAnalysisButtonText}>Start Analysis</Text>
              <Feather name="arrow-right" size={16} color={colors.white} />
            </TouchableOpacity>
          </View>
        )}

        {isLoading && (
          <View style={styles.loadingCard}>
            <ActivityIndicator size="large" color={colors.primary} />
            <Text style={styles.loadingText}>Analyzing your budget...</Text>
            <Text style={styles.loadingSubtext}>
              This may take a few moments
            </Text>
          </View>
        )}

        {analysis && (
          <>
            {/* Analysis Overview */}
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <Feather name="bar-chart-2" size={20} color={colors.primary} />
                <Text style={styles.cardTitle}>Budget Analysis</Text>
              </View>
              <Text style={styles.analysisText}>{analysis.analysis}</Text>
            </View>

            {/* Suggestions */}
            {analysis.suggestions.length > 0 && (
              <View style={styles.card}>
                <View style={styles.cardHeader}>
                  <Feather name="bulb" size={20} color={colors.warning} />
                  <Text style={styles.cardTitle}>Money-Saving Tips</Text>
                </View>
                {analysis.suggestions.map((suggestion, index) => (
                  <View key={index} style={styles.suggestionItem}>
                    <View style={styles.suggestionBullet} />
                    <Text style={styles.suggestionText}>{suggestion}</Text>
                  </View>
                ))}
              </View>
            )}

            {/* Optimizations */}
            {analysis.optimizations.length > 0 && (
              <View style={styles.card}>
                <View style={styles.cardHeader}>
                  <Feather name="target" size={20} color={colors.success} />
                  <Text style={styles.cardTitle}>Optimization Opportunities</Text>
                </View>
                {analysis.optimizations.map((optimization, index) => (
                  <View key={index} style={styles.optimizationItem}>
                    <View style={styles.optimizationHeader}>
                      <Text style={styles.optimizationCategory}>
                        {optimization.category}
                      </Text>
                      <Text style={[
                        styles.optimizationSavings,
                        { color: getSavingsColor(optimization.savings) }
                      ]}>
                        Save {formatCurrency(optimization.savings)}
                      </Text>
                    </View>
                    <View style={styles.optimizationDetails}>
                      <Text style={styles.optimizationCurrent}>
                        Current: {formatCurrency(optimization.currentSpending)}
                      </Text>
                      <Text style={styles.optimizationSuggested}>
                        Suggested: {formatCurrency(optimization.suggestedSpending)}
                      </Text>
                    </View>
                    <Text style={styles.optimizationReason}>
                      {optimization.reason}
                    </Text>
                  </View>
                ))}
              </View>
            )}

            {/* Action Buttons */}
            <View style={styles.actionButtons}>
              <TouchableOpacity
                onPress={runAnalysis}
                style={styles.refreshButton}
              >
                <Feather name="refresh-cw" size={16} color={colors.primary} />
                <Text style={styles.refreshButtonText}>Refresh Analysis</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: colors.white,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  aiIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  headerSubtitle: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  analyzeButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  analyzeButtonText: {
    color: colors.white,
    fontWeight: '600',
    fontSize: 14,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  welcomeCard: {
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    marginBottom: 20,
  },
  welcomeTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.text,
    marginTop: 16,
    marginBottom: 8,
  },
  welcomeText: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 24,
  },
  startAnalysisButton: {
    backgroundColor: colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 25,
  },
  startAnalysisButtonText: {
    color: colors.white,
    fontWeight: '600',
    fontSize: 16,
    marginRight: 8,
  },
  loadingCard: {
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: 40,
    alignItems: 'center',
    marginBottom: 20,
  },
  loadingText: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginTop: 16,
    marginBottom: 8,
  },
  loadingSubtext: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  card: {
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginLeft: 8,
  },
  analysisText: {
    fontSize: 16,
    color: colors.text,
    lineHeight: 24,
  },
  suggestionItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  suggestionBullet: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.warning,
    marginTop: 8,
    marginRight: 12,
  },
  suggestionText: {
    flex: 1,
    fontSize: 15,
    color: colors.text,
    lineHeight: 22,
  },
  optimizationItem: {
    backgroundColor: colors.background,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  optimizationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  optimizationCategory: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  optimizationSavings: {
    fontSize: 16,
    fontWeight: '700',
  },
  optimizationDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  optimizationCurrent: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  optimizationSuggested: {
    fontSize: 14,
    color: colors.success,
    fontWeight: '500',
  },
  optimizationReason: {
    fontSize: 14,
    color: colors.textSecondary,
    fontStyle: 'italic',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  refreshButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  refreshButtonText: {
    color: colors.primary,
    fontWeight: '600',
    fontSize: 16,
    marginLeft: 8,
  },
});
