import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, Pressable } from "react-native";
import { rsvpCounts, subscribeRsvpCounts } from "@/src/services/guests";
import { router } from "expo-router";
import type { RSVPStatus } from "@/types/guest";

export default function RsvpOverview({ weddingId }: { weddingId: string }) {
  const [counts, setCounts] = useState({ going: 0, maybe: 0, declined: 0, no_reply: 0 });

  useEffect(() => { 
    (async () => {
      try {
        const data = await rsvpCounts(weddingId);
        setCounts(data);
      } catch (error) {
        console.error('Error loading RSVP counts:', error);
      }
    })(); 
  }, [weddingId]);

  // Subscribe to real-time changes
  useEffect(() => {
    const unsubscribe = subscribeRsvpCounts(weddingId, setCounts);
    return unsubscribe;
  }, [weddingId]);

  const goToGuests = (status?: RSVPStatus) => {
    const qs = status ? `?status=${status}` : '';
    router.push(`/(tabs)/guests${qs}`);
  };

  const Chip = ({ label, value, status }: { label: string; value: number; status: RSVPStatus }) => (
    <Pressable 
      style={({ pressed }) => [s.chip, pressed && { opacity: 0.8 }]}
      onPress={() => goToGuests(status)}
    >
      <Text style={s.chipLabel}>{label}</Text>
      <Text style={s.chipValue}>{value}</Text>
    </Pressable>
  );

  return (
    <View style={s.chipsRow}>
      <Chip label="Going" value={counts.going} status="going" />
      <Chip label="Maybe" value={counts.maybe} status="maybe" />
      <Chip label="Declined" value={counts.declined} status="declined" />
      <Chip label="No Reply" value={counts.no_reply} status="no_reply" />
    </View>
  );
}

const s = StyleSheet.create({
  chipsRow: { 
    flexDirection: "row", 
    gap: 10, 
    marginTop: 12,
    marginBottom: 20,
  },
  chip: { 
    flex: 1, 
    minHeight: 44,
    borderRadius: 16,
    backgroundColor: '#F5E8C7',
    paddingVertical: 10,
    paddingHorizontal: 14,
    minWidth: 84,
    alignItems: "center",
    justifyContent: "center",
    gap: 2,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  chipLabel: { 
    fontSize: 12.5,
    color: '#3B2F2F',
    fontWeight: '600',
  },
  chipValue: { 
    fontSize: 16, 
    fontWeight: "700", 
    color: '#8B6E4E',
  },
});
