import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';

interface LogoProps {
  size?: 'small' | 'medium' | 'large';
  showText?: boolean;
  color?: 'primary' | 'white' | 'dark';
}

export function Logo({ size = 'medium', showText = true, color = 'primary' }: LogoProps) {
  const getSize = () => {
    switch (size) {
      case 'small': return { width: 80, height: 80, fontSize: 28 };
      case 'large': return { width: 240, height: 240, fontSize: 48 };
      default: return { width: 160, height: 160, fontSize: 36 };
    }
  };

  const { width, height, fontSize } = getSize();
  
  const getColors = () => {
    switch (color) {
      case 'white':
        return {
          text: '#FFFFFF',
          textSecondary: '#FFFFFF'
        };
      case 'dark':
        return {
          text: '#1A1A1A',
          textSecondary: '#6B7280'
        };
      default:
        return {
          text: '#1A1A1A',
          textSecondary: '#6B7280'
        };
    }
  };

  const colors = getColors();

  return (
    <View style={styles.container}>
      <View style={styles.logoContainer}>
        {/* Your authentic umshado logo */}
        <Image 
          source={require('../../../assets/images/logo.png')}
          style={{ width, height }}
          resizeMode="contain"
        />
      </View>
      
      {showText && (
        <View style={styles.textContainer}>
          <Text style={[styles.brandText, { fontSize, color: colors.text }]}>
            umshado
          </Text>
          <Text style={[styles.taglineText, { fontSize: fontSize * 0.7, color: colors.textSecondary }]}>
            your wedding app
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  textContainer: {
    alignItems: 'center',
    marginTop: 4,
  },
  brandText: {
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  taglineText: {
    fontWeight: '400',
    letterSpacing: 0.3,
  },
});
