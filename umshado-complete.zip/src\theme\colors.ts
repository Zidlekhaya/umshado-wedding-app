export const colors = {
  bg: '#D4A373',
  card: '#F5E8C7',
  text: '#2B2B2B',
  mutedText: '#6B6B6B',
  maroon: '#7C2E1F',
  beige: '#F0DAB5',
  border: '#D3D3D3',
  accent: '#A9B7A0',
  white: '#FFFFFF',
  shadow: 'rgba(0,0,0,0.08)',
};




