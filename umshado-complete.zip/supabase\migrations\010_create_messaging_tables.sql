-- 010_create_messaging_tables.sql
BEGIN;

-- threads: a conversation between a couple and a vendor (or group later)
CREATE TABLE IF NOT EXISTS threads (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  vendor_id uuid NOT NULL REFERENCES vendor_profiles(id) ON DELETE CASCADE,
  couple_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  subject text,
  last_message text,
  last_message_at timestamptz,
  unread_count_for_vendor integer DEFAULT 0,
  unread_count_for_couple integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- messages
CREATE TABLE IF NOT EXISTS messages (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  thread_id uuid NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
  sender_user_id uuid NOT NULL REFERENCES auth.users(id),
  content text,
  message_type text NOT NULL DEFAULT 'text' CHECK (message_type IN ('text','image','file','system')),
  attachments jsonb DEFAULT '[]'::jsonb, -- [{url, filename, size, mime}]
  is_edited boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- read receipts (per message per user)
CREATE TABLE IF NOT EXISTS message_reads (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  message_id uuid NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id),
  read_at timestamptz DEFAULT now(),
  UNIQUE (message_id, user_id)
);

-- typing indicator optional lightweight table (or use presence channel in realtime)
CREATE TABLE IF NOT EXISTS typing_presence (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  thread_id uuid NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id),
  is_typing boolean DEFAULT true,
  last_seen timestamptz DEFAULT now()
);

-- indexes for performance
CREATE INDEX IF NOT EXISTS idx_threads_vendor_couple ON threads (vendor_id, couple_user_id);
CREATE INDEX IF NOT EXISTS idx_messages_thread_created_at ON messages (thread_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_threads_last_message_at ON threads (last_message_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages (sender_user_id);
CREATE INDEX IF NOT EXISTS idx_message_reads_message_user ON message_reads (message_id, user_id);
CREATE INDEX IF NOT EXISTS idx_typing_presence_thread_user ON typing_presence (thread_id, user_id);

-- Function to update thread when new message is added
CREATE OR REPLACE FUNCTION update_thread_on_new_message()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE threads SET
    last_message = NEW.content,
    last_message_at = NEW.created_at,
    unread_count_for_vendor = CASE 
      WHEN NEW.sender_user_id = threads.couple_user_id THEN threads.unread_count_for_vendor + 1 
      ELSE threads.unread_count_for_vendor 
    END,
    unread_count_for_couple = CASE 
      WHEN NEW.sender_user_id != threads.couple_user_id THEN threads.unread_count_for_couple + 1 
      ELSE threads.unread_count_for_couple 
    END,
    updated_at = NEW.created_at
  WHERE id = NEW.thread_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to automatically update thread on new message
CREATE TRIGGER trigger_update_thread_on_new_message
  AFTER INSERT ON messages
  FOR EACH ROW
  EXECUTE FUNCTION update_thread_on_new_message();

COMMIT;








