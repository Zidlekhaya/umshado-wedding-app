import { useEffect, useState, useCallback } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Alert, SafeAreaView, Animated, Image, TextInput, Modal } from 'react-native';
import { router, Stack } from 'expo-router';
import { useWeddingStore } from '@/stores/wedding';
import { getCurrentWedding, invitePartner } from '@/lib/wedding-service';
import { listGuests } from '@/lib/guest-service';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Loading } from '@/components/ui/Loading';
import { Logo } from '@/src/components/ui/Logo';
import { ProfilePicture } from '@/components/ui/ProfilePicture';
import { Feather } from '@expo/vector-icons';
import { supabase } from '@/lib/supabase';
import { formatDate, getDaysUntil } from '@/lib/date-utils';

// Updated color scheme with new background
const modernColors = {
  background: '#f0fbea',
  surface: '#FFFFFF',
  primary: '#00a86b',
  secondary: '#FF6B35',
  text: '#000000',
  textSecondary: '#6B7280',
  textLight: '#9CA3AF',
  border: '#E5E7EB',
  divider: '#F1F5F9',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  white: '#FFFFFF',
  accent: '#F3F4F6',
  cardBackground: '#FFFFFF',
  shadow: 'rgba(0, 0, 0, 0.1)',
};

export default function Home() {
  const [loading, setLoading] = useState(true);
  const [guestStats, setGuestStats] = useState({ total: 0, confirmed: 0, pending: 0, declined: 0 });
  const [daysToWedding, setDaysToWedding] = useState(0);
  const [fadeAnim] = useState(new Animated.Value(0));
  const [profilePictureUri, setProfilePictureUri] = useState<string | null>(null);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [partnerEmail, setPartnerEmail] = useState('');
  const [invitingPartner, setInvitingPartner] = useState(false);
  const { currentWedding, setCurrentWedding, setHasWedding } = useWeddingStore();

  const handleLogout = async () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Logout', 
          style: 'destructive',
          onPress: async () => {
            try {
              console.log('Logging out...');
              await supabase.auth.signOut();
              console.log('Logged out successfully');
              router.replace('/user-type-selection');
            } catch (error) {
              console.error('Logout error:', error);
              Alert.alert('Error', 'Failed to logout');
            }
          }
        }
      ]
    );
  };

  const loadWeddingData = useCallback(async () => {
    try {
      console.log('Home: Loading wedding data...');
      setLoading(true);

      const wedding = await getCurrentWedding();
      if (wedding) {
        setCurrentWedding(wedding);
        setHasWedding(true);

        // Calculate days to wedding
        if (wedding.date) {
          const daysUntil = getDaysUntil(wedding.date);
          setDaysToWedding(daysUntil);
        }

        // Load guest statistics
        try {
          const guests = await listGuests(wedding.id);
          const stats = {
            total: guests.length,
            confirmed: guests.filter(g => g.rsvp === 'going').length,
            pending: guests.filter(g => g.rsvp === 'no_reply').length,
            declined: guests.filter(g => g.rsvp === 'declined').length,
          };
          setGuestStats(stats);
        } catch (error) {
          console.error('Error loading guests:', error);
          setGuestStats({ total: 0, confirmed: 0, pending: 0, declined: 0 });
        }
      } else {
        setHasWedding(false);
      }
    } catch (error) {
      console.error('Error loading wedding data:', error);
      setHasWedding(false);
    } finally {
      setLoading(false);
    }
  }, [setCurrentWedding, setHasWedding]);

  const handleProfilePictureChange = async (uri: string) => {
    try {
      setProfilePictureUri(uri);
      // Here you could save the profile picture to Supabase storage
      // For now, we'll just store it locally
      console.log('Profile picture updated:', uri);
    } catch (error) {
      console.error('Error updating profile picture:', error);
      Alert.alert('Error', 'Failed to update profile picture');
    }
  };

  const handleInvitePartner = async () => {
    if (!currentWedding?.id || !partnerEmail.trim()) {
      Alert.alert('Error', 'Please enter your partner\'s email address');
      return;
    }

    try {
      setInvitingPartner(true);
      await invitePartner(currentWedding.id, partnerEmail.trim());
      setShowInviteModal(false);
      setPartnerEmail('');
      Alert.alert(
        'Invitation Sent! 💕',
        `We've sent an invitation to ${partnerEmail.trim()}. Once they accept, you'll both have access to plan your wedding together!`,
        [{ text: 'OK', style: 'default' }]
      );
    } catch (error) {
      console.error('Error inviting partner:', error);
      Alert.alert('Error', 'Failed to send invitation. Please try again.');
    } finally {
      setInvitingPartner(false);
    }
  };

  useEffect(() => {
    loadWeddingData();
  }, [loadWeddingData]);

  useEffect(() => {
    if (!loading) {
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }).start();
    }
  }, [loading, fadeAnim]);

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <Loading size="large" color={modernColors.primary} text="Loading your wedding..." />
      </SafeAreaView>
    );
  }

  if (!currentWedding) {
    return (
      <SafeAreaView style={styles.container}>
        <Stack.Screen options={{ headerShown: false }} />
        <View style={styles.noWeddingContainer}>
          <View style={styles.noWeddingContent}>
            <Logo size="large" showText={true} />
            <Text style={styles.noWeddingTitle}>Welcome to Umshado!</Text>
            <Text style={styles.noWeddingSubtitle}>
              Let&apos;s start planning your dream wedding together.
            </Text>
            <Button
              title="Create Your Wedding"
              onPress={() => router.push('/(tabs)/create-wedding')}
              style={styles.createWeddingButton}
            />
          </View>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen 
        options={{ 
          headerShown: false 
        }} 
      />
      
      {/* Modern Header with Logo and Profile */}
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <Logo size="small" showText={false} />
          <Text style={styles.headerTitle}>Home</Text>
          <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
            <Feather name="log-out" size={16} color={modernColors.white} />
            <Text style={styles.logoutButtonText}>Logout</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.profileSection}>
          <ProfilePicture
            size={120}
            imageUri={profilePictureUri || undefined}
            onImageChange={handleProfilePictureChange}
            editable={true}
          />
          <View style={styles.welcomeSection}>
            <Text style={styles.welcomeText}>Good morning!</Text>
            <Text style={styles.weddingName}>{currentWedding.name}</Text>
            <Text style={styles.weddingDate}>
              {currentWedding.date ? formatDate(currentWedding.date) : 'Date TBD'}
            </Text>
            <TouchableOpacity 
              style={styles.invitePartnerButton}
              onPress={() => setShowInviteModal(true)}
            >
              <Feather name="heart" size={16} color="#EF4444" />
              <Text style={styles.invitePartnerText}>Invite Partner</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
        <ScrollView 
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scrollContent}
        >
          {/* Guest Statistics */}
          <TouchableOpacity 
            style={styles.guestStatsSection}
            onPress={() => router.push('/(tabs)/guests')}
            activeOpacity={0.7}
          >
            <View style={styles.guestStatsHeader}>
              <View style={styles.guestStatsHeaderLeft}>
                <View style={styles.guestStatsIcon}>
                  <Feather name="users" size={20} color={modernColors.primary} />
                </View>
                <View>
                  <Text style={styles.guestStatsTitle}>Guest List</Text>
                  <Text style={styles.guestStatsSubtitle}>Tap to view all guests</Text>
                </View>
              </View>
              <Feather name="chevron-right" size={20} color={modernColors.textSecondary} />
            </View>
            
            <View style={styles.guestStatsGrid}>
              <View style={styles.guestStatCard}>
                <Text style={styles.guestStatNumber}>{guestStats.total}</Text>
                <Text style={styles.guestStatLabel}>Total</Text>
              </View>
              <View style={[styles.guestStatCard, styles.guestStatConfirmed]}>
                <Text style={[styles.guestStatNumber, styles.guestStatNumberConfirmed]}>{guestStats.confirmed}</Text>
                <Text style={[styles.guestStatLabel, styles.guestStatLabelConfirmed]}>Confirmed</Text>
              </View>
              <View style={[styles.guestStatCard, styles.guestStatPending]}>
                <Text style={[styles.guestStatNumber, styles.guestStatNumberPending]}>{guestStats.pending}</Text>
                <Text style={[styles.guestStatLabel, styles.guestStatLabelPending]}>Pending</Text>
              </View>
              <View style={[styles.guestStatCard, styles.guestStatDeclined]}>
                <Text style={[styles.guestStatNumber, styles.guestStatNumberDeclined]}>{guestStats.declined}</Text>
                <Text style={[styles.guestStatLabel, styles.guestStatLabelDeclined]}>Declined</Text>
              </View>
            </View>
          </TouchableOpacity>

          {/* Section Divider */}
          <View style={styles.sectionDivider} />

          {/* Wedding Services Suggestions */}
          <View style={styles.suggestionsSection}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Wedding Services</Text>
              <TouchableOpacity onPress={() => router.push('/(tabs)/explore')}>
                <Text style={styles.sectionLink}>See all</Text>
              </TouchableOpacity>
            </View>
            
            <View style={styles.suggestionsGrid}>
              <TouchableOpacity style={styles.suggestionCard} onPress={() => router.push('/(tabs)/explore')}>
                <View style={styles.suggestionIcon}>
                  <Feather name="camera" size={24} color={modernColors.primary} />
                </View>
                <Text style={styles.suggestionText}>Photography</Text>
                <View style={styles.promoBadge}>
                  <Text style={styles.promoText}>Promo</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity style={styles.suggestionCard} onPress={() => router.push('/(tabs)/budget')}>
                <View style={styles.suggestionIcon}>
                  <Feather name="dollar-sign" size={24} color={modernColors.success} />
                </View>
                <Text style={styles.suggestionText}>Budget</Text>
                <View style={styles.promoBadge}>
                  <Text style={styles.promoText}>100%</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity style={styles.suggestionCard} onPress={() => router.push('/(tabs)/guests')}>
                <View style={styles.suggestionIcon}>
                  <Feather name="users" size={24} color={modernColors.warning} />
                </View>
                <Text style={styles.suggestionText}>Guests</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.suggestionCard} onPress={() => router.push('/(tabs)/tasks')}>
                <View style={styles.suggestionIcon}>
                  <Feather name="check-square" size={24} color={modernColors.error} />
                </View>
                <Text style={styles.suggestionText}>Tasks</Text>
                <View style={styles.promoBadge}>
                  <Text style={styles.promoText}>Promo</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity style={styles.suggestionCard} onPress={() => router.push('/(tabs)/explore')}>
                <View style={styles.suggestionIcon}>
                  <Feather name="music" size={24} color={modernColors.secondary} />
                </View>
                <Text style={styles.suggestionText}>Music</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.suggestionCard} onPress={() => router.push('/(tabs)/explore')}>
                <View style={styles.suggestionIcon}>
                  <Feather name="coffee" size={24} color={modernColors.primary} />
                </View>
                <Text style={styles.suggestionText}>Catering</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.suggestionCard} onPress={() => router.push('/(tabs)/explore')}>
                <View style={styles.suggestionIcon}>
                  <Feather name="heart" size={24} color={modernColors.success} />
                </View>
                <Text style={styles.suggestionText}>Flowers</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.suggestionCard} onPress={() => router.push('/(tabs)/explore')}>
                <View style={styles.suggestionIcon}>
                  <Feather name="truck" size={24} color={modernColors.warning} />
                </View>
                <Text style={styles.suggestionText}>Transport</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Section Divider */}
          <View style={styles.sectionDivider} />

          {/* Wedding Countdown Card */}
          <View style={styles.countdownSection}>
            <Card style={styles.countdownCard} variant="elevated">
              <View style={styles.countdownContent}>
                <View style={styles.countdownIcon}>
                  <Feather name="calendar" size={24} color={modernColors.primary} />
                </View>
                <View style={styles.countdownText}>
                  <Text style={styles.countdownNumber}>{daysToWedding}</Text>
                  <Text style={styles.countdownLabel}>Days to go</Text>
                </View>
                <View style={styles.countdownDate}>
                  <Text style={styles.countdownWeddingDate}>
                    {currentWedding.date ? formatDate(currentWedding.date) : 'TBD'}
                  </Text>
                  <Text style={styles.weddingLocation}>{currentWedding.city || 'Location TBD'}</Text>
                </View>
              </View>
            </Card>
          </View>

          {/* Section Divider */}
          <View style={styles.sectionDivider} />

          {/* Promotional Cards */}
          <View style={styles.promoSection}>
            <TouchableOpacity style={styles.promoCard} onPress={() => router.push('/(tabs)/budget')}>
              <View style={styles.promoContent}>
                <Text style={styles.promoTitle}>Stay on budget, stress-free</Text>
                <Button 
                  title="Track Budget" 
                  onPress={() => router.push('/(tabs)/budget')}
                  style={styles.promoButton}
                />
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.promoCard2} onPress={() => router.push('/(tabs)/explore')}>
              <View style={styles.promoContent2}>
                <Text style={styles.promoTitle2}>Find your perfect vendors</Text>
                <Text style={styles.promoSubtitle2}>Photographers, caterers, florists and more</Text>
              </View>
            </TouchableOpacity>
          </View>

          {/* Section Divider */}
          <View style={styles.sectionDivider} />

          {/* More Wedding Planning */}
          <View style={styles.moreSection}>
            <Text style={styles.sectionTitle}>More ways to plan your wedding</Text>
            <View style={styles.moreCard}>
              <Image 
                source={{ uri: 'https://via.placeholder.com/300x120/00A86B/FFFFFF?text=Wedding+Planning' }}
                style={styles.moreImage}
              />
            </View>
          </View>
        </ScrollView>
      </Animated.View>

      {/* Invite Partner Modal */}
      <Modal
        visible={showInviteModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowInviteModal(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Invite Your Partner 💕</Text>
            <TouchableOpacity
              onPress={() => setShowInviteModal(false)}
              style={styles.modalCloseButton}
            >
              <Feather name="x" size={24} color={modernColors.text} />
            </TouchableOpacity>
          </View>
          
          <View style={styles.modalContent}>
            <View style={styles.inviteIconContainer}>
              <View style={styles.inviteIcon}>
                <Feather name="heart" size={48} color="#EF4444" />
              </View>
            </View>
            
            <Text style={styles.inviteDescription}>
              Planning a wedding is better together! Invite your partner to collaborate on your special day.
            </Text>
            
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Partner&apos;s Email Address</Text>
              <TextInput
                style={styles.emailInput}
                value={partnerEmail}
                onChangeText={setPartnerEmail}
                placeholder="sipho@gmail.com"
                placeholderTextColor={modernColors.textLight}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>
            
            <Text style={styles.inviteNote}>
              Your partner will receive an email invitation and can access all wedding planning features.
            </Text>
          </View>
          
          <View style={styles.modalActions}>
            <TouchableOpacity
              style={[styles.modalButton, styles.cancelButton]}
              onPress={() => setShowInviteModal(false)}
            >
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.modalButton, styles.inviteButton]}
              onPress={handleInvitePartner}
              disabled={invitingPartner}
            >
              {invitingPartner ? (
                <View style={styles.loadingContainer}>
                  <Text style={styles.inviteButtonText}>Sending...</Text>
                </View>
              ) : (
                <>
                  <Feather name="heart" size={16} color={modernColors.white} />
                  <Text style={styles.inviteButtonText}>Send Invitation</Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: modernColors.background,
  },
  header: {
    backgroundColor: modernColors.background,
    paddingTop: 10,
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: modernColors.border,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: modernColors.text,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  welcomeSection: {
    flex: 1,
  },
  welcomeText: {
    fontSize: 16,
    color: modernColors.textSecondary,
    marginBottom: 4,
  },
  weddingName: {
    fontSize: 24,
    fontWeight: '700',
    color: modernColors.text,
    marginBottom: 4,
  },
  weddingDate: {
    fontSize: 14,
    color: modernColors.textSecondary,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: modernColors.error,
    gap: 6,
    shadowColor: modernColors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  logoutButtonText: {
    color: modernColors.white,
    fontSize: 12,
    fontWeight: '600',
  },
  content: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 100,
  },
  noWeddingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  noWeddingContent: {
    alignItems: 'center',
  },
  noWeddingIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: modernColors.surface,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  noWeddingTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: modernColors.text,
    marginBottom: 12,
    textAlign: 'center',
  },
  noWeddingSubtitle: {
    fontSize: 16,
    color: modernColors.textSecondary,
    textAlign: 'center',
    marginBottom: 32,
    lineHeight: 24,
  },
  createWeddingButton: {
    backgroundColor: modernColors.primary,
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 12,
  },
  // New modern styles
  sectionDivider: {
    height: 1,
    backgroundColor: modernColors.divider,
    marginVertical: 24,
    marginHorizontal: 4,
  },
  guestStatsSection: {
    backgroundColor: modernColors.cardBackground,
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    shadowColor: modernColors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  guestStatsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  guestStatsHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  guestStatsIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: modernColors.primary + '20',
    justifyContent: 'center',
    alignItems: 'center',
  },
  guestStatsTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: modernColors.text,
    marginBottom: 2,
  },
  guestStatsSubtitle: {
    fontSize: 12,
    color: modernColors.textSecondary,
  },
  guestStatsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  guestStatCard: {
    flex: 1,
    backgroundColor: modernColors.accent,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  guestStatConfirmed: {
    backgroundColor: modernColors.success + '20',
  },
  guestStatPending: {
    backgroundColor: modernColors.warning + '20',
  },
  guestStatDeclined: {
    backgroundColor: modernColors.error + '20',
  },
  guestStatNumber: {
    fontSize: 24,
    fontWeight: '700',
    color: modernColors.text,
    marginBottom: 4,
  },
  guestStatNumberConfirmed: {
    color: modernColors.success,
  },
  guestStatNumberPending: {
    color: modernColors.warning,
  },
  guestStatNumberDeclined: {
    color: modernColors.error,
  },
  guestStatLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: modernColors.textSecondary,
    textAlign: 'center',
  },
  guestStatLabelConfirmed: {
    color: modernColors.success,
  },
  guestStatLabelPending: {
    color: modernColors.warning,
  },
  guestStatLabelDeclined: {
    color: modernColors.error,
  },
  suggestionsSection: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: modernColors.text,
  },
  sectionLink: {
    fontSize: 14,
    color: modernColors.primary,
    fontWeight: '600',
  },
  suggestionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  suggestionCard: {
    width: '22%',
    aspectRatio: 1,
    backgroundColor: modernColors.cardBackground,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 8,
    shadowColor: modernColors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    position: 'relative',
  },
  suggestionIcon: {
    marginBottom: 8,
  },
  suggestionText: {
    fontSize: 12,
    color: modernColors.text,
    fontWeight: '500',
    textAlign: 'center',
  },
  promoBadge: {
    position: 'absolute',
    top: 4,
    right: 4,
    backgroundColor: modernColors.success,
    borderRadius: 8,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  promoText: {
    fontSize: 10,
    color: modernColors.background,
    fontWeight: '600',
  },
  countdownSection: {
    marginBottom: 24,
  },
  countdownCard: {
    backgroundColor: modernColors.primary,
    borderRadius: 16,
  },
  countdownContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
  },
  countdownIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  countdownText: {
    flex: 1,
  },
  countdownNumber: {
    fontSize: 32,
    fontWeight: '700',
    color: modernColors.background,
  },
  countdownLabel: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  countdownDate: {
    alignItems: 'flex-end',
  },
  countdownWeddingDate: {
    fontSize: 16,
    fontWeight: '600',
    color: modernColors.background,
  },
  weddingLocation: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
    marginTop: 2,
  },
  promoSection: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 24,
  },
  promoCard: {
    flex: 1,
    backgroundColor: '#FEF3F2',
    borderRadius: 16,
    padding: 20,
  },
  promoContent: {
    alignItems: 'flex-start',
  },
  promoTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: modernColors.text,
    marginBottom: 12,
  },
  promoButton: {
    backgroundColor: modernColors.primary,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  promoCard2: {
    flex: 1,
    backgroundColor: '#F3F4F6',
    borderRadius: 16,
    padding: 20,
    justifyContent: 'center',
  },
  promoContent2: {
    alignItems: 'flex-start',
  },
  promoTitle2: {
    fontSize: 16,
    fontWeight: '700',
    color: modernColors.text,
    marginBottom: 4,
  },
  promoSubtitle2: {
    fontSize: 14,
    color: modernColors.textSecondary,
  },
  moreSection: {
    marginBottom: 24,
  },
  moreCard: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  moreImage: {
    width: '100%',
    height: 120,
    borderRadius: 16,
  },
  
  // Invite Partner Styles
  invitePartnerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FEF2F2',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    marginTop: 8,
    alignSelf: 'flex-start',
    gap: 6,
  },
  invitePartnerText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#EF4444',
  },
  
  // Modal Styles
  modalContainer: {
    flex: 1,
    backgroundColor: modernColors.background,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: modernColors.border,
    backgroundColor: modernColors.white,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: modernColors.text,
  },
  modalCloseButton: {
    padding: 4,
  },
  modalContent: {
    flex: 1,
    padding: 20,
  },
  inviteIconContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  inviteIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FEF2F2',
    justifyContent: 'center',
    alignItems: 'center',
  },
  inviteDescription: {
    fontSize: 16,
    color: modernColors.text,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 32,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: modernColors.text,
    marginBottom: 8,
  },
  emailInput: {
    borderWidth: 1,
    borderColor: modernColors.border,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: modernColors.text,
    backgroundColor: modernColors.white,
  },
  inviteNote: {
    fontSize: 14,
    color: modernColors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
  },
  modalActions: {
    flexDirection: 'row',
    padding: 20,
    gap: 12,
    backgroundColor: modernColors.white,
    borderTopWidth: 1,
    borderTopColor: modernColors.border,
  },
  modalButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelButton: {
    backgroundColor: modernColors.accent,
    borderWidth: 1,
    borderColor: modernColors.border,
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: modernColors.text,
  },
  inviteButton: {
    backgroundColor: '#EF4444',
    flexDirection: 'row',
    gap: 8,
  },
  inviteButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: modernColors.white,
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
});