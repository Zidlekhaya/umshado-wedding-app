-- 011_messaging_rls.sql
BEGIN;

ALTER TABLE threads ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE message_reads ENABLE ROW LEVEL SECURITY;
ALTER TABLE typing_presence ENABLE ROW LEVEL SECURITY;

-- Threads: only the vendor and the couple can see the thread
CREATE POLICY threads_select ON threads
  FOR SELECT USING (
    auth.uid() = couple_user_id OR
    EXISTS (SELECT 1 FROM vendor_profiles vp WHERE vp.id = vendor_id AND vp.user_id = auth.uid())
  );

CREATE POLICY threads_insert ON threads
  FOR INSERT WITH CHECK (
    -- only couples can create a thread initiating to a vendor
    auth.uid() = couple_user_id
  );

CREATE POLICY threads_update ON threads
  FOR UPDATE USING (
    auth.uid() = couple_user_id OR
    EXISTS (SELECT 1 FROM vendor_profiles vp WHERE vp.id = vendor_id AND vp.user_id = auth.uid())
  ) WITH CHECK (
    auth.uid() = couple_user_id OR
    EXISTS (SELECT 1 FROM vendor_profiles vp WHERE vp.id = vendor_id AND vp.user_id = auth.uid())
  );

-- Messages: only allow inserting if sender is part of thread
CREATE POLICY messages_select ON messages
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM threads t
      WHERE t.id = messages.thread_id
      AND (t.couple_user_id = auth.uid() OR EXISTS (SELECT 1 FROM vendor_profiles vp WHERE vp.id = t.vendor_id AND vp.user_id = auth.uid()))
    )
  );

CREATE POLICY messages_insert ON messages
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM threads t
      WHERE t.id = messages.thread_id
      AND (t.couple_user_id = auth.uid() OR EXISTS (SELECT 1 FROM vendor_profiles vp WHERE vp.id = t.vendor_id AND vp.user_id = auth.uid()))
    )
  );

CREATE POLICY messages_update ON messages
  FOR UPDATE USING (
    messages.sender_user_id = auth.uid()
  ) WITH CHECK (
    messages.sender_user_id = auth.uid()
  );

-- message_reads: user can insert/read their own read receipt
CREATE POLICY message_reads_select ON message_reads
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY message_reads_insert ON message_reads
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY message_reads_delete ON message_reads
  FOR DELETE USING (user_id = auth.uid());

-- typing_presence: user may upsert their typing status for a thread they belong to
CREATE POLICY typing_presence_select ON typing_presence
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM threads t
      WHERE t.id = typing_presence.thread_id
      AND (t.couple_user_id = auth.uid() OR EXISTS (SELECT 1 FROM vendor_profiles vp WHERE vp.id = t.vendor_id AND vp.user_id = auth.uid()))
    )
  );

CREATE POLICY typing_presence_insert ON typing_presence
  FOR INSERT WITH CHECK (
    user_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM threads t
      WHERE t.id = typing_presence.thread_id
      AND (t.couple_user_id = auth.uid() OR EXISTS (SELECT 1 FROM vendor_profiles vp WHERE vp.id = t.vendor_id AND vp.user_id = auth.uid()))
    )
  );

CREATE POLICY typing_presence_update ON typing_presence
  FOR UPDATE USING (
    user_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM threads t
      WHERE t.id = typing_presence.thread_id
      AND (t.couple_user_id = auth.uid() OR EXISTS (SELECT 1 FROM vendor_profiles vp WHERE vp.id = t.vendor_id AND vp.user_id = auth.uid()))
    )
  ) WITH CHECK (
    user_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM threads t
      WHERE t.id = typing_presence.thread_id
      AND (t.couple_user_id = auth.uid() OR EXISTS (SELECT 1 FROM vendor_profiles vp WHERE vp.id = t.vendor_id AND vp.user_id = auth.uid()))
    )
  );

CREATE POLICY typing_presence_delete ON typing_presence
  FOR DELETE USING (user_id = auth.uid());

COMMIT;








