import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface GenerateUploadUrlRequest {
  thread_id: string;
  filename: string;
  file_type: string;
  file_size: number;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Create Supabase client with service role key
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    )

    // Get the authorization header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('No authorization header')
    }

    // Create a client with the user's token to verify their identity
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: authHeader },
        },
      }
    )

    // Get the current user
    const { data: { user }, error: userError } = await supabase.auth.getUser()
    if (userError || !user) {
      throw new Error('Invalid user')
    }

    const { thread_id, filename, file_type, file_size }: GenerateUploadUrlRequest = await req.json()

    if (!thread_id || !filename || !file_type) {
      throw new Error('Missing required fields: thread_id, filename, file_type')
    }

    // Validate file size (max 10MB)
    const maxSize = 10 * 1024 * 1024 // 10MB
    if (file_size > maxSize) {
      throw new Error('File size exceeds 10MB limit')
    }

    // Validate file type
    const allowedTypes = [
      'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp',
      'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain', 'video/mp4', 'video/quicktime', 'video/x-msvideo'
    ]
    
    if (!allowedTypes.includes(file_type)) {
      throw new Error('File type not allowed')
    }

    // Verify user belongs to the thread
    const { data: thread, error: threadError } = await supabaseAdmin
      .from('threads')
      .select(`
        id,
        vendor_id,
        couple_user_id,
        vendor_profiles!inner(user_id)
      `)
      .eq('id', thread_id)
      .single()

    if (threadError || !thread) {
      throw new Error('Thread not found')
    }

    // Check if user is part of this thread
    const isCouple = thread.couple_user_id === user.id
    const isVendor = thread.vendor_profiles.user_id === user.id

    if (!isCouple && !isVendor) {
      throw new Error('User not authorized to upload files to this thread')
    }

    // Generate unique filename with timestamp
    const timestamp = Date.now()
    const fileExtension = filename.split('.').pop() || ''
    const sanitizedFilename = filename.replace(/[^a-zA-Z0-9.-]/g, '_')
    const uniqueFilename = `${timestamp}_${sanitizedFilename}`

    // Determine upload path based on user type
    const userType = isCouple ? 'couple' : 'vendor'
    const userId = isCouple ? user.id : thread.vendor_id
    const uploadPath = `${userType}_${userId}/threads/${thread_id}/${uniqueFilename}`

    // Generate signed URL for upload
    const { data: signedUrlData, error: signedUrlError } = await supabaseAdmin.storage
      .from('message-attachments')
      .createSignedUploadUrl(uploadPath, {
        expiresIn: 3600, // 1 hour
        upsert: false // Don't allow overwriting
      })

    if (signedUrlError) {
      throw new Error(`Failed to generate upload URL: ${signedUrlError.message}`)
    }

    // Get the public URL for the file (for after upload)
    const { data: publicUrlData } = supabaseAdmin.storage
      .from('message-attachments')
      .getPublicUrl(uploadPath)

    return new Response(
      JSON.stringify({ 
        success: true, 
        upload_url: signedUrlData.signedUrl,
        public_url: publicUrlData.publicUrl,
        file_path: uploadPath,
        attachment_metadata: {
          url: publicUrlData.publicUrl,
          filename: sanitizedFilename,
          size: file_size,
          mime: file_type,
          uploaded_at: new Date().toISOString()
        }
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )

  } catch (error) {
    console.error('Error in generate-upload-url function:', error)
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400 
      }
    )
  }
})








