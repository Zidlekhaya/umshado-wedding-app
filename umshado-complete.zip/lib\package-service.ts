import { supabase } from './supabase';

export interface Package {
  id: string;
  vendor_profile_id: string;
  name: string;
  description?: string;
  price?: number;
  duration_hours?: number;
  includes?: string[];
  excludes?: string[];
  terms_conditions?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  vendor_profiles?: {
    business_name: string;
    city: string;
    category: string;
  };
  // Legacy support for old package structure
  package_name?: string;
  short_description?: string;
  long_description?: string;
  price_type?: 'fixed' | 'range' | 'hourly' | 'per_person';
  price_min?: number;
  price_max?: number;
  currency?: string;
  has_availability?: boolean;
  package_items?: PackageItem[];
  package_addons?: PackageAddon[];
  package_images?: PackageImage[];
}

export interface PackageItem {
  id: string;
  package_id: string;
  item_name: string;
  item_description?: string;
  quantity: number;
  order_index: number;
}

export interface PackageAddon {
  id: string;
  package_id: string;
  title: string;
  description?: string;
  price: number;
  price_type: 'fixed' | 'per_person' | 'hourly';
  is_active: boolean;
}

export interface PackageImage {
  id: string;
  package_id: string;
  storage_path: string;
  alt_text?: string;
  order_index: number;
}

export interface CreatePackageData {
  name: string;
  description?: string;
  price?: number;
  duration_hours?: number;
  includes?: string[];
  excludes?: string[];
  terms_conditions?: string;
  is_active?: boolean;
  // Legacy support
  package_name?: string;
  short_description?: string;
  long_description?: string;
  price_type?: 'fixed' | 'range' | 'hourly' | 'per_person';
  price_min?: number;
  price_max?: number;
  currency?: string;
  has_availability?: boolean;
}

export interface UpdatePackageData extends Partial<CreatePackageData> {
  id: string;
}

// Package CRUD Operations
export async function listPackages(vendorProfileId?: string): Promise<Package[]> {
  // Try vendor_packages table first, fallback to packages table
  let query = supabase
    .from('vendor_packages')
    .select('*');

  if (vendorProfileId) {
    query = query.eq('vendor_id', vendorProfileId);
  }

  let { data, error } = await query.order('created_at', { ascending: false });

  // If vendor_packages table doesn't exist or has different schema, try packages table
  if (error && error.code === '42P01') {
    console.log('vendor_packages table not found, trying packages table...');
    query = supabase
      .from('packages')
      .select('*');

    if (vendorProfileId) {
      query = query.eq('vendor_id', vendorProfileId);
    }

    const result = await query.order('created_at', { ascending: false });
    data = result.data;
    error = result.error;
  }

  if (error) {
    console.error('Package service error:', error);
    throw error;
  }
  
  // Map the new schema to legacy format for compatibility
  return (data || []).map((pkg: any) => ({
    ...pkg,
    package_name: pkg.name,
    short_description: pkg.description,
    price_min: pkg.price,
    currency: 'ZAR',
    price_type: 'fixed' as const,
  })) as Package[];
}

export async function getPackage(packageId: string): Promise<Package> {
  const { data, error } = await supabase
    .from('vendor_packages')
    .select(`
      *,
      vendor_profiles!inner(business_name, city, category)
    `)
    .eq('id', packageId)
    .single();

  if (error) throw error;
  
  // Map to legacy format for compatibility
  return {
    ...data,
    package_name: data.name,
    short_description: data.description,
    price_min: data.price,
    currency: 'ZAR',
    price_type: 'fixed' as const,
  } as Package;
}

export async function createPackage(vendorProfileId: string, packageData: CreatePackageData): Promise<Package> {
  // Map legacy data to new schema
  const newPackageData = {
    vendor_profile_id: vendorProfileId,
    name: packageData.name || packageData.package_name || '',
    description: packageData.description || packageData.short_description,
    price: packageData.price || packageData.price_min,
    duration_hours: packageData.duration_hours,
    includes: packageData.includes || [],
    excludes: packageData.excludes || [],
    terms_conditions: packageData.terms_conditions,
    is_active: packageData.is_active ?? true,
  };

  const { data, error } = await supabase
    .from('vendor_packages')
    .insert(newPackageData)
    .select()
    .single();

  if (error) throw error;
  
  // Map back to legacy format for compatibility
  return {
    ...data,
    package_name: data.name,
    short_description: data.description,
    price_min: data.price,
    currency: 'ZAR',
    price_type: 'fixed' as const,
  } as Package;
}

export async function updatePackage(packageData: UpdatePackageData): Promise<Package> {
  const { id, ...updateData } = packageData;
  
  // Map legacy data to new schema
  const newUpdateData: any = {};
  if (updateData.name || updateData.package_name) {
    newUpdateData.name = updateData.name || updateData.package_name;
  }
  if (updateData.description || updateData.short_description) {
    newUpdateData.description = updateData.description || updateData.short_description;
  }
  if (updateData.price || updateData.price_min) {
    newUpdateData.price = updateData.price || updateData.price_min;
  }
  if (updateData.duration_hours !== undefined) {
    newUpdateData.duration_hours = updateData.duration_hours;
  }
  if (updateData.includes) {
    newUpdateData.includes = updateData.includes;
  }
  if (updateData.excludes) {
    newUpdateData.excludes = updateData.excludes;
  }
  if (updateData.terms_conditions) {
    newUpdateData.terms_conditions = updateData.terms_conditions;
  }
  if (updateData.is_active !== undefined) {
    newUpdateData.is_active = updateData.is_active;
  }

  const { data, error } = await supabase
    .from('vendor_packages')
    .update(newUpdateData)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  
  // Map back to legacy format for compatibility
  return {
    ...data,
    package_name: data.name,
    short_description: data.description,
    price_min: data.price,
    currency: 'ZAR',
    price_type: 'fixed' as const,
  } as Package;
}

export async function deletePackage(packageId: string): Promise<void> {
  const { error } = await supabase
    .from('vendor_packages')
    .delete()
    .eq('id', packageId);

  if (error) throw error;
}

// Package Items Management
export async function addPackageItem(packageId: string, itemData: Omit<PackageItem, 'id' | 'package_id'>): Promise<PackageItem> {
  const { data, error } = await supabase
    .from('package_items')
    .insert({
      package_id: packageId,
      ...itemData,
    })
    .select()
    .single();

  if (error) throw error;
  return data as PackageItem;
}

export async function updatePackageItem(itemId: string, itemData: Partial<PackageItem>): Promise<PackageItem> {
  const { data, error } = await supabase
    .from('package_items')
    .update(itemData)
    .eq('id', itemId)
    .select()
    .single();

  if (error) throw error;
  return data as PackageItem;
}

export async function deletePackageItem(itemId: string): Promise<void> {
  const { error } = await supabase
    .from('package_items')
    .delete()
    .eq('id', itemId);

  if (error) throw error;
}

// Package Addons Management
export async function addPackageAddon(packageId: string, addonData: Omit<PackageAddon, 'id' | 'package_id'>): Promise<PackageAddon> {
  const { data, error } = await supabase
    .from('package_addons')
    .insert({
      package_id: packageId,
      ...addonData,
    })
    .select()
    .single();

  if (error) throw error;
  return data as PackageAddon;
}

export async function updatePackageAddon(addonId: string, addonData: Partial<PackageAddon>): Promise<PackageAddon> {
  const { data, error } = await supabase
    .from('package_addons')
    .update(addonData)
    .eq('id', addonId)
    .select()
    .single();

  if (error) throw error;
  return data as PackageAddon;
}

export async function deletePackageAddon(addonId: string): Promise<void> {
  const { error } = await supabase
    .from('package_addons')
    .delete()
    .eq('id', addonId);

  if (error) throw error;
}

// Package Images Management
export async function addPackageImage(packageId: string, imageData: Omit<PackageImage, 'id' | 'package_id'>): Promise<PackageImage> {
  const { data, error } = await supabase
    .from('package_images')
    .insert({
      package_id: packageId,
      ...imageData,
    })
    .select()
    .single();

  if (error) throw error;
  return data as PackageImage;
}

export async function updatePackageImage(imageId: string, imageData: Partial<PackageImage>): Promise<PackageImage> {
  const { data, error } = await supabase
    .from('package_images')
    .update(imageData)
    .eq('id', imageId)
    .select()
    .single();

  if (error) throw error;
  return data as PackageImage;
}

export async function deletePackageImage(imageId: string): Promise<void> {
  const { error } = await supabase
    .from('package_images')
    .delete()
    .eq('id', imageId);

  if (error) throw error;
}

// Utility functions
export function formatPrice(pkg: Package): string {
  const currency = pkg.currency || 'R';
  
  if (pkg.price || pkg.price_min) {
    const price = pkg.price || pkg.price_min || 0;
    if (pkg.price_type === 'fixed' || !pkg.price_type) {
      return `${currency}${price.toLocaleString()}`;
    } else if (pkg.price_type === 'range' && pkg.price_max) {
      return `${currency}${price.toLocaleString()} - ${currency}${pkg.price_max.toLocaleString()}`;
    } else if (pkg.price_type === 'per_person') {
      return `${currency}${price.toLocaleString()}/person`;
    } else if (pkg.price_type === 'hourly') {
      return `${currency}${price.toLocaleString()}/hour`;
    }
    return `${currency}${price.toLocaleString()}`;
  }
  return 'Price on request';
}

export function getPackageStatus(pkg: Package): string {
  if (!pkg.is_active) return 'Inactive';
  if (pkg.has_availability) return 'Available';
  return 'Active';
}
