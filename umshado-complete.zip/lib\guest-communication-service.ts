import { supabase } from './supabase';

export type RSVPResponse = 'going' | 'maybe' | 'declined' | 'no_reply';
export type CommunicationType = 'invite_sent' | 'reminder_sent' | 'rsvp_received' | 'message_sent' | 'call_made' | 'email_sent';
export type CommunicationStatus = 'sent' | 'delivered' | 'read' | 'failed';

export interface GuestRSVP {
  id: string;
  wedding_id: string;
  guest_id: string;
  response: RSVPResponse;
  plus_ones: number;
  dietary_requirements?: string | null;
  song_requests?: string | null;
  special_requests?: string | null;
  responded_at?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface GuestCommunication {
  id: string;
  wedding_id: string;
  guest_id: string;
  communication_type: CommunicationType;
  message_content?: string | null;
  template_id?: string | null;
  sent_at: string;
  status: CommunicationStatus;
  created_at?: string;
}

export interface SeatingChart {
  id: string;
  wedding_id: string;
  table_name: string;
  table_number: number;
  capacity: number;
  created_at?: string;
  updated_at?: string;
}

export interface SeatingAssignment {
  id: string;
  wedding_id: string;
  guest_id: string;
  table_id: string;
  seat_number?: number | null;
  notes?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface RSVPSummary {
  total_invited: number;
  going: number;
  maybe: number;
  declined: number;
  no_reply: number;
  response_rate: number;
  total_guests: number; // including plus-ones
}

export interface CommunicationSummary {
  total_communications: number;
  by_type: Record<CommunicationType, number>;
  recent_activity: GuestCommunication[];
  response_rate: number;
}

// RSVP Management
export async function getGuestRSVP(weddingId: string, guestId: string): Promise<GuestRSVP | null> {
  const { data, error } = await supabase
    .from('guest_rsvp')
    .select('*')
    .eq('wedding_id', weddingId)
    .eq('guest_id', guestId)
    .single();

  if (error && error.code !== 'PGRST116') throw error;
  return data as GuestRSVP | null;
}

export async function updateGuestRSVP(weddingId: string, guestId: string, rsvpData: Partial<GuestRSVP>): Promise<GuestRSVP> {
  const { data, error } = await supabase
    .from('guest_rsvp')
    .upsert({
      wedding_id: weddingId,
      guest_id: guestId,
      ...rsvpData,
      responded_at: rsvpData.response ? new Date().toISOString() : null,
    })
    .select()
    .single();

  if (error) throw error;
  return data as GuestRSVP;
}

export async function getAllRSVPs(weddingId: string): Promise<GuestRSVP[]> {
  const { data, error } = await supabase
    .from('guest_rsvp')
    .select('*')
    .eq('wedding_id', weddingId)
    .order('responded_at', { ascending: false });

  if (error) throw error;
  return data as GuestRSVP[];
}

export async function getRSVPSummary(weddingId: string): Promise<RSVPSummary> {
  const { data: rsvps, error } = await supabase
    .from('guest_rsvp')
    .select('response, plus_ones')
    .eq('wedding_id', weddingId);

  if (error) throw error;

  const summary = {
    total_invited: rsvps.length,
    going: 0,
    maybe: 0,
    declined: 0,
    no_reply: 0,
    response_rate: 0,
    total_guests: 0,
  };

  rsvps.forEach(rsvp => {
    summary[rsvp.response]++;
    if (rsvp.response === 'going') {
      summary.total_guests += 1 + (rsvp.plus_ones || 0);
    }
  });

  summary.response_rate = summary.total_invited > 0 
    ? ((summary.going + summary.maybe + summary.declined) / summary.total_invited) * 100 
    : 0;

  return summary;
}

// Communication Management
export async function logCommunication(
  weddingId: string, 
  guestId: string, 
  type: CommunicationType, 
  content?: string, 
  templateId?: string
): Promise<GuestCommunication> {
  const { data, error } = await supabase
    .from('guest_communication')
    .insert({
      wedding_id: weddingId,
      guest_id: guestId,
      communication_type: type,
      message_content: content,
      template_id: templateId,
      sent_at: new Date().toISOString(),
      status: 'sent',
    })
    .select()
    .single();

  if (error) throw error;
  return data as GuestCommunication;
}

export async function getGuestCommunications(weddingId: string, guestId: string): Promise<GuestCommunication[]> {
  const { data, error } = await supabase
    .from('guest_communication')
    .select('*')
    .eq('wedding_id', weddingId)
    .eq('guest_id', guestId)
    .order('sent_at', { ascending: false });

  if (error) throw error;
  return data as GuestCommunication[];
}

export async function getCommunicationSummary(weddingId: string): Promise<CommunicationSummary> {
  const { data: communications, error } = await supabase
    .from('guest_communication')
    .select('*')
    .eq('wedding_id', weddingId)
    .order('sent_at', { ascending: false });

  if (error) throw error;

  const by_type: Record<CommunicationType, number> = {
    invite_sent: 0,
    reminder_sent: 0,
    rsvp_received: 0,
    message_sent: 0,
    call_made: 0,
    email_sent: 0,
  };

  communications.forEach(comm => {
    by_type[comm.communication_type]++;
  });

  return {
    total_communications: communications.length,
    by_type,
    recent_activity: communications.slice(0, 10),
    response_rate: 0, // Will be calculated based on RSVP data
  };
}

// Bulk Messaging
export async function sendBulkMessage(
  weddingId: string, 
  guestIds: string[], 
  messageContent: string, 
  templateId?: string
): Promise<GuestCommunication[]> {
  const communications = guestIds.map(guestId => ({
    wedding_id: weddingId,
    guest_id: guestId,
    communication_type: 'message_sent' as CommunicationType,
    message_content: messageContent,
    template_id: templateId,
    sent_at: new Date().toISOString(),
    status: 'sent' as CommunicationStatus,
  }));

  const { data, error } = await supabase
    .from('guest_communication')
    .insert(communications)
    .select();

  if (error) throw error;
  return data as GuestCommunication[];
}

// Seating Chart Management
export async function createSeatingChart(weddingId: string, tableData: Omit<SeatingChart, 'id' | 'wedding_id' | 'created_at' | 'updated_at'>): Promise<SeatingChart> {
  const { data, error } = await supabase
    .from('seating_chart')
    .insert({
      wedding_id: weddingId,
      ...tableData,
    })
    .select()
    .single();

  if (error) throw error;
  return data as SeatingChart;
}

export async function getSeatingChart(weddingId: string): Promise<SeatingChart[]> {
  const { data, error } = await supabase
    .from('seating_chart')
    .select('*')
    .eq('wedding_id', weddingId)
    .order('table_number', { ascending: true });

  if (error) throw error;
  return data as SeatingChart[];
}

export async function assignGuestToTable(
  weddingId: string, 
  guestId: string, 
  tableId: string, 
  seatNumber?: number, 
  notes?: string
): Promise<SeatingAssignment> {
  const { data, error } = await supabase
    .from('seating_assignments')
    .upsert({
      wedding_id: weddingId,
      guest_id: guestId,
      table_id: tableId,
      seat_number: seatNumber,
      notes: notes,
    })
    .select()
    .single();

  if (error) throw error;
  return data as SeatingAssignment;
}

export async function getSeatingAssignments(weddingId: string): Promise<SeatingAssignment[]> {
  const { data, error } = await supabase
    .from('seating_assignments')
    .select(`
      *,
      seating_chart:table_id (
        table_name,
        table_number,
        capacity
      )
    `)
    .eq('wedding_id', weddingId);

  if (error) throw error;
  return data as SeatingAssignment[];
}

// Utility functions
export function getResponseColor(response: RSVPResponse): string {
  const colors = {
    going: '#10B981',
    maybe: '#F59E0B',
    declined: '#EF4444',
    no_reply: '#6B7280',
  };
  return colors[response];
}

export function getResponseIcon(response: RSVPResponse): string {
  const icons = {
    going: 'check-circle',
    maybe: 'help-circle',
    declined: 'x-circle',
    no_reply: 'clock',
  };
  return icons[response];
}

export function getCommunicationTypeIcon(type: CommunicationType): string {
  const icons = {
    invite_sent: 'mail',
    reminder_sent: 'bell',
    rsvp_received: 'check',
    message_sent: 'message-circle',
    call_made: 'phone',
    email_sent: 'at-sign',
  };
  return icons[type];
}

export function formatResponseRate(rate: number): string {
  return `${rate.toFixed(1)}%`;
}

export function getDaysUntilWedding(weddingDate: string): number {
  const today = new Date();
  const wedding = new Date(weddingDate);
  const diffTime = wedding.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}
















