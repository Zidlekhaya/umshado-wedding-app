import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Image, TextInput, SafeAreaView, Alert } from 'react-native';
import { Stack, router, useLocalSearchParams } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { Loading } from '@/components/ui/Loading';
import { supabase } from '@/lib/supabase';
import { Logo } from '@/src/components/ui/Logo';
import PackageManagementModal from '@/components/package-management/PackageManagementModal';
import { Package, listPackages, deletePackage, formatPrice } from '@/lib/package-service';

const colors = {
  background: '#f0fbea',
  primary: '#00a86b',
  text: '#1A1A1A',
  textLight: '#6B7280',
  border: '#E5E7EB',
  success: '#10B981',
  error: '#EF4444',
  warning: '#F59E0B',
  white: '#FFFFFF',
  urgent: '#FF6B6B',
  high: '#FF8E53',
  medium: '#FFA500',
  low: '#4ECDC4',
  completed: '#95E1A3',
  pending: '#FFD93D',
  inProgress: '#6BCF7F',
  // Enhanced colors for better UI
  headerBg: '#F8FAFC',
  headerText: '#1E293B',
  cardShadow: 'rgba(0, 0, 0, 0.1)',
  accent: '#F3F4F6',
};

// Package interface is now imported from package-service.ts

export default function MarketplacePackages() {
  const { vendor } = useLocalSearchParams();
  const [loading, setLoading] = useState(true);
  const [packages, setPackages] = useState<Package[]>([]);
  const [filteredPackages, setFilteredPackages] = useState<Package[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [priceRange] = useState({ min: 0, max: 100000 });
  const [vendorName, setVendorName] = useState<string>('');
  const [currentVendorProfile, setCurrentVendorProfile] = useState<any>(null);
  const [showManagementModal, setShowManagementModal] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<Package | null>(null);

  const categories = [
    { id: 'all', name: 'All Categories' },
    { id: 'photography', name: 'Photography' },
    { id: 'catering', name: 'Catering' },
    { id: 'venue', name: 'Venue' },
    { id: 'music', name: 'Music' },
    { id: 'flowers', name: 'Flowers' },
    { id: 'beauty', name: 'Beauty' },
    { id: 'transport', name: 'Transport' },
  ];

  const loadPackages = useCallback(async () => {
    try {
      setLoading(true);

      // Get current user
      const { data: { user } } = await supabase.auth.getUser();

      // Get current user's vendor profile if they are a vendor
      if (user) {
        const { data: vendorProfile } = await supabase
          .from('vendor_profiles')
          .select('id, business_name, user_id')
          .eq('user_id', user.id)
          .single();
        
        if (vendorProfile) {
          setCurrentVendorProfile(vendorProfile);
          console.log('Current vendor profile:', vendorProfile);
        }
      }

      // If vendor filter is provided, get vendor name first
      if (vendor) {
        const { data: vendorData } = await supabase
          .from('vendor_profiles')
          .select('business_name')
          .eq('id', vendor)
          .single();
        
        if (vendorData) {
          setVendorName(vendorData.business_name);
        }
      }

      // Use the new package service
      const vendorPackages = await listPackages(vendor as string);
      console.log('Packages loaded:', vendorPackages?.length || 0);
      setPackages(vendorPackages || []);
    } catch (error: any) {
      console.error('Error loading packages:', error);
    } finally {
      setLoading(false);
    }
  }, [vendor]);

  useEffect(() => {
    loadPackages();
  }, [loadPackages]);

  const filterPackages = useCallback(() => {
    let filtered = [...packages];

    // Search filter
    if (searchQuery.trim()) {
      filtered = filtered.filter(pkg =>
        pkg.package_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (pkg.short_description && pkg.short_description.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (pkg.vendor_profiles?.business_name && pkg.vendor_profiles.business_name.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    // Category filter
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(pkg =>
        pkg.vendor_profiles?.category?.toLowerCase() === selectedCategory.toLowerCase()
      );
    }

    // Price filter
    filtered = filtered.filter(pkg => {
      const minPrice = pkg.price_min || 0;
      const maxPrice = pkg.price_max || 0;
      return minPrice >= priceRange.min && maxPrice <= priceRange.max;
    });

    setFilteredPackages(filtered);
  }, [packages, searchQuery, selectedCategory, priceRange]);

  useEffect(() => {
    filterPackages();
  }, [filterPackages]);

  const handleEditPackage = (pkg: Package) => {
    console.log('Edit package clicked:', pkg);
    setSelectedPackage(pkg);
    setShowManagementModal(true);
  };

  const handleDeletePackage = async (pkg: Package) => {
    console.log('Delete package clicked:', pkg);
    Alert.alert(
      'Delete Package',
      `Are you sure you want to delete "${pkg.package_name}"? This action cannot be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              console.log('Deleting package:', pkg.id);
              setLoading(true);
              await deletePackage(pkg.id);
              await loadPackages();
              Alert.alert('Success', 'Package deleted successfully!');
            } catch (error) {
              console.error('Error deleting package:', error);
              Alert.alert('Error', 'Failed to delete package');
            } finally {
              setLoading(false);
            }
          },
        },
      ]
    );
  };

  const handlePackageUpdated = async (updatedPackage: Package) => {
    setPackages(packages.map(pkg => pkg.id === updatedPackage.id ? updatedPackage : pkg));
    setShowManagementModal(false);
    setSelectedPackage(null);
  };

  const isPackageOwner = (pkg: Package) => {
    if (!currentVendorProfile) return false;
    return pkg.vendor_id === currentVendorProfile.id;
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <Stack.Screen
          options={{
            title: vendor ? `${vendorName} Packages` : 'Wedding Packages',
            headerLeft: () => <Logo size="small" showText={false} />,
            headerRight: vendor ? () => (
              <TouchableOpacity onPress={() => router.back()} style={styles.headerButton}>
                <Feather name="x" size={24} color={colors.primary} />
              </TouchableOpacity>
            ) : undefined
          }}
        />
        <View style={styles.loadingContainer}>
          <Loading size="large" color={colors.primary} text="Loading packages..." />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen
        options={{
          headerShown: false,
        }}
      />
      
      {/* Custom Header */}
      <View style={styles.headerSection}>
        <View style={styles.headerTop}>
          <Logo size="small" showText={false} />
          <Text style={styles.headerTitle}>
            {vendor ? `${vendorName} Packages` : 'Wedding Packages'}
          </Text>
          {vendor && (
            <TouchableOpacity 
              style={styles.backButton}
              onPress={() => router.back()}
            >
              <Feather name="x" size={16} color={colors.white} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      <View style={styles.content}>
        {/* Search Bar */}
        <View style={styles.searchCard}>
          <View style={styles.searchContainer}>
            <Feather name="search" size={20} color={colors.textLight} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search packages, vendors..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholderTextColor={colors.textLight}
            />
          </View>
        </View>

        {/* Category Filter */}
        <View style={styles.filtersSection}>
          <Text style={styles.filtersTitle}>Filter by Category</Text>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            style={styles.filtersScroll}
          >
            {categories.map((category) => (
              <TouchableOpacity
                key={category.id}
                style={[
                  styles.filterButton,
                  selectedCategory === category.id && styles.activeFilter
                ]}
                onPress={() => setSelectedCategory(category.id)}
              >
                <Text style={[
                  styles.filterText,
                  selectedCategory === category.id && styles.activeFilterText
                ]}>
                  {category.name}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Results Count */}
        <View style={styles.resultsContainer}>
          <Text style={styles.resultsText}>
            {filteredPackages.length} package{filteredPackages.length !== 1 ? 's' : ''} found
          </Text>
        </View>

        {/* Packages Grid */}
        <ScrollView 
          style={styles.packagesContainer}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.packagesGrid}
        >
          {filteredPackages.map((pkg) => (
            <View key={pkg.id} style={styles.packageCard}>
              <TouchableOpacity
                style={styles.card}
                onPress={() => router.push(`/(marketplace)/packages/${pkg.slug}` as any)}
              >
                {/* Package Image */}
                <View style={styles.imageContainer}>
                  {pkg.package_images && pkg.package_images.length > 0 ? (
                    <Image 
                      source={{ uri: pkg.package_images[0].storage_path }} 
                      style={styles.packageImage}
                      resizeMode="cover"
                    />
                  ) : (
                    <View style={styles.imagePlaceholder}>
                      <Feather name="package" size={32} color={colors.textLight} />
                    </View>
                  )}
                  <View style={styles.priceBadge}>
                    <Text style={styles.priceBadgeText}>{formatPrice(pkg)}</Text>
                  </View>
                  
                </View>

                {/* Package Info */}
                <View style={styles.packageInfo}>
                  <Text style={styles.packageName} numberOfLines={2}>
                    {pkg.package_name}
                  </Text>
                  <Text style={styles.vendorName}>
                    {pkg.vendor_profiles?.business_name}
                  </Text>
                  <Text style={styles.packageDescription} numberOfLines={2}>
                    {pkg.short_description}
                  </Text>
                  
                  {/* Package Meta */}
                  <View style={styles.packageMeta}>
                    <View style={styles.metaItem}>
                      <Feather name="map-pin" size={12} color={colors.textLight} />
                      <Text style={styles.metaText}>{pkg.vendor_profiles?.city}</Text>
                    </View>
                    {pkg.duration_hours && (
                      <View style={styles.metaItem}>
                        <Feather name="clock" size={12} color={colors.textLight} />
                        <Text style={styles.metaText}>{pkg.duration_hours}h</Text>
                      </View>
                    )}
                  </View>

                  {/* Package Items Preview */}
                  {pkg.package_items && pkg.package_items.length > 0 && (
                    <View style={styles.itemsPreview}>
                      <Text style={styles.itemsPreviewText}>
                        Includes: {pkg.package_items.slice(0, 2).map(item => item.item_name).join(', ')}
                        {pkg.package_items.length > 2 && ` +${pkg.package_items.length - 2} more`}
                      </Text>
                    </View>
                  )}

                  {/* Action Buttons for Package Owner */}
                  {isPackageOwner(pkg) && (
                    <View style={styles.actionButtonsContainer}>
                      <TouchableOpacity
                        style={styles.actionButton}
                        onPress={() => handleEditPackage(pkg)}
                      >
                        <Feather name="edit" size={16} color={colors.primary} />
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={styles.actionButton}
                        onPress={() => handleDeletePackage(pkg)}
                      >
                        <Feather name="trash-2" size={16} color={colors.error} />
                      </TouchableOpacity>
                    </View>
                  )}
                </View>
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>

        {filteredPackages.length === 0 && (
          <View style={styles.emptyCard}>
            <View style={styles.emptyIcon}>
              <Feather name="search" size={48} color={colors.border} />
            </View>
            <Text style={styles.emptyTitle}>No Packages Found</Text>
            <Text style={styles.emptySubtitle}>
              Try adjusting your search or filters to find more packages
            </Text>
          </View>
        )}
      </View>

      {/* Package Management Modal */}
      <PackageManagementModal
        visible={showManagementModal}
        package={selectedPackage}
        onClose={() => {
          setShowManagementModal(false);
          setSelectedPackage(null);
        }}
        onPackageUpdated={handlePackageUpdated}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  // Header Section
  headerSection: {
    backgroundColor: colors.headerBg,
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: colors.headerText,
  },
  backButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  headerButton: {
    padding: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  searchCard: {
    backgroundColor: colors.white,
    padding: 16,
    borderRadius: 16,
    marginBottom: 20,
    shadowColor: colors.cardShadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    borderWidth: 1,
    borderColor: colors.border,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: colors.text,
  },
  // Filters
  filtersSection: {
    marginBottom: 20,
  },
  filtersTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  filtersScroll: {
    paddingHorizontal: 4,
  },
  filterButton: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    marginRight: 8,
    shadowColor: colors.cardShadow,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  activeFilter: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  filterText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textLight,
  },
  activeFilterText: {
    color: colors.white,
  },
  resultsContainer: {
    marginBottom: 20,
  },
  resultsText: {
    fontSize: 14,
    color: colors.textLight,
  },
  packagesContainer: {
    flex: 1,
  },
  packagesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    paddingBottom: 20,
  },
  packageCard: {
    width: '48%',
  },
  card: {
    backgroundColor: colors.white,
    borderRadius: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    height: 320,
  },
  imageContainer: {
    height: 120,
    position: 'relative',
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    overflow: 'hidden',
  },
  packageImage: {
    width: '100%',
    height: '100%',
  },
  imagePlaceholder: {
    width: '100%',
    height: '100%',
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  priceBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: colors.primary,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  priceBadgeText: {
    fontSize: 12,
    color: colors.white,
    fontWeight: '600',
  },
  packageInfo: {
    padding: 16,
    flex: 1,
  },
  packageName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  vendorName: {
    fontSize: 14,
    color: colors.primary,
    fontWeight: '500',
    marginBottom: 4,
  },
  packageDescription: {
    fontSize: 14,
    color: colors.textLight,
    marginBottom: 8,
    lineHeight: 20,
  },
  packageMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 8,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metaText: {
    fontSize: 12,
    color: colors.textLight,
  },
  itemsPreview: {
    marginTop: 'auto',
  },
  itemsPreviewText: {
    fontSize: 12,
    color: colors.textLight,
    fontStyle: 'italic',
  },
  // Empty State
  emptyCard: {
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: 40,
    alignItems: 'center',
    marginTop: 20,
    shadowColor: colors.cardShadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    borderWidth: 1,
    borderColor: colors.border,
  },
  emptyIcon: {
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: colors.textLight,
    textAlign: 'center',
    lineHeight: 20,
  },
  // Action Buttons (matching task system style)
  actionButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: 12,
    gap: 8,
  },
  actionButton: {
    backgroundColor: colors.white,
    borderRadius: 8,
    width: 36,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
});
