export type TaskStatus = 'open' | 'done';

export interface Task {
  id: string;
  wedding_id: string;
  title: string;
  due_date?: string | null; // ISO date
  status: TaskStatus;
  notes?: string | null;
  remind_at?: string | null; // ISO date for reminder
  created_at?: string;
}
