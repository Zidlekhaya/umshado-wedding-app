-- Debug script to check guests table and RLS policies

-- 1. Check if guests table exists and its structure
SELECT 
  table_name, 
  column_name, 
  data_type, 
  is_nullable
FROM information_schema.columns 
WHERE table_name = 'guests' 
ORDER BY ordinal_position;

-- 2. Check if RLS is enabled on guests table
SELECT 
  schemaname, 
  tablename, 
  rowsecurity 
FROM pg_tables 
WHERE tablename = 'guests';

-- 3. List all policies on guests table
SELECT 
  schemaname, 
  tablename, 
  policyname, 
  permissive, 
  roles, 
  cmd, 
  qual,
  with_check
FROM pg_policies 
WHERE tablename = 'guests';

-- 4. Check if wedding table exists and has data
SELECT 
  id, 
  owner_id, 
  slug,
  city,
  created_at
FROM wedding 
LIMIT 5;

-- 5. Check current user context
SELECT auth.uid() as current_user_id;

-- 6. Test the RLS policy logic manually
SELECT 
  w.id as wedding_id,
  w.owner_id,
  (w.owner_id = auth.uid()) as is_owner
FROM wedding w 
WHERE w.owner_id = auth.uid();
