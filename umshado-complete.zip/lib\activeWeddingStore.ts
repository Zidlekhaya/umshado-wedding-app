import { create } from 'zustand';

type ActiveWeddingState = {
  id: string | null;
  name: string | null;
  set: (id: string | null, name?: string | null) => void;
  clear: () => void;
};

export const useActiveWedding = create<ActiveWeddingState>((set) => ({
  id: null,
  name: null,
  set: (id, name = null) => set({ id, name }),
  clear: () => set({ id: null, name: null }),
}));






























