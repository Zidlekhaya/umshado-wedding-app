// Manual guest creation test
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL || 'YOUR_SUPABASE_URL';
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || 'YOUR_SUPABASE_ANON_KEY';

const supabase = createClient(supabaseUrl, supabaseKey);

async function testManualGuest() {
  try {
    console.log('🧪 Testing manual guest creation...\n');
    
    // Get the first wedding
    const { data: weddings, error: weddingError } = await supabase
      .from('wedding')
      .select('id, name')
      .limit(1);
    
    if (weddingError || !weddings || weddings.length === 0) {
      console.error('❌ No wedding found. Please create a wedding first.');
      return;
    }
    
    const wedding = weddings[0];
    console.log('Using wedding:', wedding.name);
    
    // Try to create a guest manually
    const testGuest = {
      wedding_id: wedding.id,
      full_name: 'Test Contact Guest',
      email: 'test@example.com',
      phone: '+1234567890',
      side: 'both',
      rsvp: 'no_reply',
    };
    
    console.log('Creating guest with data:', testGuest);
    
    const { data: newGuest, error: createError } = await supabase
      .from('guest')
      .insert([testGuest])
      .select()
      .single();
    
    if (createError) {
      console.error('❌ Guest creation failed:', createError);
      console.log('Error details:', JSON.stringify(createError, null, 2));
    } else {
      console.log('✅ Guest created successfully:', newGuest);
      
      // Clean up
      await supabase.from('guest').delete().eq('id', newGuest.id);
      console.log('✅ Test guest cleaned up');
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error);
  }
}

testManualGuest();










