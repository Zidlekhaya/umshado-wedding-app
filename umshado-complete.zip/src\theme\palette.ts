export const palette = {
  bg: '#D4A373',
  surface: '#F5E8C7',
  surfaceMuted: '#EFE0C4',
  textPrimary: '#2B1E12',
  textOnDark: '#FFFFFF',
  border: '#D3D3D3',
  accent: '#A9B7A0',
  primary: '#8C2F2F',
  primaryDark: '#6E1F1F',
  success: '#25D366',
  tabbar: '#6B4F3A',
  chipGoing: '#DDF3E5',
  chipMaybe: '#F7EFD7',
  chipDeclined: '#FCE8E6',
  chipNoReply: '#E9EEF5',
};




