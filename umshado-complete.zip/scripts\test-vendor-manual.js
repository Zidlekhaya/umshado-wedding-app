#!/usr/bin/env node

/**
 * Test Manual Vendor Profile Creation
 * This script tests vendor profile creation without relying on triggers
 */

const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing Supabase environment variables');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function testManualVendorCreation() {
  console.log('🧪 Testing Manual Vendor Profile Creation...\n');

  try {
    // Test 1: Check if vendor_profiles table exists
    console.log('1️⃣ Checking vendor_profiles table...');
    const { data: tableCheck, error: tableError } = await supabase
      .from('vendor_profiles')
      .select('id')
      .limit(1);

    if (tableError) {
      console.error('❌ vendor_profiles table error:', tableError.message);
      return;
    }

    console.log('✅ vendor_profiles table exists and is accessible');

    // Test 2: Create a test user account (without vendor metadata)
    console.log('\n2️⃣ Creating test user account...');
    const testEmail = `test-user-${Date.now()}@example.com`;
    const testPassword = 'testpassword123';

    const { data: signupData, error: signupError } = await supabase.auth.signUp({
      email: testEmail,
      password: testPassword
    });

    if (signupError) {
      console.error('❌ User signup error:', signupError.message);
      return;
    }

    console.log('✅ Test user account created:', testEmail);

    // Test 3: Manually create vendor profile
    console.log('\n3️⃣ Creating vendor profile manually...');
    
    const { data: profileData, error: profileError } = await supabase
      .from('vendor_profiles')
      .insert([{
        user_id: signupData.user.id,
        business_name: 'Test Photography Studio',
        business_description: 'Professional wedding photography services',
        category: 'photography',
        contact_email: testEmail,
        city: 'Cape Town',
        location: 'Cape Town',
        is_active: true,
        is_verified: false
      }])
      .select()
      .single();

    if (profileError) {
      console.error('❌ Vendor profile creation error:', profileError.message);
      return;
    }

    console.log('✅ Vendor profile created manually:', profileData.business_name);

    // Test 4: Update user metadata to vendor
    console.log('\n4️⃣ Updating user metadata to vendor...');
    
    const { error: updateError } = await supabase.auth.updateUser({
      data: {
        user_type: 'vendor',
        business_name: 'Test Photography Studio',
        category: 'photography',
        location: 'Cape Town'
      }
    });

    if (updateError) {
      console.error('❌ User metadata update error:', updateError.message);
    } else {
      console.log('✅ User metadata updated to vendor');
    }

    // Test 5: Test vendor sign in
    console.log('\n5️⃣ Testing vendor sign in...');
    
    // Sign out first
    await supabase.auth.signOut();

    const { data: signinData, error: signinError } = await supabase.auth.signInWithPassword({
      email: testEmail,
      password: testPassword
    });

    if (signinError) {
      console.error('❌ Vendor sign in error:', signinError.message);
      return;
    }

    console.log('✅ Vendor sign in successful');
    console.log('   User type:', signinData.user.user_metadata?.user_type);

    // Test 6: Verify vendor profile is accessible
    console.log('\n6️⃣ Verifying vendor profile access...');
    
    const { data: profileCheck, error: profileCheckError } = await supabase
      .from('vendor_profiles')
      .select('*')
      .eq('user_id', signinData.user.id)
      .single();

    if (profileCheckError) {
      console.error('❌ Vendor profile access error:', profileCheckError.message);
      return;
    }

    console.log('✅ Vendor profile accessible:', profileCheck.business_name);

    // Test 7: Clean up test data
    console.log('\n7️⃣ Cleaning up test data...');
    
    // Delete the vendor profile
    await supabase
      .from('vendor_profiles')
      .delete()
      .eq('user_id', signupData.user.id);

    // Delete the user account
    await supabase.auth.admin.deleteUser(signupData.user.id);

    console.log('✅ Test data cleaned up');

    console.log('\n🎉 All manual vendor creation tests passed!');
    console.log('\n📋 Summary:');
    console.log('✅ vendor_profiles table exists');
    console.log('✅ User account creation works');
    console.log('✅ Manual vendor profile creation works');
    console.log('✅ User metadata update works');
    console.log('✅ Vendor sign in works');
    console.log('✅ Vendor profile access works');

  } catch (error) {
    console.error('❌ Test failed with error:', error.message);
    console.error('Stack trace:', error.stack);
  }
}

// Run the test
testManualVendorCreation().then(() => {
  console.log('\n✨ Manual vendor creation test completed');
  process.exit(0);
}).catch((error) => {
  console.error('❌ Test script failed:', error);
  process.exit(1);
});
