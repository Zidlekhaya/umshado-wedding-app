import { useState, useEffect } from 'react';
import { View, Text, Alert, StyleSheet, ScrollView } from 'react-native';
import { Link, Redirect } from 'expo-router';
import { supabase } from '@/lib/supabase';
import type { Session } from '@supabase/supabase-js';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Card } from '@/components/ui/Card';
import { Logo } from '@/src/components/ui/Logo';
import { ProfilePicture } from '@/components/ui/ProfilePicture';
import { Colors, Typography, Spacing } from '@/constants/Design';

export default function SignUp() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [session, setSession] = useState<Session | null | undefined>(undefined);
  const [loading, setLoading] = useState(false);
  const [profilePictureUri, setProfilePictureUri] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => subscription.unsubscribe();
  }, []);

  if (session) return <Redirect href="/(tabs)" />;

  const handleProfilePictureChange = (uri: string) => {
    setProfilePictureUri(uri);
  };

  async function handleSignUp() {
    try {
      setLoading(true);
      const { error } = await supabase.auth.signUp({ 
        email, 
        password,
        options: {
          data: {
            user_type: 'couple',
          }
        }
      });
      if (error) throw error;
      Alert.alert('Check your email', 'Please verify your account before signing in.');
    } catch (err: any) {
      Alert.alert('Sign up failed', err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Logo size="medium" showText={true} />
        <Text style={styles.title}>Create account</Text>
        <Text style={styles.subtitle}>Join Umshado and start planning your perfect wedding</Text>
      </View>

      <Card style={styles.formCard}>
        <View style={styles.profileSection}>
          <Text style={styles.profileLabel}>Profile Picture (Optional)</Text>
          <View style={styles.profileContainer}>
            <ProfilePicture
              size={100}
              imageUri={profilePictureUri || undefined}
              onImageChange={handleProfilePictureChange}
              editable={true}
            />
            <Text style={styles.profileHint}>Tap to add a profile picture</Text>
          </View>
        </View>

        <Input
          label="Email"
          placeholder="thandi@gmail.com"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
        />

        <Input
          label="Password"
          placeholder="Create a password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />

        <Button
          title={loading ? 'Creating account...' : 'Create account'}
          onPress={handleSignUp}
          loading={loading}
          disabled={loading}
          size="lg"
          style={styles.signUpButton}
        />

        <View style={styles.signInLink}>
          <Text style={styles.signInText}>Already have an account? </Text>
          <Link href="/(auth)/sign-in" style={styles.link}>
            <Text style={styles.linkText}>Sign in</Text>
          </Link>
        </View>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0fbe9',
  },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing['3xl'],
    paddingBottom: Spacing.lg,
    alignItems: 'center',
  },
  title: {
    fontSize: Typography.fontSize['3xl'],
    fontWeight: Typography.fontWeight.bold as any,
    color: Colors.primary,
    marginBottom: Spacing.md,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: Typography.fontSize.base,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: Typography.lineHeight.relaxed * Typography.fontSize.base,
  },
  formCard: {
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  profileSection: {
    marginBottom: Spacing.xl,
    alignItems: 'center',
  },
  profileLabel: {
    fontSize: Typography.fontSize.lg,
    fontWeight: Typography.fontWeight.semibold as any,
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
  },
  profileContainer: {
    alignItems: 'center',
  },
  profileHint: {
    fontSize: Typography.fontSize.sm,
    color: Colors.textSecondary,
    marginTop: Spacing.sm,
    textAlign: 'center',
  },
  signUpButton: {
    marginTop: Spacing.lg,
  },
  signInLink: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: Spacing.lg,
  },
  signInText: {
    fontSize: Typography.fontSize.base,
    color: Colors.textSecondary,
  },
  link: {
    marginLeft: Spacing.xs,
  },
  linkText: {
    fontSize: Typography.fontSize.base,
    color: Colors.primary,
    fontWeight: Typography.fontWeight.semibold as any,
  },
});
