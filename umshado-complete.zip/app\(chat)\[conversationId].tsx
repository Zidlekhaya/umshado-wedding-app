// Chat screen for real-time messaging between couples and vendors
import React, { useCallback, useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  Alert,
  TouchableOpacity,
  Text,
  Platform,
  Linking,
  ActivityIndicator,
  KeyboardAvoidingView,
  TextInput,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GiftedChat, Actions, Composer, Send, InputToolbar, Bubble, Time, Day } from 'react-native-gifted-chat';
import { Feather } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';

import useMessages from '@/hooks/useMessages';
import {
  sendMessage,
  uploadFileToStorage,
  getConversation,
  markMessagesAsRead,
  type Conversation,
  type GiftedChatMessage,
} from '@/lib/chat-service';
import { supabase } from '@/lib/supabase';
import { useWeddingStore } from '@/stores/wedding';

const colors = {
  primary: '#00a86b',
  primaryLight: '#40c997',
  background: '#ffffff',
  surface: '#f8fafc',
  text: '#1f2937',
  textSecondary: '#6b7280',
  textLight: '#9ca3af',
  border: '#e5e7eb',
  success: '#00a86b',
  error: '#ef4444',
  white: '#ffffff',
  chatBubbleRight: '#00a86b',
  chatBubbleLeft: '#f8fafc',
  inputBackground: '#f1f5f9',
  sendButton: '#00a86b',
  sendButtonDisabled: '#e5e7eb',
  heartDelivered: '#00a86b',
  heartRead: '#ff6b9d',
};

export default function ChatScreen() {
  const { conversationId } = useLocalSearchParams<{ conversationId: string }>();
  const router = useRouter();
  const { currentWedding } = useWeddingStore();
  
  const { messages, loading, error, loadEarlierMessages, setMessages, refreshMessages } = useMessages(conversationId);
  const [conversation, setConversation] = useState<Conversation | null>(null);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [isSending, setIsSending] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  // Get current user and conversation details
  useEffect(() => {
    const initialize = async () => {
      try {
        // Get current user
        const { data: sessionData } = await supabase.auth.getSession();
        if (!sessionData.session?.user) {
          Alert.alert('Error', 'Please sign in to access chat');
          router.back();
          return;
        }
        setCurrentUser(sessionData.session.user);

        // Get conversation details
        if (conversationId) {
          const conv = await getConversation(conversationId);
          setConversation(conv);
        }
      } catch (err) {
        console.error('Error initializing chat:', err);
        Alert.alert('Error', 'Failed to load chat');
      }
    };

    initialize();
  }, [conversationId]);

  // Mark messages as read when conversation loads and when user is active
  useEffect(() => {
    if (!conversationId || !currentUser) return;

    const markAsRead = async () => {
      try {
        await markMessagesAsRead(conversationId);
      } catch (error) {
        console.error('Error marking messages as read:', error);
      }
    };

    // Mark messages as read when conversation loads
    markAsRead();

    // Mark messages as read when app becomes active (user returns to chat)
    const handleAppStateChange = (nextAppState: string) => {
      if (nextAppState === 'active') {
        markAsRead();
      }
    };

    // Import AppState
    const { AppState } = require('react-native');
    const subscription = AppState.addEventListener('change', handleAppStateChange);

    return () => {
      subscription?.remove();
    };
  }, [conversationId, currentUser]);

  // Determine user display name based on their role
  const getUserDisplayName = () => {
    if (!currentUser || !conversation) return 'You';
    
    // If current user is the couple, use couple name
    if (currentUser.id === conversation.couple_id) {
      return conversation.couple_name || 'Couple';
    }
    
    // If current user is the vendor, use vendor name
    return conversation.vendor_name || 'Vendor';
  };

  // Get other party's name for header
  const getOtherPartyName = () => {
    if (!currentUser || !conversation) return 'Chat';
    
    const isCouple = currentUser.id === conversation.couple_id;
    const isVendor = currentUser.id === conversation.vendor_id;
    
    // If current user is couple, show vendor business name
    if (isCouple) {
      return conversation.vendor_name || 'Vendor';
    }
    
    // If current user is vendor, show couple wedding name
    if (isVendor) {
      return conversation.couple_name || 'Wedding Couple';
    }
    
    return 'Chat';
  };

  // Get subtitle for header (additional info)
  const getHeaderSubtitle = () => {
    if (!currentUser || !conversation) return '';
    
    // If current user is couple, show vendor category/location
    if (currentUser.id === conversation.couple_id) {
      return 'Wedding Vendor';
    }
    
    // If current user is vendor, show "Wedding Inquiry"
    return 'Wedding Inquiry';
  };

  const onSend = useCallback(async (newMessages: GiftedChatMessage[] = []) => {
    if (!newMessages.length || !conversationId || !currentUser) return;

    const message = newMessages[0];

    // Add message optimistically for instant UI
    const optimisticMessage: GiftedChatMessage = {
      _id: `temp-${Date.now()}`,
      text: message.text,
      createdAt: new Date(),
      user: {
        _id: currentUser.id,
        name: getUserDisplayName(),
        avatar: currentUser.user_metadata?.avatar_url,
      },
    };

    // Add to UI immediately
    setMessages(prevMessages => [optimisticMessage, ...prevMessages]);

    // Send to database in background
    try {
      const result = await sendMessage({
        conversationId,
        senderName: getUserDisplayName(),
        senderAvatar: currentUser.user_metadata?.avatar_url,
        messageText: message.text,
        messageType: 'text',
      });
      
      // Replace optimistic message with real one
      setMessages(prevMessages => 
        prevMessages.map(msg => 
          msg._id === optimisticMessage._id 
            ? {
                _id: result.id,
                text: result.content || message.text,
                createdAt: new Date(result.created_at),
                user: {
                  _id: currentUser.id,
                  name: getUserDisplayName(),
                  avatar: currentUser.user_metadata?.avatar_url,
                }
              }
            : msg
        )
      );
      
    } catch (err) {
      console.error('Error sending message:', err);
      // Remove optimistic message on error
      setMessages(prevMessages => 
        prevMessages.filter(msg => msg._id !== optimisticMessage._id)
      );
      Alert.alert('Error', 'Failed to send message. Please try again.');
    }
  }, [conversationId, currentUser]);

  const pickImage = async () => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Please grant access to your photos to share images.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.7,
      });

      if (!result.canceled && result.assets[0]) {
        await uploadAndSendFile(result.assets[0].uri, 'image.jpg', 'image');
      }
    } catch (err) {
      console.error('Error picking image:', err);
      Alert.alert('Error', 'Failed to pick image');
    }
  };

  const pickDocument = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: '*/*',
        copyToCacheDirectory: true,
      });

      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        await uploadAndSendFile(asset.uri, asset.name, 'file');
      }
    } catch (err) {
      console.error('Error picking document:', err);
      Alert.alert('Error', 'Failed to pick document');
    }
  };

  const uploadAndSendFile = async (uri: string, fileName: string, type: 'image' | 'file') => {
    if (!conversationId || !currentUser) return;

    setIsUploading(true);
    try {
      const fileUrl = await uploadFileToStorage(uri, fileName, conversationId);
      
      await sendMessage({
        conversationId,
        senderName: getUserDisplayName(),
        senderAvatar: currentUser.user_metadata?.avatar_url,
        messageType: type,
        imageUrl: type === 'image' ? fileUrl : undefined,
        fileUrl: type === 'file' ? fileUrl : undefined,
        fileName: type === 'file' ? fileName : undefined,
      });
    } catch (err) {
      console.error('Error uploading file:', err);
      Alert.alert('Error', 'Failed to upload file. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  const renderActions = (props: any) => (
    <Actions
      {...props}
      options={{
        'Camera': () => pickImage(),
        'Photo Library': () => pickImage(),
        'Document': () => pickDocument(),
        'Cancel': () => {},
      }}
      icon={() => (
        <View style={styles.actionButton}>
          <Feather name="plus" size={20} color={colors.primary} />
        </View>
      )}
      wrapperStyle={styles.actionsWrapper}
      containerStyle={styles.actionsContainer}
    />
  );

  const renderSend = (props: any) => (
    <Send {...props}>
      <View style={[styles.sendButton, isSending && styles.sendButtonDisabled]}>
        {isSending ? (
          <ActivityIndicator size="small" color={colors.white} />
        ) : (
          <Feather name="send" size={18} color={colors.white} />
        )}
      </View>
    </Send>
  );

  const renderBubble = (props: any) => (
    <Bubble
      {...props}
      wrapperStyle={{
        right: styles.rightBubble,
        left: styles.leftBubble,
      }}
      textStyle={{
        right: styles.rightBubbleText,
        left: styles.leftBubbleText,
      }}
    />
  );

  const renderTime = (props: any) => (
    <Time
      {...props}
      timeTextStyle={{
        right: styles.timeTextRight,
        left: styles.timeTextLeft,
      }}
    />
  );

  const renderDay = (props: any) => (
    <Day
      {...props}
      textStyle={styles.dayText}
      wrapperStyle={styles.dayWrapper}
    />
  );

  const renderInputToolbar = (props: any) => (
    <InputToolbar
      {...props}
      containerStyle={styles.inputToolbar}
      primaryStyle={styles.inputPrimary}
      accessoryStyle={styles.inputAccessory}
    />
  );

  const renderComposer = (props: any) => (
    <Composer
      {...props}
      textInputStyle={styles.composer}
      placeholderTextColor={colors.textLight}
      textInputProps={{
        autoCapitalize: 'sentences',
        autoCorrect: true,
        blurOnSubmit: false,
        multiline: true,
        numberOfLines: 1,
        returnKeyType: 'send',
        keyboardType: 'default',
      }}
    />
  );

  const renderMessage = (props: any) => {
    const { currentMessage } = props;
    
    // Handle file messages
    if (currentMessage.file) {
      return (
        <View style={[
          styles.fileMessage,
          currentMessage.user._id === currentUser?.id ? styles.fileMessageRight : styles.fileMessageLeft
        ]}>
          <TouchableOpacity 
            style={styles.fileContainer}
            onPress={() => Linking.openURL(currentMessage.file.url)}
          >
            <Feather name="file" size={20} color={colors.primary} />
            <Text style={styles.fileName} numberOfLines={1}>
              {currentMessage.file.name}
            </Text>
          </TouchableOpacity>
          <Text style={styles.fileTime}>
            {new Date(currentMessage.createdAt).toLocaleTimeString([], { 
              hour: '2-digit', 
              minute: '2-digit' 
            })}
          </Text>
        </View>
      );
    }
    
    return null; // Use default rendering for text and image messages
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <Stack.Screen
          options={{
            title: 'Loading...',
            headerBackTitle: 'Back',
          }}
        />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>Loading conversation...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (error) {
    return (
      <SafeAreaView style={styles.container}>
        <Stack.Screen
          options={{
            title: 'Error',
            headerBackTitle: 'Back',
          }}
        />
        <View style={styles.errorContainer}>
          <Feather name="alert-circle" size={48} color={colors.error} />
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity 
            style={styles.retryButton}
            onPress={() => router.back()}
          >
            <Text style={styles.retryButtonText}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen
        options={{
          title: getOtherPartyName(),
          headerBackTitle: 'Back',
          headerTitleStyle: { 
            fontSize: 18, 
            fontWeight: '600', 
            color: colors.text 
          },
          headerStyle: {
            backgroundColor: colors.white,
          },
          headerShadowVisible: true,
        }}
      />
      
      {isUploading && (
        <View style={styles.uploadingIndicator}>
          <ActivityIndicator size="small" color={colors.primary} />
          <Text style={styles.uploadingText}>Uploading...</Text>
        </View>
      )}



      <View style={{ flex: 1 }}>
        <GiftedChat
          messages={messages}
          onSend={onSend}
          user={{
            _id: currentUser?.id || '',
            name: getUserDisplayName(),
          }}
          renderBubble={(props) => (
            <View>
              <View
                style={[
                  styles.bubble,
                  props.currentMessage?.user._id === currentUser?.id
                    ? styles.bubbleRight
                    : styles.bubbleLeft,
                ]}
              >
                <Text
                  style={[
                    styles.messageText,
                    props.currentMessage?.user._id === currentUser?.id
                      ? styles.messageTextRight
                      : styles.messageTextLeft,
                  ]}
                >
                  {props.currentMessage?.text}
                </Text>
              </View>
              {/* Heart read receipts for sent messages */}
              {props.currentMessage?.user._id === currentUser?.id && (
                <View style={styles.readReceiptContainer}>
                  {props.currentMessage?.is_read ? (
                    // Two hearts for read
                    <View style={{ flexDirection: 'row' }}>
                      <Feather name="heart" size={12} color={colors.primary} />
                      <Feather name="heart" size={12} color={colors.primary} style={{ marginLeft: 2 }} />
                    </View>
                  ) : (
                    // One heart for delivered (message sent but not read)
                    <Feather name="heart" size={12} color={colors.lightGray} />
                  )}
                </View>
              )}
            </View>
          )}
          renderInputToolbar={(props) => (
            <View style={{ 
              flexDirection: 'row', 
              alignItems: 'center',
              padding: 12,
              backgroundColor: colors.inputBackground,
              borderTopWidth: 1,
              borderTopColor: colors.border,
              paddingBottom: 16,
            }}>
              <TextInput
                style={{
                  flex: 1,
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 24,
                  paddingHorizontal: 16,
                  paddingVertical: 12,
                  marginRight: 12,
                  backgroundColor: colors.white,
                  fontSize: 16,
                  color: colors.text,
                  maxHeight: 100,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 1 },
                  shadowOpacity: 0.1,
                  shadowRadius: 2,
                  elevation: 2,
                }}
                placeholder="Type a message..."
                value={props.text}
                onChangeText={props.onTextChanged}
                multiline
                onSubmitEditing={() => {
                  if (props.text?.trim()) {
                    props.onSend([{
                      _id: Date.now().toString(),
                      text: props.text,
                      createdAt: new Date(),
                      user: {
                        _id: currentUser?.id || '',
                        name: getUserDisplayName(),
                      }
                    }]);
                    // Clear the input after sending
                    props.onTextChanged('');
                  }
                }}
              />
              <TouchableOpacity
                onPress={() => {
                  if (props.text?.trim()) {
                    props.onSend([{
                      _id: Date.now().toString(), 
                      text: props.text,
                      createdAt: new Date(),
                      user: {
                        _id: currentUser?.id || '',
                        name: getUserDisplayName(),
                      }
                    }]);
                    // Clear the input after sending
                    props.onTextChanged('');
                  }
                }}
                style={{
                  backgroundColor: props.text?.trim() ? colors.sendButton : colors.sendButtonDisabled,
                  borderRadius: 24,
                  paddingHorizontal: 16,
                  paddingVertical: 12,
                  minWidth: 48,
                  justifyContent: 'center',
                  alignItems: 'center',
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.15,
                  shadowRadius: 3,
                  elevation: 3,
                }}
                disabled={!props.text?.trim()}
              >
                <Text style={{ color: '#fff', fontWeight: 'bold' }}>Send</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  keyboardAvoidingView: {
    flex: 1,
  },
  bubble: {
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    marginVertical: 2,
    maxWidth: '80%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  bubbleRight: {
    backgroundColor: colors.chatBubbleRight,
    alignSelf: 'flex-end',
    marginRight: 10,
    borderBottomRightRadius: 4,
  },
  bubbleLeft: {
    backgroundColor: colors.chatBubbleLeft,
    alignSelf: 'flex-start',
    marginLeft: 10,
    borderBottomLeftRadius: 4,
    borderWidth: 1,
    borderColor: colors.border,
  },
  messageText: {
    fontSize: 16,
    lineHeight: 20,
  },
  messageTextRight: {
    color: colors.white,
  },
  messageTextLeft: {
    color: colors.text,
  },
  readReceiptContainer: {
    flexDirection: 'row',
    alignSelf: 'flex-end',
    marginRight: 10,
    marginTop: 2,
    marginBottom: 4,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
    gap: 16,
  },
  errorText: {
    fontSize: 16,
    color: colors.error,
    textAlign: 'center',
  },
  retryButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  retryButtonText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
  uploadingIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 8,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    gap: 8,
  },
  uploadingText: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  messagesContainer: {
    backgroundColor: colors.background,
  },
  inputToolbar: {
    backgroundColor: colors.white,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingHorizontal: 8,
    paddingVertical: 8,
  },
  inputPrimary: {
    alignItems: 'center',
    flex: 1,
  },
  inputAccessory: {
    backgroundColor: colors.white,
  },
  composer: {
    backgroundColor: colors.surface,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 16,
    paddingVertical: 10,
    marginHorizontal: 8,
    fontSize: 16,
    lineHeight: 20,
    color: colors.text,
    minHeight: 40,
    maxHeight: 100,
    textAlignVertical: 'center',
  },
  actionsWrapper: {
    marginRight: 8,
  },
  actionsContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
    marginBottom: 8,
  },
  sendButtonDisabled: {
    backgroundColor: colors.textLight,
  },
  rightBubble: {
    backgroundColor: colors.chatBubbleRight,
  },
  leftBubble: {
    backgroundColor: colors.chatBubbleLeft,
  },
  rightBubbleText: {
    color: colors.white,
  },
  leftBubbleText: {
    color: colors.text,
  },
  timeTextRight: {
    color: colors.white,
    opacity: 0.7,
  },
  timeTextLeft: {
    color: colors.textSecondary,
  },
  dayText: {
    color: colors.textSecondary,
    fontSize: 12,
    fontWeight: '500',
  },
  dayWrapper: {
    backgroundColor: colors.surface,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    marginVertical: 8,
  },
  fileMessage: {
    marginVertical: 4,
    marginHorizontal: 16,
    maxWidth: '70%',
  },
  fileMessageRight: {
    alignSelf: 'flex-end',
  },
  fileMessageLeft: {
    alignSelf: 'flex-start',
  },
  fileContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    padding: 12,
    gap: 8,
  },
  fileName: {
    flex: 1,
    fontSize: 14,
    color: colors.text,
  },
  fileTime: {
    fontSize: 11,
    color: colors.textSecondary,
    marginTop: 4,
    textAlign: 'right',
  },
});
