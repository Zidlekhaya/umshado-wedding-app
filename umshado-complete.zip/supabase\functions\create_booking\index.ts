import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface CreateBookingRequest {
  package_id: string
  selected_addons: string[]
  event_date: string
  notes?: string
  guest_count?: number
}

interface BookingResponse {
  success: boolean
  booking?: any
  error?: string
  total_price?: number
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    )

    // Get the authenticated user
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser()
    
    if (authError || !user) {
      return new Response(
        JSON.stringify({ success: false, error: 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Parse request body
    const { package_id, selected_addons, event_date, notes, guest_count }: CreateBookingRequest = await req.json()

    // Validate required fields
    if (!package_id || !event_date) {
      return new Response(
        JSON.stringify({ success: false, error: 'Package ID and event date are required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Get package details
    const { data: packageData, error: packageError } = await supabaseClient
      .from('vendor_packages')
      .select(`
        *,
        vendor_profiles!inner(user_id, business_name),
        package_addons(*)
      `)
      .eq('id', package_id)
      .eq('is_active', true)
      .single()

    if (packageError || !packageData) {
      return new Response(
        JSON.stringify({ success: false, error: 'Package not found or inactive' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Check availability if package has availability enabled
    if (packageData.has_availability) {
      const eventDate = new Date(event_date)
      const { data: availabilityData, error: availabilityError } = await supabaseClient
        .from('package_availability')
        .select('*')
        .eq('package_id', package_id)
        .eq('date', eventDate.toISOString().split('T')[0])
        .eq('is_available', false)

      if (availabilityError) {
        console.error('Availability check error:', availabilityError)
      } else if (availabilityData && availabilityData.length > 0) {
        return new Response(
          JSON.stringify({ success: false, error: 'Package is not available on the selected date' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // Check for existing confirmed bookings on the same date
      const { data: existingBookings, error: bookingsError } = await supabaseClient
        .from('package_bookings')
        .select('id')
        .eq('package_id', package_id)
        .eq('booking_status', 'confirmed')
        .gte('event_date', eventDate.toISOString().split('T')[0])
        .lt('event_date', new Date(eventDate.getTime() + 24 * 60 * 60 * 1000).toISOString().split('T')[0])

      if (bookingsError) {
        console.error('Existing bookings check error:', bookingsError)
      } else if (existingBookings && existingBookings.length > 0) {
        return new Response(
          JSON.stringify({ success: false, error: 'Package is already booked on the selected date' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }
    }

    // Calculate total price
    let totalPrice = 0

    // Base package price
    if (packageData.price_type === 'fixed') {
      totalPrice = packageData.price_min || 0
    } else if (packageData.price_type === 'range') {
      totalPrice = packageData.price_min || 0 // Use minimum for booking
    } else if (packageData.price_type === 'per_person') {
      totalPrice = (packageData.price_min || 0) * (guest_count || 1)
    } else if (packageData.price_type === 'hourly') {
      const hours = packageData.duration_hours || 1
      totalPrice = (packageData.price_min || 0) * hours
    }

    // Add selected addons
    if (selected_addons && selected_addons.length > 0) {
      const { data: addonsData, error: addonsError } = await supabaseClient
        .from('package_addons')
        .select('*')
        .in('id', selected_addons)
        .eq('is_active', true)

      if (addonsError) {
        console.error('Addons fetch error:', addonsError)
      } else if (addonsData) {
        for (const addon of addonsData) {
          if (addon.price_type === 'fixed') {
            totalPrice += addon.price
          } else if (addon.price_type === 'per_person') {
            totalPrice += addon.price * (guest_count || 1)
          } else if (addon.price_type === 'hourly') {
            totalPrice += addon.price * (packageData.duration_hours || 1)
          }
        }
      }
    }

    // Create booking
    const { data: bookingData, error: bookingError } = await supabaseClient
      .from('package_bookings')
      .insert({
        package_id,
        couple_user_id: user.id,
        vendor_user_id: packageData.vendor_profiles.user_id,
        selected_addons: selected_addons || [],
        total_price: totalPrice,
        event_date: event_date,
        notes: notes || null,
        booking_status: 'pending'
      })
      .select(`
        *,
        vendor_packages!inner(package_name, vendor_profiles!inner(business_name))
      `)
      .single()

    if (bookingError) {
      console.error('Booking creation error:', bookingError)
      return new Response(
        JSON.stringify({ success: false, error: 'Failed to create booking' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // TODO: Send notification to vendor
    // This could be implemented as a separate Edge Function or webhook

    const response: BookingResponse = {
      success: true,
      booking: bookingData,
      total_price: totalPrice
    }

    return new Response(
      JSON.stringify(response),
      { status: 201, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Unexpected error:', error)
    return new Response(
      JSON.stringify({ success: false, error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
