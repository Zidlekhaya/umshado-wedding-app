// Test script to verify database migration
const { createClient } = require('@supabase/supabase-js');

// Load environment variables
require('dotenv').config();

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing Supabase environment variables');
  console.log('Please create a .env file with:');
  console.log('EXPO_PUBLIC_SUPABASE_URL=your_supabase_url');
  console.log('EXPO_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function testMigration() {
  console.log('🚀 Testing database migration...\n');

  // Test 1: Check if core tables exist
  console.log('📋 Checking core tables...');
  const coreTables = [
    'app_user', 'wedding', 'wedding_co_owner', 'guest', 'task', 
    'vendor', 'budget_item', 'timeline_event', 'wedding_invites'
  ];

  for (const table of coreTables) {
    try {
      const { error } = await supabase.from(table).select('*').limit(1);
      if (error && error.code !== 'PGRST116') { // PGRST116 is "table is empty"
        console.log(`❌ Table '${table}' error:`, error.message);
      } else {
        console.log(`✅ Table '${table}' exists and accessible`);
      }
    } catch (err) {
      console.log(`❌ Table '${table}' failed:`, err.message);
    }
  }

  // Test 2: Check vendor marketplace tables
  console.log('\n🏪 Checking vendor marketplace tables...');
  const vendorTables = ['vendor_profiles', 'vendor_packages', 'vendor_inquiries'];

  for (const table of vendorTables) {
    try {
      const { error } = await supabase.from(table).select('*').limit(1);
      if (error && error.code !== 'PGRST116') {
        console.log(`❌ Table '${table}' error:`, error.message);
      } else {
        console.log(`✅ Table '${table}' exists and accessible`);
      }
    } catch (err) {
      console.log(`❌ Table '${table}' failed:`, err.message);
    }
  }

  // Test 3: Check messaging tables
  console.log('\n💬 Checking messaging tables...');
  const messagingTables = ['conversations', 'messages', 'push_tokens'];

  for (const table of messagingTables) {
    try {
      const { error } = await supabase.from(table).select('*').limit(1);
      if (error && error.code !== 'PGRST116') {
        console.log(`❌ Table '${table}' error:`, error.message);
      } else {
        console.log(`✅ Table '${table}' exists and accessible`);
      }
    } catch (err) {
      console.log(`❌ Table '${table}' failed:`, err.message);
    }
  }

  // Test 4: Test authentication
  console.log('\n🔐 Testing authentication...');
  try {
    const { data, error } = await supabase.auth.getSession();
    if (error) {
      console.log(`❌ Auth error: ${error.message}`);
    } else {
      console.log(`✅ Authentication system working`);
      if (data.session) {
        console.log(`✅ User logged in: ${data.session.user.email}`);
      } else {
        console.log(`ℹ️ No user currently logged in`);
      }
    }
  } catch (err) {
    console.log(`❌ Auth test failed: ${err.message}`);
  }

  console.log('\n🎉 Migration test completed!');
  console.log('\n📝 Next steps:');
  console.log('1. If all tables show ✅, your migration was successful');
  console.log('2. If any tables show ❌, run the MASTER_MIGRATION.sql script in Supabase');
  console.log('3. Test the app: npm start');
}

testMigration().catch(console.error);

