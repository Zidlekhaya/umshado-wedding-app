import { supabase } from '@/lib/supabase';

export type VendorCategory = 
  | 'photography' | 'catering' | 'venue' | 'flowers' | 'music' | 'decor'
  | 'transportation' | 'makeup' | 'hair' | 'dress' | 'suit' | 'cake'
  | 'invitations' | 'officiant' | 'other';

export type VendorStatus = 
  | 'contacted' | 'quoted' | 'booked' | 'confirmed' | 'completed' | 'cancelled';

export type VendorPriority = 'low' | 'medium' | 'high' | 'urgent';

export interface Vendor {
  id: string;
  wedding_id: string;
  name: string;
  category: VendorCategory;
  contact_person?: string;
  email?: string;
  phone?: string;
  website?: string;
  address?: string;
  city?: string;
  province?: string;
  postal_code?: string;
  country: string;
  service_description?: string;
  price_range?: string;
  estimated_cost?: number;
  deposit_paid: number;
  final_payment_due?: string;
  status: VendorStatus;
  priority: VendorPriority;
  notes?: string;
  rating?: number;
  review?: string;
  created_at: string;
  updated_at: string;
}

export interface CreateVendorData {
  name: string;
  category: VendorCategory;
  contact_person?: string;
  email?: string;
  phone?: string;
  website?: string;
  address?: string;
  city?: string;
  province?: string;
  postal_code?: string;
  country?: string;
  service_description?: string;
  price_range?: string;
  estimated_cost?: number;
  deposit_paid?: number;
  final_payment_due?: string;
  status?: VendorStatus;
  priority?: VendorPriority;
  notes?: string;
  rating?: number;
  review?: string;
}

export interface UpdateVendorData extends Partial<CreateVendorData> {}

// Get all vendors for a wedding
export async function listVendors(weddingId: string): Promise<Vendor[]> {
  const { data, error } = await supabase
    .from('vendors')
    .select('*')
    .eq('wedding_id', weddingId)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('List vendors error:', error);
    throw error;
  }

  return data as Vendor[];
}

// Get vendor by ID
export async function getVendor(id: string): Promise<Vendor | null> {
  const { data, error } = await supabase
    .from('vendors')
    .select('*')
    .eq('id', id)
    .single();

  if (error) {
    console.error('Get vendor error:', error);
    throw error;
  }

  return data as Vendor;
}

// Create new vendor
export async function createVendor(weddingId: string, vendorData: CreateVendorData): Promise<Vendor> {
  const { data, error } = await supabase
    .from('vendors')
    .insert([{
      wedding_id: weddingId,
      ...vendorData,
      country: vendorData.country || 'South Africa',
      deposit_paid: vendorData.deposit_paid || 0,
      status: vendorData.status || 'contacted',
      priority: vendorData.priority || 'medium',
    }])
    .select()
    .single();

  if (error) {
    console.error('Create vendor error:', error);
    throw error;
  }

  return data as Vendor;
}

// Update vendor
export async function updateVendor(id: string, updates: UpdateVendorData): Promise<Vendor> {
  const { data, error } = await supabase
    .from('vendors')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('Update vendor error:', error);
    throw error;
  }

  return data as Vendor;
}

// Delete vendor
export async function deleteVendor(id: string): Promise<void> {
  const { error } = await supabase
    .from('vendors')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Delete vendor error:', error);
    throw error;
  }
}

// Get vendors by category
export async function getVendorsByCategory(weddingId: string, category: VendorCategory): Promise<Vendor[]> {
  const { data, error } = await supabase
    .from('vendors')
    .select('*')
    .eq('wedding_id', weddingId)
    .eq('category', category)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Get vendors by category error:', error);
    throw error;
  }

  return data as Vendor[];
}

// Get vendors by status
export async function getVendorsByStatus(weddingId: string, status: VendorStatus): Promise<Vendor[]> {
  const { data, error } = await supabase
    .from('vendors')
    .select('*')
    .eq('wedding_id', weddingId)
    .eq('status', status)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Get vendors by status error:', error);
    throw error;
  }

  return data as Vendor[];
}

// Get category icon
export function getCategoryIcon(category: VendorCategory): string {
  switch (category) {
    case 'photography': return 'camera';
    case 'catering': return 'coffee';
    case 'venue': return 'map-pin';
    case 'flowers': return 'heart';
    case 'music': return 'music';
    case 'decor': return 'palette';
    case 'transportation': return 'truck';
    case 'makeup': return 'smile';
    case 'hair': return 'scissors';
    case 'dress': return 'shopping-bag';
    case 'suit': return 'user';
    case 'cake': return 'gift';
    case 'invitations': return 'mail';
    case 'officiant': return 'user-check';
    case 'other': return 'more-horizontal';
    default: return 'star';
  }
}

// Get category color
export function getCategoryColor(category: VendorCategory): string {
  switch (category) {
    case 'photography': return '#FF6B6B';
    case 'catering': return '#4ECDC4';
    case 'venue': return '#45B7D1';
    case 'flowers': return '#96CEB4';
    case 'music': return '#FFEAA7';
    case 'decor': return '#DDA0DD';
    case 'transportation': return '#98D8C8';
    case 'makeup': return '#F7DC6F';
    case 'hair': return '#BB8FCE';
    case 'dress': return '#85C1E9';
    case 'suit': return '#F8C471';
    case 'cake': return '#F1948A';
    case 'invitations': return '#82E0AA';
    case 'officiant': return '#D7BDE2';
    case 'other': return '#AEB6BF';
    default: return '#D5DBDB';
  }
}

// Get status color
export function getStatusColor(status: VendorStatus): string {
  switch (status) {
    case 'contacted': return '#FFD93D';
    case 'quoted': return '#FF8E53';
    case 'booked': return '#6BCF7F';
    case 'confirmed': return '#4ECDC4';
    case 'completed': return '#95E1A3';
    case 'cancelled': return '#E74C3C';
    default: return '#AEB6BF';
  }
}

// Get priority color
export function getPriorityColor(priority: VendorPriority): string {
  switch (priority) {
    case 'urgent': return '#FF6B6B';
    case 'high': return '#FF8E53';
    case 'medium': return '#FFA500';
    case 'low': return '#4ECDC4';
    default: return '#AEB6BF';
  }
}