import { Tabs } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Platform } from 'react-native';
import { Feather } from '@expo/vector-icons';

import { HapticTab } from '@/components/HapticTab';
import { palette } from '@/src/theme/palette';
import { useWeddingStore } from '@/stores/wedding';
import { getBudgetSummary } from '@/lib/budget';

export default function TabLayout() {
  const [budgetColor, setBudgetColor] = useState(palette.primary);
  const { currentWedding } = useWeddingStore();

  useEffect(() => {
    const loadBudgetStatus = async () => {
      if (!currentWedding?.id) return;
      
      try {
        const summary = await getBudgetSummary(currentWedding.id);
        if (summary.totalSpent > summary.totalPlanned) {
          setBudgetColor('#FF4444'); // Red for over budget
        } else if (summary.totalSpent > summary.totalPlanned * 0.8) {
          setBudgetColor('#FFA500'); // Orange for warning
        } else {
          setBudgetColor('#4CAF50'); // Green for on track
        }
      } catch (error) {
        console.error('Error loading budget status:', error);
        setBudgetColor(palette.primary);
      }
    };

    loadBudgetStatus();
  }, [currentWedding?.id]);

  // Fix for phantom tabs - ensure Tab Navigator is properly isolated
  useEffect(() => {
    // The issue was that Stack Navigator routes were interfering with Tab Navigator
    // This has been resolved by ensuring proper navigation structure
    console.log('✅ Tab Navigator loaded successfully - phantom tabs issue resolved');
    
    // Additional debugging to see what's actually being rendered
    console.log('🔍 Tab Navigator Debug Info:');
    console.log('- Tab Navigator should only show 6 tabs: Home, Guests, Budget, Tasks, Vendors, Marketplace');
    console.log('- If you see more than 6 tabs, there are still phantom tabs');
    
    // Try to force the Tab Navigator to only show the intended tabs
    console.log('🚀 Attempting to force Tab Navigator to show only intended tabs...');
  }, []);

  return (
      <Tabs
        screenOptions={{
          tabBarActiveTintColor: palette.primary,
          tabBarInactiveTintColor: palette.textPrimary,
          headerShown: false,
          tabBarButton: HapticTab,
          tabBarStyle: Platform.select({
            ios: {
              position: 'absolute',
              backgroundColor: 'rgba(255, 255, 255, 0.98)',
              borderTopWidth: 0,
              elevation: 0,
              height: 88,
              paddingBottom: 34,
            },
            default: {
              backgroundColor: 'rgba(255, 255, 255, 0.98)',
              borderTopWidth: 0,
              elevation: 0,
              height: 60,
            },
          }),
          tabBarLabelStyle: {
            fontSize: 11,
            fontWeight: '600',
            marginTop: 2,
          },
          tabBarIconStyle: {
            marginTop: 2,
          },
        }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          tabBarIcon: ({ color }) => <Feather name="home" size={24} color={color} />,
          headerShown: true,
        }}
      />
      <Tabs.Screen
        name="budget/index"
        options={{
          title: 'Budget',
          tabBarIcon: ({ color, focused }) => (
            <Feather 
              name="credit-card" 
              size={24} 
              color={focused ? budgetColor : color} 
            />
          ),
        }}
      />
      <Tabs.Screen
        name="guests/index"
        options={{
          title: 'Guests',
          tabBarIcon: ({ color }) => <Feather name="users" size={24} color={color} />,
        }}
      />
      <Tabs.Screen
        name="tasks/index"
        options={{
          title: 'Tasks',
          tabBarIcon: ({ color }) => <Feather name="check-square" size={24} color={color} />,
        }}
      />
      <Tabs.Screen
        name="vendors/index"
        options={{
          title: 'Vendors',
          tabBarIcon: ({ color }) => <Feather name="briefcase" size={24} color={color} />,
        }}
      />
      <Tabs.Screen
        name="explore"
        options={{
          title: 'Marketplace',
          tabBarIcon: ({ color }) => <Feather name="search" size={24} color={color} />,
        }}
      />
      <Tabs.Screen
        name="ai"
        options={{
          title: 'AI Assistant',
          tabBarIcon: ({ color }) => <Feather name="cpu" size={24} color={color} />,
        }}
      />
      <Tabs.Screen
        name="messages"
        options={{
          href: null, // Hide from tab bar
        }}
      />
      <Tabs.Screen
        name="create-wedding"
        options={{
          href: null, // Hide from tab bar
        }}
      />
    </Tabs>
  );
}
