-- Simple migration for Guest Communication Hub
-- Only create the essential tables needed for the messaging feature

-- Create message_template table (if it doesn't exist)
CREATE TABLE IF NOT EXISTS public.message_template (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL,
  name TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create guest_rsvp table (if it doesn't exist)
CREATE TABLE IF NOT EXISTS public.guest_rsvp (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL,
  guest_id UUID NOT NULL,
  response TEXT NOT NULL CHECK (response IN ('going', 'maybe', 'declined', 'no_reply')),
  plus_ones INTEGER DEFAULT 0,
  dietary_requirements TEXT,
  song_requests TEXT,
  special_requests TEXT,
  responded_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create guest_communication table (if it doesn't exist)
CREATE TABLE IF NOT EXISTS public.guest_communication (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL,
  guest_id UUID NOT NULL,
  communication_type TEXT NOT NULL CHECK (communication_type IN ('invite_sent', 'reminder_sent', 'rsvp_received', 'message_sent', 'call_made', 'email_sent')),
  message_content TEXT,
  template_id UUID,
  sent_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  status TEXT DEFAULT 'sent' CHECK (status IN ('sent', 'delivered', 'read', 'failed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS message_template_wedding_idx ON public.message_template(wedding_id);
CREATE INDEX IF NOT EXISTS guest_rsvp_wedding_idx ON public.guest_rsvp(wedding_id);
CREATE INDEX IF NOT EXISTS guest_rsvp_guest_idx ON public.guest_rsvp(guest_id);
CREATE INDEX IF NOT EXISTS guest_communication_wedding_idx ON public.guest_communication(wedding_id);
CREATE INDEX IF NOT EXISTS guest_communication_guest_idx ON public.guest_communication(guest_id);

-- Enable RLS
ALTER TABLE public.message_template ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.guest_rsvp ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.guest_communication ENABLE ROW LEVEL SECURITY;

-- Simple RLS policies (allow all for now to avoid recursion issues)
CREATE POLICY "allow_all_message_template" ON public.message_template
  FOR ALL USING (true);

CREATE POLICY "allow_all_guest_rsvp" ON public.guest_rsvp
  FOR ALL USING (true);

CREATE POLICY "allow_all_guest_communication" ON public.guest_communication
  FOR ALL USING (true);
















