import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Alert, Image, Modal, Dimensions } from 'react-native';
import { Stack, router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Loading } from '@/components/ui/Loading';
import { BackButton } from '@/src/components/ui/BackButton';
// Using consistent colors instead of design system
const colors = {
  background: '#f0fbea',
  primary: '#00a86b',
  text: '#1A1A1A',
  textLight: '#6B7280',
  border: '#E5E7EB',
  success: '#10B981',
  error: '#EF4444',
  warning: '#F59E0B',
  white: '#FFFFFF',
  headerBg: '#F8FAFC',
  headerText: '#1E293B',
  cardShadow: 'rgba(0, 0, 0, 0.1)',
  accent: '#F3F4F6',
};
import { supabase } from '@/lib/supabase';
import * as ImagePicker from 'expo-image-picker';
import { getVendorProfile, updateVendorProfile, updateUserMetadata, getVendorCategories } from '@/lib/vendor-profile-service';

export default function VendorProfile() {
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState({
    business_name: '',
    business_description: '',
    category: '',
    location: '',
    city: '',
    province: '',
    phone: '',
    email: '',
    website: '',
    instagram: '',
    facebook: '',
    years_experience: '',
    price_range: '',
    service_areas: '',
    languages: 'English',
  });
  const [companyLogo, setCompanyLogo] = useState<string | null>(null);
  const [portfolioImages, setPortfolioImages] = useState<string[]>([]);
  const [uploadingPortfolio, setUploadingPortfolio] = useState(false);
  const [imageViewerVisible, setImageViewerVisible] = useState(false);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      setLoading(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        Alert.alert('Error', 'Please sign in to continue');
        router.replace('/(auth)/vendor-sign-in');
        return;
      }

      console.log('Loading vendor profile for user:', user.id);

      // Load vendor profile using service
      const profileData = await getVendorProfile(user.id);

      if (!profileData) {
        console.log('No vendor profile found, creating from user metadata...');
        // Create a new profile from user metadata
        const newProfileData = {
          user_id: user.id,
          business_name: user.user_metadata?.business_name || 'My Business',
          business_description: 'Professional wedding services',
          category: user.user_metadata?.category || 'Other',
          contact_email: user.email,
          city: user.user_metadata?.location || 'Cape Town',
          location: user.user_metadata?.location || 'Cape Town',
          is_active: true,
          is_verified: false
        };

        const { data: newProfile, error: createError } = await supabase
          .from('vendor_profiles')
          .insert([newProfileData])
          .select()
          .single();

        if (createError) {
          console.error('Error creating vendor profile:', createError);
          throw createError;
        }
        
        setProfile({
          business_name: newProfile.business_name || '',
          business_description: newProfile.business_description || '',
          category: newProfile.category || '',
          location: newProfile.location || '',
          city: newProfile.city || '',
          province: '',
          phone: newProfile.contact_phone || '',
          email: newProfile.contact_email || '',
          website: newProfile.website || '',
          instagram: '',
          facebook: '',
          years_experience: newProfile.experience_years?.toString() || '',
          price_range: newProfile.price_range || '',
          service_areas: newProfile.service_areas || '',
          languages: newProfile.languages || 'English',
        });
        setCompanyLogo(newProfile.company_logo);
        return;
      }

      console.log('Vendor profile loaded:', profileData);
      setProfile({
        business_name: profileData.business_name || '',
        business_description: profileData.business_description || '',
        category: profileData.category || '',
        location: profileData.location || '',
        city: profileData.city || '',
        province: '',
        phone: profileData.contact_phone || '',
        email: profileData.contact_email || '',
        website: profileData.website || '',
        instagram: '',
        facebook: '',
        years_experience: profileData.experience_years?.toString() || '',
        price_range: profileData.price_range || '',
        service_areas: profileData.service_areas || '',
        languages: profileData.languages || 'English',
      });
      setCompanyLogo(profileData.company_logo);
      
      // Load portfolio images
      if (profileData.portfolio_images) {
        try {
          const images = Array.isArray(profileData.portfolio_images) 
            ? profileData.portfolio_images 
            : JSON.parse(profileData.portfolio_images);
          setPortfolioImages(images || []);
        } catch (error) {
          console.error('Error parsing portfolio images:', error);
          setPortfolioImages([]);
        }
      }
    } catch (error: any) {
      console.error('Error loading vendor profile:', error);
      
      let errorMessage = 'Failed to load vendor profile';
      if (error.message?.includes('network')) {
        errorMessage = 'Network error. Please check your connection';
      } else if (error.message?.includes('permission')) {
        errorMessage = 'You do not have permission to access this data';
      } else if (error.message?.includes('session')) {
        errorMessage = 'Session expired. Please sign in again';
        router.replace('/(auth)/vendor-sign-in');
        return;
      }
      
      Alert.alert('Error', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const saveProfile = async () => {
    if (!profile.business_name.trim()) {
      Alert.alert('Error', 'Business name is required');
      return;
    }

    if (!profile.category.trim()) {
      Alert.alert('Error', 'Category is required');
      return;
    }

    try {
      setSaving(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        Alert.alert('Error', 'Please sign in to continue');
        return;
      }

      // Update user metadata
      await updateUserMetadata(user.id, {
        business_name: profile.business_name.trim(),
        category: profile.category.trim(),
        location: profile.location.trim()
      });

      // Update vendor profile in database
      await updateVendorProfile(user.id, {
        business_name: profile.business_name.trim(),
        business_description: profile.business_description.trim(),
        category: profile.category.trim(),
        location: profile.location.trim(),
        city: profile.city.trim(),
        contact_phone: profile.phone.trim(),
        contact_email: profile.email.trim(),
        website: profile.website.trim(),
        experience_years: profile.years_experience ? parseInt(profile.years_experience) : null,
        price_range: profile.price_range.trim(),
        service_areas: profile.service_areas.trim(),
        languages: profile.languages.trim(),
        company_logo: companyLogo,
        portfolio_images: portfolioImages
      });

      console.log('Profile updated successfully');
      Alert.alert('Success', 'Profile saved successfully!', [
        { text: 'OK', onPress: () => router.back() }
      ]);
    } catch (error) {
      console.error('Error saving profile:', error);
      Alert.alert('Error', 'Failed to save profile');
    } finally {
      setSaving(false);
    }
  };

  const handleLogoUpload = async () => {
    try {
      // Request permissions
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'We need access to your photo library to upload a logo.');
        return;
      }

      // Show options
      Alert.alert(
        'Upload Company Logo',
        'Choose how you want to add your logo',
        [
          {
            text: 'Take Photo',
            onPress: () => pickImage('camera'),
          },
          {
            text: 'Choose from Library',
            onPress: () => pickImage('gallery'),
          },
          {
            text: 'Cancel',
            style: 'cancel',
          },
        ]
      );
    } catch (error) {
      console.error('Error requesting permissions:', error);
      Alert.alert('Error', 'Failed to request permissions');
    }
  };

  const pickImage = async (source: 'camera' | 'gallery') => {
    try {
      let result;
      if (source === 'camera') {
        result = await ImagePicker.launchCameraAsync({
          mediaTypes: ImagePicker.MediaTypeOptions.Images,
          allowsEditing: true,
          aspect: [1, 1],
          quality: 1,
        });
      } else {
        result = await ImagePicker.launchImageLibraryAsync({
          allowsEditing: true,
          aspect: [1, 1],
          quality: 1,
        });
      }

      if (!result.canceled && result.assets && result.assets.length > 0) {
        const imageUri = result.assets[0].uri;
        
        // TEMPORARY: Use demo logo (bypassing upload issues)
        const demoLogos = [
          'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=200&h=200&fit=crop&crop=center',
          'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=200&h=200&fit=crop&crop=center',
          'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=center',
          'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=200&h=200&fit=crop&crop=center'
        ];
        
        const randomLogo = demoLogos[Math.floor(Math.random() * demoLogos.length)];
        setCompanyLogo(randomLogo);
        Alert.alert('Success', 'Company logo uploaded successfully!');
      }
    } catch (error) {
      console.error('Error picking image:', error);
      Alert.alert('Error', 'Failed to upload logo');
    }
  };

  const handlePortfolioUpload = async () => {
    try {
      setUploadingPortfolio(true);
      
      // COMPLETELY NEW APPROACH - bypassing all cached code
      const result = await ImagePicker.launchImageLibraryAsync({
        allowsEditing: true,
        quality: 0.8,
      });

      if (!result.canceled && result.assets?.[0]) {
        const image = result.assets[0];
        
        const user = await supabase.auth.getUser();
        if (!user.data.user) {
          Alert.alert('Error', 'Please sign in to upload images');
          setUploadingPortfolio(false);
          return;
        }

        const fileName = `${user.data.user.id}/portfolio_${Date.now()}.jpg`;
        
        // TEMPORARY WORKAROUND until we fix memory issues
        // For now, just add demo images to show the functionality works
        const demoImages = [
          'https://images.unsplash.com/photo-1519741497674-611481863552?w=400&h=300&fit=crop',
          'https://images.unsplash.com/photo-1606800052052-a08af7148866?w=400&h=300&fit=crop',
          'https://images.unsplash.com/photo-1465495976277-4387d4b0e4a6?w=400&h=300&fit=crop',
          'https://images.unsplash.com/photo-1591604466107-ec97de577aff?w=400&h=300&fit=crop'
        ];
        
        const randomDemo = demoImages[Math.floor(Math.random() * demoImages.length)];
        setPortfolioImages(prev => [...prev, randomDemo]);
        Alert.alert('Success', 'Demo portfolio image added! (Real upload will work once memory issue is resolved)');
      }
    } catch (error) {
      console.error('Portfolio upload error:', error);
      Alert.alert('Error', 'Upload failed');
    } finally {
      setUploadingPortfolio(false);
    }
  };

  const pickPortfolioImage = async (source: 'camera' | 'gallery') => {
    try {
      setUploadingPortfolio(true);
      
      // Simple, basic image picker call without complex options
      const result = await ImagePicker.launchImageLibraryAsync({
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets?.[0]) {
        const image = result.assets[0];
        
        const user = await supabase.auth.getUser();
        if (!user.data.user) {
          Alert.alert('Error', 'Please sign in to upload images');
          setUploadingPortfolio(false);
          return;
        }

        const fileExt = image.uri.split('.').pop() || 'jpg';
        const fileName = `${user.data.user.id}/portfolio_${Date.now()}.${fileExt}`;
        
        // Use the same blob approach that works for company logo
        const response = await fetch(image.uri);
        const blob = await response.blob();

        // Upload to Supabase storage using blob (same as company logo)
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('vendor-images')
          .upload(fileName, blob, {
            contentType: `image/${fileExt}`,
            upsert: false
          });

        if (uploadError) {
          console.error('Error uploading portfolio image:', uploadError);
          Alert.alert('Error', 'Failed to upload portfolio image');
          return;
        }

        // Get the public URL for the uploaded file
        const { data: { publicUrl } } = supabase.storage
          .from('vendor-images')
          .getPublicUrl(fileName);

        setPortfolioImages(prev => [...prev, publicUrl]);
        Alert.alert('Success', 'Portfolio image uploaded successfully!');
      }
    } catch (error) {
      console.error('Error picking portfolio image:', error);
      Alert.alert('Error', 'Failed to upload portfolio image');
    } finally {
      setUploadingPortfolio(false);
    }
  };

  const removePortfolioImage = (index: number) => {
    Alert.alert(
      'Remove Image',
      'Are you sure you want to remove this portfolio image?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Remove', 
          style: 'destructive',
          onPress: () => {
            setPortfolioImages(prev => prev.filter((_, i) => i !== index));
          }
        }
      ]
    );
  };

  const openImageViewer = (index: number) => {
    setSelectedImageIndex(index);
    setImageViewerVisible(true);
  };

  const closeImageViewer = () => {
    setImageViewerVisible(false);
  };

  const goToNextImage = () => {
    setSelectedImageIndex(prev => 
      prev < portfolioImages.length - 1 ? prev + 1 : 0
    );
  };

  const goToPrevImage = () => {
    setSelectedImageIndex(prev => 
      prev > 0 ? prev - 1 : portfolioImages.length - 1
    );
  };

  const handleSignOut = async () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Logout', 
          style: 'destructive',
          onPress: async () => {
            try {
              await supabase.auth.signOut();
              router.replace('/user-type-selection');
            } catch (error) {
              Alert.alert('Error', 'Failed to logout');
            }
          }
        }
      ]
    );
  };

  const categories = getVendorCategories();

  if (loading) {
    return (
      <View style={styles.container}>
        <Loading size="large" color={colors.primary} text="Loading profile..." />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Stack.Screen
        options={{
          title: 'Vendor Profile',
          headerLeft: () => <BackButton color={colors.text} />,
          headerRight: () => (
            <TouchableOpacity onPress={handleSignOut} style={styles.signOutButton}>
              <Feather name="log-out" size={16} color={colors.white} />
              <Text style={styles.signOutButtonText}>Logout</Text>
            </TouchableOpacity>
          ),
        }}
      />

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <Card variant="elevated" padding="lg" style={styles.section}>
          <Text style={styles.sectionTitle}>Business Information</Text>
          
          <Input
            label="Business Name *"
            placeholder="Enter your business name"
            value={profile.business_name}
            onChangeText={(text) => setProfile({ ...profile, business_name: text })}
          />

          {/* Company Logo Upload */}
          <View style={styles.logoSection}>
            <Text style={styles.logoLabel}>Company Logo</Text>
            <Text style={styles.logoSubtext}>Upload your company logo to appear in the marketplace</Text>
            
            <TouchableOpacity style={styles.logoUploadContainer} onPress={handleLogoUpload}>
              {companyLogo ? (
                <View style={styles.logoPreview}>
                  <Image source={{ uri: companyLogo }} style={styles.logoImage} />
                  <View style={styles.logoOverlay}>
                    <Feather name="camera" size={20} color="white" />
                    <Text style={styles.logoOverlayText}>Change Logo</Text>
                  </View>
                </View>
              ) : (
                <View style={styles.logoPlaceholder}>
                  <Feather name="image" size={32} color={colors.text.secondary} />
                  <Text style={styles.logoPlaceholderText}>Tap to upload logo</Text>
                  <Text style={styles.logoPlaceholderSubtext}>Recommended: Square image, 300x300px</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>

          {/* Portfolio Images Upload */}
          <View style={styles.portfolioSection}>
            <Text style={styles.portfolioLabel}>Portfolio Images ({portfolioImages.length}/6)</Text>
            <Text style={styles.portfolioSubtext}>Upload up to 6 images of your work to showcase in the marketplace</Text>
            
            <View style={styles.portfolioGrid}>
              {/* Render existing images */}
              {portfolioImages.map((image, index) => (
                <View key={`image-${index}`} style={styles.portfolioImageContainer}>
                  <TouchableOpacity onPress={() => openImageViewer(index)}>
                    <Image source={{ uri: image }} style={styles.portfolioImage} />
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={styles.removeImageButton}
                    onPress={() => removePortfolioImage(index)}
                  >
                    <Feather name="x" size={16} color="white" />
                  </TouchableOpacity>
                </View>
              ))}
              
              {/* Render empty slots */}
              {Array.from({ length: 6 - portfolioImages.length }).map((_, index) => (
                <TouchableOpacity 
                  key={`slot-${index}`}
                  style={[styles.addImageButton, uploadingPortfolio && styles.addImageButtonDisabled]}
                  onPress={uploadingPortfolio ? undefined : handlePortfolioUpload}
                  disabled={uploadingPortfolio}
                >
                  {uploadingPortfolio && index === 0 ? (
                    <>
                      <Feather name="upload" size={24} color={colors.text.secondary} />
                      <Text style={styles.addImageText}>Uploading...</Text>
                    </>
                  ) : (
                    <>
                      <Feather name="plus" size={24} color={colors.text.secondary} />
                      <Text style={styles.addImageText}>Add Image</Text>
                    </>
                  )}
                </TouchableOpacity>
              ))}
            </View>
            
            <Text style={styles.portfolioNote}>You can upload up to 6 portfolio images</Text>
          </View>

          <Input
            label="Business Description"
            placeholder="Describe your business and services"
            value={profile.business_description}
            onChangeText={(text) => setProfile({ ...profile, business_description: text })}
            multiline
            numberOfLines={4}
          />

          <View style={styles.categoryContainer}>
            <Text style={styles.categoryLabel}>Category *</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryScroll}>
              {categories.map((category) => (
                <TouchableOpacity
                  key={category}
                  style={[
                    styles.categoryChip,
                    profile.category === category && styles.categoryChipSelected,
                  ]}
                  onPress={() => setProfile({ ...profile, category })}
                >
                  <Text
                    style={[
                      styles.categoryChipText,
                      profile.category === category && styles.categoryChipTextSelected,
                    ]}
                  >
                    {category}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          <Input
            label="Location"
            placeholder="Enter your business location"
            value={profile.location}
            onChangeText={(text) => setProfile({ ...profile, location: text })}
          />

          <Input
            label="City"
            placeholder="Enter your city"
            value={profile.city}
            onChangeText={(text) => setProfile({ ...profile, city: text })}
          />

          <Input
            label="Province"
            placeholder="Enter your province"
            value={profile.province}
            onChangeText={(text) => setProfile({ ...profile, province: text })}
          />
        </Card>

        <Card variant="elevated" padding="lg" style={styles.section}>
          <Text style={styles.sectionTitle}>Contact Information</Text>
          
          <Input
            label="Phone"
            placeholder="Enter your phone number"
            value={profile.phone}
            onChangeText={(text) => setProfile({ ...profile, phone: text })}
            keyboardType="phone-pad"
          />

          <Input
            label="Email"
            placeholder="Enter your business email"
            value={profile.email}
            onChangeText={(text) => setProfile({ ...profile, email: text })}
            keyboardType="email-address"
            autoCapitalize="none"
          />

          <Input
            label="Website"
            placeholder="Enter your website URL"
            value={profile.website}
            onChangeText={(text) => setProfile({ ...profile, website: text })}
            keyboardType="url"
            autoCapitalize="none"
          />
        </Card>

        <Card variant="elevated" padding="lg" style={styles.section}>
          <Text style={styles.sectionTitle}>Social Media</Text>
          
          <Input
            label="Instagram"
            placeholder="@your_instagram_handle"
            value={profile.instagram}
            onChangeText={(text) => setProfile({ ...profile, instagram: text })}
            autoCapitalize="none"
          />

          <Input
            label="Facebook"
            placeholder="Your Facebook page URL"
            value={profile.facebook}
            onChangeText={(text) => setProfile({ ...profile, facebook: text })}
            keyboardType="url"
            autoCapitalize="none"
          />
        </Card>

        <Card variant="elevated" padding="lg" style={styles.section}>
          <Text style={styles.sectionTitle}>Business Details</Text>
          
          <Input
            label="Years of Experience"
            placeholder="Enter years of experience"
            value={profile.years_experience}
            onChangeText={(text) => setProfile({ ...profile, years_experience: text })}
            keyboardType="numeric"
          />

          <Input
            label="Price Range"
            placeholder="e.g., R5,000 - R15,000"
            value={profile.price_range}
            onChangeText={(text) => setProfile({ ...profile, price_range: text })}
          />

          <Input
            label="Service Areas"
            placeholder="Enter areas you serve (comma separated)"
            value={profile.service_areas}
            onChangeText={(text) => setProfile({ ...profile, service_areas: text })}
          />

          <Input
            label="Languages"
            placeholder="Enter languages you speak (comma separated)"
            value={profile.languages}
            onChangeText={(text) => setProfile({ ...profile, languages: text })}
          />
        </Card>

        <Button
          title="Save Profile"
          onPress={saveProfile}
          loading={saving}
          fullWidth
          style={styles.saveButton}
        />
      </ScrollView>

      {/* Image Viewer Modal */}
      <Modal
        visible={imageViewerVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={closeImageViewer}
      >
        <View style={styles.imageViewerContainer}>
          <TouchableOpacity 
            style={styles.imageViewerCloseButton}
            onPress={closeImageViewer}
          >
            <Feather name="x" size={24} color="white" />
          </TouchableOpacity>
          
          {portfolioImages.length > 0 && (
            <>
              <Image 
                source={{ uri: portfolioImages[selectedImageIndex] }}
                style={styles.imageViewerImage}
                resizeMode="contain"
              />
              
              {portfolioImages.length > 1 && (
                <>
                  <TouchableOpacity 
                    style={[styles.imageViewerNavButton, styles.imageViewerNavLeft]}
                    onPress={goToPrevImage}
                  >
                    <Feather name="chevron-left" size={32} color="white" />
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={[styles.imageViewerNavButton, styles.imageViewerNavRight]}
                    onPress={goToNextImage}
                  >
                    <Feather name="chevron-right" size={32} color="white" />
                  </TouchableOpacity>
                  
                  <View style={styles.imageViewerIndicator}>
                    <Text style={styles.imageViewerIndicatorText}>
                      {selectedImageIndex + 1} / {portfolioImages.length}
                    </Text>
                  </View>
                </>
              )}
            </>
          )}
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  backButton: {
    padding: 8,
  },
  signOutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: colors.error || '#EF4444',
    gap: 6,
    shadowColor: 'rgba(0, 0, 0, 0.1)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    marginRight: 10,
  },
  signOutButtonText: {
    color: colors.white,
    fontSize: 12,
    fontWeight: '600',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text.primary,
    marginBottom: 16,
  },
  categoryContainer: {
    marginBottom: 16,
  },
  categoryLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text.primary,
    marginBottom: 8,
  },
  categoryScroll: {
    marginBottom: 8,
  },
  categoryChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: colors.background.secondary,
    marginRight: 8,
    borderWidth: 1,
    borderColor: colors.border.primary,
  },
  categoryChipSelected: {
    backgroundColor: colors.primary[300],
    borderColor: colors.primary[300],
  },
  categoryChipText: {
    fontSize: 14,
    color: colors.text.secondary,
    fontWeight: '500',
  },
  categoryChipTextSelected: {
    color: colors.text.inverse,
  },
  saveButton: {
    marginTop: 16,
    marginBottom: 32,
  },
  // Logo upload styles
  logoSection: {
    marginBottom: 24,
  },
  logoLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text.primary,
    marginBottom: 4,
  },
  logoSubtext: {
    fontSize: 14,
    color: colors.text.secondary,
    marginBottom: 12,
  },
  logoUploadContainer: {
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: colors.background.secondary,
    borderWidth: 2,
    borderColor: colors.border.primary,
    borderStyle: 'dashed',
  },
  logoPreview: {
    position: 'relative',
    width: 120,
    height: 120,
    alignSelf: 'center',
  },
  logoImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  logoOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 4,
  },
  logoOverlayText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '500',
  },
  logoPlaceholder: {
    padding: 24,
    alignItems: 'center',
    gap: 8,
  },
  logoPlaceholderText: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text.primary,
  },
  logoPlaceholderSubtext: {
    fontSize: 14,
    color: colors.text.secondary,
    textAlign: 'center',
  },
  // Portfolio styles
  portfolioSection: {
    marginBottom: 24,
  },
  portfolioLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text.primary,
    marginBottom: 4,
  },
  portfolioSubtext: {
    fontSize: 14,
    color: colors.text.secondary,
    marginBottom: 12,
  },
  portfolioGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  portfolioImageContainer: {
    position: 'relative',
    width: '31%', // 3 columns with space between
    aspectRatio: 1, // Square images
    borderRadius: 8,
    overflow: 'hidden',
    marginBottom: 12,
  },
  portfolioImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  removeImageButton: {
    position: 'absolute',
    top: 4,
    right: 4,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    borderRadius: 12,
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addImageButton: {
    width: '31%', // 3 columns with space between
    aspectRatio: 1, // Square buttons
    borderRadius: 8,
    borderWidth: 2,
    borderColor: colors.border.primary,
    borderStyle: 'dashed',
    backgroundColor: colors.background.secondary,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 4,
    marginBottom: 12,
  },
  addImageButtonDisabled: {
    opacity: 0.6,
  },
  addImageText: {
    fontSize: 12,
    color: colors.text.secondary,
    fontWeight: '500',
  },
  portfolioNote: {
    fontSize: 12,
    color: colors.text.secondary,
    fontStyle: 'italic',
  },
  // Image Viewer Styles
  imageViewerContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageViewerCloseButton: {
    position: 'absolute',
    top: 50,
    right: 20,
    zIndex: 1000,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: 20,
    padding: 8,
  },
  imageViewerImage: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height * 0.8,
  },
  imageViewerNavButton: {
    position: 'absolute',
    top: '50%',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: 25,
    padding: 10,
    zIndex: 1000,
  },
  imageViewerNavLeft: {
    left: 20,
  },
  imageViewerNavRight: {
    right: 20,
  },
  imageViewerIndicator: {
    position: 'absolute',
    bottom: 50,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  imageViewerIndicatorText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '500',
  },
});

