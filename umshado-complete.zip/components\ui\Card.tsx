// components/ui/Card.tsx
import React from 'react';
import { View, StyleSheet, ViewStyle, TouchableOpacity, Animated } from 'react-native';
import { colors, spacing, borderRadius, shadows, animations } from '@/src/theme/design-system';

interface CardProps {
  children: React.ReactNode;
  variant?: 'default' | 'elevated' | 'outlined' | 'filled';
  padding?: 'sm' | 'md' | 'lg' | 'xl';
  style?: ViewStyle;
  onPress?: () => void;
  pressable?: boolean;
  animated?: boolean;
}

export function Card({
  children,
  variant = 'default',
  padding = 'md',
  style,
  onPress,
  pressable = false,
  animated = false,
}: CardProps) {
  const [scaleValue] = React.useState(new Animated.Value(1));

  const handlePressIn = () => {
    if (animated) {
      Animated.spring(scaleValue, {
        toValue: 0.98,
        duration: animations.duration.fast,
        useNativeDriver: true,
      }).start();
    }
  };

  const handlePressOut = () => {
    if (animated) {
      Animated.spring(scaleValue, {
        toValue: 1,
        duration: animations.duration.fast,
        useNativeDriver: true,
      }).start();
    }
  };

  const cardStyle = [
    styles.base,
    styles[variant],
    styles[`padding${padding.charAt(0).toUpperCase() + padding.slice(1)}`],
    style,
  ];

  const CardComponent = pressable ? TouchableOpacity : View;
  const cardProps = pressable ? {
    onPress,
    onPressIn: handlePressIn,
    onPressOut: handlePressOut,
    activeOpacity: 0.95,
  } : {};

  if (animated) {
    return (
      <Animated.View style={{ transform: [{ scale: scaleValue }] }}>
        <CardComponent style={cardStyle} {...cardProps}>
          {children}
        </CardComponent>
      </Animated.View>
    );
  }

  return (
    <CardComponent style={cardStyle} {...cardProps}>
      {children}
    </CardComponent>
  );
}

const styles = StyleSheet.create({
  base: {
    borderRadius: borderRadius.lg,
    backgroundColor: colors.surface.primary,
  },
  
  // Variants
  default: {
    ...shadows.sm,
  },
  elevated: {
    ...shadows.lg,
  },
  outlined: {
    borderWidth: 1,
    borderColor: colors.border.primary,
  },
  filled: {
    backgroundColor: colors.background.secondary,
    ...shadows.sm,
  },
  
  // Padding
  paddingSm: {
    padding: spacing[3],
  },
  paddingMd: {
    padding: spacing[4],
  },
  paddingLg: {
    padding: spacing[6],
  },
  paddingXl: {
    padding: spacing[8],
  },
});


