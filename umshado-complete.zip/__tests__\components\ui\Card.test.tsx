import React from 'react';
import { render } from '@testing-library/react-native';
import { Card } from '@/components/ui/Card';
import { Text } from 'react-native';

describe('Card Component', () => {
  it('renders correctly with default props', () => {
    const { getByText } = render(
      <Card>
        <Text>Test Content</Text>
      </Card>
    );
    expect(getByText('Test Content')).toBeTruthy();
  });

  it('renders with different variants', () => {
    const { getByText: getDefault } = render(
      <Card variant="default">
        <Text>Default Card</Text>
      </Card>
    );
    const { getByText: getElevated } = render(
      <Card variant="elevated">
        <Text>Elevated Card</Text>
      </Card>
    );
    const { getByText: getOutlined } = render(
      <Card variant="outlined">
        <Text>Outlined Card</Text>
      </Card>
    );

    expect(getDefault('Default Card')).toBeTruthy();
    expect(getElevated('Elevated Card')).toBeTruthy();
    expect(getOutlined('Outlined Card')).toBeTruthy();
  });

  it('renders with different padding sizes', () => {
    const { getByText: getSmall } = render(
      <Card padding="sm">
        <Text>Small Padding</Text>
      </Card>
    );
    const { getByText: getMedium } = render(
      <Card padding="md">
        <Text>Medium Padding</Text>
      </Card>
    );
    const { getByText: getLarge } = render(
      <Card padding="lg">
        <Text>Large Padding</Text>
      </Card>
    );

    expect(getSmall('Small Padding')).toBeTruthy();
    expect(getMedium('Medium Padding')).toBeTruthy();
    expect(getLarge('Large Padding')).toBeTruthy();
  });

  it('applies custom style', () => {
    const customStyle = { backgroundColor: 'red' };
    const { getByText } = render(
      <Card style={customStyle}>
        <Text>Custom Style Card</Text>
      </Card>
    );
    expect(getByText('Custom Style Card')).toBeTruthy();
  });
});


