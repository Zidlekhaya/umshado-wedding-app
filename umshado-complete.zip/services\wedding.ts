import { supabase } from "@/lib/supabase";
import type { Wedding } from "@/types/wedding";

export async function createWedding(input: {
  name?: string;       // allow single input
  bride?: string;      // optional separate inputs
  groom?: string;
  date?: string;
  location?: string;
  culture?: string;
}) {
  const combinedName =
    input.name ??
    (input.bride && input.groom
      ? `${input.bride} & ${input.groom}`
      : input.bride ?? input.groom ?? "My Wedding");

  const { data, error } = await supabase
    .from("wedding")
    .insert({
      name: combinedName,
      date: input.date ?? null,
      location: input.location ?? null,
      culture: input.culture ?? null,
    })
    .select()
    .single();

  if (error) throw error;
  return data as Wedding;
}

export async function getWeddings() {
  const { data, error } = await supabase
    .from("wedding")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) throw error;
  return (data ?? []) as Wedding[];
}






