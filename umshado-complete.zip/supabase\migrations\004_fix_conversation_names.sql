-- Fix conversation names to show proper business names and couple names

-- Update vendor_name to use business_name from vendor_profiles
UPDATE conversations 
SET vendor_name = vp.business_name
FROM vendor_profiles vp
WHERE conversations.vendor_id = vp.user_id
AND conversations.vendor_name != vp.business_name;

-- Update couple_name to use actual wedding names from weddings table
UPDATE conversations 
SET couple_name = CONCAT(w.partner1_name, ' & ', w.partner2_name)
FROM weddings w
WHERE conversations.wedding_id = w.id
AND (conversations.couple_name = 'Couple' OR conversations.couple_name IS NULL);

-- If no wedding found, try to get names from auth.users metadata
UPDATE conversations 
SET couple_name = COALESCE(
  (au.raw_user_meta_data->>'partner1_name')::text || ' & ' || (au.raw_user_meta_data->>'partner2_name')::text,
  COALESCE((au.raw_user_meta_data->>'full_name')::text, 'Wedding Couple')
)
FROM auth.users au
WHERE conversations.couple_id = au.id
AND (conversations.couple_name = 'Couple' OR conversations.couple_name IS NULL);



