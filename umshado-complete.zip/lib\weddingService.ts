import { supabase } from './supabase';

export async function fetchActiveWeddingId(): Promise<string | null> {
  const { data, error } = await supabase.rpc('get_active_wedding');
  if (error) throw error;
  return data ?? null;
}

export async function setActiveWedding(id: string) {
  const { error } = await supabase.rpc('set_active_wedding', { p_wedding_id: id });
  if (error) throw error;
}

export async function loadWeddingById(id: string) {
  return supabase.from('weddings').select('id,name,date,location,culture').eq('id', id).single();
}

export async function listMyWeddings() {
  // list weddings where I'm a member
  return supabase
    .from('wedding_co_owner')
    .select('wedding_id,weddings!inner(id,name,date,location)')
    .order('created_at', { ascending: false });
}
