-- Create vendors table
CREATE TABLE IF NOT EXISTS public.vendors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL REFERENCES public.wedding(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN (
    'photography', 'catering', 'venue', 'flowers', 'music', 'decor', 
    'transportation', 'makeup', 'hair', 'dress', 'suit', 'cake', 
    'invitations', 'officiant', 'other'
  )),
  contact_person TEXT,
  email TEXT,
  phone TEXT,
  website TEXT,
  address TEXT,
  city TEXT,
  province TEXT,
  postal_code TEXT,
  country TEXT DEFAULT 'South Africa',
  
  -- Service details
  service_description TEXT,
  price_range TEXT,
  estimated_cost DECIMAL(12,2),
  deposit_paid DECIMAL(12,2) DEFAULT 0,
  final_payment_due DATE,
  
  -- Status and notes
  status TEXT NOT NULL DEFAULT 'contacted' CHECK (status IN (
    'contacted', 'quoted', 'booked', 'confirmed', 'completed', 'cancelled'
  )),
  priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN (
    'low', 'medium', 'high', 'urgent'
  )),
  notes TEXT,
  
  -- Rating and review
  rating DECIMAL(2,1) CHECK (rating >= 0 AND rating <= 5),
  review TEXT,
  
  -- Timestamps
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS vendors_wedding_idx ON public.vendors(wedding_id);
CREATE INDEX IF NOT EXISTS vendors_category_idx ON public.vendors(category);
CREATE INDEX IF NOT EXISTS vendors_status_idx ON public.vendors(status);
CREATE INDEX IF NOT EXISTS vendors_priority_idx ON public.vendors(priority);

-- Enable RLS
ALTER TABLE public.vendors ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "select_own_wedding_vendors" ON public.vendors
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "insert_own_wedding_vendors" ON public.vendors
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "update_own_wedding_vendors" ON public.vendors
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

CREATE POLICY "delete_own_wedding_vendors" ON public.vendors
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM public.wedding w 
      WHERE w.id = wedding_id AND w.owner_id = auth.uid()
    )
  );

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_vendors_updated
  BEFORE UPDATE ON public.vendors
  FOR EACH ROW
  EXECUTE FUNCTION set_updated_at();

-- Add vendor_id column to expense table for budget integration
ALTER TABLE public.expense 
ADD COLUMN IF NOT EXISTS vendor_id UUID REFERENCES public.vendors(id) ON DELETE SET NULL;

-- Create index for vendor_id in expense table
CREATE INDEX IF NOT EXISTS expense_vendor_idx ON public.expense(vendor_id);