import { supabase } from './supabase';

export interface VendorProfile {
  id: string;
  user_id: string;
  business_name: string;
  business_description?: string;
  category: string;
  location?: string;
  city?: string;
  contact_phone?: string;
  contact_email?: string;
  website?: string;
  experience_years?: number;
  price_range?: string;
  service_areas?: string;
  languages?: string;
  company_logo?: string;
  is_active: boolean;
  is_verified: boolean;
  created_at: string;
  updated_at: string;
}

/**
 * Get vendor profile by user ID
 */
export async function getVendorProfile(userId: string): Promise<VendorProfile | null> {
  try {
    const { data: profile, error } = await supabase
      .from('vendor_profiles')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        // No profile found
        return null;
      }
      console.error('Error loading vendor profile:', error);
      throw error;
    }

    return profile;
  } catch (error) {
    console.error('Error getting vendor profile:', error);
    throw error;
  }
}

/**
 * Create vendor profile
 */
export async function createVendorProfile(profileData: Partial<VendorProfile>): Promise<VendorProfile> {
  try {
    const { data: profile, error } = await supabase
      .from('vendor_profiles')
      .insert([profileData])
      .select()
      .single();

    if (error) {
      console.error('Error creating vendor profile:', error);
      throw error;
    }

    return profile;
  } catch (error) {
    console.error('Error creating vendor profile:', error);
    throw error;
  }
}

/**
 * Update vendor profile
 */
export async function updateVendorProfile(userId: string, updates: Partial<VendorProfile>): Promise<VendorProfile> {
  try {
    const { data: profile, error } = await supabase
      .from('vendor_profiles')
      .update({
        ...updates,
        updated_at: new Date().toISOString()
      })
      .eq('user_id', userId)
      .select()
      .single();

    if (error) {
      console.error('Error updating vendor profile:', error);
      throw error;
    }

    return profile;
  } catch (error) {
    console.error('Error updating vendor profile:', error);
    throw error;
  }
}

/**
 * Update user metadata to match vendor profile
 */
export async function updateUserMetadata(userId: string, profileData: Partial<VendorProfile>): Promise<void> {
  try {
    const { error } = await supabase.auth.updateUser({
      data: {
        user_type: 'vendor',
        business_name: profileData.business_name,
        category: profileData.category,
        location: profileData.location
      }
    });

    if (error) {
      console.error('Error updating user metadata:', error);
      throw error;
    }
  } catch (error) {
    console.error('Error updating user metadata:', error);
    throw error;
  }
}

/**
 * Get available vendor categories
 */
export function getVendorCategories(): string[] {
  return [
    'Photography',
    'Venues',
    'Catering',
    'Florist',
    'Beauty',
    'Music',
    'Transport',
    'Planning',
    'Decor',
    'Other',
  ];
}








