import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Image,
  Dimensions,
  RefreshControl,
  Alert,
  Modal,
} from 'react-native';
import { Stack, router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { supabase } from '@/lib/supabase';
import { Loading } from '@/components/ui/Loading';
import { Logo } from '@/src/components/ui/Logo';
import { shadows } from '@/src/theme/design-system';
import { trackVendorView } from '@/lib/vendor-stats-service';
import { getOrCreateConversation } from '@/lib/chat-service';
import { useWeddingStore } from '@/stores/wedding';

// Updated color scheme with new background
const colors = {
  background: '#f0fbea',
  surface: '#FFFFFF',
  primary: '#00a86b', // Updated green
  primaryGreen: '#00a86b', // Alias for primary
  secondary: '#FF6B35', // Orange accent
  text: '#1A1A1A',
  textSecondary: '#6B7280',
  textLight: '#9CA3AF',
  border: '#E5E7EB',
  divider: '#F1F5F9',
  shadow: '#000000',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  white: '#FFFFFF',
};

const { width: screenWidth } = Dimensions.get('window');

// Categories with icons
const categories = [
  { id: 'all', name: 'All', icon: 'grid' },
  { id: 'planning', name: 'Planning', icon: 'calendar' },
  { id: 'venues', name: 'Venues', icon: 'home' },
  { id: 'photography', name: 'Photography', icon: 'camera' },
  { id: 'florist', name: 'Florist', icon: 'heart' },
  { id: 'beauty', name: 'Beauty', icon: 'star' },
  { id: 'catering', name: 'Catering', icon: 'coffee' },
  { id: 'music', name: 'Music', icon: 'music' },
];

// Featured vendors data
const featuredVendors = [
  {
    id: 1,
    name: "Protea Floral Co.",
    category: "Florist",
    rating: 4.7,
    reviews: 156,
    price: "From R2,800",
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400",
    distance: "3.1 km",
    deliveryTime: "3-5 days",
    featured: true,
    badge: "Free delivery",
  },
  {
    id: 2,
    name: "Soweto Beauty Studio",
    category: "Beauty",
    rating: 4.9,
    reviews: 142,
    price: "From R1,800",
    image: "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=400",
    distance: "2.7 km",
    deliveryTime: "2-3 days",
    featured: true,
    badge: "Popular",
  },
  {
    id: 3,
    name: "Cape Town Photography",
    category: "Photography",
    rating: 4.8,
    reviews: 89,
    price: "From R4,500",
    image: "https://images.unsplash.com/photo-1606800052052-a08af7148866?w=400",
    distance: "5.2 km",
    deliveryTime: "Same day",
    featured: true,
    badge: "New",
  },
];


export default function ExploreScreen() {
  const { currentWedding } = useWeddingStore();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [realVendors, setRealVendors] = useState<any[]>([]);
  const [selectedVendor, setSelectedVendor] = useState<any>(null);
  const [showVendorModal, setShowVendorModal] = useState(false);
  const [imageViewerVisible, setImageViewerVisible] = useState(false);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [portfolioImages, setPortfolioImages] = useState<string[]>([]);

  const openImageViewer = (images: string[], index: number) => {
    setPortfolioImages(images);
    setSelectedImageIndex(index);
    setImageViewerVisible(true);
  };

  const closeImageViewer = () => {
    setImageViewerVisible(false);
  };

  const goToNextImage = () => {
    setSelectedImageIndex(prev => 
      prev < portfolioImages.length - 1 ? prev + 1 : 0
    );
  };

  const goToPrevImage = () => {
    setSelectedImageIndex(prev => 
      prev > 0 ? prev - 1 : portfolioImages.length - 1
    );
  };

  const loadVendors = async () => {
    try {
      setLoading(true);
      console.log('Loading vendors from database...');

      // Try to get vendor profiles first, fallback to vendors table
      let { data, error } = await supabase
        .from('vendor_profiles')
        .select('id, user_id, business_name, business_description, category, location, city, price_range, contact_email, contact_phone, website, company_logo, portfolio_images, rating_average, review_count, view_count, is_active, is_verified')
        .eq('is_active', true)
        .order('rating_average', { ascending: false })
        .order('created_at', { ascending: false })
        .limit(20);

      // If vendor_profiles table doesn't exist, fallback to vendors table
      if (error && error.code === 'PGRST205') {
        console.log('vendor_profiles table not found, using vendors table...');
        const fallbackResult = await supabase
          .from('vendors')
          .select('id, business_name, business_description, category, location, city, price_range, contact_email, contact_phone, website, company_logo, rating_average, review_count, view_count, is_active, is_verified, featured_image, description, is_featured, delivery_time, address, instagram_handle, gallery_images')
          .eq('is_active', true)
          .order('rating_average', { ascending: false })
          .order('created_at', { ascending: false })
          .limit(20);
        
        // Map vendors table data to vendor_profiles structure
        if (fallbackResult.data) {
          data = fallbackResult.data.map(vendor => ({
            id: vendor.id,
            user_id: vendor.id, // Use id as user_id for messaging
            business_name: vendor.business_name,
            business_description: vendor.business_description || vendor.description,
            category: vendor.category,
            location: vendor.location,
            city: vendor.city,
            price_range: vendor.price_range,
            contact_email: vendor.contact_email,
            contact_phone: vendor.contact_phone,
            website: vendor.website,
            company_logo: vendor.company_logo,
            portfolio_images: vendor.gallery_images, // Map gallery_images to portfolio_images
            rating_average: vendor.rating_average,
            review_count: vendor.review_count,
            view_count: vendor.view_count,
            is_active: vendor.is_active,
            is_verified: vendor.is_verified,
            // Extra fields from vendors table
            featured_image: vendor.featured_image,
            is_featured: vendor.is_featured,
            delivery_time: vendor.delivery_time,
            address: vendor.address,
            instagram_handle: vendor.instagram_handle,
          }));
        }
        error = fallbackResult.error;
        
      } else {
        console.log('vendor_profiles table found, using vendor profiles...');
        console.log('Vendor profiles data:', data);
      }

      if (error) {
        console.error('Database error:', error);
        throw error;
      }

      console.log('Vendors loaded successfully:', data?.length || 0);
      
      // Use the marketplace vendors data directly (optimized transformation)
      const marketplaceVendors = (data || []).map(vendor => ({
        id: vendor.id,
        user_id: vendor.user_id, // Include user_id for messaging
        business_name: vendor.business_name,
        category: vendor.category,
        rating_average: vendor.rating_average || 4.5,
        review_count: vendor.review_count || 0,
        price_range: vendor.price_range || 'Not provided',
        city: vendor.city || 'N/A',
        business_description: vendor.business_description || `${vendor.category} services`,
        is_active: vendor.is_active || true,
        company_logo: vendor.company_logo,
        portfolio_images: vendor.portfolio_images,
        tags: [vendor.category, 'Professional'],
        isOpen: true,
        contact_email: vendor.contact_email,
        contact_phone: vendor.contact_phone,
        website: vendor.website,
        location: vendor.location,
        is_verified: vendor.is_verified,
        view_count: vendor.view_count,
      }));

      setRealVendors(marketplaceVendors);
    } catch (error: any) {
      console.error('Error loading vendors:', error);
      console.log('Database error, using hardcoded vendor data');
      setRealVendors([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVendors();
  }, []);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadVendors().finally(() => setRefreshing(false));
  }, []);

  const getFilteredVendors = () => {
    const vendorList = realVendors.length > 0 ? realVendors : featuredVendors.map((v: any) => ({
      id: v.id,
      business_name: v.business_name,
      category: v.category,
      rating_average: v.rating_average,
      review_count: v.review_count,
      price_range: v.price_range,
      city: v.city,
      years_experience: 5,
      featured_image: v.featured_image,
      business_description: v.business_description,
      is_featured: v.is_featured,
      is_active: true,
      deliveryTime: v.deliveryTime,
      tags: v.tags,
      isOpen: v.isOpen,
    }));

    let filtered = vendorList;

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(vendor => 
        vendor.category?.toLowerCase() === selectedCategory.toLowerCase()
      );
    }

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(vendor =>
        vendor.business_name?.toLowerCase().includes(query) ||
        vendor.category?.toLowerCase().includes(query) ||
        vendor.business_description?.toLowerCase().includes(query)
      );
    }

    return filtered;
  };

  const handleVendorPress = async (vendor: any) => {
    setSelectedVendor(vendor);
    setShowVendorModal(true);
    
    // Track vendor profile view (only when couples view vendor profiles)
    try {
      if (vendor.id) {
        await trackVendorView(vendor.id);
        console.log('Vendor profile view tracked for:', vendor.business_name);
      }
    } catch (error) {
      console.error('Error tracking vendor view:', error);
      // Don't show error to user, just log it
    }
  };

  const handleContactVendor = (vendor: any) => {
    // In a real app, this would open email/phone
    Alert.alert(
      'Contact Vendor',
      `Would you like to contact ${vendor.business_name}?\n\nEmail: ${vendor.contact_email || 'Not provided'}\nPhone: ${vendor.contact_phone || 'Not provided'}`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Call', onPress: () => console.log('Call vendor:', vendor.contact_phone) },
        { text: 'Email', onPress: () => console.log('Email vendor:', vendor.contact_email) },
      ]
    );
  };


  const handleMessageVendor = async (vendor: any) => {
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      if (!sessionData.session?.user) {
        Alert.alert('Please sign in', 'You need to be logged in to message vendors.');
        return;
      }

      if (!currentWedding) {
        Alert.alert('No active wedding', 'Please create or select a wedding to message vendors.');
        return;
      }

      // Get vendor user ID (assuming vendor.id is the vendor profile ID, we need the user_id)
      const vendorUserId = vendor.user_id || vendor.id;
      
      const conversationId = await getOrCreateConversation({
        weddingId: currentWedding.id,
        weddingName: currentWedding.name || 'My Wedding',
        vendorUserId: vendorUserId,
        vendorName: vendor.business_name,
        vendorAvatar: vendor.company_logo,
      });

      router.push(`/(chat)/${conversationId}`);
    } catch (error) {
      console.error('Error starting conversation:', error);
      Alert.alert('Error', 'Failed to start conversation. Please try again.');
    }
  };

  const handleCallVendor = (vendor: any) => {
    Alert.alert(
      'Call Vendor',
      `Call ${vendor.business_name}?\n\nPhone: ${vendor.contact_phone || 'Not provided'}`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Call', onPress: () => console.log('Calling vendor:', vendor.contact_phone) },
      ]
    );
  };

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Feather key={i} name="star" size={12} color="#FFD700" />
      );
    }

    if (hasHalfStar) {
      stars.push(
        <Feather key="half" name="star" size={12} color="#FFD700" />
      );
    }

    const remainingStars = 5 - Math.ceil(rating);
    for (let i = 0; i < remainingStars; i++) {
      stars.push(
        <Feather key={`empty-${i}`} name="star" size={12} color="#E5E7EB" />
      );
    }

    return stars;
  };

  const renderFeaturedVendor = (vendor: any) => (
    <TouchableOpacity key={vendor.id} style={styles.featuredCard}>
      <View style={styles.featuredImageContainer}>
        <Image source={{ uri: vendor.image }} style={styles.featuredImage} />
        <View style={styles.featuredBadge}>
          <Text style={styles.featuredBadgeText}>{vendor.badge}</Text>
        </View>
      </View>
      <View style={styles.featuredContent}>
        <Text style={styles.featuredName}>{vendor.name}</Text>
        <Text style={styles.featuredCategory}>{vendor.category}</Text>
        <View style={styles.featuredRating}>
          <View style={styles.stars}>
            {renderStars(vendor.rating)}
          </View>
          <Text style={styles.ratingText}>({vendor.reviews})</Text>
        </View>
        <View style={styles.featuredFooter}>
          <Text style={styles.featuredPrice}>{vendor.price}</Text>
          <Text style={styles.featuredDistance}>{vendor.distance}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderVendorCard = (vendor: any) => (
    <TouchableOpacity 
      key={vendor.id} 
      style={styles.vendorCard} 
      onPress={() => handleVendorPress(vendor)}
      activeOpacity={0.7}
    >
      <View style={styles.vendorImageContainer}>
        {vendor.company_logo ? (
          <Image source={{ uri: vendor.company_logo }} style={styles.vendorImage} />
        ) : (
          <View style={styles.vendorImagePlaceholder}>
            <Feather name="briefcase" size={24} color={colors.textSecondary} />
          </View>
        )}
      </View>
      <View style={styles.vendorContent}>
        <View style={styles.vendorHeader}>
          <Text style={styles.vendorName}>{vendor.business_name || vendor.name}</Text>
          <View style={styles.vendorStatus}>
            <View style={styles.statusDot} />
            <Text style={styles.statusText}>Active</Text>
          </View>
        </View>
        <Text style={styles.vendorCategory}>{vendor.category}</Text>
        <View style={styles.vendorRating}>
          <View style={styles.stars}>
            {renderStars(vendor.rating_average || vendor.rating)}
          </View>
          <Text style={styles.ratingText}>({vendor.review_count || vendor.reviews})</Text>
          <Text style={styles.distanceText}>{vendor.city || vendor.distance}</Text>
        </View>
        <View style={styles.vendorFooter}>
          <Text style={styles.vendorPrice}>{vendor.price_range || vendor.price}</Text>
          <View style={styles.actionButtons} pointerEvents="box-none">
            <TouchableOpacity 
              style={styles.messageButton}
              onPress={(e) => {
                e.stopPropagation();
                handleMessageVendor(vendor);
              }}
              activeOpacity={0.7}
            >
              <Feather name="message-circle" size={14} color={colors.primaryGreen} />
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.contactButton}
              onPress={(e) => {
                e.stopPropagation();
                handleContactVendor(vendor);
              }}
              activeOpacity={0.7}
            >
              <Feather name="phone" size={14} color={colors.white} />
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <Loading size="large" color={colors.primary} text="Loading vendors..." />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen options={{ headerShown: false }} />
      
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <Logo size="small" showText={false} />
        </View>
        
        <View style={styles.searchContainer}>
          <View style={styles.searchBar}>
            <Feather name="search" size={20} color={colors.textLight} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search vendors, venues, services..."
              placeholderTextColor={colors.textLight}
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>
        </View>
      </View>

      <ScrollView
        style={styles.scrollView}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
        }
        showsVerticalScrollIndicator={false}
      >
        {/* Categories */}
        <View style={styles.categoriesSection}>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.categoriesScroll}
          >
            {categories.map((category) => (
              <TouchableOpacity
                key={category.id}
                style={[
                  styles.categoryButton,
                  selectedCategory === category.id && styles.categoryButtonActive
                ]}
                onPress={() => setSelectedCategory(category.id)}
              >
                <Feather
                  name={category.icon as any}
                  size={20}
                  color={selectedCategory === category.id ? colors.background : colors.textSecondary}
                />
                <Text
                  style={[
                    styles.categoryText,
                    selectedCategory === category.id && styles.categoryTextActive
                  ]}
                >
                  {category.name}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Section Divider */}
        <View style={styles.sectionDivider} />

        {/* Featured Vendors */}
        <View style={styles.featuredSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>✨ Featured Vendors</Text>
            <Text style={styles.sectionSubtitle}>Top South African picks</Text>
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.featuredScroll}
          >
            {featuredVendors.map(renderFeaturedVendor)}
          </ScrollView>
        </View>

        {/* Section Divider */}
        <View style={styles.sectionDivider} />

        {/* Wedding Packages */}
        <View style={styles.featuredSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>📦 Wedding Packages</Text>
            <Text style={styles.sectionSubtitle}>Complete wedding solutions</Text>
            <TouchableOpacity 
              style={styles.viewAllButton}
              onPress={() => router.push('/(marketplace)/packages')}
            >
              <Text style={styles.viewAllText}>View All</Text>
              <Feather name="arrow-right" size={16} color={colors.primary} />
            </TouchableOpacity>
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.featuredScroll}
          >
            <TouchableOpacity 
              style={styles.packageCard}
              onPress={() => router.push('/(marketplace)/packages')}
            >
              <View style={styles.packageImagePlaceholder}>
                <Feather name="package" size={40} color={colors.primary} />
              </View>
              <View style={styles.packageInfo}>
                <Text style={styles.packageTitle}>Browse Packages</Text>
                <Text style={styles.packageSubtitle}>Find complete wedding packages</Text>
                <Text style={styles.packagePrice}>From R1,500</Text>
              </View>
            </TouchableOpacity>
          </ScrollView>
        </View>

        {/* Section Divider */}
        <View style={styles.sectionDivider} />

        {/* All Vendors */}
        <View style={styles.vendorsSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Vendors near you</Text>
            <TouchableOpacity>
              <Feather name="chevron-right" size={20} color={colors.textSecondary} />
            </TouchableOpacity>
          </View>
          <View style={styles.vendorsList}>
            {getFilteredVendors().map(renderVendorCard)}
          </View>
        </View>
      </ScrollView>

      {/* Enhanced Vendor Detail Modal */}
      {showVendorModal && selectedVendor && (
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{selectedVendor.business_name}</Text>
              <TouchableOpacity onPress={() => setShowVendorModal(false)}>
                <Feather name="x" size={24} color={colors.text} />
              </TouchableOpacity>
            </View>
            
            {/* Vendor Logo/Image */}
            <View style={styles.imageSliderContainer}>
              <View style={styles.modalImageContainer}>
                {selectedVendor.company_logo ? (
                  <Image source={{ uri: selectedVendor.company_logo }} style={styles.modalImage} />
                ) : (
                  <View style={styles.modalImagePlaceholder}>
                    <Feather name="briefcase" size={40} color={colors.primary} />
                  </View>
                )}
              </View>
            </View>
            
            <View style={styles.modalBody}>
              <Text style={styles.modalCategory}>{selectedVendor.category}</Text>
              <Text style={styles.modalDescription}>{selectedVendor.business_description}</Text>
              
              {/* Portfolio Images */}
              {selectedVendor.portfolio_images && (() => {
                try {
                  const images = Array.isArray(selectedVendor.portfolio_images) 
                    ? selectedVendor.portfolio_images 
                    : JSON.parse(selectedVendor.portfolio_images);
                  
                  if (images && images.length > 0) {
                    return (
                      <View style={styles.portfolioSection}>
                        <Text style={styles.portfolioTitle}>Portfolio</Text>
                        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.portfolioScroll}>
                          {images.map((image: string, index: number) => (
                            <TouchableOpacity key={index} onPress={() => openImageViewer(images, index)}>
                              <Image 
                                source={{ uri: image }} 
                                style={styles.portfolioImage} 
                              />
                            </TouchableOpacity>
                          ))}
                        </ScrollView>
                      </View>
                    );
                  }
                } catch (error) {
                  console.error('Error parsing portfolio images:', error);
                }
                return null;
              })()}
              
              <View style={styles.modalRating}>
                <View style={styles.stars}>
                  {renderStars(selectedVendor.rating_average)}
                </View>
                <Text style={styles.ratingText}>({selectedVendor.review_count} reviews)</Text>
              </View>
              
              <View style={styles.modalInfo}>
                <View style={styles.infoRow}>
                  <Feather name="map-pin" size={16} color={colors.textSecondary} />
                  <Text style={styles.infoText}>{selectedVendor.city || selectedVendor.location}</Text>
                </View>
                {selectedVendor.contact_email && (
                  <View style={styles.infoRow}>
                    <Feather name="mail" size={16} color={colors.textSecondary} />
                    <Text style={styles.infoText}>{selectedVendor.contact_email}</Text>
                  </View>
                )}
                {selectedVendor.contact_phone && (
                  <View style={styles.infoRow}>
                    <Feather name="phone" size={16} color={colors.textSecondary} />
                    <Text style={styles.infoText}>{selectedVendor.contact_phone}</Text>
                  </View>
                )}
                {selectedVendor.website && (
                  <View style={styles.infoRow}>
                    <Feather name="globe" size={16} color={colors.textSecondary} />
                    <Text style={styles.infoText}>{selectedVendor.website}</Text>
                  </View>
                )}
              </View>

              {/* Social Links */}
              <View style={styles.socialLinks}>
                {selectedVendor.website && (
                  <TouchableOpacity style={styles.socialButton}>
                    <Feather name="globe" size={20} color={colors.primaryGreen} />
                    <Text style={styles.socialText}>Website</Text>
                  </TouchableOpacity>
                )}
              </View>

              {/* Packages Section */}
              <View style={styles.packagesSection}>
                <View style={styles.sectionHeader}>
                  <Text style={styles.sectionTitle}>📦 Packages</Text>
                  <Text style={styles.sectionSubtitle}>View available packages</Text>
                </View>
                <TouchableOpacity 
                  style={styles.viewPackagesButton}
                  onPress={() => {
                    setShowVendorModal(false);
                    router.push(`/(marketplace)/packages?vendor=${selectedVendor.id}`);
                  }}
                >
                  <View style={styles.packageButtonContent}>
                    <Feather name="package" size={20} color={colors.primary} />
                    <Text style={styles.packageButtonText}>View Packages</Text>
                    <Feather name="arrow-right" size={16} color={colors.primary} />
                  </View>
                </TouchableOpacity>
              </View>
            </View>
            
            <View style={styles.modalFooter}>
              <TouchableOpacity 
                style={styles.modalCallButton}
                onPress={() => handleCallVendor(selectedVendor)}
              >
                <Feather name="phone" size={20} color={colors.white} />
                <Text style={styles.modalContactButtonText}>Call Now</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.modalContactButton}
                onPress={() => handleContactVendor(selectedVendor)}
              >
                <Feather name="mail" size={20} color={colors.white} />
                <Text style={styles.modalContactButtonText}>Email</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}

      {/* Image Viewer Modal */}
      <Modal
        visible={imageViewerVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={closeImageViewer}
      >
        <View style={styles.imageViewerContainer}>
          <TouchableOpacity 
            style={styles.imageViewerCloseButton}
            onPress={closeImageViewer}
          >
            <Feather name="x" size={24} color="white" />
          </TouchableOpacity>
          
          {portfolioImages.length > 0 && (
            <>
              <Image 
                source={{ uri: portfolioImages[selectedImageIndex] }}
                style={styles.imageViewerImage}
                resizeMode="contain"
              />
              
              {portfolioImages.length > 1 && (
                <>
                  <TouchableOpacity 
                    style={[styles.imageViewerNavButton, styles.imageViewerNavLeft]}
                    onPress={goToPrevImage}
                  >
                    <Feather name="chevron-left" size={32} color="white" />
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={[styles.imageViewerNavButton, styles.imageViewerNavRight]}
                    onPress={goToNextImage}
                  >
                    <Feather name="chevron-right" size={32} color="white" />
                  </TouchableOpacity>
                  
                  <View style={styles.imageViewerIndicator}>
                    <Text style={styles.imageViewerIndicatorText}>
                      {selectedImageIndex + 1} / {portfolioImages.length}
                    </Text>
                  </View>
                </>
              )}
            </>
          )}
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  sectionDivider: {
    height: 1,
    backgroundColor: colors.divider,
    marginVertical: 24,
    marginHorizontal: 4,
  },
  header: {
    backgroundColor: colors.background,
    paddingTop: 10,
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  headerTime: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    color: colors.text,
  },
  scrollView: {
    flex: 1,
  },
  categoriesSection: {
    paddingVertical: 20,
  },
  categoriesScroll: {
    paddingHorizontal: 20,
  },
  categoryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginRight: 12,
    borderRadius: 25,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    minWidth: 100,
  },
  categoryButtonActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  categoryText: {
    marginLeft: 8,
    fontSize: 14,
    fontWeight: '500',
    color: colors.textSecondary,
  },
  categoryTextActive: {
    color: colors.background,
  },
  featuredSection: {
    paddingBottom: 30,
  },
  sectionHeader: {
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  featuredScroll: {
    paddingHorizontal: 20,
  },
  featuredCard: {
    width: screenWidth * 0.7,
    backgroundColor: colors.background,
    borderRadius: 16,
    marginRight: 16,
    overflow: 'hidden',
    ...shadows.md,
  },
  featuredImageContainer: {
    position: 'relative',
    height: 160,
  },
  featuredImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  featuredBadge: {
    position: 'absolute',
    top: 12,
    left: 12,
    backgroundColor: colors.success,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  featuredBadgeText: {
    color: colors.background,
    fontSize: 12,
    fontWeight: '600',
  },
  featuredContent: {
    padding: 16,
  },
  featuredName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  featuredCategory: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 8,
  },
  featuredRating: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  stars: {
    flexDirection: 'row',
    marginRight: 8,
  },
  ratingText: {
    fontSize: 12,
    color: colors.textSecondary,
    marginRight: 12,
  },
  featuredFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  featuredPrice: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
  },
  featuredDistance: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  vendorsSection: {
    paddingBottom: 100,
  },
  vendorsList: {
    paddingHorizontal: 20,
  },
  vendorCard: {
    flexDirection: 'row',
    backgroundColor: colors.background,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  vendorImageContainer: {
    width: 80,
    height: 80,
    marginRight: 16,
  },
  vendorImage: {
    width: '100%',
    height: '100%',
    borderRadius: 8,
    resizeMode: 'cover',
  },
  vendorImagePlaceholder: {
    width: '100%',
    height: '100%',
    borderRadius: 8,
    backgroundColor: colors.border,
    justifyContent: 'center',
    alignItems: 'center',
  },
  vendorContent: {
    flex: 1,
  },
  vendorHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 4,
  },
  vendorName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    flex: 1,
  },
  vendorStatus: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.success,
    marginRight: 4,
  },
  statusText: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  vendorCategory: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 8,
  },
  vendorRating: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  distanceText: {
    fontSize: 12,
    color: colors.textSecondary,
    marginLeft: 8,
  },
  vendorFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  vendorPrice: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
  },
  deliveryTime: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 6,
  },
  messageButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.primaryGreen,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: colors.shadow,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  contactButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.primaryGreen,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: colors.shadow,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 3,
  },
  modalOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modalContent: {
    backgroundColor: colors.background,
    borderRadius: 16,
    margin: 20,
    maxHeight: '80%',
    width: '90%',
    ...shadows.lg,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    flex: 1,
  },
  modalImage: {
    width: '100%',
    height: 160,
    resizeMode: 'cover',
  },
  modalBody: {
    padding: 20,
  },
  modalCategory: {
    fontSize: 14,
    color: colors.primaryGreen,
    fontWeight: '600',
    marginBottom: 8,
  },
  modalDescription: {
    fontSize: 16,
    color: colors.text,
    lineHeight: 24,
    marginBottom: 16,
  },
  portfolioSection: {
    marginBottom: 16,
  },
  portfolioTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  portfolioScroll: {
    marginHorizontal: -4,
  },
  portfolioImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
    marginHorizontal: 4,
    resizeMode: 'cover',
  },
  modalRating: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalInfo: {
    gap: 8,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  infoText: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  modalFooter: {
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    flexDirection: 'row',
    gap: 8,
  },
  modalContactButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.secondary,
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
    flex: 1,
  },
  modalContactButtonText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
  imageSliderContainer: {
    position: 'relative',
  },
  imageSlider: {
    height: 200,
  },
  imageDots: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 10,
    gap: 8,
  },
  imageDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.border,
  },
  socialLinks: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  socialButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 6,
  },
  socialText: {
    fontSize: 14,
    color: colors.text,
    fontWeight: '500',
  },
  modalCallButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primaryGreen,
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
    flex: 1,
    marginRight: 8,
  },
  // Package styles
  viewAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  viewAllText: {
    fontSize: 14,
    color: colors.primary,
    fontWeight: '600',
  },
  packageCard: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 16,
    marginRight: 16,
    width: 200,
    ...shadows.sm,
  },
  packageImagePlaceholder: {
    height: 80,
    backgroundColor: colors.background,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  packageInfo: {
    gap: 4,
  },
  packageTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  packageSubtitle: {
    fontSize: 12,
    color: colors.textLight,
    marginBottom: 8,
  },
  packagePrice: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.primary,
  },
  // Modal package styles
  modalImageContainer: {
    height: 120,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.background,
    borderRadius: 12,
    marginBottom: 16,
  },
  modalImagePlaceholder: {
    height: 100,
    backgroundColor: colors.background,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  packagesSection: {
    marginTop: 20,
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  viewPackagesButton: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 16,
    marginTop: 12,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  packageButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  packageButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.primary,
    flex: 1,
    marginLeft: 12,
  },
  // Image Viewer Styles
  imageViewerContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageViewerCloseButton: {
    position: 'absolute',
    top: 50,
    right: 20,
    zIndex: 1000,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: 20,
    padding: 8,
  },
  imageViewerImage: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height * 0.8,
  },
  imageViewerNavButton: {
    position: 'absolute',
    top: '50%',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: 25,
    padding: 10,
    zIndex: 1000,
  },
  imageViewerNavLeft: {
    left: 20,
  },
  imageViewerNavRight: {
    right: 20,
  },
  imageViewerIndicator: {
    position: 'absolute',
    bottom: 50,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  imageViewerIndicatorText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '500',
  },
});