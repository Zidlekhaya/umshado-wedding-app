// constants/Design.ts
// Design system inspired by the wedding app reference

export const Colors = {
  // Primary colors - Updated green palette
  primary: '#00a86b',        // Updated green (main brand color)
  primaryLight: '#00a86b',   // Same green
  primaryDark: '#00a86b',    // Same green
  
  // Secondary colors
  secondary: '#FF6B35',      // Orange accent
  secondaryLight: '#FF6B35', // Same orange
  secondaryDark: '#FF6B35',  // Same orange
  
  // Accent colors
  accent: '#00a86b',         // Green accent
  accentLight: '#00a86b',    // Same green
  accentDark: '#00a86b',     // Same green
  
  // Neutral colors
  white: '#FFFFFF',          // Pure white for headings and contrast
  black: '#1A1A1A',          // Dark text
  gray: {
    50: '#F8F8F8',           // Very light gray
    100: '#F0F0F0',          // Light gray
    200: '#E0E0E0',          // Medium light gray
    300: '#D3D3D3',          // Subtle gray (button outlines)
    400: '#B0B0B0',          // Medium gray
    500: '#8A8A8A',          // Base gray
    600: '#6B6B6B',          // Dark gray
    700: '#4A4A4A',          // Darker gray
    800: '#2C2C2C',          // Very dark gray
    900: '#1A1A1A',          // Almost black
  },
  
  // Status colors - Updated palette
  success: '#10B981',        // Green success
  warning: '#F59E0B',        // Orange warning
  error: '#EF4444',          // Red error
  info: '#00a86b',           // Green info
  
  // Background colors
  background: '#f0fbea',     // Updated light green background
  backgroundSecondary: '#f0fbea', // Same background
  surface: '#FFFFFF',        // White for cards
  surfaceSecondary: '#FFFFFF', // White secondary
  
  // Text colors
  text: '#1A1A1A',           // Dark text for main text
  textPrimary: '#1A1A1A',    // Dark text for headings
  textSecondary: '#6B7280',  // Medium gray for secondary text
  textLight: '#9CA3AF',      // Light gray for subtle text
  textOnPrimary: '#FFFFFF',  // White text on primary background
  textOnSecondary: '#1A1A1A', // Dark text on secondary background
  
  // Additional colors
  blue: {
    50: '#EFF6FF',
    100: '#DBEAFE',
    200: '#BFDBFE',
    300: '#93C5FD',
    400: '#60A5FA',
    500: '#3B82F6',
    600: '#2563EB',
    700: '#1D4ED8',
    800: '#1E40AF',
    900: '#1E3A8A',
  },
  green: {
    50: '#ECFDF5',
    100: '#D1FAE5',
    200: '#A7F3D0',
    300: '#6EE7B7',
    400: '#34D399',
    500: '#10B981',
    600: '#059669',
    700: '#047857',
    800: '#065F46',
    900: '#064E3B',
  },
};

export const Typography = {
  // Font families
  fontFamily: {
    primary: 'System', // Will use system font
    heading: 'System',
    body: 'System',
  },
  
  // Font sizes
  fontSize: {
    xs: 12,
    sm: 14,
    base: 16,
    lg: 18,
    xl: 20,
    '2xl': 24,
    '3xl': 30,
    '4xl': 36,
    '5xl': 48,
  },
  
  // Font weights
  fontWeight: {
    normal: '400' as const,
    medium: '500' as const,
    semibold: '600' as const,
    bold: '700' as const,
    extrabold: '800' as const,
  },
  
  // Line heights
  lineHeight: {
    tight: 1.25,
    normal: 1.5,
    relaxed: 1.75,
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  '2xl': 48,
  '3xl': 64,
};

export const BorderRadius = {
  none: 0,
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  '2xl': 24,
  full: 9999,
};

export const Shadows = {
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  lg: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 4,
  },
  xl: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.2,
    shadowRadius: 16,
    elevation: 8,
  },
};

export const Components = {
  // Button styles
  button: {
    primary: {
      backgroundColor: Colors.primary,
      borderRadius: BorderRadius.lg,
      paddingVertical: Spacing.md,
      paddingHorizontal: Spacing.lg,
    },
    secondary: {
      backgroundColor: Colors.secondary,
      borderRadius: BorderRadius.lg,
      paddingVertical: Spacing.md,
      paddingHorizontal: Spacing.lg,
    },
    outline: {
      backgroundColor: 'transparent',
      borderWidth: 1,
      borderColor: Colors.gray[300], // Subtle gray outlines
      borderRadius: BorderRadius.lg,
      paddingVertical: Spacing.md,
      paddingHorizontal: Spacing.lg,
    },
  },
  
  // Card styles
  card: {
    backgroundColor: Colors.surface, // Light beige cards
    borderRadius: BorderRadius.xl,
    padding: Spacing.lg,
    ...Shadows.md,
  },
  
  // Input styles
  input: {
    backgroundColor: Colors.surface, // Light beige background
    borderWidth: 1,
    borderColor: Colors.gray[300], // Subtle gray borders
    borderRadius: BorderRadius.lg,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    fontSize: Typography.fontSize.base,
  },
  
  // Section styles
  section: {
    marginVertical: Spacing.lg,
  },
  
  // Container styles
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingHorizontal: Spacing.lg,
  },
};
