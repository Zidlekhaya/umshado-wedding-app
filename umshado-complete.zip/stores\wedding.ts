// stores/wedding.ts
import { create } from 'zustand';
import type { Wedding } from '@/lib/wedding-service';

type WeddingState = {
  currentWedding: Wedding | null;
  setCurrentWedding: (wedding: Wedding | null) => void;
  hasWedding: boolean;
  setHasWedding: (has: boolean) => void;
  clearWedding: () => void;
};

export const useWeddingStore = create<WeddingState>((set) => ({
  currentWedding: null,
  setCurrentWedding: (wedding) => set({ 
    currentWedding: wedding,
    hasWedding: !!wedding 
  }),
  hasWedding: false,
  setHasWedding: (has) => set({ hasWedding: has }),
  clearWedding: () => set({ 
    currentWedding: null,
    hasWedding: false 
  }),
}));


