-- Add remind_at column to tasks table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'tasks' AND column_name = 'remind_at'
  ) THEN
    ALTER TABLE public.tasks
      ADD COLUMN remind_at timestamptz NULL;
  END IF;
END$$;

-- Create helpful index for upcoming reminders
CREATE INDEX IF NOT EXISTS task_remind_at_idx ON public.tasks(remind_at);

-- RLS is already limited via wedding_id; no extra policies needed.




