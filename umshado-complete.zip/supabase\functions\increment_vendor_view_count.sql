-- Function to increment vendor view count
CREATE OR REPLACE FUNCTION increment_vendor_view_count(vendor_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE vendor_profiles 
  SET view_count = COALESCE(view_count, 0) + 1,
      updated_at = NOW()
  WHERE id = vendor_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;








