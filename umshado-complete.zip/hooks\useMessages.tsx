// React hook for managing real-time messages in a conversation
import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { GiftedChatMessage, Message, Conversation, messageToGiftedChat, subscribeToMessages, getConversation, markMessagesAsRead } from '@/lib/chat-service';

export default function useMessages(conversationId: string) {
  const [messages, setMessages] = useState<GiftedChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [conversation, setConversation] = useState<Conversation | null>(null);

  // Fetch initial messages
  const fetchMessages = useCallback(async () => {
    if (!conversationId) return;

    try {
      setLoading(true);
      setError(null);

      // Get conversation data first
      const conversationData = await getConversation(conversationId);
      setConversation(conversationData);

      const { data, error: fetchError } = await supabase
        .from('messages')
        .select('*')
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: false })
        .limit(50);

      if (fetchError) throw fetchError;

      const giftedMessages = (data || []).map(msg => messageToGiftedChat(msg, conversationData));
      setMessages(giftedMessages);
    } catch (err) {
      console.error('Error fetching messages:', err);
      setError(err instanceof Error ? err.message : 'Failed to load messages');
    } finally {
      setLoading(false);
    }
  }, [conversationId]);

  // Set up real-time subscription
  useEffect(() => {
    if (!conversationId) return;

    // Fetch initial messages
    fetchMessages();

    // Subscribe to real-time updates
    const subscription = subscribeToMessages(conversationId, (newMessage) => {
      setMessages(prev => [newMessage, ...prev]);
    });

    return () => {
      supabase.removeChannel(subscription);
    };
  }, [conversationId, fetchMessages]);

  // Load earlier messages (for pagination)
  const loadEarlierMessages = useCallback(async () => {
    if (!conversationId || messages.length === 0) return;

    try {
      const oldestMessage = messages[messages.length - 1];
      
      const { data, error: fetchError } = await supabase
        .from('messages')
        .select('*')
        .eq('conversation_id', conversationId)
        .lt('created_at', oldestMessage.createdAt.toISOString())
        .order('created_at', { ascending: false })
        .limit(20);

      if (fetchError) throw fetchError;

      const earlierMessages = (data || []).map(msg => messageToGiftedChat(msg, conversation));
      setMessages(prev => [...prev, ...earlierMessages]);
    } catch (err) {
      console.error('Error loading earlier messages:', err);
    }
  }, [conversationId, messages]);

  return {
    messages,
    loading,
    error,
    loadEarlierMessages,
    refreshMessages: fetchMessages,
    setMessages,
  };
}
