#!/usr/bin/env node

/**
 * Test Policy Script
 * This script tests the RLS policy and shows what's happening
 */

const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing Supabase environment variables');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function testPolicy() {
  console.log('🧪 Testing RLS policy...\n');

  try {
    // Get current user
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    
    if (userError) {
      console.error('❌ Error getting user:', userError.message);
      return;
    }

    if (!user) {
      console.log('❌ No authenticated user found');
      return;
    }

    console.log('👤 Current user:', user.email);
    console.log('🆔 User ID:', user.id);

    // Get vendor profile for this user
    const { data: vendorProfile, error: profileError } = await supabase
      .from('vendor_profiles')
      .select('id, business_name, user_id')
      .eq('user_id', user.id)
      .single();

    if (profileError) {
      console.error('❌ Error fetching vendor profile:', profileError.message);
      return;
    }

    console.log('🏢 Vendor profile:', vendorProfile.business_name);
    console.log('🆔 Vendor ID:', vendorProfile.id);
    console.log('🔗 User ID match:', vendorProfile.user_id === user.id);

    // Test the policy by trying to insert a simple service
    console.log('\n🧪 Testing INSERT policy...');
    
    const testService = {
      vendor_id: vendorProfile.id,
      service_name: 'Test Service',
      description: 'This is a test service',
      price_min: 1000,
      price_max: 2000,
      price_type: 'fixed',
      is_active: true,
    };

    const { data: insertedService, error: insertError } = await supabase
      .from('vendor_services')
      .insert([testService])
      .select();

    if (insertError) {
      console.error('❌ INSERT failed:', insertError.message);
      console.error('📋 Error details:', insertError);
      
      // Check if there are existing policies
      console.log('\n🔍 Checking existing policies...');
      const { data: policies, error: policiesError } = await supabase
        .from('pg_policies')
        .select('*')
        .eq('tablename', 'vendor_services');
      
      if (policiesError) {
        console.log('❌ Could not check policies:', policiesError.message);
      } else {
        console.log('📋 Existing policies:', policies);
      }
      
    } else {
      console.log('✅ INSERT successful!');
      console.log('🎉 Service created:', insertedService[0].service_name);
      
      // Clean up the test service
      await supabase
        .from('vendor_services')
        .delete()
        .eq('id', insertedService[0].id);
      console.log('🧹 Test service cleaned up');
    }

  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

testPolicy().then(() => {
  console.log('\n✨ Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('❌ Script failed:', error);
  process.exit(1);
});
