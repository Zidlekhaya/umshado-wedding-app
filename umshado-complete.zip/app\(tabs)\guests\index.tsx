import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  Alert,
  SafeAreaView,
  Modal,
  ScrollView,
  TextInput,
} from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { useWeddingStore } from '@/stores/wedding';
import { listGuests, deleteGuest, updateGuest, createGuest } from '@/lib/guest-service';
import type { Guest, RSVPStatus } from '@/types/guest';
import { getRelativeTime } from '@/lib/date-utils';
import { 
  getResponseColor,
  getResponseIcon,
} from '@/lib/guest-communication-service';
import { Card } from '@/components/ui/Card';
import { Loading } from '@/components/ui/Loading';
import { Logo } from '@/src/components/ui/Logo';
import ContactSelector from '@/src/components/ContactSelector';

// Updated color scheme with enhanced UI colors
const modernColors = {
  background: '#f0fbea',
  surface: '#FFFFFF',
  primary: '#00a86b',
  secondary: '#FF6B35',
  text: '#1A1A1A',
  textSecondary: '#6B7280',
  textLight: '#9CA3AF',
  border: '#E5E7EB',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  white: '#FFFFFF',
  // Enhanced colors for better UI
  headerBg: '#F8FAFC',
  headerText: '#1E293B',
  cardShadow: 'rgba(0, 0, 0, 0.1)',
  shadow: 'rgba(0, 0, 0, 0.1)',
  accent: '#F3F4F6',
};

export default function GuestsScreen() {
  const [guests, setGuests] = useState<Guest[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState<'guests' | 'rsvp'>('guests');
  const [selectedResponse, setSelectedResponse] = useState<RSVPStatus | null>(null);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [showContactSelector, setShowContactSelector] = useState(false);
  const [showAddGuestModal, setShowAddGuestModal] = useState(false);
  const [showEditGuestModal, setShowEditGuestModal] = useState(false);
  const [editingGuest, setEditingGuest] = useState<Guest | null>(null);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [side, setSide] = useState<'Bride' | 'Groom' | 'Both'>('Both');
  const [addingGuest, setAddingGuest] = useState(false);
  const router = useRouter();
  const { currentWedding } = useWeddingStore();

  const loadGuests = useCallback(async () => {
    console.log('🔍 loadGuests called, currentWedding:', currentWedding);
    if (!currentWedding?.id) {
      console.log('❌ No currentWedding.id, skipping guest load');
      return;
    }
    
    try {
      console.log('Loading guests...');
      const guestList = await listGuests(currentWedding.id);
      setGuests(guestList);
    } catch (error) {
      console.error('Error loading guests:', error);
      Alert.alert('Error', 'Failed to load guests');
    } finally {
      setLoading(false);
    }
  }, [currentWedding]);

  useEffect(() => {
    loadGuests();
  }, [loadGuests]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadGuests().finally(() => setRefreshing(false));
  }, [loadGuests]);

  const handleDeleteGuest = useCallback(async (guest: Guest) => {
    Alert.alert(
      'Delete Guest',
      `Are you sure you want to delete ${guest.full_name}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteGuest(guest.id);
              await loadGuests();
              Alert.alert('Success', 'Guest deleted successfully');
            } catch (error) {
              console.error('Error deleting guest:', error);
              Alert.alert('Error', 'Failed to delete guest');
            }
          },
        },
      ]
    );
  }, [loadGuests]);

  const handleGuestsAdded = useCallback(() => {
    loadGuests();
  }, [loadGuests]);

  const handleEditGuest = useCallback((guest: Guest) => {
    setEditingGuest(guest);
    setFullName(guest.full_name);
    setEmail(guest.email || '');
    setPhone(guest.phone || '');
    setSide((guest.side === 'bride' ? 'Bride' : guest.side === 'groom' ? 'Groom' : 'Both') as 'Bride' | 'Groom' | 'Both');
    setShowEditGuestModal(true);
  }, []);

  const handleUpdateGuest = useCallback(async () => {
    if (!fullName.trim() || !editingGuest) {
      Alert.alert('Error', 'Please enter the guest&apos;s full name');
      return;
    }

    setAddingGuest(true);
    try {
      await updateGuest({
        id: editingGuest.id,
        full_name: fullName.trim(),
        email: email.trim() || null,
        phone: phone.trim() || null,
        side: side.toLowerCase() as any, // Convert to lowercase for database
      });
      
      Alert.alert('Success', 'Guest updated successfully!');
      
      // Reset form
      setFullName('');
      setEmail('');
      setPhone('');
      setSide('Both');
      setEditingGuest(null);
      setShowEditGuestModal(false);
      
      // Refresh guest list
      loadGuests();
    } catch (error) {
      console.error('Error updating guest:', error);
      Alert.alert('Error', 'Failed to update guest. Please try again.');
    } finally {
      setAddingGuest(false);
    }
  }, [fullName, email, phone, side, editingGuest, loadGuests]);

  const handleCreateGuest = useCallback(async () => {
    if (!fullName.trim()) {
      Alert.alert('Error', 'Please enter the guest&apos;s full name');
      return;
    }

    if (!currentWedding?.id) {
      Alert.alert('Error', 'No wedding selected');
      return;
    }

    setAddingGuest(true);
    try {
      await createGuest({
        wedding_id: currentWedding.id,
        full_name: fullName.trim(),
        email: email.trim() || null,
        phone: phone.trim() || null,
        side: side.toLowerCase() as any, // Convert to lowercase for database
      });
      
      Alert.alert('Success', 'Guest added successfully!');
      
      // Reset form
      setFullName('');
      setEmail('');
      setPhone('');
      setSide('Both');
      setShowAddGuestModal(false);
      
      // Refresh guest list
      loadGuests();
    } catch (error) {
      console.error('Error creating guest:', error);
      Alert.alert('Error', 'Failed to add guest. Please try again.');
    } finally {
      setAddingGuest(false);
    }
  }, [fullName, email, phone, side, currentWedding?.id, loadGuests]);


  const handleUpdateRSVP = useCallback(async (guestId: string, response: RSVPStatus) => {
    if (!currentWedding?.id) return;

    try {
      await updateGuest({
        id: guestId,
        rsvp: response,
      });
      await loadGuests();
      Alert.alert('Success', 'RSVP updated successfully');
    } catch (error) {
      console.error('Error updating RSVP:', error);
      Alert.alert('Error', 'Failed to update RSVP');
    }
  }, [currentWedding?.id, loadGuests]);

  const renderGuest = ({ item }: { item: Guest }) => (
    <Card style={styles.guestCard} variant="elevated">
    <TouchableOpacity
        style={styles.guestContent}
      onPress={() => handleEditGuest(item)}
    >
        <View style={styles.guestAvatar}>
          <Text style={styles.guestAvatarText}>
            {item.full_name.split(' ').map(n => n[0]).join('').toUpperCase()}
          </Text>
        </View>
      <View style={styles.guestInfo}>
        <Text style={styles.guestName}>{item.full_name}</Text>
        <Text style={styles.guestEmail}>{item.email}</Text>
        {item.phone && (
          <Text style={styles.guestPhone}>{item.phone}</Text>
        )}
      </View>
      <View style={styles.guestActions}>
        <TouchableOpacity
          style={styles.guestActionButton}
          onPress={() => handleEditGuest(item)}
        >
            <Feather name="edit" size={18} color={modernColors.white} />
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.guestActionButton}
          onPress={() => handleDeleteGuest(item)}
        >
            <Feather name="trash-2" size={18} color={modernColors.white} />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
    </Card>
  );

  const renderRSVPItem = ({ item }: { item: Guest }) => {
    return (
      <Card style={styles.rsvpCard} variant="elevated">
        <View style={styles.rsvpHeader}>
          <View style={styles.rsvpGuestInfo}>
            <View style={styles.rsvpAvatar}>
              <Text style={styles.rsvpAvatarText}>
                {item.full_name.split(' ').map(n => n[0]).join('').toUpperCase()}
              </Text>
            </View>
            <View style={styles.rsvpDetails}>
              <Text style={styles.rsvpName}>{item.full_name}</Text>
              <Text style={styles.rsvpEmail}>{item.email}</Text>
            </View>
          </View>
          <View style={[styles.rsvpStatus, { backgroundColor: getResponseColor(item.rsvp) }]}>
            {getResponseIcon(item.rsvp)}
            <Text style={styles.responseText}>{item.rsvp || 'no_reply'}</Text>
          </View>
        </View>
        {item.rsvp && item.rsvp !== 'no_reply' && (
          <Text style={styles.respondedAt}>
            Responded {item.updated_at ? getRelativeTime(item.updated_at) : 'recently'}
          </Text>
        )}
        <View style={styles.rsvpActions}>
          <TouchableOpacity
            style={[styles.rsvpActionButton, { backgroundColor: modernColors.success }]}
            onPress={() => handleUpdateRSVP(item.id, 'going')}
          >
            <Text style={styles.rsvpActionButtonText}>Accept</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.rsvpActionButton, { backgroundColor: modernColors.error }]}
            onPress={() => handleUpdateRSVP(item.id, 'declined')}
          >
            <Text style={styles.rsvpActionButtonText}>Decline</Text>
          </TouchableOpacity>
        </View>
      </Card>
    );
  };

  const filteredGuests = selectedResponse 
    ? guests.filter(guest => guest.rsvp === selectedResponse)
    : guests;

  const getRSVPStats = () => {
    const total = guests.length;
    const attending = guests.filter(g => g.rsvp === 'going').length;
    const declined = guests.filter(g => g.rsvp === 'declined').length;
    const pending = guests.filter(g => g.rsvp === 'no_reply' || !g.rsvp).length;
    
    return { total, attending, declined, pending };
  };

  const stats = getRSVPStats();

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <Loading size="large" color={modernColors.primary} text="Loading guests..." />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen
        options={{
          headerShown: false,
        }}
      />
      
      {/* Custom Header */}
      <View style={styles.headerSection}>
        <View style={styles.headerTop}>
          <Logo size="small" showText={false} />
          <Text style={styles.headerTitle}>Guests</Text>
          <View style={styles.headerActions}>
            <TouchableOpacity 
              style={styles.filterButton}
              onPress={() => setShowFilterModal(true)}
            >
              <Feather name="filter" size={16} color={modernColors.textSecondary} />
            </TouchableOpacity>
          </View>
        </View>
      </View>
      
      <View style={styles.content}>
        {/* Stats Overview */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <View style={styles.statIcon}>
              <Feather name="users" size={20} color={modernColors.primary} />
            </View>
            <Text style={styles.statNumber}>{stats.total}</Text>
            <Text style={styles.statLabel}>Total Guests</Text>
          </View>
          
          <View style={styles.statCard}>
            <View style={styles.statIcon}>
              <Feather name="check-circle" size={20} color={modernColors.success} />
            </View>
            <Text style={styles.statNumber}>{stats.attending}</Text>
            <Text style={styles.statLabel}>Attending</Text>
          </View>
          
          <View style={styles.statCard}>
            <View style={styles.statIcon}>
              <Feather name="x-circle" size={20} color={modernColors.error} />
            </View>
            <Text style={styles.statNumber}>{stats.declined}</Text>
            <Text style={styles.statLabel}>Declined</Text>
          </View>
          
          <View style={styles.statCard}>
            <View style={styles.statIcon}>
              <Feather name="clock" size={20} color={modernColors.warning} />
            </View>
            <Text style={styles.statNumber}>{stats.pending}</Text>
            <Text style={styles.statLabel}>Pending</Text>
          </View>
        </View>

        {/* ADD GUEST BUTTONS - VERY VISIBLE */}
        <View style={styles.addGuestButtonsContainer}>
          <TouchableOpacity 
            style={styles.addContactButton}
            onPress={() => {
              console.log('🔥 Add Contact button pressed!');
              setShowAddGuestModal(true);
            }}
          >
            <Feather name="user-plus" size={20} color="#FFFFFF" />
            <Text style={styles.addContactButtonText}>Add Contact</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.importContactsButton}
            onPress={() => {
              console.log('🔥 Import button pressed!');
              setShowContactSelector(true);
            }}
          >
            <Feather name="users" size={20} color="#00a86b" />
            <Text style={styles.importContactsButtonText}>Import Contacts</Text>
          </TouchableOpacity>
        </View>

        {/* Tab Selector */}
        <View style={styles.tabContainer}>
          <TouchableOpacity
            style={[styles.tabButton, activeTab === 'guests' && styles.tabButtonActive]}
            onPress={() => setActiveTab('guests')}
          >
            <Feather 
              name="users" 
              size={16} 
              color={activeTab === 'guests' ? modernColors.white : modernColors.textSecondary} 
            />
            <Text style={[styles.tabText, activeTab === 'guests' && styles.tabTextActive]}>
              Guest List
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tabButton, activeTab === 'rsvp' && styles.tabButtonActive]}
            onPress={() => setActiveTab('rsvp')}
          >
            <Feather 
              name="mail" 
              size={16} 
              color={activeTab === 'rsvp' ? modernColors.white : modernColors.textSecondary} 
            />
            <Text style={[styles.tabText, activeTab === 'rsvp' && styles.tabTextActive]}>
              RSVP Status
            </Text>
          </TouchableOpacity>
        </View>

        {/* Guest List */}
            <FlatList
              data={filteredGuests}
              keyExtractor={(item) => item.id}
          renderItem={activeTab === 'guests' ? renderGuest : renderRSVPItem}
          contentContainerStyle={styles.guestList}
              refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={modernColors.primary} />
              }
              ListEmptyComponent={
                <View style={styles.emptyContainer}>
              <View style={styles.emptyIcon}>
                <Feather name="users" size={48} color={modernColors.textLight} />
              </View>
              <Text style={styles.emptyTitle}>No guests yet</Text>
                  <Text style={styles.emptySubtitle}>
                Start by adding guests to your wedding list.
                  </Text>
                </View>
              }
            />
      </View>


      {/* Filter Modal */}
      <Modal
        visible={showFilterModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Filter RSVPs</Text>
            <TouchableOpacity onPress={() => setShowFilterModal(false)}>
              <Feather name="x" size={24} color={modernColors.primary} />
            </TouchableOpacity>
          </View>
          
          <ScrollView style={styles.modalContent}>
            <TouchableOpacity
              style={[
                styles.filterOption,
                !selectedResponse && styles.filterOptionActive
              ]}
              onPress={() => setSelectedResponse(null)}
            >
              <Text style={[
                styles.filterOptionText,
                !selectedResponse && styles.filterOptionTextActive
              ]}>
                All Guests
              </Text>
            </TouchableOpacity>
            {(['going', 'maybe', 'declined', 'no_reply'] as RSVPStatus[]).map((response) => (
              <TouchableOpacity
                key={response}
                style={[
                  styles.filterOption,
                  selectedResponse === response && styles.filterOptionActive
                ]}
                onPress={() => setSelectedResponse(response)}
              >
                  <Text style={[
                    styles.filterOptionText,
                    selectedResponse === response && styles.filterOptionTextActive
                  ]}>
                  {response === 'going' ? 'Attending' : 
                   response === 'maybe' ? 'Maybe' :
                   response === 'declined' ? 'Declined' :
                   response === 'no_reply' ? 'No Reply' : response}
                  </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
          
          <View style={styles.modalFooter}>
            <TouchableOpacity style={styles.applyFilterButton} onPress={() => setShowFilterModal(false)}>
              <Text style={styles.applyFilterButtonText}>Apply Filter</Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </Modal>

      {/* Debug: Always show buttons */}
      {(() => {
        console.log('🔥 Rendering floating buttons!');
        return null;
      })()}
      
      {/* Floating Add Contact Button - Left Side */}
      <TouchableOpacity 
        style={styles.floatingAddButton}
        onPress={() => {
          console.log('🔥 Add Contact button pressed!');
          setShowAddGuestModal(true);
        }}
        activeOpacity={0.8}
      >
        <Feather name="user-plus" size={20} color="#FFFFFF" />
        <Text style={styles.floatingAddText}>Add Contact</Text>
      </TouchableOpacity>

      {/* Floating Import Button - Right Side */}
      <TouchableOpacity 
        style={styles.floatingImportButton}
        onPress={() => {
          console.log('🔥 Import button pressed!');
          setShowContactSelector(true);
        }}
        activeOpacity={0.8}
      >
        <Feather name="users" size={20} color="#00a86b" />
        <Text style={styles.floatingImportText}>Import</Text>
      </TouchableOpacity>

      {/* Add Guest Modal */}
      <Modal
        visible={showAddGuestModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowAddGuestModal(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity
              onPress={() => setShowAddGuestModal(false)}
              style={styles.modalCloseButton}
            >
              <Feather name="x" size={24} color={modernColors.text} />
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Add New Guest</Text>
            <View style={styles.modalHeaderSpacer} />
          </View>

          <ScrollView style={styles.modalContent} showsVerticalScrollIndicator={false}>
            <Card variant="elevated" padding="lg">
              <View style={styles.formContainer}>
                {/* Full Name - Required */}
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>
                    Full Name <Text style={styles.required}>*</Text>
                  </Text>
                  <View style={styles.inputField}>
                    <Feather name="user" size={20} color={modernColors.textSecondary} />
                    <TextInput
                      style={styles.input}
                      value={fullName}
                      onChangeText={setFullName}
                      placeholder="e.g. Thandi Mthembu"
                      placeholderTextColor={modernColors.textLight}
                      autoCapitalize="words"
                      autoCorrect={false}
                    />
                  </View>
                </View>

                {/* Email */}
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Email</Text>
                  <View style={styles.inputField}>
                    <Feather name="mail" size={20} color={modernColors.textSecondary} />
                    <TextInput
                      style={styles.input}
                      value={email}
                      onChangeText={setEmail}
                      placeholder="thandi@gmail.com"
                      placeholderTextColor={modernColors.textLight}
                      keyboardType="email-address"
                      autoCapitalize="none"
                      autoCorrect={false}
                    />
                  </View>
                </View>

                {/* Phone Number */}
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Phone Number</Text>
                  <View style={styles.inputField}>
                    <Feather name="phone" size={20} color={modernColors.textSecondary} />
                    <TextInput
                      style={styles.input}
                      value={phone}
                      onChangeText={setPhone}
                      placeholder="+27 82 123 4567"
                      placeholderTextColor={modernColors.textLight}
                      keyboardType="phone-pad"
                    />
                  </View>
                </View>

                {/* Guest Side */}
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Guest Side</Text>
                  <View style={styles.sideSelector}>
                    {[
                      { value: 'Both', label: 'Both', icon: 'heart' },
                      { value: 'Bride', label: 'Bride', icon: 'user' },
                      { value: 'Groom', label: 'Groom', icon: 'user' },
                    ].map((option) => (
                      <TouchableOpacity
                        key={option.value}
                        style={[
                          styles.sideOption,
                          side === option.value && styles.sideOptionActive,
                        ]}
                        onPress={() => setSide(option.value as 'Bride' | 'Groom' | 'Both')}
                      >
                        <Feather
                          name={option.icon as any}
                          size={16}
                          color={
                            side === option.value
                              ? modernColors.white
                              : modernColors.textSecondary
                          }
                        />
                        <Text
                          style={[
                            styles.sideOptionText,
                            side === option.value && styles.sideOptionTextActive,
                          ]}
                        >
                          {option.label}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                <View style={styles.infoBox}>
                  <Feather name="info" size={18} color={modernColors.textSecondary} />
                  <Text style={styles.infoText}>
                    Email and phone are optional but recommended for sending invitations and updates.
                  </Text>
                </View>
              </View>
            </Card>

            {/* Action Buttons */}
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[
                  styles.addButton,
                  !fullName.trim() && styles.addButtonDisabled,
                ]}
                onPress={handleCreateGuest}
                disabled={!fullName.trim() || addingGuest}
              >
                <Text style={styles.addButtonText}>
                  {addingGuest ? 'Adding...' : 'Add Guest'}
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => setShowAddGuestModal(false)}
                disabled={addingGuest}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </SafeAreaView>
      </Modal>

      {/* Edit Guest Modal */}
      <Modal
        visible={showEditGuestModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowEditGuestModal(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity
              onPress={() => setShowEditGuestModal(false)}
              style={styles.modalCloseButton}
            >
              <Feather name="x" size={24} color={modernColors.text} />
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Edit Guest</Text>
            <View style={styles.modalHeaderSpacer} />
          </View>

          <ScrollView style={styles.modalContent} showsVerticalScrollIndicator={false}>
            <Card variant="elevated" padding="lg">
              <View style={styles.formContainer}>
                {/* Full Name - Required */}
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>
                    Full Name <Text style={styles.required}>*</Text>
                  </Text>
                  <View style={styles.inputField}>
                    <Feather name="user" size={20} color={modernColors.textSecondary} />
                    <TextInput
                      style={styles.input}
                      value={fullName}
                      onChangeText={setFullName}
                      placeholder="e.g. Thandi Mthembu"
                      placeholderTextColor={modernColors.textLight}
                      autoCapitalize="words"
                      autoCorrect={false}
                    />
                  </View>
                </View>

                {/* Email */}
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Email</Text>
                  <View style={styles.inputField}>
                    <Feather name="mail" size={20} color={modernColors.textSecondary} />
                    <TextInput
                      style={styles.input}
                      value={email}
                      onChangeText={setEmail}
                      placeholder="thandi@gmail.com"
                      placeholderTextColor={modernColors.textLight}
                      keyboardType="email-address"
                      autoCapitalize="none"
                      autoCorrect={false}
                    />
                  </View>
                </View>

                {/* Phone Number */}
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Phone Number</Text>
                  <View style={styles.inputField}>
                    <Feather name="phone" size={20} color={modernColors.textSecondary} />
                    <TextInput
                      style={styles.input}
                      value={phone}
                      onChangeText={setPhone}
                      placeholder="+27 82 123 4567"
                      placeholderTextColor={modernColors.textLight}
                      keyboardType="phone-pad"
                    />
                  </View>
                </View>

                {/* Guest Side */}
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Guest Side</Text>
                  <View style={styles.sideSelector}>
                    {[
                      { value: 'Both', label: 'Both', icon: 'heart' },
                      { value: 'Bride', label: 'Bride', icon: 'user' },
                      { value: 'Groom', label: 'Groom', icon: 'user' },
                    ].map((option) => (
                      <TouchableOpacity
                        key={option.value}
                        style={[
                          styles.sideOption,
                          side === option.value && styles.sideOptionActive,
                        ]}
                        onPress={() => setSide(option.value as 'Bride' | 'Groom' | 'Both')}
                      >
                        <Feather
                          name={option.icon as any}
                          size={16}
                          color={
                            side === option.value
                              ? modernColors.white
                              : modernColors.textSecondary
                          }
                        />
                        <Text
                          style={[
                            styles.sideOptionText,
                            side === option.value && styles.sideOptionTextActive,
                          ]}
                        >
                          {option.label}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                <View style={styles.infoBox}>
                  <Feather name="info" size={18} color={modernColors.textSecondary} />
                  <Text style={styles.infoText}>
                    Email and phone are optional but recommended for sending invitations and updates.
                  </Text>
                </View>
              </View>
            </Card>

            {/* Action Buttons */}
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[
                  styles.addButton,
                  !fullName.trim() && styles.addButtonDisabled,
                ]}
                onPress={handleUpdateGuest}
                disabled={!fullName.trim() || addingGuest}
              >
                <Text style={styles.addButtonText}>
                  {addingGuest ? 'Updating...' : 'Update Guest'}
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => setShowEditGuestModal(false)}
                disabled={addingGuest}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </SafeAreaView>
      </Modal>

      {/* Contact Selector Modal */}
      <ContactSelector
        visible={showContactSelector}
        onClose={() => setShowContactSelector(false)}
        onGuestsAdded={handleGuestsAdded}
      />

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: modernColors.background,
  },
  // Header Section
  headerSection: {
    backgroundColor: modernColors.headerBg,
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: modernColors.border,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: modernColors.headerText,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  filterButton: {
    backgroundColor: modernColors.white,
    borderWidth: 1,
    borderColor: modernColors.border,
    borderRadius: 12,
    padding: 8,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  headerButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  headerButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: modernColors.surface,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    backgroundColor: modernColors.white,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: modernColors.cardShadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    borderWidth: 1,
    borderColor: modernColors.border,
  },
  statIcon: {
    marginBottom: 8,
  },
  statNumber: {
    fontSize: 20,
    fontWeight: '700',
    color: modernColors.text,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: modernColors.textSecondary,
    textAlign: 'center',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: modernColors.white,
    borderRadius: 12,
    marginBottom: 20,
    padding: 4,
    borderWidth: 1,
    borderColor: modernColors.border,
    shadowColor: modernColors.cardShadow,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  tabButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    gap: 6,
  },
  tabButtonActive: {
    backgroundColor: modernColors.primary,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
    color: modernColors.textSecondary,
  },
  tabTextActive: {
    color: modernColors.white,
  },
  guestList: {
    paddingBottom: 100,
  },
  guestCard: {
    backgroundColor: modernColors.background,
    marginBottom: 12,
  },
  guestContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  guestAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: modernColors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  guestAvatarText: {
    color: modernColors.background,
    fontSize: 16,
    fontWeight: '700',
  },
  guestInfo: {
    flex: 1,
  },
  guestName: {
    fontSize: 16,
    fontWeight: '600',
    color: modernColors.text,
  },
  guestEmail: {
    fontSize: 14,
    color: modernColors.textSecondary,
    marginTop: 2,
  },
  guestPhone: {
    fontSize: 14,
    color: modernColors.textSecondary,
    marginTop: 2,
  },
  guestActions: {
    flexDirection: 'row',
    gap: 8,
  },
  guestActionButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: modernColors.primary,
  },
  rsvpCard: {
    backgroundColor: modernColors.background,
    marginBottom: 12,
  },
  rsvpHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  rsvpGuestInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  rsvpAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: modernColors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  rsvpAvatarText: {
    color: modernColors.background,
    fontSize: 14,
    fontWeight: '700',
  },
  rsvpDetails: {
    flex: 1,
  },
  rsvpName: {
    fontSize: 16,
    fontWeight: '600',
    color: modernColors.text,
  },
  rsvpEmail: {
    fontSize: 12,
    color: modernColors.textSecondary,
    marginTop: 2,
  },
  rsvpStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    gap: 4,
  },
  responseText: {
    fontSize: 12,
    color: modernColors.background,
    fontWeight: '600',
  },
  respondedAt: {
    fontSize: 12,
    color: modernColors.textSecondary,
    marginBottom: 12,
    paddingHorizontal: 16,
  },
  rsvpActions: {
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  rsvpActionButton: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 8,
    alignItems: 'center',
  },
  rsvpActionButtonText: {
    color: modernColors.background,
    fontSize: 12,
    fontWeight: '600',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: modernColors.surface,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: modernColors.text,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: modernColors.textSecondary,
    textAlign: 'center',
    paddingHorizontal: 40,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: modernColors.background,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: modernColors.background,
    borderBottomWidth: 1,
    borderBottomColor: modernColors.border,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: modernColors.primary,
  },
  modalContent: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  filterOption: {
    paddingVertical: 16,
    paddingHorizontal: 20,
    backgroundColor: modernColors.background,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: modernColors.border,
  },
  filterOptionActive: {
    backgroundColor: modernColors.primary,
    borderColor: modernColors.primary,
  },
  filterOptionText: {
    fontSize: 16,
    color: modernColors.text,
    fontWeight: '500',
  },
  filterOptionTextActive: {
    color: modernColors.background,
  },
  modalFooter: {
    padding: 20,
    backgroundColor: modernColors.background,
    borderTopWidth: 1,
    borderTopColor: modernColors.border,
  },
  applyFilterButton: {
    backgroundColor: modernColors.primary,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  applyFilterButtonText: {
    color: modernColors.background,
    fontSize: 16,
    fontWeight: 'bold',
  },
  floatingAddButton: {
    position: 'absolute',
    bottom: 30,
    left: 20,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FF6B35', // Force orange color
    paddingHorizontal: 18,
    paddingVertical: 14,
    borderRadius: 30,
    gap: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
    minWidth: 140,
    zIndex: 9999, // Force on top
  },
  floatingAddText: {
    color: modernColors.white,
    fontSize: 14,
    fontWeight: '600',
  },
  floatingImportButton: {
    position: 'absolute',
    bottom: 30,
    right: 20,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF', // Force white
    borderWidth: 2,
    borderColor: '#00a86b', // Force green border
    paddingHorizontal: 18,
    paddingVertical: 14,
    borderRadius: 30,
    gap: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
    minWidth: 120,
    zIndex: 9999, // Force on top
  },
  floatingImportText: {
    color: modernColors.primary,
    fontSize: 14,
    fontWeight: '600',
  },
  // Add Guest Form Modal styles
  formContainer: {
    gap: 20,
  },
  inputGroup: {
    gap: 8,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: modernColors.text,
  },
  required: {
    color: modernColors.error,
  },
  inputField: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: modernColors.accent,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: modernColors.text,
  },
  sideSelector: {
    flexDirection: 'row',
    gap: 12,
  },
  sideOption: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: modernColors.border,
    backgroundColor: modernColors.white,
    gap: 8,
  },
  sideOptionActive: {
    backgroundColor: modernColors.primary,
    borderColor: modernColors.primary,
  },
  sideOptionText: {
    fontSize: 14,
    fontWeight: '500',
    color: modernColors.text,
  },
  sideOptionTextActive: {
    color: modernColors.white,
  },
  infoBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: modernColors.accent,
    borderRadius: 12,
    padding: 16,
    gap: 10,
  },
  infoText: {
    flex: 1,
    fontSize: 12,
    color: modernColors.textSecondary,
    lineHeight: 18,
  },
  modalActions: {
    gap: 12,
    marginTop: 20,
    marginBottom: 40,
  },
  addButton: {
    backgroundColor: modernColors.primary,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  addButtonDisabled: {
    backgroundColor: modernColors.textLight,
  },
  addButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: modernColors.white,
  },
  cancelButton: {
    paddingVertical: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: modernColors.border,
    backgroundColor: modernColors.white,
    alignItems: 'center',
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: modernColors.textSecondary,
  },
  modalCloseButton: {
    padding: 8,
  },
  modalHeaderSpacer: {
    width: 40,
  },
  // NEW VISIBLE BUTTONS
  addGuestButtonsContainer: {
    flexDirection: 'row',
    gap: 12,
    marginVertical: 20,
    paddingHorizontal: 4,
  },
  addContactButton: {
    flex: 1,
    backgroundColor: '#FF6B35',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  addContactButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  importContactsButton: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderWidth: 2,
    borderColor: '#00a86b',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  importContactsButtonText: {
    color: '#00a86b',
    fontSize: 16,
    fontWeight: '600',
  },
});