import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { 
  Task, 
  TaskCategory, 
  TaskStatus, 
  TaskPriority,
  createTask, 
  updateTask,
  getCategoryIcon,
  getCategoryColor,
  getPriorityColor
} from '@/lib/task-service';

interface TaskFormProps {
  visible: boolean;
  onClose: () => void;
  onSuccess: () => void;
  task?: Task | null;
  weddingId: string;
}

const categories: TaskCategory[] = [
  'venue', 'catering', 'photography', 'music', 'flowers', 'decor',
  'transportation', 'makeup', 'hair', 'attire', 'rings', 'cake',
  'invitations', 'officiant', 'ceremony', 'reception', 'honeymoon', 'other'
];

const statusOptions: { value: TaskStatus; label: string }[] = [
  { value: 'pending', label: 'Pending' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'completed', label: 'Completed' },
  { value: 'cancelled', label: 'Cancelled' },
];

const priorityOptions: { value: TaskPriority; label: string }[] = [
  { value: 'low', label: 'Low' },
  { value: 'medium', label: 'Medium' },
  { value: 'high', label: 'High' },
  { value: 'urgent', label: 'Urgent' },
];

export default function TaskForm({ visible, onClose, onSuccess, task, weddingId }: TaskFormProps) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'other' as TaskCategory,
    priority: 'medium' as TaskPriority,
    status: 'pending' as TaskStatus,
    due_date: '',
    assigned_to: '',
    estimated_hours: '',
    notes: '',
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (task) {
      setFormData({
        title: task.title || '',
        description: task.description || '',
        category: task.category || 'other',
        priority: task.priority || 'medium',
        status: task.status || 'pending',
        due_date: task.due_date || '',
        assigned_to: task.assigned_to || '',
        estimated_hours: task.estimated_hours ? task.estimated_hours.toString() : '',
        notes: task.notes || '',
      });
    } else {
      setFormData({
        title: '',
        description: '',
        category: 'other',
        priority: 'medium',
        status: 'pending',
        due_date: '',
        assigned_to: '',
        estimated_hours: '',
        notes: '',
      });
    }
    setErrors({});
  }, [task, visible]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Task title is required';
    }

    if (formData.estimated_hours && isNaN(Number(formData.estimated_hours))) {
      newErrors.estimated_hours = 'Please enter a valid number of hours';
    }

    if (formData.due_date && new Date(formData.due_date) < new Date()) {
      newErrors.due_date = 'Due date cannot be in the past';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      return;
    }

    try {
      setLoading(true);
      
      const taskData = {
        title: formData.title,
        description: formData.description || undefined,
        category: formData.category,
        priority: formData.priority,
        status: formData.status,
        due_date: formData.due_date || undefined,
        assigned_to: formData.assigned_to || undefined,
        estimated_hours: formData.estimated_hours ? Number(formData.estimated_hours) : undefined,
        notes: formData.notes || undefined,
      };

      if (task) {
        await updateTask({ id: task.id, ...taskData });
      } else {
        await createTask(weddingId, taskData);
      }
      
      Alert.alert(
        'Success',
        task ? 'Task updated successfully' : 'Task created successfully'
      );
      
      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error saving task:', error);
      Alert.alert('Error', 'Failed to save task. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const renderCategorySelector = () => (
    <View style={styles.selectorContainer}>
      <Text style={styles.label}>Category *</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryScroll}>
        {categories.map((category) => (
          <TouchableOpacity
            key={category}
            style={[
              styles.categoryChip,
              formData.category === category && styles.categoryChipActive
            ]}
            onPress={() => handleInputChange('category', category)}
          >
            <Feather 
              name={getCategoryIcon(category) as any} 
              size={16} 
              color={formData.category === category ? '#FFFFFF' : getCategoryColor(category)} 
            />
            <Text style={[
              styles.categoryChipText,
              formData.category === category && styles.categoryChipTextActive
            ]}>
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      {errors.category && <Text style={styles.errorText}>{errors.category}</Text>}
    </View>
  );

  const renderPrioritySelector = () => (
    <View style={styles.selectorContainer}>
      <Text style={styles.label}>Priority</Text>
      <View style={styles.priorityContainer}>
        {priorityOptions.map((option) => (
          <TouchableOpacity
            key={option.value}
            style={[
              styles.priorityChip,
              formData.priority === option.value && styles.priorityChipActive
            ]}
            onPress={() => handleInputChange('priority', option.value)}
          >
            <Text style={[
              styles.priorityChipText,
              formData.priority === option.value && styles.priorityChipTextActive
            ]}>
              {option.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  const renderStatusSelector = () => (
    <View style={styles.selectorContainer}>
      <Text style={styles.label}>Status</Text>
      <View style={styles.statusContainer}>
        {statusOptions.map((option) => (
          <TouchableOpacity
            key={option.value}
            style={[
              styles.statusChip,
              formData.status === option.value && styles.statusChipActive
            ]}
            onPress={() => handleInputChange('status', option.value)}
          >
            <Text style={[
              styles.statusChipText,
              formData.status === option.value && styles.statusChipTextActive
            ]}>
              {option.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <SafeAreaView style={styles.container}>
        <KeyboardAvoidingView
          style={styles.keyboardContainer}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          <View style={styles.header}>
            <Text style={styles.title}>
              {task ? 'Edit Task' : 'Create New Task'}
            </Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Feather name="x" size={24} color="#D4A373" />
            </TouchableOpacity>
          </View>

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {/* Basic Information */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Basic Information</Text>
            
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Task Title *</Text>
              <TextInput
                style={[styles.input, errors.title && styles.inputError]}
                value={formData.title}
                onChangeText={(value) => handleInputChange('title', value)}
                placeholder="Enter task title"
                placeholderTextColor="#D3D3D3"
              />
              {errors.title && <Text style={styles.errorText}>{errors.title}</Text>}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Description</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={formData.description}
                onChangeText={(value) => handleInputChange('description', value)}
                placeholder="Enter task description"
                placeholderTextColor="#D3D3D3"
                multiline
                numberOfLines={3}
                textAlignVertical="top"
              />
            </View>

            {renderCategorySelector()}
            {renderPrioritySelector()}
            {renderStatusSelector()}
          </View>

          {/* Scheduling */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Scheduling</Text>
            
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Due Date</Text>
              <TextInput
                style={[styles.input, errors.due_date && styles.inputError]}
                value={formData.due_date}
                onChangeText={(value) => handleInputChange('due_date', value)}
                placeholder="YYYY-MM-DD"
                placeholderTextColor="#D3D3D3"
              />
              {errors.due_date && <Text style={styles.errorText}>{errors.due_date}</Text>}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Assigned To</Text>
              <TextInput
                style={styles.input}
                value={formData.assigned_to}
                onChangeText={(value) => handleInputChange('assigned_to', value)}
                placeholder="Enter name or email"
                placeholderTextColor="#D3D3D3"
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Estimated Hours</Text>
              <TextInput
                style={[styles.input, errors.estimated_hours && styles.inputError]}
                value={formData.estimated_hours}
                onChangeText={(value) => handleInputChange('estimated_hours', value)}
                placeholder="0.0"
                placeholderTextColor="#D3D3D3"
                keyboardType="numeric"
              />
              {errors.estimated_hours && <Text style={styles.errorText}>{errors.estimated_hours}</Text>}
            </View>
          </View>

          {/* Additional Information */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Additional Information</Text>
            
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Notes</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={formData.notes}
                onChangeText={(value) => handleInputChange('notes', value)}
                placeholder="Add any additional notes..."
                placeholderTextColor="#D3D3D3"
                multiline
                numberOfLines={4}
                textAlignVertical="top"
              />
            </View>
          </View>
        </ScrollView>

        {/* Actions */}
        <View style={styles.actions}>
          <TouchableOpacity
            style={styles.cancelButton}
            onPress={onClose}
            disabled={loading}
          >
            <Text style={styles.cancelButtonText}>Cancel</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.saveButton, loading && styles.saveButtonDisabled]}
            onPress={handleSubmit}
            disabled={loading}
          >
            {loading ? (
              <Text style={styles.saveButtonText}>Saving...</Text>
            ) : (
              <Text style={styles.saveButtonText}>
                {task ? 'Update Task' : 'Create Task'}
              </Text>
            )}
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5E8C7',
  },
  keyboardContainer: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#D3D3D3',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#D4A373',
  },
  closeButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#FFFFFF',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  inputContainer: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: '#333',
    borderWidth: 1,
    borderColor: '#D3D3D3',
  },
  inputError: {
    borderColor: '#FF6B6B',
  },
  textArea: {
    height: 80,
  },
  errorText: {
    color: '#FF6B6B',
    fontSize: 14,
    marginTop: 4,
  },
  selectorContainer: {
    marginBottom: 16,
  },
  categoryScroll: {
    marginTop: 8,
  },
  categoryChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#D3D3D3',
  },
  categoryChipActive: {
    backgroundColor: '#D4A373',
    borderColor: '#D4A373',
  },
  categoryChipText: {
    fontSize: 12,
    color: '#666',
    marginLeft: 6,
    fontWeight: '500',
  },
  categoryChipTextActive: {
    color: '#FFFFFF',
  },
  priorityContainer: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 8,
  },
  priorityChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#D3D3D3',
  },
  priorityChipActive: {
    backgroundColor: '#D4A373',
    borderColor: '#D4A373',
  },
  priorityChipText: {
    fontSize: 14,
    color: '#666',
    fontWeight: '500',
  },
  priorityChipTextActive: {
    color: '#FFFFFF',
  },
  statusContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 8,
  },
  statusChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#D3D3D3',
  },
  statusChipActive: {
    backgroundColor: '#A9B7A0',
    borderColor: '#A9B7A0',
  },
  statusChipText: {
    fontSize: 14,
    color: '#666',
    fontWeight: '500',
  },
  statusChipTextActive: {
    color: '#FFFFFF',
  },
  actions: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderTopWidth: 1,
    borderTopColor: '#D3D3D3',
    gap: 12,
  },
  cancelButton: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 8,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#D3D3D3',
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#666',
    fontSize: 16,
    fontWeight: '600',
  },
  saveButton: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 8,
    backgroundColor: '#D4A373',
    alignItems: 'center',
  },
  saveButtonDisabled: {
    backgroundColor: '#D3D3D3',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
});

