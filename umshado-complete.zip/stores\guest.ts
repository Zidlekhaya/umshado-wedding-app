// stores/guest.ts
import { create } from 'zustand';
import { Guest, CreateGuestData, UpdateGuestData } from '@/lib/guest-service';

interface GuestState {
  guests: Guest[];
  loading: boolean;
  error: string | null;
  selectedGuests: string[];
  
  // Actions
  setGuests: (guests: Guest[]) => void;
  addGuest: (guest: Guest) => void;
  updateGuest: (guestId: string, updates: Partial<Guest>) => void;
  removeGuest: (guestId: string) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  setSelectedGuests: (guestIds: string[]) => void;
  toggleGuestSelection: (guestId: string) => void;
  clearSelection: () => void;
  
  // Computed values
  getGuestStats: () => {
    total: number;
    attending: number;
    notAttending: number;
    pending: number;
    maybe: number;
    plusOnes: number;
  };
  getGuestsByCategory: (category: string) => Guest[];
  getGuestsByRSVP: (status: string) => Guest[];
}

export const useGuestStore = create<GuestState>((set, get) => ({
  guests: [],
  loading: false,
  error: null,
  selectedGuests: [],

  setGuests: (guests) => set({ guests }),
  
  addGuest: (guest) => set((state) => ({
    guests: [...state.guests, guest]
  })),
  
  updateGuest: (guestId, updates) => set((state) => ({
    guests: state.guests.map(guest =>
      guest.id === guestId ? { ...guest, ...updates } : guest
    )
  })),
  
  removeGuest: (guestId) => set((state) => ({
    guests: state.guests.filter(guest => guest.id !== guestId),
    selectedGuests: state.selectedGuests.filter(id => id !== guestId)
  })),
  
  setLoading: (loading) => set({ loading }),
  
  setError: (error) => set({ error }),
  
  setSelectedGuests: (guestIds) => set({ selectedGuests: guestIds }),
  
  toggleGuestSelection: (guestId) => set((state) => ({
    selectedGuests: state.selectedGuests.includes(guestId)
      ? state.selectedGuests.filter(id => id !== guestId)
      : [...state.selectedGuests, guestId]
  })),
  
  clearSelection: () => set({ selectedGuests: [] }),

  getGuestStats: () => {
    const { guests } = get();
    return {
      total: guests.length,
      attending: guests.filter(g => g.rsvp_status === 'attending').length,
      notAttending: guests.filter(g => g.rsvp_status === 'not_attending').length,
      pending: guests.filter(g => g.rsvp_status === 'pending').length,
      maybe: guests.filter(g => g.rsvp_status === 'maybe').length,
      plusOnes: guests.filter(g => g.plus_one).length,
    };
  },

  getGuestsByCategory: (category) => {
    const { guests } = get();
    return guests.filter(guest => guest.category === category);
  },

  getGuestsByRSVP: (status) => {
    const { guests } = get();
    return guests.filter(guest => guest.rsvp_status === status);
  },
}));


