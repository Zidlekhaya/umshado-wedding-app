import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, SafeAreaView } from 'react-native';
import { router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { colors, typography, spacing, borderRadius, shadows } from '@/src/theme/design-system';

export default function AuthLanding() {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.logoContainer}>
            <Feather name="heart" size={40} color={colors.error[500]} />
          </View>
          <Text style={styles.title}>Umshado</Text>
          <Text style={styles.subtitle}>Your wedding planning companion</Text>
        </View>

        {/* Options */}
        <View style={styles.optionsContainer}>
          <TouchableOpacity 
            style={styles.optionCard}
            onPress={() => router.push('/(auth)/sign-in')}
          >
            <View style={styles.optionIcon}>
              <Feather name="users" size={32} color={colors.primary[300]} />
            </View>
            <Text style={styles.optionTitle}>I'm Planning a Wedding</Text>
            <Text style={styles.optionDescription}>
              Sign in as a couple to plan your perfect wedding day
            </Text>
            <View style={styles.optionArrow}>
              <Feather name="arrow-right" size={20} color={colors.text.secondary} />
            </View>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.optionCard}
            onPress={() => router.push('/(auth)/vendor-sign-in')}
          >
            <View style={styles.optionIcon}>
              <Feather name="briefcase" size={32} color={colors.secondary[300]} />
            </View>
            <Text style={styles.optionTitle}>I'm a Wedding Vendor</Text>
            <Text style={styles.optionDescription}>
              Sign in as a vendor to showcase your services
            </Text>
            <View style={styles.optionArrow}>
              <Feather name="arrow-right" size={20} color={colors.text.secondary} />
            </View>
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Don't have an account?{' '}
            <Text style={styles.footerLink} onPress={() => router.push('/(auth)/sign-up')}>
              Sign up as a couple
            </Text>
            {' '}or{' '}
            <Text style={styles.footerLink} onPress={() => router.push('/(auth)/vendor-sign-up')}>
              Sign up as a vendor
            </Text>
          </Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  content: {
    flex: 1,
    paddingHorizontal: spacing[6],
    paddingVertical: spacing[8],
  },
  header: {
    alignItems: 'center',
    marginBottom: spacing[12],
  },
  logoContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.surface.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing[4],
    ...shadows.lg,
  },
  title: {
    fontSize: typography.fontSize['4xl'],
    fontWeight: typography.fontWeight.bold,
    color: colors.text.primary,
    marginBottom: spacing[2],
  },
  subtitle: {
    fontSize: typography.fontSize.lg,
    color: colors.text.secondary,
    textAlign: 'center',
  },
  optionsContainer: {
    flex: 1,
    justifyContent: 'center',
    gap: spacing[6],
  },
  optionCard: {
    backgroundColor: colors.surface.primary,
    borderRadius: borderRadius.xl,
    padding: spacing[6],
    ...shadows.md,
    borderWidth: 1,
    borderColor: colors.border.primary,
  },
  optionIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.background.secondary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing[4],
  },
  optionTitle: {
    fontSize: typography.fontSize.xl,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text.primary,
    marginBottom: spacing[2],
  },
  optionDescription: {
    fontSize: typography.fontSize.base,
    color: colors.text.secondary,
    lineHeight: typography.lineHeight.relaxed * typography.fontSize.base,
    marginBottom: spacing[4],
  },
  optionArrow: {
    alignSelf: 'flex-end',
  },
  footer: {
    alignItems: 'center',
    paddingTop: spacing[6],
  },
  footerText: {
    fontSize: typography.fontSize.sm,
    color: colors.text.secondary,
    textAlign: 'center',
    lineHeight: typography.lineHeight.relaxed * typography.fontSize.sm,
  },
  footerLink: {
    color: colors.primary[500],
    fontWeight: typography.fontWeight.medium,
  },
});










