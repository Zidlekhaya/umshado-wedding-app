import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Alert, Image, SafeAreaView } from 'react-native';
import { Stack, router, useFocusEffect } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Loading } from '@/components/ui/Loading';
import { supabase } from '@/lib/supabase';
import { Logo } from '@/src/components/ui/Logo';
import { getVendorStats } from '@/lib/vendor-stats-service';
import { useCallback } from 'react';

const colors = {
  background: '#f0fbea',
  primary: '#00a86b',
  text: '#1A1A1A',
  textLight: '#6B7280',
  border: '#E5E7EB',
  success: '#10B981',
  error: '#EF4444',
  warning: '#F59E0B',
  white: '#FFFFFF',
  urgent: '#FF6B6B',
  high: '#FF8E53',
  medium: '#FFA500',
  low: '#4ECDC4',
  completed: '#95E1A3',
  pending: '#FFD93D',
  inProgress: '#6BCF7F',
  // Enhanced colors for better UI
  headerBg: '#F8FAFC',
  headerText: '#1E293B',
  cardShadow: 'rgba(0, 0, 0, 0.1)',
  accent: '#F3F4F6',
};

export default function VendorDashboard() {
  const [loading, setLoading] = useState(true);
  const [vendorProfile, setVendorProfile] = useState<any>(null);
  const [stats, setStats] = useState({
    totalViews: 0,
    totalInquiries: 0,
    totalReviews: 0,
    averageRating: 0,
  });

  useEffect(() => {
    loadVendorData();
  }, []);

  // Refresh data when screen comes into focus (e.g., returning from profile page)
  useFocusEffect(
    useCallback(() => {
      loadVendorData();
    }, [])
  );

  const loadVendorData = async () => {
    try {
      setLoading(true);
      
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        Alert.alert('Error', 'Please sign in to continue');
        router.replace('/(auth)/vendor-sign-in');
        return;
      }

      console.log('Loading vendor profile for user:', user.id);

      // Load real vendor profile from database
      const { data: profileData, error: profileError } = await supabase
        .from('vendor_profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (profileError) {
        console.error('Error loading vendor profile:', profileError);
        
        // If no profile exists, create one from user metadata
        if (profileError.code === 'PGRST116') {
          console.log('No vendor profile found, creating from user metadata...');
          const { data: newProfile, error: createError } = await supabase
            .from('vendor_profiles')
            .insert([{
              user_id: user.id,
              business_name: user.user_metadata?.business_name || 'My Business',
              business_description: 'Professional wedding services',
              category: user.user_metadata?.category || 'other',
              contact_email: user.email,
              city: user.user_metadata?.location || 'Cape Town',
              location: user.user_metadata?.location || 'Cape Town',
              is_active: true,
              is_verified: false
            }])
            .select()
            .single();

          if (createError) {
            console.error('Error creating vendor profile:', createError);
            throw createError;
          }
          
          setVendorProfile(newProfile);
          setStats({
            totalViews: newProfile.view_count || 0,
            totalInquiries: newProfile.inquiry_count || 0,
            totalReviews: newProfile.review_count || 0,
            averageRating: newProfile.rating_average || 0,
          });
          return;
        }
        
        throw profileError;
      }

      console.log('Vendor profile loaded:', profileData);
      setVendorProfile(profileData);
      
      // Load real-time stats
      const realStats = await getVendorStats(profileData.id);
      setStats(realStats);

    } catch (error: any) {
      console.error('Error loading vendor data:', error);
      
      let errorMessage = 'Failed to load vendor data';
      if (error.message?.includes('network')) {
        errorMessage = 'Network error. Please check your connection';
      } else if (error.message?.includes('permission')) {
        errorMessage = 'You do not have permission to access this data';
      } else if (error.message?.includes('session')) {
        errorMessage = 'Session expired. Please sign in again';
        router.replace('/(auth)/vendor-sign-in');
        return;
      }
      
      Alert.alert('Error', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Logout', 
          style: 'destructive',
          onPress: async () => {
            try {
              await supabase.auth.signOut();
              router.replace('/user-type-selection');
            } catch (error) {
              Alert.alert('Error', 'Failed to logout');
            }
          }
        }
      ]
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <Stack.Screen
          options={{
            headerShown: false,
          }}
        />
        <View style={styles.loadingContainer}>
          <Loading size="large" color={colors.primary} text="Loading dashboard..." />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen
        options={{
          headerShown: false,
        }}
      />
      
      {/* Custom Header */}
      <View style={styles.headerSection}>
        <View style={styles.headerTop}>
          <Logo size="small" showText={false} />
          <View style={styles.headerTitleContainer}>
            <Text style={styles.headerTitle}>Vendor</Text>
            <Text style={styles.headerSubtitle}>Dashboard</Text>
          </View>
          <TouchableOpacity
            style={styles.logoutButton}
            onPress={handleSignOut}
          >
            <Feather name="log-out" size={16} color={colors.white} />
            <Text style={styles.logoutButtonText}>Logout</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.content}>
        <ScrollView showsVerticalScrollIndicator={false}>
          {/* Welcome Section */}
          <View style={styles.welcomeCard}>
            <View style={styles.welcomeHeader}>
              <View style={styles.welcomeLeft}>
                <View style={styles.welcomeIcon}>
                  {vendorProfile?.company_logo ? (
                    <Image 
                      source={{ uri: vendorProfile.company_logo }} 
                      style={styles.companyLogo}
                      resizeMode="cover"
                    />
                  ) : (
                    <Feather name="briefcase" size={24} color={colors.primary} />
                  )}
                </View>
                <View style={styles.welcomeText}>
                  <Text style={styles.welcomeTitle}>Welcome back!</Text>
                  <Text style={styles.welcomeSubtitle}>{vendorProfile?.business_name || 'My Business'}</Text>
                  <Text style={styles.welcomeCategory}>{vendorProfile?.category || 'Wedding Services'}</Text>
                </View>
              </View>
            </View>
            <Text style={styles.welcomeDescription}>
              {vendorProfile?.business_description || 'Manage your wedding services and connect with couples planning their special day.'}
            </Text>
            {vendorProfile?.location && (
              <View style={styles.locationContainer}>
                <Feather name="map-pin" size={14} color={colors.textLight} />
                <Text style={styles.locationText}>{vendorProfile.location}</Text>
              </View>
            )}
          </View>

          {/* Stats Cards */}
          <View style={styles.statsContainer}>
            <View style={styles.statCard}>
              <View style={styles.statIcon}>
                <Feather name="eye" size={20} color={colors.success} />
              </View>
              <Text style={styles.statValue}>{stats.totalViews}</Text>
              <Text style={styles.statLabel}>Profile Views</Text>
            </View>

            <View style={styles.statCard}>
              <View style={styles.statIcon}>
                <Feather name="message-circle" size={20} color={colors.warning} />
              </View>
              <Text style={styles.statValue}>{stats.totalInquiries}</Text>
              <Text style={styles.statLabel}>Inquiries</Text>
            </View>

            <View style={styles.statCard}>
              <View style={styles.statIcon}>
                <Feather name="star" size={20} color={colors.error} />
              </View>
              <Text style={styles.statValue}>{stats.averageRating.toFixed(1)}</Text>
              <Text style={styles.statLabel}>Rating</Text>
            </View>

            <View style={styles.statCard}>
              <View style={styles.statIcon}>
                <Feather name="users" size={20} color={colors.primary} />
              </View>
              <Text style={styles.statValue}>{stats.totalReviews}</Text>
              <Text style={styles.statLabel}>Reviews</Text>
            </View>
          </View>

          {/* Quick Actions */}
          <View style={styles.actionsCard}>
            <Text style={styles.actionsTitle}>Quick Actions</Text>
            <View style={styles.actionsGrid}>
              <TouchableOpacity 
                style={styles.actionButton}
                onPress={() => router.push('/(vendor)/profile')}
              >
                <View style={styles.actionIcon}>
                  <Feather name="edit-3" size={20} color={colors.primary} />
                </View>
                <Text style={styles.actionText}>Edit Profile</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={styles.actionButton}
                onPress={() => router.push('/(vendor)/services')}
              >
                <View style={styles.actionIcon}>
                  <Feather name="plus" size={20} color={colors.success} />
                </View>
                <Text style={styles.actionText}>Add Service</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={styles.actionButton}
                onPress={() => router.push('/(vendor)/messages')}
              >
                <View style={styles.actionIcon}>
                  <Feather name="message-circle" size={20} color={colors.warning} />
                </View>
                <Text style={styles.actionText}>Messages</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={styles.actionButton}
                onPress={() => router.push('/(vendor)/analytics')}
              >
                <View style={styles.actionIcon}>
                  <Feather name="bar-chart-2" size={20} color={colors.error} />
                </View>
                <Text style={styles.actionText}>Analytics</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Recent Activity */}
          <View style={styles.activityCard}>
            <Text style={styles.activityTitle}>Recent Activity</Text>
            {stats.totalInquiries > 0 || stats.totalViews > 0 ? (
              <>
                {stats.totalViews > 0 && (
                  <View style={styles.activityItem}>
                    <View style={styles.activityIcon}>
                      <Feather name="eye" size={16} color={colors.success} />
                    </View>
                    <Text style={styles.activityText}>Profile viewed {stats.totalViews} times</Text>
                    <Text style={styles.activityTime}>Recently</Text>
                  </View>
                )}
                {stats.totalInquiries > 0 && (
                  <View style={styles.activityItem}>
                    <View style={styles.activityIcon}>
                      <Feather name="message-circle" size={16} color={colors.warning} />
                    </View>
                    <Text style={styles.activityText}>{stats.totalInquiries} inquiry{stats.totalInquiries > 1 ? 'ies' : ''} received</Text>
                    <Text style={styles.activityTime}>Recently</Text>
                  </View>
                )}
                {stats.totalReviews > 0 && (
                  <View style={styles.activityItem}>
                    <View style={styles.activityIcon}>
                      <Feather name="star" size={16} color={colors.error} />
                    </View>
                    <Text style={styles.activityText}>{stats.totalReviews} review{stats.totalReviews > 1 ? 's' : ''} received</Text>
                    <Text style={styles.activityTime}>Recently</Text>
                  </View>
                )}
              </>
            ) : (
              <View style={styles.noActivityContainer}>
                <Feather name="activity" size={24} color={colors.textLight} />
                <Text style={styles.noActivityText}>No recent activity</Text>
                <Text style={styles.noActivitySubtext}>Start by adding services to get inquiries</Text>
              </View>
            )}
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  // Header Section
  headerSection: {
    backgroundColor: colors.headerBg,
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitleContainer: {
    flex: 1,
    alignItems: 'center',
    marginHorizontal: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.headerText,
    lineHeight: 28,
  },
  headerSubtitle: {
    fontSize: 18,
    fontWeight: '500',
    color: colors.headerText,
    opacity: 0.8,
    lineHeight: 22,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: colors.error || '#EF4444',
    gap: 6,
    shadowColor: 'rgba(0, 0, 0, 0.1)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  logoutButtonText: {
    color: colors.white,
    fontSize: 12,
    fontWeight: '600',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  welcomeCard: {
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    shadowColor: colors.cardShadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    borderWidth: 1,
    borderColor: colors.border,
  },
  welcomeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  welcomeLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  welcomeIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  welcomeText: {
    flex: 1,
  },
  welcomeTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  welcomeSubtitle: {
    fontSize: 16,
    color: colors.text,
    fontWeight: '600',
  },
  welcomeCategory: {
    fontSize: 14,
    color: colors.textLight,
    textTransform: 'capitalize',
  },
  welcomeDescription: {
    fontSize: 14,
    color: colors.textLight,
    lineHeight: 20,
    marginTop: 8,
  },
  companyLogo: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  locationText: {
    fontSize: 14,
    color: colors.textLight,
    marginLeft: 4,
  },
  statsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 20,
    gap: 12,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    shadowColor: colors.cardShadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    borderWidth: 1,
    borderColor: colors.border,
  },
  statIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: colors.textLight,
    textAlign: 'center',
  },
  actionsCard: {
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    shadowColor: colors.cardShadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    borderWidth: 1,
    borderColor: colors.border,
  },
  actionsTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 16,
  },
  actionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    minWidth: '45%',
    alignItems: 'center',
    padding: 16,
    backgroundColor: colors.accent,
    borderRadius: 12,
  },
  actionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  actionText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
    textAlign: 'center',
  },
  activityCard: {
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    shadowColor: colors.cardShadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    borderWidth: 1,
    borderColor: colors.border,
  },
  activityTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 16,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  activityIcon: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  activityText: {
    flex: 1,
    fontSize: 14,
    color: colors.text,
  },
  activityTime: {
    fontSize: 12,
    color: colors.textLight,
  },
  noActivityContainer: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  noActivityText: {
    fontSize: 16,
    color: colors.textLight,
    marginTop: 8,
    marginBottom: 4,
  },
  noActivitySubtext: {
    fontSize: 14,
    color: colors.textLight,
    textAlign: 'center',
  },
});
