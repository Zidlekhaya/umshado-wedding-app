-- Vendor Marketplace Migration
-- This script extends the database to support vendor marketplace functionality

-- Create vendor user type
CREATE TYPE user_type AS ENUM ('couple', 'vendor');

-- Add user_type to app_user table
ALTER TABLE app_user ADD COLUMN user_type user_type DEFAULT 'couple';

-- Create vendor profiles table
CREATE TABLE vendor_profile (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
  business_name TEXT NOT NULL,
  business_description TEXT,
  category TEXT NOT NULL,
  subcategories TEXT[],
  location TEXT,
  city TEXT,
  province TEXT,
  country TEXT DEFAULT 'South Africa',
  
  -- Contact Information
  phone TEXT,
  email TEXT,
  website TEXT,
  
  -- Social Media
  instagram TEXT,
  facebook TEXT,
  twitter TEXT,
  tiktok TEXT,
  linkedin TEXT,
  
  -- Business Details
  years_experience INTEGER DEFAULT 0,
  price_range TEXT, -- e.g., "R5,000 - R15,000"
  service_areas TEXT[], -- Areas they serve
  languages TEXT[] DEFAULT '{"English"}',
  
  -- Portfolio
  portfolio_images TEXT[], -- Array of image URLs
  featured_image TEXT,
  
  -- Verification
  is_verified BOOLEAN DEFAULT FALSE,
  verification_documents TEXT[], -- Array of document URLs
  
  -- Status
  is_active BOOLEAN DEFAULT TRUE,
  is_featured BOOLEAN DEFAULT FALSE,
  
  -- Analytics
  view_count INTEGER DEFAULT 0,
  inquiry_count INTEGER DEFAULT 0,
  rating_average DECIMAL(3,2) DEFAULT 0.00,
  review_count INTEGER DEFAULT 0,
  
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create vendor services table
CREATE TABLE vendor_service (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  vendor_id UUID NOT NULL REFERENCES vendor_profile(id) ON DELETE CASCADE,
  service_name TEXT NOT NULL,
  description TEXT,
  price_min NUMERIC(10,2),
  price_max NUMERIC(10,2),
  price_type TEXT, -- 'fixed', 'hourly', 'per_person', 'custom'
  duration_hours INTEGER,
  includes TEXT[], -- What's included in the service
  add_ons TEXT[], -- Optional add-ons
  images TEXT[], -- Service-specific images
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create vendor reviews table
CREATE TABLE vendor_review (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  vendor_id UUID NOT NULL REFERENCES vendor_profile(id) ON DELETE CASCADE,
  reviewer_name TEXT NOT NULL,
  reviewer_email TEXT,
  wedding_date DATE,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review_text TEXT,
  images TEXT[], -- Review images
  is_verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create vendor inquiries table (when couples contact vendors)
CREATE TABLE vendor_inquiry (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  vendor_id UUID NOT NULL REFERENCES vendor_profile(id) ON DELETE CASCADE,
  couple_id UUID REFERENCES app_user(id) ON DELETE SET NULL,
  wedding_id UUID REFERENCES wedding(id) ON DELETE SET NULL,
  
  -- Inquiry details
  inquiry_type TEXT DEFAULT 'general', -- 'general', 'quote', 'booking'
  message TEXT NOT NULL,
  wedding_date DATE,
  guest_count INTEGER,
  budget_range TEXT,
  
  -- Contact information
  contact_name TEXT NOT NULL,
  contact_email TEXT NOT NULL,
  contact_phone TEXT,
  
  -- Status
  status TEXT DEFAULT 'pending', -- 'pending', 'responded', 'closed'
  vendor_response TEXT,
  responded_at TIMESTAMPTZ,
  
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create vendor categories table
CREATE TABLE vendor_category (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT UNIQUE NOT NULL,
  description TEXT,
  icon TEXT, -- Icon name for UI
  color TEXT, -- Color hex code
  sort_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Insert default vendor categories
INSERT INTO vendor_category (name, description, icon, color, sort_order) VALUES
('Photography', 'Wedding photographers and videographers', 'camera', '#3B82F6', 1),
('Venues', 'Wedding venues and locations', 'home', '#10B981', 2),
('Catering', 'Food and beverage services', 'coffee', '#F59E0B', 3),
('Florist', 'Flowers and decorations', 'heart', '#EF4444', 4),
('Beauty', 'Hair, makeup, and styling', 'scissors', '#8B5CF6', 5),
('Music', 'DJs, bands, and entertainment', 'music', '#06B6D4', 6),
('Transport', 'Wedding cars and transportation', 'truck', '#84CC16', 7),
('Planning', 'Wedding planners and coordinators', 'calendar', '#F97316', 8),
('Decor', 'Wedding decorations and styling', 'star', '#EC4899', 9),
('Other', 'Other wedding services', 'grid', '#6B7280', 10);

-- Create indexes for better performance
CREATE INDEX idx_vendor_profile_category ON vendor_profile(category);
CREATE INDEX idx_vendor_profile_location ON vendor_profile(city, province);
CREATE INDEX idx_vendor_profile_active ON vendor_profile(is_active);
CREATE INDEX idx_vendor_profile_featured ON vendor_profile(is_featured);
CREATE INDEX idx_vendor_service_vendor ON vendor_service(vendor_id);
CREATE INDEX idx_vendor_review_vendor ON vendor_review(vendor_id);
CREATE INDEX idx_vendor_inquiry_vendor ON vendor_inquiry(vendor_id);
CREATE INDEX idx_vendor_inquiry_couple ON vendor_inquiry(couple_id);

-- Create RLS policies for vendor profiles
ALTER TABLE vendor_profile ENABLE ROW LEVEL SECURITY;
ALTER TABLE vendor_service ENABLE ROW LEVEL SECURITY;
ALTER TABLE vendor_review ENABLE ROW LEVEL SECURITY;
ALTER TABLE vendor_inquiry ENABLE ROW LEVEL SECURITY;

-- Vendor profiles are public (readable by everyone)
CREATE POLICY "Vendor profiles are publicly readable" ON vendor_profile
  FOR SELECT USING (is_active = true);

-- Vendors can manage their own profiles
CREATE POLICY "Vendors can manage their own profiles" ON vendor_profile
  FOR ALL USING (auth.uid() = user_id);

-- Vendor services are public (readable by everyone)
CREATE POLICY "Vendor services are publicly readable" ON vendor_service
  FOR SELECT USING (is_active = true);

-- Vendors can manage their own services
CREATE POLICY "Vendors can manage their own services" ON vendor_service
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM vendor_profile 
      WHERE vendor_profile.id = vendor_service.vendor_id 
      AND vendor_profile.user_id = auth.uid()
    )
  );

-- Vendor reviews are public (readable by everyone)
CREATE POLICY "Vendor reviews are publicly readable" ON vendor_review
  FOR SELECT USING (true);

-- Anyone can create reviews (we'll add verification later)
CREATE POLICY "Anyone can create vendor reviews" ON vendor_review
  FOR INSERT WITH CHECK (true);

-- Vendor inquiries are private to the vendor
CREATE POLICY "Vendors can view their inquiries" ON vendor_inquiry
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM vendor_profile 
      WHERE vendor_profile.id = vendor_inquiry.vendor_id 
      AND vendor_profile.user_id = auth.uid()
    )
  );

-- Couples can create inquiries
CREATE POLICY "Couples can create inquiries" ON vendor_inquiry
  FOR INSERT WITH CHECK (true);

-- Vendors can update their inquiries (respond to them)
CREATE POLICY "Vendors can update their inquiries" ON vendor_inquiry
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM vendor_profile 
      WHERE vendor_profile.id = vendor_inquiry.vendor_id 
      AND vendor_profile.user_id = auth.uid()
    )
  );

-- Create functions for analytics
CREATE OR REPLACE FUNCTION update_vendor_view_count(vendor_uuid UUID)
RETURNS void AS $$
BEGIN
  UPDATE vendor_profile 
  SET view_count = view_count + 1 
  WHERE id = vendor_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION update_vendor_inquiry_count(vendor_uuid UUID)
RETURNS void AS $$
BEGIN
  UPDATE vendor_profile 
  SET inquiry_count = inquiry_count + 1 
  WHERE id = vendor_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to update inquiry count
CREATE OR REPLACE FUNCTION trigger_update_inquiry_count()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM update_vendor_inquiry_count(NEW.vendor_id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_inquiry_count_trigger
  AFTER INSERT ON vendor_inquiry
  FOR EACH ROW
  EXECUTE FUNCTION trigger_update_inquiry_count();

-- Create function to calculate vendor rating
CREATE OR REPLACE FUNCTION calculate_vendor_rating(vendor_uuid UUID)
RETURNS void AS $$
DECLARE
  avg_rating DECIMAL(3,2);
  total_reviews INTEGER;
BEGIN
  SELECT AVG(rating)::DECIMAL(3,2), COUNT(*)
  INTO avg_rating, total_reviews
  FROM vendor_review
  WHERE vendor_id = vendor_uuid;
  
  UPDATE vendor_profile 
  SET rating_average = COALESCE(avg_rating, 0.00),
      review_count = total_reviews
  WHERE id = vendor_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to update rating when reviews change
CREATE OR REPLACE FUNCTION trigger_update_vendor_rating()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    PERFORM calculate_vendor_rating(NEW.vendor_id);
  ELSIF TG_OP = 'DELETE' THEN
    PERFORM calculate_vendor_rating(OLD.vendor_id);
  END IF;
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_vendor_rating_trigger
  AFTER INSERT OR UPDATE OR DELETE ON vendor_review
  FOR EACH ROW
  EXECUTE FUNCTION trigger_update_vendor_rating();










