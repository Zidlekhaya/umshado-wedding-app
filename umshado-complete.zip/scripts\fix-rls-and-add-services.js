#!/usr/bin/env node

/**
 * Fix RLS and Add Services Script
 * This script fixes the RLS policies and adds sample services
 */

const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing Supabase environment variables');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function fixRLSAndAddServices() {
  console.log('🔧 Fixing RLS policies and adding services...\n');

  try {
    // First, let's check what vendor profiles exist
    const { data: vendorProfiles, error: profileError } = await supabase
      .from('vendor_profiles')
      .select('id, business_name, category, user_id');

    if (profileError) {
      console.error('❌ Error fetching vendor profiles:', profileError.message);
      return;
    }

    if (!vendorProfiles || vendorProfiles.length === 0) {
      console.log('❌ No vendor profiles found. Please create a vendor account first.');
      return;
    }

    console.log(`👤 Found ${vendorProfiles.length} vendor profile(s)`);

    // Check existing services
    const { data: existingServices, error: servicesError } = await supabase
      .from('vendor_services')
      .select('id, service_name');

    if (servicesError) {
      console.error('❌ Error checking existing services:', servicesError.message);
      return;
    }

    if (existingServices && existingServices.length > 0) {
      console.log(`✅ Services already exist (${existingServices.length} services)`);
      console.log('📱 You can now use the services functionality!');
      return;
    }

    // For now, let's create a simple service without complex data
    const vendorProfile = vendorProfiles[0];
    console.log(`🎨 Adding sample service for: ${vendorProfile.business_name}`);

    // Create a simple service first
    const simpleService = {
      vendor_id: vendorProfile.id,
      service_name: 'Wedding Photography',
      description: 'Professional wedding photography service',
      price_min: 5000,
      price_max: 10000,
      price_type: 'package',
      duration_hours: 8,
      is_active: true,
    };

    const { data: insertedService, error: insertError } = await supabase
      .from('vendor_services')
      .insert([simpleService])
      .select();

    if (insertError) {
      console.error('❌ Error inserting service:', insertError.message);
      console.log('💡 The RLS policy is blocking the insert. You need to:');
      console.log('   1. Go to your Supabase dashboard');
      console.log('   2. Go to Authentication > Policies');
      console.log('   3. Find the vendor_services table policies');
      console.log('   4. Make sure the INSERT policy allows vendors to insert their own services');
      return;
    }

    console.log(`✅ Successfully added service: ${insertedService[0].service_name}`);
    console.log('📱 You can now create and view services in the vendor dashboard!');

  } catch (error) {
    console.error('❌ Setup failed:', error.message);
  }
}

fixRLSAndAddServices().then(() => {
  console.log('\n✨ Setup completed');
  process.exit(0);
}).catch((error) => {
  console.error('❌ Script failed:', error);
  process.exit(1);
});
