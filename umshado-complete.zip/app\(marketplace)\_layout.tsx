import { Stack } from 'expo-router';

export default function MarketplaceLayout() {
  return (
    <Stack>
      <Stack.Screen 
        name="packages" 
        options={{
          title: 'Wedding Packages',
          headerShown: true,
        }} 
      />
      <Stack.Screen 
        name="packages/[slug]" 
        options={{
          title: 'Package Details',
          headerShown: true,
        }} 
      />
    </Stack>
  );
}
