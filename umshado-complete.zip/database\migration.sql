-- Umshado Database Migration
-- This script creates the complete database schema as per PRD

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create custom types
CREATE TYPE user_role AS ENUM ('owner', 'co_owner', 'viewer');
CREATE TYPE guest_side AS ENUM ('Bride', 'Groom', 'Both');
CREATE TYPE rsvp_status AS ENUM ('Pending', 'Yes', 'No', 'Maybe');
CREATE TYPE task_status AS ENUM ('Todo', 'InProgress', 'Done');
CREATE TYPE task_priority AS ENUM ('Low', 'Medium', 'High');
CREATE TYPE vendor_status AS ENUM ('Shortlisted', 'Contacted', 'Confirmed', 'Rejected');

-- 1. Users table (extends Supabase auth.users)
CREATE TABLE app_user (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- 2. Weddings table
CREATE TABLE wedding (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  owner_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
  name_bride TEXT,
  name_groom TEXT,
  date DATE,
  ceremony_location TEXT,
  reception_location TEXT,
  city TEXT,
  cover_image_url TEXT,
  slug TEXT UNIQUE NOT NULL,
  notes TEXT,
  colors JSONB DEFAULT '{"primary": "#2563EB", "secondary": "#9333EA"}',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  deleted_at TIMESTAMPTZ
);

-- 3. Wedding co-owners (many-to-many)
CREATE TABLE wedding_co_owner (
  wedding_id UUID REFERENCES wedding(id) ON DELETE CASCADE,
  user_id UUID REFERENCES app_user(id) ON DELETE CASCADE,
  role user_role DEFAULT 'co_owner',
  created_at TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY (wedding_id, user_id)
);

-- 4. Guests table
CREATE TABLE guest (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  wedding_id UUID REFERENCES wedding(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  side guest_side DEFAULT 'Both',
  party_size INT DEFAULT 1 CHECK (party_size > 0),
  dietary TEXT,
  table_name TEXT,
  tags TEXT[],
  rsvp_status rsvp_status DEFAULT 'Pending',
  invite_code TEXT UNIQUE,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- 5. Tasks table
CREATE TABLE task (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  wedding_id UUID REFERENCES wedding(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  status task_status DEFAULT 'Todo',
  priority task_priority DEFAULT 'Medium',
  due_date DATE,
  assignee_id UUID REFERENCES app_user(id),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- 6. Vendors table
CREATE TABLE vendor (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  wedding_id UUID REFERENCES wedding(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  category TEXT,
  phone TEXT,
  email TEXT,
  website TEXT,
  quote_amount NUMERIC(12,2),
  status vendor_status DEFAULT 'Shortlisted',
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- 7. Budget items table
CREATE TABLE budget_item (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  wedding_id UUID REFERENCES wedding(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  category TEXT,
  estimated NUMERIC(12,2) DEFAULT 0,
  actual NUMERIC(12,2) DEFAULT 0,
  paid NUMERIC(12,2) DEFAULT 0,
  due_date DATE,
  vendor_id UUID REFERENCES vendor(id),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- 8. Timeline events table
CREATE TABLE timeline_event (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  wedding_id UUID REFERENCES wedding(id) ON DELETE CASCADE,
  starts_at TIMESTAMPTZ NOT NULL,
  title TEXT NOT NULL,
  location TEXT,
  responsible_user_id UUID REFERENCES app_user(id),
  notes TEXT,
  order_index INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- 9. Wedding invites (for the current invite system)
CREATE TABLE wedding_invites (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  wedding_id UUID REFERENCES wedding(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  role TEXT CHECK (role IN ('guest', 'partner', 'planner')) DEFAULT 'guest',
  status TEXT CHECK (status IN ('pending', 'accepted', 'revoked', 'expired')) DEFAULT 'pending',
  token TEXT UNIQUE,
  invited_by UUID REFERENCES app_user(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(wedding_id, email)
);

-- Create indexes for performance
CREATE INDEX idx_wedding_slug ON wedding(slug);
CREATE INDEX idx_wedding_owner ON wedding(owner_id);
CREATE INDEX idx_wedding_deleted ON wedding(deleted_at) WHERE deleted_at IS NULL;
CREATE INDEX idx_guest_wedding ON guest(wedding_id);
CREATE INDEX idx_guest_rsvp ON guest(rsvp_status);
CREATE INDEX idx_guest_side ON guest(side);
CREATE INDEX idx_task_wedding ON task(wedding_id);
CREATE INDEX idx_task_status ON task(status);
CREATE INDEX idx_task_due_date ON task(due_date);
CREATE INDEX idx_vendor_wedding ON vendor(wedding_id);
CREATE INDEX idx_vendor_category ON vendor(category);
CREATE INDEX idx_budget_wedding ON budget_item(wedding_id);
CREATE INDEX idx_timeline_wedding ON timeline_event(wedding_id);
CREATE INDEX idx_timeline_starts_at ON timeline_event(starts_at);
CREATE INDEX idx_invites_wedding ON wedding_invites(wedding_id);
CREATE INDEX idx_invites_token ON wedding_invites(token);

-- Create updated_at triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_wedding_updated_at BEFORE UPDATE ON wedding FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_guest_updated_at BEFORE UPDATE ON guest FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_task_updated_at BEFORE UPDATE ON task FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_vendor_updated_at BEFORE UPDATE ON vendor FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_budget_item_updated_at BEFORE UPDATE ON budget_item FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_timeline_event_updated_at BEFORE UPDATE ON timeline_event FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_wedding_invites_updated_at BEFORE UPDATE ON wedding_invites FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Row Level Security (RLS) Policies
ALTER TABLE app_user ENABLE ROW LEVEL SECURITY;
ALTER TABLE wedding ENABLE ROW LEVEL SECURITY;
ALTER TABLE wedding_co_owner ENABLE ROW LEVEL SECURITY;
ALTER TABLE guest ENABLE ROW LEVEL SECURITY;
ALTER TABLE task ENABLE ROW LEVEL SECURITY;
ALTER TABLE vendor ENABLE ROW LEVEL SECURITY;
ALTER TABLE budget_item ENABLE ROW LEVEL SECURITY;
ALTER TABLE timeline_event ENABLE ROW LEVEL SECURITY;
ALTER TABLE wedding_invites ENABLE ROW LEVEL SECURITY;

-- RLS Policies for app_user
CREATE POLICY "Users can view their own profile" ON app_user FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update their own profile" ON app_user FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can insert their own profile" ON app_user FOR INSERT WITH CHECK (auth.uid() = id);

-- RLS Policies for wedding
CREATE POLICY "Users can view weddings they own or co-own" ON wedding FOR SELECT USING (
  owner_id = auth.uid() OR 
  id IN (SELECT wedding_id FROM wedding_co_owner WHERE user_id = auth.uid())
);
CREATE POLICY "Users can create weddings" ON wedding FOR INSERT WITH CHECK (owner_id = auth.uid());
CREATE POLICY "Owners can update their weddings" ON wedding FOR UPDATE USING (owner_id = auth.uid());
CREATE POLICY "Owners can delete their weddings" ON wedding FOR DELETE USING (owner_id = auth.uid());

-- RLS Policies for wedding_co_owner
CREATE POLICY "Users can view co-owners of their weddings" ON wedding_co_owner FOR SELECT USING (
  wedding_id IN (
    SELECT id FROM wedding WHERE owner_id = auth.uid()
    UNION
    SELECT wedding_id FROM wedding_co_owner WHERE user_id = auth.uid()
  )
);
CREATE POLICY "Wedding owners can manage co-owners" ON wedding_co_owner FOR ALL USING (
  wedding_id IN (SELECT id FROM wedding WHERE owner_id = auth.uid())
);

-- RLS Policies for guests
CREATE POLICY "Users can manage guests of their weddings" ON guest FOR ALL USING (
  wedding_id IN (
    SELECT id FROM wedding WHERE owner_id = auth.uid()
    UNION
    SELECT wedding_id FROM wedding_co_owner WHERE user_id = auth.uid()
  )
);

-- RLS Policies for task
CREATE POLICY "Users can manage tasks of their weddings" ON task FOR ALL USING (
  wedding_id IN (
    SELECT id FROM wedding WHERE owner_id = auth.uid()
    UNION
    SELECT wedding_id FROM wedding_co_owner WHERE user_id = auth.uid()
  )
);

-- RLS Policies for vendor
CREATE POLICY "Users can manage vendors of their weddings" ON vendor FOR ALL USING (
  wedding_id IN (
    SELECT id FROM wedding WHERE owner_id = auth.uid()
    UNION
    SELECT wedding_id FROM wedding_co_owner WHERE user_id = auth.uid()
  )
);

-- RLS Policies for budget_item
CREATE POLICY "Users can manage budget items of their weddings" ON budget_item FOR ALL USING (
  wedding_id IN (
    SELECT id FROM wedding WHERE owner_id = auth.uid()
    UNION
    SELECT wedding_id FROM wedding_co_owner WHERE user_id = auth.uid()
  )
);

-- RLS Policies for timeline_event
CREATE POLICY "Users can manage timeline events of their weddings" ON timeline_event FOR ALL USING (
  wedding_id IN (
    SELECT id FROM wedding WHERE owner_id = auth.uid()
    UNION
    SELECT wedding_id FROM wedding_co_owner WHERE user_id = auth.uid()
  )
);

-- RLS Policies for wedding_invites
CREATE POLICY "Users can manage invites of their weddings" ON wedding_invites FOR ALL USING (
  wedding_id IN (
    SELECT id FROM wedding WHERE owner_id = auth.uid()
    UNION
    SELECT wedding_id FROM wedding_co_owner WHERE user_id = auth.uid()
  )
);

-- Function to prevent removing last owner
CREATE OR REPLACE FUNCTION prevent_remove_last_owner()
RETURNS TRIGGER AS $$
BEGIN
  -- Only check if we're removing an owner
  IF OLD.role = 'owner' THEN
    -- Check if there are any remaining owners for this wedding
    IF (SELECT COUNT(*) FROM wedding_co_owner WHERE wedding_id = OLD.wedding_id AND role = 'owner') <= 1 THEN
      RAISE EXCEPTION 'Cannot remove the last owner of a wedding';
    END IF;
  END IF;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER prevent_remove_last_owner_trigger
  BEFORE DELETE ON wedding_co_owner
  FOR EACH ROW
  EXECUTE FUNCTION prevent_remove_last_owner();

-- Function to generate wedding slug
CREATE OR REPLACE FUNCTION generate_wedding_slug()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.slug IS NULL OR NEW.slug = '' THEN
    NEW.slug := lower(replace(concat(NEW.name_bride, '-', NEW.name_groom, '-', extract(year from NEW.date)), ' ', '-'));
    -- Ensure uniqueness
    WHILE EXISTS (SELECT 1 FROM wedding WHERE slug = NEW.slug AND id != NEW.id) LOOP
      NEW.slug := NEW.slug || '-' || extract(epoch from now())::text;
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER generate_wedding_slug_trigger
  BEFORE INSERT OR UPDATE ON wedding
  FOR EACH ROW
  EXECUTE FUNCTION generate_wedding_slug();

-- Function to create app_user record when auth user is created
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO app_user (id, email, full_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Function to get active wedding for current user
CREATE OR REPLACE FUNCTION get_active_wedding()
RETURNS UUID AS $$
DECLARE
  active_wedding_id UUID;
BEGIN
  -- Get the active wedding ID from user metadata
  SELECT (auth.jwt() ->> 'user_metadata' ->> 'active_wedding_id')::UUID INTO active_wedding_id;
  
  -- Verify the user has access to this wedding
  IF active_wedding_id IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1 FROM wedding 
      WHERE id = active_wedding_id 
      AND (owner_id = auth.uid() OR id IN (
        SELECT wedding_id FROM wedding_co_owner WHERE user_id = auth.uid()
      ))
    ) THEN
      active_wedding_id := NULL;
    END IF;
  END IF;
  
  RETURN active_wedding_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to set active wedding for current user
CREATE OR REPLACE FUNCTION set_active_wedding(p_wedding_id UUID)
RETURNS VOID AS $$
BEGIN
  -- Verify the user has access to this wedding
  IF NOT EXISTS (
    SELECT 1 FROM wedding 
    WHERE id = p_wedding_id 
    AND (owner_id = auth.uid() OR id IN (
      SELECT wedding_id FROM wedding_co_owner WHERE user_id = auth.uid()
    ))
  ) THEN
    RAISE EXCEPTION 'User does not have access to this wedding';
  END IF;
  
  -- Update user metadata with active wedding ID
  UPDATE auth.users 
  SET user_metadata = COALESCE(user_metadata, '{}'::jsonb) || jsonb_build_object('active_wedding_id', p_wedding_id)
  WHERE id = auth.uid();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

