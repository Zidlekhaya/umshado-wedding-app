// Test the design system constants
const { Colors, Typography, Spacing, BorderRadius, Shadows } = require('../../constants/Design');

describe('Design System', () => {
  describe('Colors', () => {
    it('should have all required color properties', () => {
      expect(Colors.primary).toBeDefined();
      expect(Colors.secondary).toBeDefined();
      expect(Colors.accent).toBeDefined();
      expect(Colors.white).toBeDefined();
      expect(Colors.black).toBeDefined();
      expect(Colors.background).toBeDefined();
      expect(Colors.textPrimary).toBeDefined();
      expect(Colors.textSecondary).toBeDefined();
    });

    it('should have proper color values', () => {
      expect(Colors.primary).toBe('#00a86b');
      expect(Colors.secondary).toBe('#FF6B35');
      expect(Colors.accent).toBe('#00a86b');
      expect(Colors.white).toBe('#FFFFFF');
      expect(Colors.black).toBe('#1A1A1A');
    });

    it('should have gray scale colors', () => {
      expect(Colors.gray[50]).toBeDefined();
      expect(Colors.gray[100]).toBeDefined();
      expect(Colors.gray[500]).toBeDefined();
      expect(Colors.gray[900]).toBeDefined();
    });

    it('should have status colors', () => {
      expect(Colors.success).toBeDefined();
      expect(Colors.warning).toBeDefined();
      expect(Colors.error).toBeDefined();
      expect(Colors.info).toBeDefined();
    });
  });

  describe('Typography', () => {
    it('should have all required font sizes', () => {
      expect(Typography.fontSize.xs).toBe(12);
      expect(Typography.fontSize.sm).toBe(14);
      expect(Typography.fontSize.base).toBe(16);
      expect(Typography.fontSize.lg).toBe(18);
      expect(Typography.fontSize.xl).toBe(20);
      expect(Typography.fontSize['2xl']).toBe(24);
      expect(Typography.fontSize['3xl']).toBe(30);
      expect(Typography.fontSize['4xl']).toBe(36);
      expect(Typography.fontSize['5xl']).toBe(48);
    });

    it('should have all required font weights', () => {
      expect(Typography.fontWeight.normal).toBe('400');
      expect(Typography.fontWeight.medium).toBe('500');
      expect(Typography.fontWeight.semibold).toBe('600');
      expect(Typography.fontWeight.bold).toBe('700');
      expect(Typography.fontWeight.extrabold).toBe('800');
    });

    it('should have line heights', () => {
      expect(Typography.lineHeight.tight).toBe(1.25);
      expect(Typography.lineHeight.normal).toBe(1.5);
      expect(Typography.lineHeight.relaxed).toBe(1.75);
    });
  });

  describe('Spacing', () => {
    it('should have all required spacing values', () => {
      expect(Spacing.xs).toBe(4);
      expect(Spacing.sm).toBe(8);
      expect(Spacing.md).toBe(16);
      expect(Spacing.lg).toBe(24);
      expect(Spacing.xl).toBe(32);
      expect(Spacing['2xl']).toBe(48);
      expect(Spacing['3xl']).toBe(64);
    });
  });

  describe('BorderRadius', () => {
    it('should have all required border radius values', () => {
      expect(BorderRadius.none).toBe(0);
      expect(BorderRadius.sm).toBe(4);
      expect(BorderRadius.md).toBe(8);
      expect(BorderRadius.lg).toBe(12);
      expect(BorderRadius.xl).toBe(16);
      expect(BorderRadius['2xl']).toBe(24);
      expect(BorderRadius.full).toBe(9999);
    });
  });

  describe('Shadows', () => {
    it('should have all required shadow presets', () => {
      expect(Shadows.sm).toBeDefined();
      expect(Shadows.md).toBeDefined();
      expect(Shadows.lg).toBeDefined();
      expect(Shadows.xl).toBeDefined();
    });

    it('should have proper shadow properties', () => {
      expect(Shadows.sm.shadowColor).toBe('#000');
      expect(Shadows.sm.shadowOffset).toEqual({ width: 0, height: 1 });
      expect(Shadows.sm.shadowOpacity).toBe(0.05);
      expect(Shadows.sm.elevation).toBe(1);
    });
  });
});


