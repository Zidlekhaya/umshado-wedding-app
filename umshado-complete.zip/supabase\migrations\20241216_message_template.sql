-- Create message_template table for WhatsApp invite templates
create table if not exists public.message_template (
  id uuid primary key default gen_random_uuid(),
  wedding_id uuid not null references public.wedding(id) on delete cascade,
  name text not null,
  body text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Create index for efficient queries
create index if not exists message_template_wedding_idx on public.message_template(wedding_id);

-- Enable RLS
alter table public.message_template enable row level security;

-- RLS policies: only owner of wedding can manage templates
create policy "select own wedding templates"
  on public.message_template for select
  using (exists (select 1 from public.wedding w where w.id = wedding_id and w.owner_id = auth.uid()));

create policy "insert own wedding templates"
  on public.message_template for insert
  with check (exists (select 1 from public.wedding w where w.id = wedding_id and w.owner_id = auth.uid()));

create policy "update own wedding templates"
  on public.message_template for update
  using (exists (select 1 from public.wedding w where w.id = wedding_id and w.owner_id = auth.uid()));

create policy "delete own wedding templates"
  on public.message_template for delete
  using (exists (select 1 from public.wedding w where w.id = wedding_id and w.owner_id = auth.uid()));




