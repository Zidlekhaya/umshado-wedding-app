// Database service layer for Umshado
import { supabase } from './supabase';
import type {
  AppUser,
  Wedding,
  WeddingCoOwner,
  Guest,
  Task,
  Vendor,
  BudgetItem,
  TimelineEvent,
  WeddingSummary,
  CreateWeddingData,
  UpdateWeddingData,
  CreateGuestData,
  UpdateGuestData,
  CreateTaskData,
  UpdateTaskData,
  CreateVendorData,
  UpdateVendorData,
  CreateBudgetItemData,
  UpdateBudgetItemData,
  CreateTimelineEventData,
  UpdateTimelineEventData,
  GuestFilters,
  TaskFilters,
  VendorFilters,
} from './types';

// User services
export const userService = {
  async getCurrentUser(): Promise<AppUser | null> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from('app_user')
      .select('*')
      .eq('id', user.id)
      .single();

    if (error) throw error;
    return data;
  },

  async updateProfile(updates: Partial<AppUser>): Promise<AppUser> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase
      .from('app_user')
      .update(updates)
      .eq('id', user.id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },
};

// Wedding services
export const weddingService = {
  async getWeddings(): Promise<Wedding[]> {
    const { data, error } = await supabase
      .from('weddings')
      .select('*')
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async getWedding(id: string): Promise<Wedding | null> {
    const { data, error } = await supabase
      .from('weddings')
      .select('*')
      .eq('id', id)
      .is('deleted_at', null)
      .single();

    if (error) throw error;
    return data;
  },

  async createWedding(weddingData: CreateWeddingData): Promise<Wedding> {
    // Ensure date is 'YYYY-MM-DD'
    const dateStr =
      typeof (weddingData as any).date === 'string'
        ? (weddingData as any).date
        : new Date((weddingData as any).date).toISOString().slice(0, 10);

    // Some forms use "location" instead of "city"
    const city =
      (weddingData as any).city ??
      (weddingData as any).location ??
      null;

    const { data, error } = await supabase.rpc('create_wedding_secure', {
      p_name: (weddingData as any).name,
      p_date: dateStr,
      p_city: city,
      p_culture: (weddingData as any).culture ?? null,
      p_ceremony: (weddingData as any).ceremony_location ?? null,
      p_reception: (weddingData as any).reception_location ?? null,
    });

    if (error) {
      console.log('create_wedding_secure error:', error);
      throw error;
    }
    return data as Wedding;
  },

  async updateWedding(updates: UpdateWeddingData): Promise<Wedding> {
    const { data, error } = await supabase
      .from('weddings')
      .update(updates)
      .eq('id', updates.id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteWedding(id: string): Promise<void> {
    const { error } = await supabase
      .from('weddings')
      .update({ deleted_at: new Date().toISOString() })
      .eq('id', id);

    if (error) throw error;
  },

  async getWeddingSummary(id: string): Promise<WeddingSummary> {
    const wedding = await this.getWedding(id);
    if (!wedding) throw new Error('Wedding not found');

    // Get guest counts
    const { data: guests } = await supabase
      .from('guests')
      .select('rsvp_status')
      .eq('wedding_id', id);

    const guest_counts = {
      total: guests?.length || 0,
      pending: guests?.filter(g => g.rsvp_status === 'Pending').length || 0,
      confirmed: guests?.filter(g => g.rsvp_status === 'Yes').length || 0,
      declined: guests?.filter(g => g.rsvp_status === 'No').length || 0,
    };

    // Get task counts
    const { data: tasks } = await supabase
      .from('task')
      .select('status, due_date')
      .eq('wedding_id', id);

    const now = new Date();
    const task_counts = {
      total: tasks?.length || 0,
      todo: tasks?.filter(t => t.status === 'Todo').length || 0,
      in_progress: tasks?.filter(t => t.status === 'InProgress').length || 0,
      done: tasks?.filter(t => t.status === 'Done').length || 0,
      overdue: tasks?.filter(t => t.due_date && new Date(t.due_date) < now && t.status !== 'Done').length || 0,
    };

    // Get budget summary
    const { data: budgetItems } = await supabase
      .from('budget_item')
      .select('estimated, actual, paid')
      .eq('wedding_id', id);

    const budget_summary = {
      estimated_total: budgetItems?.reduce((sum, item) => sum + (item.estimated || 0), 0) || 0,
      actual_total: budgetItems?.reduce((sum, item) => sum + (item.actual || 0), 0) || 0,
      paid_total: budgetItems?.reduce((sum, item) => sum + (item.paid || 0), 0) || 0,
      outstanding: 0, // Will be calculated
    };
    budget_summary.outstanding = budget_summary.actual_total - budget_summary.paid_total;

    // Get upcoming events
    const { data: upcoming_events } = await supabase
      .from('timeline_event')
      .select('*')
      .eq('wedding_id', id)
      .gte('starts_at', now.toISOString())
      .order('starts_at', { ascending: true })
      .limit(5);

    return {
      wedding,
      guest_counts,
      task_counts,
      budget_summary,
      upcoming_events: upcoming_events || [],
    };
  },
};

// Guest services
export const guestService = {
  async getGuests(weddingId: string, filters: GuestFilters = {}): Promise<Guest[]> {
    let query = supabase
      .from('guests')
      .select('*')
      .eq('wedding_id', weddingId)
      .order('created_at', { ascending: false });

    if (filters.search) {
      query = query.or(`full_name.ilike.%${filters.search}%,email.ilike.%${filters.search}%`);
    }
    if (filters.rsvp_status) {
      query = query.eq('rsvp_status', filters.rsvp_status);
    }
    if (filters.side) {
      query = query.eq('side', filters.side);
    }
    if (filters.tags && filters.tags.length > 0) {
      query = query.overlaps('tags', filters.tags);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data || [];
  },

  async createGuest(weddingId: string, guestData: CreateGuestData): Promise<Guest> {
    const { data, error } = await supabase
      .from('guests')
      .insert({
        wedding_id: weddingId,
        ...guestData,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateGuest(updates: UpdateGuestData): Promise<Guest> {
    const { data, error } = await supabase
      .from('guests')
      .update(updates)
      .eq('id', updates.id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteGuest(id: string): Promise<void> {
    const { error } = await supabase
      .from('guests')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  async bulkImportGuests(weddingId: string, guests: CreateGuestData[]): Promise<Guest[]> {
    const { data, error } = await supabase
      .from('guests')
      .insert(guests.map(guest => ({ wedding_id: weddingId, ...guest })))
      .select();

    if (error) throw error;
    return data || [];
  },
};

// Task services
export const taskService = {
  async getTasks(weddingId: string, filters: TaskFilters = {}): Promise<Task[]> {
    let query = supabase
      .from('task')
      .select(`
        *,
        assignee:app_user!task_assignee_id_fkey(*)
      `)
      .eq('wedding_id', weddingId)
      .order('created_at', { ascending: false });

    if (filters.status) {
      query = query.eq('status', filters.status);
    }
    if (filters.priority) {
      query = query.eq('priority', filters.priority);
    }
    if (filters.assignee_id) {
      query = query.eq('assignee_id', filters.assignee_id);
    }
    if (filters.due_date_from) {
      query = query.gte('due_date', filters.due_date_from);
    }
    if (filters.due_date_to) {
      query = query.lte('due_date', filters.due_date_to);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data || [];
  },

  async createTask(weddingId: string, taskData: CreateTaskData): Promise<Task> {
    const { data, error } = await supabase
      .from('task')
      .insert({
        wedding_id: weddingId,
        ...taskData,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateTask(updates: UpdateTaskData): Promise<Task> {
    const { data, error } = await supabase
      .from('task')
      .update(updates)
      .eq('id', updates.id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteTask(id: string): Promise<void> {
    const { error } = await supabase
      .from('task')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },
};

// Vendor services
export const vendorService = {
  async getVendors(weddingId: string, filters: VendorFilters = {}): Promise<Vendor[]> {
    let query = supabase
      .from('vendor')
      .select('*')
      .eq('wedding_id', weddingId)
      .order('created_at', { ascending: false });

    if (filters.category) {
      query = query.eq('category', filters.category);
    }
    if (filters.status) {
      query = query.eq('status', filters.status);
    }
    if (filters.search) {
      query = query.or(`name.ilike.%${filters.search}%,category.ilike.%${filters.search}%`);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data || [];
  },

  async createVendor(weddingId: string, vendorData: CreateVendorData): Promise<Vendor> {
    const { data, error } = await supabase
      .from('vendor')
      .insert({
        wedding_id: weddingId,
        ...vendorData,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateVendor(updates: UpdateVendorData): Promise<Vendor> {
    const { data, error } = await supabase
      .from('vendor')
      .update(updates)
      .eq('id', updates.id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteVendor(id: string): Promise<void> {
    const { error } = await supabase
      .from('vendor')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },
};

// Budget services
export const budgetService = {
  async getBudgetItems(weddingId: string): Promise<BudgetItem[]> {
    const { data, error } = await supabase
      .from('budget_item')
      .select(`
        *,
        vendor:vendor(*)
      `)
      .eq('wedding_id', weddingId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async createBudgetItem(weddingId: string, itemData: CreateBudgetItemData): Promise<BudgetItem> {
    const { data, error } = await supabase
      .from('budget_item')
      .insert({
        wedding_id: weddingId,
        ...itemData,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateBudgetItem(updates: UpdateBudgetItemData): Promise<BudgetItem> {
    const { data, error } = await supabase
      .from('budget_item')
      .update(updates)
      .eq('id', updates.id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteBudgetItem(id: string): Promise<void> {
    const { error } = await supabase
      .from('budget_item')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },
};

// Timeline services
export const timelineService = {
  async getTimelineEvents(weddingId: string): Promise<TimelineEvent[]> {
    const { data, error } = await supabase
      .from('timeline_event')
      .select(`
        *,
        responsible_user:app_user!timeline_event_responsible_user_id_fkey(*)
      `)
      .eq('wedding_id', weddingId)
      .order('starts_at', { ascending: true });

    if (error) throw error;
    return data || [];
  },

  async createTimelineEvent(weddingId: string, eventData: CreateTimelineEventData): Promise<TimelineEvent> {
    const { data, error } = await supabase
      .from('timeline_event')
      .insert({
        wedding_id: weddingId,
        ...eventData,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateTimelineEvent(updates: UpdateTimelineEventData): Promise<TimelineEvent> {
    const { data, error } = await supabase
      .from('timeline_event')
      .update(updates)
      .eq('id', updates.id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteTimelineEvent(id: string): Promise<void> {
    const { error } = await supabase
      .from('timeline_event')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  async reorderTimelineEvents(weddingId: string, eventIds: string[]): Promise<void> {
    const updates = eventIds.map((id, index) => ({
      id,
      order_index: index,
    }));

    for (const update of updates) {
      await supabase
        .from('timeline_event')
        .update({ order_index: update.order_index })
        .eq('id', update.id);
    }
  },
};

// Co-owner services
export const coOwnerService = {
  async getCoOwners(weddingId: string): Promise<WeddingCoOwner[]> {
    const { data, error } = await supabase
      .from('wedding_co_owner')
      .select(`
        *,
        user:app_user(*)
      `)
      .eq('wedding_id', weddingId)
      .order('created_at', { ascending: true });

    if (error) throw error;
    return data || [];
  },

  async inviteCoOwner(weddingId: string, email: string, role: 'co_owner' | 'viewer' = 'co_owner'): Promise<void> {
    // First, get the user by email
    const { data: user, error: userError } = await supabase
      .from('app_user')
      .select('id')
      .eq('email', email)
      .single();

    if (userError) throw new Error('User not found');

    // Add as co-owner
    const { error } = await supabase
      .from('wedding_co_owner')
      .insert({
        wedding_id: weddingId,
        user_id: user.id,
        role,
      });

    if (error) throw error;
  },

  async removeCoOwner(weddingId: string, userId: string): Promise<void> {
    const { error } = await supabase
      .from('wedding_co_owner')
      .delete()
      .eq('wedding_id', weddingId)
      .eq('user_id', userId);

    if (error) throw error;
  },

  async updateCoOwnerRole(weddingId: string, userId: string, role: 'co_owner' | 'viewer'): Promise<void> {
    const { error } = await supabase
      .from('wedding_co_owner')
      .update({ role })
      .eq('wedding_id', weddingId)
      .eq('user_id', userId);

    if (error) throw error;
  },
};

