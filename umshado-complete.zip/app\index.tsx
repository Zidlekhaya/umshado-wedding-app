// app/index.tsx
import { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { supabase } from '@/lib/supabase';
import { router } from 'expo-router';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Colors, Typography, Spacing } from '@/constants/Design';

export default function HomeGate() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      console.log('HomeGate: Checking session and active wedding...');
      
      const { data: sessionResp } = await supabase.auth.getSession();
      const session = sessionResp?.session;
      
      if (!session?.user) {
        console.log('HomeGate: No session, redirecting to login...');
        router.replace('/(auth)/sign-in');
        return;
      }

      // Check user type - redirect vendors to vendor dashboard
      const userType = session.user.user_metadata?.user_type || 'couple';
      console.log('HomeGate: User metadata:', session.user.user_metadata);
      console.log('HomeGate: Detected user type:', userType);
      
      if (userType === 'vendor') {
        console.log('HomeGate: Vendor detected, redirecting to vendor dashboard...');
        router.replace('/(vendor)');
        return;
      }

      console.log('HomeGate: Session found, checking for weddings...');
      
      // Use direct database query instead of user metadata approach
      const { data: weddings, error } = await supabase
        .from('weddings')
        .select('id, name, date, location, created_at')
        .eq('owner_id', session.user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.log('Error fetching weddings:', error);
        setLoading(false);
        return;
      }

      if (weddings && weddings.length > 0) {
        console.log('HomeGate: Wedding found, redirecting to tabs...');
        router.replace('/(tabs)');
      } else {
        console.log('HomeGate: No wedding found, showing create wedding CTA...');
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.primary} />
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  // Render "Create your wedding" CTA
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Welcome to Umshado</Text>
        <Text style={styles.subtitle}>
          Have the wedding of your dreams without giving up on your dreams. 
          All your wedding planning needs in one place.
        </Text>
      </View>

      <Card style={styles.ctaCard}>
        <Text style={styles.ctaTitle}>Ready to plan your wedding?</Text>
        <Text style={styles.ctaSubtitle}>
          Create your wedding profile and start planning the perfect day.
        </Text>
        
        <Button
          title="Create Your Wedding"
          onPress={() => router.push('/(tabs)/guests')}
          size="lg"
          style={styles.createButton}
        />
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.background,
  },
  loadingText: {
    marginTop: Spacing.md,
    fontSize: Typography.fontSize.base,
    color: Colors.textSecondary,
  },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing['3xl'],
    paddingBottom: Spacing.xl,
    alignItems: 'center',
  },
  title: {
    fontSize: Typography.fontSize['4xl'],
    fontWeight: Typography.fontWeight.bold,
    color: Colors.primary,
    textAlign: 'center',
    marginBottom: Spacing.lg,
  },
  subtitle: {
    fontSize: Typography.fontSize.lg,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: Typography.lineHeight.relaxed * Typography.fontSize.lg,
  },
  ctaCard: {
    marginHorizontal: Spacing.lg,
    padding: Spacing.xl,
    alignItems: 'center',
  },
  ctaTitle: {
    fontSize: Typography.fontSize['2xl'],
    fontWeight: Typography.fontWeight.semibold,
    color: Colors.text,
    textAlign: 'center',
    marginBottom: Spacing.md,
  },
  ctaSubtitle: {
    fontSize: Typography.fontSize.base,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: Typography.lineHeight.relaxed * Typography.fontSize.base,
    marginBottom: Spacing.xl,
  },
  createButton: {
    minWidth: 200,
  },
});
