-- Create storage bucket for chat files
-- Run this in Supabase SQL Editor or via migration

-- Create the chat-files bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'chat-files',
  'chat-files',
  true,
  10485760, -- 10MB limit
  array['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain']
)
ON CONFLICT (id) DO NOTHING;

-- Create RLS policies for the chat-files bucket
CREATE POLICY "Users can view chat files they have access to"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'chat-files' AND
  auth.uid()::text IN (
    SELECT CASE 
      WHEN c.couple_user_id = auth.uid() THEN auth.uid()::text
      WHEN c.vendor_user_id = auth.uid() THEN auth.uid()::text
      ELSE NULL
    END
    FROM conversations c
    WHERE (storage.foldername(objects.name))[1] = c.id::text
  )
);

CREATE POLICY "Users can upload chat files for their conversations"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'chat-files' AND
  auth.uid()::text IN (
    SELECT CASE 
      WHEN c.couple_user_id = auth.uid() THEN auth.uid()::text
      WHEN c.vendor_user_id = auth.uid() THEN auth.uid()::text
      ELSE NULL
    END
    FROM conversations c
    WHERE (storage.foldername(objects.name))[1] = c.id::text
  )
);

CREATE POLICY "Users can delete their uploaded chat files"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'chat-files' AND
  auth.uid()::text IN (
    SELECT CASE 
      WHEN c.couple_user_id = auth.uid() THEN auth.uid()::text
      WHEN c.vendor_user_id = auth.uid() THEN auth.uid()::text
      ELSE NULL
    END
    FROM conversations c
    WHERE (storage.foldername(objects.name))[1] = c.id::text
  )
);



