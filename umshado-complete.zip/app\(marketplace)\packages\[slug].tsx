import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Image, Alert, TextInput } from 'react-native';
import { Stack, router, useLocalSearchParams } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Loading } from '@/components/ui/Loading';
import { colors, typography, spacing, borderRadius } from '@/src/theme/design-system';
import { supabase } from '@/lib/supabase';
import { getOrCreateConversation } from '@/lib/chat-service';
import { useWeddingStore } from '@/stores/wedding';

interface PackageDetail {
  id: string;
  vendor_id: string;
  package_name: string;
  slug: string;
  short_description: string;
  long_description: string;
  price_type: string;
  price_min: number;
  price_max: number;
  currency: string;
  duration_hours: number;
  has_availability: boolean;
  created_at: string;
  vendor_profiles: {
    business_name: string;
    city: string;
    category: string;
    contact_email: string;
  };
  package_images: Array<{ storage_path: string; alt_text: string }>;
  package_items: Array<{ item_name: string; item_description: string }>;
  package_addons: Array<{ id: string; title: string; description: string; price: number; price_type: string }>;
}

export default function PackageDetail() {
  const { slug } = useLocalSearchParams();
  const { currentWedding } = useWeddingStore();
  const [loading, setLoading] = useState(true);
  const [packageDetail, setPackageDetail] = useState<PackageDetail | null>(null);
  const [selectedAddons, setSelectedAddons] = useState<string[]>([]);
  const [eventDate, setEventDate] = useState('');
  const [guestCount, setGuestCount] = useState('1');
  const [notes, setNotes] = useState('');
  const [bookingLoading, setBookingLoading] = useState(false);
  const [messagingLoading, setMessagingLoading] = useState(false);

  useEffect(() => {
    if (slug) {
      loadPackageDetail();
    }
  }, [slug]);

  const loadPackageDetail = async () => {
    try {
      setLoading(true);

      const { data: packageData, error } = await supabase
        .from('vendor_packages')
        .select(`
          *,
          vendor_profiles!inner(business_name, city, category, contact_email),
          package_images(storage_path, alt_text),
          package_items(item_name, item_description),
          package_addons(id, title, description, price, price_type)
        `)
        .eq('slug', slug)
        .eq('is_active', true)
        .single();

      if (error) {
        console.error('Error loading package:', error);
        Alert.alert('Error', 'Package not found');
        router.back();
        return;
      }

      setPackageDetail(packageData);
    } catch (error: any) {
      console.error('Error loading package:', error);
      Alert.alert('Error', 'Failed to load package');
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (pkg: PackageDetail) => {
    if (pkg.price_type === 'fixed') {
      return `R${pkg.price_min?.toLocaleString()}`;
    } else if (pkg.price_type === 'range') {
      return `R${pkg.price_min?.toLocaleString()} - R${pkg.price_max?.toLocaleString()}`;
    } else if (pkg.price_type === 'per_person') {
      return `R${pkg.price_min?.toLocaleString()}/person`;
    } else if (pkg.price_type === 'hourly') {
      return `R${pkg.price_min?.toLocaleString()}/hour`;
    }
    return 'Price on request';
  };

  const calculateTotalPrice = () => {
    if (!packageDetail) return 0;

    let total = 0;

    // Base package price
    if (packageDetail.price_type === 'fixed') {
      total = packageDetail.price_min || 0;
    } else if (packageDetail.price_type === 'range') {
      total = packageDetail.price_min || 0;
    } else if (packageDetail.price_type === 'per_person') {
      total = (packageDetail.price_min || 0) * parseInt(guestCount || '1');
    } else if (packageDetail.price_type === 'hourly') {
      total = (packageDetail.price_min || 0) * (packageDetail.duration_hours || 1);
    }

    // Add selected addons
    selectedAddons.forEach(addonId => {
      const addon = packageDetail.package_addons.find(a => a.id === addonId);
      if (addon) {
        if (addon.price_type === 'fixed') {
          total += addon.price;
        } else if (addon.price_type === 'per_person') {
          total += addon.price * parseInt(guestCount || '1');
        } else if (addon.price_type === 'hourly') {
          total += addon.price * (packageDetail.duration_hours || 1);
        }
      }
    });

    return total;
  };

  const handleBooking = async () => {
    if (!packageDetail) return;

    // Validation
    if (!eventDate) {
      Alert.alert('Error', 'Please select an event date');
      return;
    }

    if (parseInt(guestCount) < 1) {
      Alert.alert('Error', 'Please enter a valid guest count');
      return;
    }

    setBookingLoading(true);

    try {
      const response = await fetch(`${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/create_booking`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          package_id: packageDetail.id,
          selected_addons: selectedAddons,
          event_date: eventDate,
          notes: notes.trim() || null,
          guest_count: parseInt(guestCount),
        }),
      });

      const result = await response.json();

      if (result.success) {
        Alert.alert(
          'Booking Request Sent!',
          'Your booking request has been sent to the vendor. They will contact you soon to confirm the details.',
          [
            {
              text: 'OK',
              onPress: () => router.back()
            }
          ]
        );
      } else {
        Alert.alert('Error', result.error || 'Failed to create booking');
      }
    } catch (error) {
      console.error('Booking error:', error);
      Alert.alert('Error', 'Failed to create booking');
    } finally {
      setBookingLoading(false);
    }
  };

  const handleMessageVendor = async () => {
    if (!packageDetail || !currentWedding) {
      Alert.alert('Error', 'Unable to start conversation. Please ensure you have an active wedding.');
      return;
    }

    try {
      setMessagingLoading(true);
      
      const conversationId = await getOrCreateConversation({
        weddingId: currentWedding.id,
        weddingName: `${currentWedding.partner1_name || ''} & ${currentWedding.partner2_name || ''}`.trim() || 'My Wedding',
        vendorUserId: packageDetail.vendor_id,
        vendorName: packageDetail.vendor_name || 'Vendor',
        vendorAvatar: packageDetail.vendor_avatar,
      });

      router.push(`/(chat)/${conversationId}`);
    } catch (error) {
      console.error('Error starting conversation:', error);
      Alert.alert('Error', 'Failed to start conversation. Please try again.');
    } finally {
      setMessagingLoading(false);
    }
  };

  const toggleAddon = (addonId: string) => {
    setSelectedAddons(prev =>
      prev.includes(addonId)
        ? prev.filter(id => id !== addonId)
        : [...prev, addonId]
    );
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <Loading size="large" color={colors.primary[300]} text="Loading package..." />
      </View>
    );
  }

  if (!packageDetail) {
    return (
      <View style={styles.container}>
        <Text>Package not found</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Stack.Screen
        options={{
          title: packageDetail.package_name,
          headerShown: true,
        }}
      />

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Package Images */}
        {packageDetail.package_images && packageDetail.package_images.length > 0 && (
          <View style={styles.imageContainer}>
            <Image 
              source={{ uri: packageDetail.package_images[0].storage_path }} 
              style={styles.mainImage}
              resizeMode="cover"
            />
          </View>
        )}

        {/* Package Header */}
        <Card variant="elevated" padding="lg" style={styles.headerCard}>
          <Text style={styles.packageName}>{packageDetail.package_name}</Text>
          <Text style={styles.vendorName}>{packageDetail.vendor_profiles.business_name}</Text>
          <Text style={styles.location}>
            <Feather name="map-pin" size={14} color={colors.text.secondary} />
            {packageDetail.vendor_profiles.city}
          </Text>
          <View style={styles.priceContainer}>
            <Text style={styles.price}>{formatPrice(packageDetail)}</Text>
            {packageDetail.duration_hours && (
              <Text style={styles.duration}>{packageDetail.duration_hours} hours</Text>
            )}
          </View>
        </Card>

        {/* Package Description */}
        <Card variant="elevated" padding="lg" style={styles.descriptionCard}>
          <Text style={styles.sectionTitle}>About This Package</Text>
          <Text style={styles.description}>{packageDetail.long_description}</Text>
        </Card>

        {/* Package Items */}
        <Card variant="elevated" padding="lg" style={styles.itemsCard}>
          <Text style={styles.sectionTitle}>What's Included</Text>
          {packageDetail.package_items.map((item, index) => (
            <View key={index} style={styles.itemRow}>
              <Feather name="check" size={16} color={colors.success[500]} />
              <View style={styles.itemContent}>
                <Text style={styles.itemName}>{item.item_name}</Text>
                {item.item_description && (
                  <Text style={styles.itemDescription}>{item.item_description}</Text>
                )}
              </View>
            </View>
          ))}
        </Card>

        {/* Package Addons */}
        {packageDetail.package_addons && packageDetail.package_addons.length > 0 && (
          <Card variant="elevated" padding="lg" style={styles.addonsCard}>
            <Text style={styles.sectionTitle}>Available Add-ons</Text>
            {packageDetail.package_addons.map((addon) => (
              <TouchableOpacity
                key={addon.id}
                style={[
                  styles.addonRow,
                  selectedAddons.includes(addon.id) && styles.addonRowSelected
                ]}
                onPress={() => toggleAddon(addon.id)}
              >
                <View style={styles.addonContent}>
                  <Text style={styles.addonTitle}>{addon.title}</Text>
                  {addon.description && (
                    <Text style={styles.addonDescription}>{addon.description}</Text>
                  )}
                  <Text style={styles.addonPrice}>
                    R{addon.price.toLocaleString()}
                    {addon.price_type === 'per_person' && '/person'}
                    {addon.price_type === 'hourly' && '/hour'}
                  </Text>
                </View>
                <View style={[
                  styles.addonCheckbox,
                  selectedAddons.includes(addon.id) && styles.addonCheckboxSelected
                ]}>
                  {selectedAddons.includes(addon.id) && (
                    <Feather name="check" size={16} color={colors.white} />
                  )}
                </View>
              </TouchableOpacity>
            ))}
          </Card>
        )}

        {/* Booking / Messaging */}
        <Card variant="elevated" padding="lg" style={styles.bookingCard}>
          <Text style={styles.sectionTitle}>Request Booking</Text>
          
          <View style={styles.formRow}>
            <Text style={styles.label}>Event Date</Text>
            <TextInput
              style={styles.input}
              placeholder="YYYY-MM-DD"
              value={eventDate}
              onChangeText={setEventDate}
              placeholderTextColor={colors.text.secondary}
            />
          </View>

          <View style={styles.formRow}>
            <Text style={styles.label}>Guest Count</Text>
            <TextInput
              style={styles.input}
              placeholder="Number of guests"
              value={guestCount}
              onChangeText={setGuestCount}
              keyboardType="numeric"
              placeholderTextColor={colors.text.secondary}
            />
          </View>

          <View style={styles.formRow}>
            <Text style={styles.label}>Additional Notes</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="Any special requirements or questions..."
              value={notes}
              onChangeText={setNotes}
              multiline
              numberOfLines={3}
              placeholderTextColor={colors.text.secondary}
            />
          </View>

          {/* Total Price */}
          <View style={styles.totalContainer}>
            <Text style={styles.totalLabel}>Estimated Total</Text>
            <Text style={styles.totalPrice}>R{calculateTotalPrice().toLocaleString()}</Text>
          </View>

          <View style={styles.actionsRow}>
            <Button
              title="Request Booking"
              onPress={handleBooking}
              variant="primary"
              size="lg"
              style={styles.actionButton}
              disabled={bookingLoading}
            />
            <Button
              title={messagingLoading ? 'Starting Chat...' : 'Message Vendor'}
              onPress={handleMessageVendor}
              variant="secondary"
              size="lg"
              style={styles.actionButton}
              disabled={messagingLoading}
            />
          </View>
        </Card>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  content: {
    flex: 1,
  },
  imageContainer: {
    height: 200,
  },
  mainImage: {
    width: '100%',
    height: '100%',
  },
  headerCard: {
    margin: spacing[4],
    marginTop: spacing[2],
  },
  packageName: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: typography.fontWeight.bold,
    color: colors.text.primary,
    marginBottom: spacing[1],
  },
  vendorName: {
    fontSize: typography.fontSize.lg,
    color: colors.primary[300],
    fontWeight: typography.fontWeight.semibold,
    marginBottom: spacing[1],
  },
  location: {
    fontSize: typography.fontSize.sm,
    color: colors.text.secondary,
    marginBottom: spacing[3],
    flexDirection: 'row',
    alignItems: 'center',
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing[3],
  },
  price: {
    fontSize: typography.fontSize.xl,
    fontWeight: typography.fontWeight.bold,
    color: colors.primary[300],
  },
  duration: {
    fontSize: typography.fontSize.sm,
    color: colors.text.secondary,
  },
  descriptionCard: {
    marginHorizontal: spacing[4],
    marginBottom: spacing[4],
  },
  sectionTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text.primary,
    marginBottom: spacing[3],
  },
  description: {
    fontSize: typography.fontSize.base,
    color: colors.text.secondary,
    lineHeight: typography.lineHeight.relaxed * typography.fontSize.base,
  },
  itemsCard: {
    marginHorizontal: spacing[4],
    marginBottom: spacing[4],
  },
  itemRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: spacing[3],
  },
  itemContent: {
    flex: 1,
    marginLeft: spacing[2],
  },
  itemName: {
    fontSize: typography.fontSize.base,
    fontWeight: typography.fontWeight.medium,
    color: colors.text.primary,
    marginBottom: spacing[1],
  },
  itemDescription: {
    fontSize: typography.fontSize.sm,
    color: colors.text.secondary,
    lineHeight: typography.lineHeight.relaxed * typography.fontSize.sm,
  },
  addonsCard: {
    marginHorizontal: spacing[4],
    marginBottom: spacing[4],
  },
  addonRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing[3],
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.md,
    marginBottom: spacing[2],
  },
  addonRowSelected: {
    backgroundColor: colors.primary[50],
    borderWidth: 1,
    borderColor: colors.primary[300],
  },
  addonContent: {
    flex: 1,
  },
  addonTitle: {
    fontSize: typography.fontSize.base,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text.primary,
    marginBottom: spacing[1],
  },
  addonDescription: {
    fontSize: typography.fontSize.sm,
    color: colors.text.secondary,
    marginBottom: spacing[1],
  },
  addonPrice: {
    fontSize: typography.fontSize.sm,
    fontWeight: typography.fontWeight.semibold,
    color: colors.primary[300],
  },
  addonCheckbox: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.border.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addonCheckboxSelected: {
    backgroundColor: colors.primary[300],
    borderColor: colors.primary[300],
  },
  bookingCard: {
    marginHorizontal: spacing[4],
    marginBottom: spacing[4],
  },
  formRow: {
    marginBottom: spacing[4],
  },
  label: {
    fontSize: typography.fontSize.base,
    fontWeight: typography.fontWeight.medium,
    color: colors.text.primary,
    marginBottom: spacing[2],
  },
  input: {
    borderWidth: 1,
    borderColor: colors.border.primary,
    borderRadius: borderRadius.md,
    padding: spacing[3],
    fontSize: typography.fontSize.base,
    color: colors.text.primary,
    backgroundColor: colors.background.primary,
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  totalContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: spacing[3],
    borderTopWidth: 1,
    borderTopColor: colors.border.primary,
    marginBottom: spacing[4],
  },
  totalLabel: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text.primary,
  },
  totalPrice: {
    fontSize: typography.fontSize.xl,
    fontWeight: typography.fontWeight.bold,
    color: colors.primary[300],
  },
  bookingButton: {
    backgroundColor: colors.primary[300],
  },
  actionsRow: {
    flexDirection: 'row',
    gap: spacing[3],
  },
  actionButton: {
    flex: 1,
  },
});
