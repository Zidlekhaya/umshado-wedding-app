import { supabase } from '@/lib/supabase';

export type BudgetItem = {
  id: string;
  wedding_id: string;
  category: string;
  name: string;
  planned: number;
  notes?: string | null;
  created_at?: string;
  updated_at?: string;
};

export type Expense = {
  id: string;
  wedding_id: string;
  item_id: string;
  amount: number;
  vendor?: string | null;
  paid_on?: string | null; // ISO date
  method?: string | null;
  memo?: string | null;
  created_at?: string;
  updated_at?: string;
};

export type BudgetTotals = {
  planned: number;
  actual: number;
  remaining: number;
};

/**
 * Lists all budget items for a wedding
 */
export async function listBudgetItems(weddingId: string): Promise<BudgetItem[]> {
  const { data, error } = await supabase
    .from('budget_item')
    .select('*')
    .eq('wedding_id', weddingId)
    .order('created_at', { ascending: true });
  
  if (error) throw error;
  return data as BudgetItem[];
}

/**
 * Lists all expenses for a specific budget item
 */
export async function listExpensesByItem(itemId: string): Promise<Expense[]> {
  const { data, error } = await supabase
    .from('expense')
    .select('*')
    .eq('item_id', itemId)
    .order('paid_on', { ascending: false });
  
  if (error) throw error;
  return data as Expense[];
}

/**
 * Creates or updates a budget item
 */
export async function upsertBudgetItem(payload: Partial<BudgetItem> & { wedding_id: string }): Promise<BudgetItem> {
  const { data, error } = await supabase
    .from('budget_item')
    .upsert(payload)
    .select()
    .single();
  
  if (error) throw error;
  return data as BudgetItem;
}

/**
 * Deletes a budget item (and all its expenses)
 */
export async function deleteBudgetItem(id: string): Promise<void> {
  const { error } = await supabase
    .from('budget_item')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
}

/**
 * Adds a new expense to a budget item
 */
export async function addExpense(payload: Omit<Expense, 'id' | 'created_at' | 'updated_at'>): Promise<Expense> {
  const { data, error } = await supabase
    .from('expense')
    .insert(payload)
    .select()
    .single();
  
  if (error) throw error;
  return data as Expense;
}

/**
 * Updates an existing expense
 */
export async function updateExpense(id: string, updates: Partial<Omit<Expense, 'id' | 'created_at' | 'updated_at'>>): Promise<Expense> {
  const { data, error } = await supabase
    .from('expense')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  
  if (error) throw error;
  return data as Expense;
}

/**
 * Deletes an expense
 */
export async function deleteExpense(id: string): Promise<void> {
  const { error } = await supabase
    .from('expense')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
}

/**
 * Calculates budget totals for a wedding
 */
export async function getBudgetTotals(weddingId: string): Promise<BudgetTotals> {
  // Get planned total from budget items
  const { data: items, error: e1 } = await supabase
    .from('budget_item')
    .select('planned')
    .eq('wedding_id', weddingId);
  
  if (e1) throw e1;
  const planned = (items ?? []).reduce((s, i: any) => s + Number(i.planned || 0), 0);

  // Get actual total from expenses
  const { data: exps, error: e2 } = await supabase
    .from('expense')
    .select('amount')
    .eq('wedding_id', weddingId);
  
  if (e2) throw e2;
  const actual = (exps ?? []).reduce((s, e: any) => s + Number(e.amount || 0), 0);

  return { 
    planned, 
    actual, 
    remaining: planned - actual 
  };
}

/**
 * Gets budget item with its total expenses
 */
export async function getBudgetItemWithExpenses(itemId: string): Promise<{
  item: BudgetItem;
  expenses: Expense[];
  totalSpent: number;
}> {
  const [itemResult, expenses] = await Promise.all([
    supabase.from('budget_item').select('*').eq('id', itemId).single(),
    listExpensesByItem(itemId)
  ]);

  if (itemResult.error) throw itemResult.error;
  
  const totalSpent = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  
  return {
    item: itemResult.data as BudgetItem,
    expenses,
    totalSpent
  };
}

/**
 * Creates default budget categories for a new wedding
 */
export async function createDefaultBudgetItems(weddingId: string): Promise<void> {
  const existing = await listBudgetItems(weddingId);
  if (existing.length > 0) return;

  const defaults = [
    { category: 'Venue', name: 'Wedding Venue', planned: 0 },
    { category: 'Catering', name: 'Food & Beverages', planned: 0 },
    { category: 'Photography', name: 'Photography & Videography', planned: 0 },
    { category: 'Attire', name: 'Bride & Groom Attire', planned: 0 },
    { category: 'Flowers', name: 'Bouquets & Decorations', planned: 0 },
    { category: 'Music', name: 'DJ or Band', planned: 0 },
    { category: 'Transport', name: 'Transportation', planned: 0 },
    { category: 'Rings', name: 'Wedding Rings', planned: 0 },
  ];

  for (const item of defaults) {
    await upsertBudgetItem({
      wedding_id: weddingId,
      ...item
    });
  }
}




