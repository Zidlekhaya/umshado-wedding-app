import { supabase } from '@/lib/supabase';
import { scheduleTaskNotification, cancelAllNotifications } from '@/src/lib/notifications';
import type { Task, TaskStatus } from '@/types/task';

export async function getUpcomingTasks(weddingId: string, limit = 3) {
  const { data, error } = await supabase
    .from('tasks')
    .select('*')
    .eq('wedding_id', weddingId)
    .eq('status', 'open')
    .order('due_date', { ascending: true, nullsFirst: true })
    .limit(limit)
    .returns<Task[]>();
  if (error) throw error;
  return data ?? [];
}

export async function getAllTasks(weddingId: string) {
  const { data, error } = await supabase
    .from('tasks')
    .select('*')
    .eq('wedding_id', weddingId)
    .order('status', { ascending: true })
    .order('due_date', { ascending: true, nullsFirst: true })
    .returns<Task[]>();
  if (error) throw error;
  return data ?? [];
}

export async function addTask(input: Omit<Task, 'id' | 'created_at'>) {
  const { data, error } = await supabase.from('tasks').insert(input).select().single<Task>();
  if (error) throw error;
  
  // Schedule notification if remind_at is set and task is open
  if (data.remind_at && data.status === 'open') {
    const remindDate = new Date(data.remind_at);
    await scheduleTaskNotification(data.id, data.title, remindDate);
  }
  
  return data!;
}

export async function setTaskStatus(id: string, status: TaskStatus) {
  const { data, error } = await supabase.from('tasks').update({ status }).eq('id', id).select().single<Task>();
  if (error) throw error;
  
  // Reschedule all notifications when task status changes
  await rescheduleOpenTaskReminders();
  
  return data!;
}

export async function updateTask(id: string, updates: Partial<{
  title: string;
  due_date: string | null;
  notes: string | null;
  status: TaskStatus;
  remind_at: string | null;
}>) {
  const { data, error } = await supabase
    .from('tasks')
    .update(updates)
    .eq('id', id)
    .select()
    .single<Task>();
  
  if (error) throw error;
  
  // Reschedule all notifications when task is updated
  await rescheduleOpenTaskReminders();
  
  return data!;
}

export async function rescheduleOpenTaskReminders() {
  // Simple strategy: clear all local schedules and schedule again for all open tasks with future remind_at
  await cancelAllNotifications();
  
  const { data } = await supabase
    .from('tasks')
    .select('id, title, remind_at, status')
    .eq('status', 'open')
    .not('remind_at', 'is', null);
  
  if (!data) return;
  
  for (const task of data) {
    if (task.remind_at) {
      const when = new Date(task.remind_at);
      await scheduleTaskNotification(task.id, task.title, when);
    }
  }
}
