-- RLS Package Tests
-- Run these tests with different user contexts to validate RLS policies

-- Test 1: Vendor can insert package for their own vendor_id
-- Run as vendor A (auth.uid() == vendor_profiles.user_id)
-- Expected: SUCCESS
/*
INSERT INTO vendor_packages (vendor_id, package_name, price_type, price_min, price_max) 
VALUES ('<VENDOR_A_ID>', 'Test Package A', 'fixed', 1000, 2000);
*/

-- Test 2: Vendor cannot insert package for different vendor_id
-- Run as vendor A trying to insert for vendor B
-- Expected: FAIL (RLS policy violation)
/*
INSERT INTO vendor_packages (vendor_id, package_name, price_type, price_min, price_max) 
VALUES ('<VENDOR_B_ID>', 'Unauthorized Package', 'fixed', 1000, 2000);
*/

-- Test 3: Anonymous/public can read packages
-- Run without authentication
-- Expected: SUCCESS
/*
SELECT id, package_name, price_min FROM vendor_packages LIMIT 10;
*/

-- Test 4: Vendor can update their own packages
-- Run as vendor A updating their package
-- Expected: SUCCESS
/*
UPDATE vendor_packages 
SET package_name = 'Updated Package Name' 
WHERE vendor_id = '<VENDOR_A_ID>' AND package_name = 'Test Package A';
*/

-- Test 5: Vendor cannot update other vendor's packages
-- Run as vendor A trying to update vendor B's package
-- Expected: FAIL (RLS policy violation)
/*
UPDATE vendor_packages 
SET package_name = 'Hacked Package' 
WHERE vendor_id = '<VENDOR_B_ID>';
*/

-- Test 6: Vendor can manage package items for their packages
-- Run as vendor A
-- Expected: SUCCESS
/*
INSERT INTO package_items (package_id, item_name) 
VALUES ('<PACKAGE_A_ID>', 'Test Item');
*/

-- Test 7: Vendor cannot manage package items for other vendor's packages
-- Run as vendor A trying to insert item for vendor B's package
-- Expected: FAIL (RLS policy violation)
/*
INSERT INTO package_items (package_id, item_name) 
VALUES ('<PACKAGE_B_ID>', 'Unauthorized Item');
*/

-- Test 8: Couple can insert booking for themselves
-- Run as couple user
-- Expected: SUCCESS
/*
INSERT INTO package_bookings (package_id, couple_user_id, vendor_user_id, total_price, event_date) 
VALUES ('<PACKAGE_A_ID>', auth.uid(), '<VENDOR_A_USER_ID>', 1500, '2024-12-25');
*/

-- Test 9: Couple cannot insert booking for another user
-- Run as couple A trying to book for couple B
-- Expected: FAIL (RLS policy violation)
/*
INSERT INTO package_bookings (package_id, couple_user_id, vendor_user_id, total_price, event_date) 
VALUES ('<PACKAGE_A_ID>', '<COUPLE_B_ID>', '<VENDOR_A_USER_ID>', 1500, '2024-12-25');
*/

-- Test 10: Vendor can read bookings for their packages
-- Run as vendor A
-- Expected: SUCCESS
/*
SELECT * FROM package_bookings WHERE package_id = '<PACKAGE_A_ID>';
*/

-- Test 11: Vendor cannot read bookings for other vendor's packages
-- Run as vendor A trying to read vendor B's bookings
-- Expected: FAIL (RLS policy violation)
/*
SELECT * FROM package_bookings WHERE package_id = '<PACKAGE_B_ID>';
*/

-- Test 12: Couple can read their own bookings
-- Run as couple A
-- Expected: SUCCESS
/*
SELECT * FROM package_bookings WHERE couple_user_id = auth.uid();
*/

-- Test 13: Vendor can update booking status for their packages
-- Run as vendor A
-- Expected: SUCCESS
/*
UPDATE package_bookings 
SET booking_status = 'confirmed' 
WHERE package_id = '<PACKAGE_A_ID>' AND couple_user_id = '<COUPLE_A_ID>';
*/

-- Test 14: Vendor cannot update booking status for other vendor's packages
-- Run as vendor A trying to update vendor B's booking
-- Expected: FAIL (RLS policy violation)
/*
UPDATE package_bookings 
SET booking_status = 'confirmed' 
WHERE package_id = '<PACKAGE_B_ID>';
*/

-- Test 15: Package images RLS test
-- Run as vendor A
-- Expected: SUCCESS
/*
INSERT INTO package_images (package_id, storage_path, alt_text) 
VALUES ('<PACKAGE_A_ID>', 'vendor_123/packages/456/image.jpg', 'Test image');
*/

-- Test 16: Package availability RLS test
-- Run as vendor A
-- Expected: SUCCESS
/*
INSERT INTO package_availability (package_id, date, is_available) 
VALUES ('<PACKAGE_A_ID>', '2024-12-25', false);
*/

-- Test 17: Package addons RLS test
-- Run as vendor A
-- Expected: SUCCESS
/*
INSERT INTO package_addons (package_id, title, price, price_type) 
VALUES ('<PACKAGE_A_ID>', 'Test Addon', 500, 'fixed');
*/

-- Verification queries to check data integrity
-- Run these after the tests to verify expected results

-- Check packages created by vendor A
-- SELECT id, package_name, vendor_id FROM vendor_packages WHERE vendor_id = '<VENDOR_A_ID>';

-- Check package items for vendor A's packages
-- SELECT pi.*, vp.vendor_id FROM package_items pi 
-- JOIN vendor_packages vp ON pi.package_id = vp.id 
-- WHERE vp.vendor_id = '<VENDOR_A_ID>';

-- Check bookings for vendor A's packages
-- SELECT pb.*, vp.vendor_id FROM package_bookings pb 
-- JOIN vendor_packages vp ON pb.package_id = vp.id 
-- WHERE vp.vendor_id = '<VENDOR_A_ID>';

-- Check that no unauthorized data exists
-- SELECT COUNT(*) as unauthorized_packages FROM vendor_packages 
-- WHERE vendor_id = '<VENDOR_B_ID>' AND package_name LIKE '%Unauthorized%';

-- SELECT COUNT(*) as unauthorized_items FROM package_items pi 
-- JOIN vendor_packages vp ON pi.package_id = vp.id 
-- WHERE vp.vendor_id = '<VENDOR_B_ID>' AND pi.item_name = 'Unauthorized Item';
