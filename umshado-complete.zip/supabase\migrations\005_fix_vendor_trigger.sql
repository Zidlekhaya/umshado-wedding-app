-- Fix Vendor Trigger Function
-- This migration fixes the trigger function that's causing vendor signup to fail

-- Drop the existing trigger and function
DROP TRIGGER IF EXISTS trigger_create_vendor_profile_on_signup ON auth.users;
DROP FUNCTION IF EXISTS create_vendor_profile_on_signup();

-- Create a simpler, more robust trigger function
CREATE OR REPLACE FUNCTION create_vendor_profile_on_signup()
RETURNS TRIGGER AS $$
BEGIN
  -- Only create profile if user_type is 'vendor'
  IF NEW.raw_user_meta_data->>'user_type' = 'vendor' THEN
    BEGIN
      INSERT INTO vendor_profiles (
        user_id,
        business_name,
        business_description,
        category,
        contact_email,
        city,
        location,
        is_active,
        is_verified
      ) VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'business_name', 'My Business'),
        'Professional wedding services',
        COALESCE(NEW.raw_user_meta_data->>'category', 'other'),
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'location', 'Cape Town'),
        COALESCE(NEW.raw_user_meta_data->>'location', 'Cape Town'),
        TRUE,
        FALSE
      );
    EXCEPTION
      WHEN OTHERS THEN
        -- Log the error but don't fail the user creation
        RAISE LOG 'Failed to create vendor profile for user %: %', NEW.id, SQLERRM;
    END;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create the trigger
CREATE TRIGGER trigger_create_vendor_profile_on_signup
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION create_vendor_profile_on_signup();

-- Also create a manual function to create vendor profiles
CREATE OR REPLACE FUNCTION create_vendor_profile_manual(
  p_user_id UUID,
  p_business_name TEXT,
  p_category TEXT,
  p_location TEXT DEFAULT 'Cape Town'
)
RETURNS UUID AS $$
DECLARE
  profile_id UUID;
BEGIN
  INSERT INTO vendor_profiles (
    user_id,
    business_name,
    business_description,
    category,
    contact_email,
    city,
    location,
    is_active,
    is_verified
  ) VALUES (
    p_user_id,
    p_business_name,
    'Professional wedding services',
    p_category,
    (SELECT email FROM auth.users WHERE id = p_user_id),
    p_location,
    p_location,
    TRUE,
    FALSE
  ) RETURNING id INTO profile_id;
  
  RETURN profile_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission on the manual function
GRANT EXECUTE ON FUNCTION create_vendor_profile_manual TO authenticated;
