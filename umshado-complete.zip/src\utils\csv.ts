/**
 * CSV utility functions for RFC-4180 compliant CSV generation
 */

/**
 * Escapes a value for CSV according to RFC-4180
 * @param value - The value to escape
 * @returns Properly escaped CSV field
 */
export function csvEscape(value: unknown): string {
  const s = value ?? '';
  const str = String(s);
  
  // Quote if value contains quotes, commas, or newlines
  if (/[",\r\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

/**
 * Converts headers and rows to RFC-4180 compliant CSV string
 * @param headers - Array of column headers
 * @param rows - Array of rows, where each row is an array of values
 * @returns Complete CSV string
 */
export function toCSV(headers: string[], rows: (string | number | null | undefined)[][]): string {
  const headerLine = headers.map(csvEscape).join(',');
  const body = rows.map(r => r.map(csvEscape).join(',')).join('\r\n');
  return `${headerLine}\r\n${body}\r\n`;
}




